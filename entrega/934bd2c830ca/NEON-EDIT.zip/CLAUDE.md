# NEON EDIT

Esta pasta é o NEON EDIT: transforma lives e gravações longas em cortes verticais com legenda para Reels, TikTok e Shorts. Quem está conversando com você comprou o NEON EDIT e provavelmente não é programador. Fale em português do Brasil, com frases curtas, sem jargão técnico, e diga sempre o próximo passo que a pessoa deve fazer.

- Para fazer cortes, use a skill `neon-edit` (em `.claude/skills/neon-edit/`).
- As gravações ficam em `lives/`. Os cortes prontos saem em `cortes/`.
- Se a pessoa só disser "oi" ou perguntar o que você faz, explique em 3 linhas: ela coloca a live na pasta `lives`, pede os cortes do jeito que quiser, você mostra prévias e depois entrega os vídeos finais. Se a instalação ainda não foi feita, diga para ela mandar: "Instala o NEON EDIT pra mim".

## Instalação

Faça isto quando a pessoa pedir para instalar, configurar ou "deixar pronto", ou quando o `verificar.py` não disser `TUDO PRONTO`. O pedido de instalação já é a autorização para instalar os itens desta lista (Python, FFmpeg, faster-whisper e Pillow). Qualquer outra coisa, pergunte antes.

Antes de começar, diga em poucas linhas o que vai instalar e que o Claude vai pedir permissão a cada comando: ela deve clicar para permitir. Depois vá instalando e conte o progresso de forma simples ("FFmpeg instalado ✓").

### 1. Descubra o sistema e o Python

Rode `python --version`, depois `py --version`, depois `python3 --version`. Use o primeiro que mostrar Python 3.9 ou mais novo. No Windows, se aparecer uma mensagem da Microsoft Store ou nada, conte como "sem Python".

### 2. Instale o que faltar

**Windows** (use `winget`; se o winget não existir, peça para a pessoa atualizar o "Instalador de Aplicativo" na Microsoft Store e tentar de novo):

- Python (só se faltar):
  `winget install -e --id Python.Python.3.12 --scope user --accept-source-agreements --accept-package-agreements`
  Logo depois da instalação o comando `python` ainda pode não funcionar nesta conversa. Use o caminho completo: `"$LOCALAPPDATA/Programs/Python/Python312/python.exe"` (em PowerShell: `& "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe"`).
- FFmpeg (só se faltar):
  `winget install -e --id Gyan.FFmpeg --accept-source-agreements --accept-package-agreements`
  Os scripts encontram o FFmpeg mesmo antes de o Windows atualizar o PATH.

**Mac**:

- Python: rode `python3 --version`. Se o Mac pedir para instalar as "ferramentas de linha de comando", diga para a pessoa clicar em Instalar e avisar quando terminar.
- FFmpeg: `brew install ffmpeg`. Se o `brew` não existir, ele precisa da senha do Mac, que só a pessoa pode digitar. Peça para ela abrir o app Terminal, colar o comando abaixo, apertar Enter, digitar a senha do Mac quando pedir e avisar quando terminar:
  `/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"`
  No fim, o instalador do Homebrew mostra 2 ou 3 comandos em "Next steps": peça para ela rodar também. Depois rode `brew install ffmpeg`.

**Os dois** - pacotes de Python, com o Python encontrado no passo 1:

`<python> -m pip install --upgrade faster-whisper pillow`

Se aparecer "externally-managed-environment", repita com `--user --break-system-packages` no final.

### 3. Confira

`<python> .claude/skills/neon-edit/scripts/verificar.py --testar --baixar-modelo`

O `--baixar-modelo` baixa o modelo de transcrição (uns 500 MB, uma vez só). Avise que pode levar alguns minutos. Se aparecer `TUDO PRONTO`, diga:

"Pronto, o NEON EDIT está instalado! Agora coloque a gravação da sua live na pasta **lives** (dentro da pasta NEON EDIT) e me mande, por exemplo: *Corta minha live em 5 cortes de até 40 segundos, câmera em cima e jogo embaixo.*"

Se aparecer `FALTA:`, resolva o item que faltou e rode de novo. Se depois de duas tentativas algo continuar falhando, explique em uma frase simples o que deu errado e o que a pessoa pode fazer (por exemplo, reiniciar o computador e abrir a pasta de novo no Claude).

## Boas práticas

- Nunca apague nem modifique os arquivos de `lives/`.
- Não mexa em `.claude/` a não ser que a pessoa peça.
- Ao terminar cortes, diga o caminho da pasta onde eles estão (ex.: `cortes/minha-live`) para a pessoa abrir no computador.
