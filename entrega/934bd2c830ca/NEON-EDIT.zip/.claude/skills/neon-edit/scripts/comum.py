"""Funções compartilhadas pelos scripts do NEON EDIT."""
import json
import shutil
import subprocess
import sys
from pathlib import Path

SKILL_DIR = Path(__file__).resolve().parent.parent
FONTS_DIR = SKILL_DIR / "fonts"

# No Windows o terminal pode não ser UTF-8; evita erro ao imprimir acentos.
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def achar_exe(nome):
    """Acha ffmpeg/ffprobe mesmo logo depois de instalar, quando o PATH ainda não foi atualizado."""
    achado = shutil.which(nome)
    if achado:
        return achado
    import glob
    import os
    ext = ".exe" if os.name == "nt" else ""
    locais = []
    la = os.environ.get("LOCALAPPDATA")
    if la:
        locais.append(os.path.join(la, "Microsoft", "WinGet", "Links", nome + ext))
        locais += glob.glob(os.path.join(la, "Microsoft", "WinGet", "Packages", "*FFmpeg*", "**", "bin", nome + ext), recursive=True)
    for base in (os.environ.get("ProgramFiles", r"C:\Program Files"), "C:\\"):
        locais += glob.glob(os.path.join(base, "ffmpeg*", "bin", nome + ext))
    locais += [f"/opt/homebrew/bin/{nome}", f"/usr/local/bin/{nome}", f"/usr/bin/{nome}"]
    for p in locais:
        if os.path.isfile(p):
            return p
    return None


def exe(nome):
    return achar_exe(nome) or nome


def erro(msg, codigo=1):
    print(f"ERRO: {msg}", file=sys.stderr)
    sys.exit(codigo)


def exigir_ffmpeg():
    for nome in ("ffmpeg", "ffprobe"):
        if not achar_exe(nome):
            erro(f"'{nome}' não encontrado. Peça ao Claude: \"instala o NEON EDIT pra mim\".")


def rodar(cmd, cwd=None, mostrar=False):
    """Roda um comando e devolve stdout. Mostra o fim do stderr se falhar."""
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if p.returncode != 0:
        cauda = "\n".join(p.stderr.strip().splitlines()[-15:])
        erro(f"comando falhou ({cmd[0]}):\n{cauda}")
    if mostrar and p.stderr:
        print(p.stderr)
    return p.stdout


def info_video(caminho):
    out = rodar([exe("ffprobe"), "-v", "error", "-print_format", "json", "-show_format", "-show_streams", str(caminho)])
    d = json.loads(out)
    v = next((s for s in d.get("streams", []) if s.get("codec_type") == "video"), None)
    a = next((s for s in d.get("streams", []) if s.get("codec_type") == "audio"), None)
    if not v:
        erro("o arquivo não tem vídeo.")
    fps = v.get("avg_frame_rate", "30/1")
    try:
        n, dd = fps.split("/")
        fps = float(n) / float(dd) if float(dd) else 30.0
    except Exception:
        fps = 30.0
    return {
        "arquivo": str(caminho),
        "duracao": float(d["format"].get("duration", 0) or 0),
        "largura": int(v["width"]),
        "altura": int(v["height"]),
        "fps": round(fps, 3),
        "tem_audio": a is not None,
    }


def ler_json(caminho):
    return json.loads(Path(caminho).read_text(encoding="utf-8"))


def salvar_json(caminho, dados):
    Path(caminho).write_text(json.dumps(dados, ensure_ascii=False, indent=2), encoding="utf-8")


def hms(seg):
    seg = max(0, float(seg))
    h = int(seg // 3600)
    m = int((seg % 3600) // 60)
    s = int(seg % 60)
    return f"{h:02d}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"
