#!/usr/bin/env python3
"""
Gera os cortes verticais (1080x1920) a partir do cortes.json: recorta os trechos,
monta o layout, coloca título e legenda palavra por palavra.

Uso:
    python cortar.py cortes.json [--saida cortes] [--previa] [--so 1,3]

  --previa   versão leve (540x960) para aprovar antes da versão final
  --so       gera só os cortes com esses números

Layouts:
  camera-jogo    câmera em cima, jogo embaixo (precisa de "camera")
  jogo-camera    jogo em cima, câmera embaixo (precisa de "camera")
  cheia          um recorte vertical da tela inteira (use "foco_x" para escolher o ponto)
  jogo-borrado   a tela inteira no meio, com o fundo desfocado em cima e embaixo

Coordenadas de "camera" e "jogo" em PORCENTAGEM da tela (0 a 100), como no quadro.py:
  {"x": 78, "y": 22, "l": 22, "a": 30}   x/y = canto superior esquerdo, l = largura, a = altura
Veja config/cortes.exemplo.json.
"""
import argparse
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from comum import exe, FONTS_DIR, erro, exigir_ffmpeg, hms, info_video, ler_json, salvar_json  # noqa: E402

W, H = 1080, 1920

PADRAO = {
    "layout": "camera-jogo",
    "camera": None,
    "jogo": {"x": 0, "y": 0, "l": 100, "a": 100},
    "divisao": 0.40,
    "foco_x": 50,
    "titulo": True,
    "legenda": {"estilo": "marca-texto", "maiusculas": True, "palavras_por_linha": 3, "tamanho": 80, "ligada": True},
}
MARCA = {
    "fonte_legenda": "Inter Display Black",
    "fonte_titulo": "Inter Display Black",
    "cor_texto": "#FFFFFF",
    "cor_destaque": "#FFE600",
    "cor_texto_destaque": "#0A0A12",
    "cor_contorno": "#000000",
    "cor_faixa": "#FF2E93",
    "cor_texto_faixa": "#FFFFFF",
}


def mesclar(base, extra):
    out = dict(base)
    for k, v in (extra or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = mesclar(out[k], v)
        else:
            out[k] = v
    return out


def ass_cor(hexcor, alfa=0):
    h = hexcor.strip().lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    r, g, b = h[0:2], h[2:4], h[4:6]
    return f"&H{alfa:02X}{b}{g}{r}".upper()


def ass_tempo(t):
    t = max(0.0, t)
    h = int(t // 3600)
    m = int((t % 3600) // 60)
    s = t % 60
    return f"{h}:{m:02d}:{s:05.2f}"


def limpar(txt):
    return re.sub(r"[{}\\]", "", txt)


def snap(palavras, ini, fim):
    """Ajusta início e fim para não cortar palavras no meio."""
    dentro = [w for w in palavras if w["fim"] > ini - 0.05 and w["ini"] < fim + 0.05]
    if dentro:
        ini = min(ini, dentro[0]["ini"]) if dentro[0]["ini"] - ini < 1.0 else ini
        fim = max(fim, dentro[-1]["fim"]) if fim - dentro[-1]["fim"] < 1.5 else fim
    return max(0.0, ini - 0.15), fim + 0.25


def blocos_legenda(palavras, ppl):
    blocos, atual = [], []
    for w in palavras:
        if atual and (len(atual) >= ppl or w["ini"] - atual[-1]["fim"] > 0.45
                      or sum(len(x["w"]) for x in atual) + len(w["w"]) > 22):
            blocos.append(atual)
            atual = []
        atual.append(w)
    if atual:
        blocos.append(atual)
    return blocos


def posicoes(layout, divisao):
    """Devolve (y_legenda, y_titulo) em pixels no quadro 1080x1920."""
    topo = round(H * divisao)
    if layout == "camera-jogo":
        return topo + round((H - topo) * 0.42), topo
    if layout == "jogo-camera":
        jogo = H - topo
        return round(jogo * 0.72), jogo
    return 1350, 430


def gerar_ass(caminho, palavras, ini, dur, cfg, marca, titulo):
    leg = cfg["legenda"]
    tam = int(leg.get("tamanho", 80))
    y_leg, y_tit = posicoes(cfg["layout"], cfg["divisao"])
    estilos = [
        f"Style: Legenda,{marca['fonte_legenda']},{tam},{ass_cor(marca['cor_texto'])},{ass_cor(marca['cor_texto'])},"
        f"{ass_cor(marca['cor_contorno'])},&H64000000,0,0,0,0,100,100,0,0,1,7,2,5,60,60,0,1",
        f"Style: Titulo,{marca['fonte_titulo']},58,{ass_cor(marca['cor_texto_faixa'])},{ass_cor(marca['cor_texto_faixa'])},"
        f"{ass_cor(marca['cor_faixa'])},{ass_cor(marca['cor_faixa'])},0,0,0,0,100,100,0,0,3,18,0,5,70,70,0,1",
    ]
    ev = []
    if titulo:
        t = limpar(titulo.upper())
        ev.append(f"Dialogue: 1,{ass_tempo(0)},{ass_tempo(dur)},Titulo,,0,0,0,,{{\\pos(540,{y_tit})}}{t}")
    if leg.get("ligada", True) and palavras:
        rel = [{"w": w["w"], "ini": w["ini"] - ini, "fim": w["fim"] - ini} for w in palavras
               if w["fim"] > ini and w["ini"] < ini + dur]
        estilo = leg.get("estilo", "marca-texto")
        cd = ass_cor(marca["cor_destaque"])
        ctd = ass_cor(marca["cor_texto_destaque"])
        blocos = blocos_legenda(rel, int(leg.get("palavras_por_linha", 3)))
        for bi, b in enumerate(blocos):
            fim_bloco = b[-1]["fim"]
            if bi + 1 < len(blocos) and blocos[bi + 1][0]["ini"] - fim_bloco < 0.35:
                fim_bloco = blocos[bi + 1][0]["ini"]
            textos = [limpar(w["w"].upper() if leg.get("maiusculas", True) else w["w"]) for w in b]
            pos = f"{{\\pos(540,{y_leg})}}"
            if estilo == "simples":
                ev.append(f"Dialogue: 0,{ass_tempo(b[0]['ini'])},{ass_tempo(fim_bloco)},Legenda,,0,0,0,,{pos}{' '.join(textos)}")
                continue
            for j, w in enumerate(b):
                t0 = b[0]["ini"] if j == 0 else w["ini"]
                t1 = b[j + 1]["ini"] if j + 1 < len(b) else fim_bloco
                partes = []
                for k, txt in enumerate(textos):
                    if k == j and estilo == "marca-texto":
                        partes.append(f"{{\\1c{ctd}\\3c{cd}\\bord16\\shad0}}{txt}{{\\r}}")
                    elif k == j:
                        partes.append(f"{{\\1c{cd}}}{txt}{{\\r}}")
                    else:
                        partes.append(txt)
                sep = " \\h" if estilo == "marca-texto" else " "
                ev.append(f"Dialogue: 0,{ass_tempo(t0)},{ass_tempo(t1)},Legenda,,0,0,0,,{pos}{sep.join(partes)}")
    conteudo = (
        "[Script Info]\nScriptType: v4.00+\nPlayResX: 1080\nPlayResY: 1920\nWrapStyle: 0\nScaledBorderAndShadow: yes\n\n"
        "[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, "
        "Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n"
        + "\n".join(estilos)
        + "\n\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
        + "\n".join(ev) + "\n"
    )
    Path(caminho).write_text(conteudo, encoding="utf-8")


def caixa(reg, sw, sh):
    x = max(0, round(sw * reg["x"] / 100))
    y = max(0, round(sh * reg["y"] / 100))
    w = min(sw - x, round(sw * reg["l"] / 100))
    h = min(sh - y, round(sh * reg["a"] / 100))
    w -= w % 2
    h -= h % 2
    if w < 16 or h < 16:
        erro(f"região muito pequena: {reg}")
    return x, y, w, h


def preencher(rotulo_in, reg, sw, sh, ow, oh, foco_x=50, rotulo_out="o"):
    x, y, w, h = caixa(reg, sw, sh)
    fx = max(0, min(100, foco_x)) / 100
    return (f"[{rotulo_in}]crop={w}:{h}:{x}:{y},scale={ow}:{oh}:force_original_aspect_ratio=increase,"
            f"crop={ow}:{oh}:(iw-ow)*{fx:.3f}:(ih-oh)/2,setsar=1[{rotulo_out}]")


def grafo(cfg, sw, sh):
    lay = cfg["layout"]
    topo = round(H * cfg["divisao"])
    topo -= topo % 2
    if lay in ("camera-jogo", "jogo-camera"):
        if not cfg.get("camera"):
            erro(f"o layout {lay} precisa da posição da câmera ('camera' no cortes.json). Use quadro.py para ver.")
        cam = preencher("c", cfg["camera"], sw, sh, W, topo, 50, "cam")
        jogo = preencher("j", cfg["jogo"], sw, sh, W, H - topo, cfg.get("foco_x", 50), "jogo")
        ordem = "[cam][jogo]" if lay == "camera-jogo" else "[jogo][cam]"
        return f"[0:v]split=2[c][j];{cam};{jogo};{ordem}vstack=inputs=2[base]"
    if lay == "cheia":
        reg = cfg.get("jogo") or {"x": 0, "y": 0, "l": 100, "a": 100}
        return preencher("0:v", reg, sw, sh, W, H, cfg.get("foco_x", 50), "base")
    if lay == "jogo-borrado":
        x, y, w, h = caixa(cfg.get("jogo") or {"x": 0, "y": 0, "l": 100, "a": 100}, sw, sh)
        return (f"[0:v]crop={w}:{h}:{x}:{y},split=2[f][b];"
                f"[b]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},gblur=sigma=28,eq=brightness=-0.18[fb];"
                f"[f]scale={W}:-2,setsar=1[ff];[fb][ff]overlay=(W-w)/2:(H-h)/2-140[base]")
    erro(f"layout desconhecido: {lay}")


def nome_arquivo(i, titulo):
    import unicodedata
    base = unicodedata.normalize("NFKD", (titulo or "").lower()).encode("ascii", "ignore").decode()
    s = re.sub(r"[^a-z0-9]+", "-", base)[:40].strip("-")
    return f"corte-{i:02d}" + (f"-{s}" if s else "")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("config")
    ap.add_argument("--saida", default="cortes")
    ap.add_argument("--previa", action="store_true")
    ap.add_argument("--so", help="números dos cortes, ex.: 1,3")
    a = ap.parse_args()
    exigir_ffmpeg()
    base_dir = Path(a.config).resolve().parent
    c = ler_json(a.config)
    def achar(rel):
        """Caminho relativo vale a partir do cortes.json ou da pasta onde o script foi chamado."""
        p = Path(rel)
        if p.is_absolute():
            return p
        for base in (base_dir, Path.cwd()):
            if (base / p).exists():
                return (base / p).resolve()
        return (Path.cwd() / p).resolve()

    fonte = achar(c["fonte"])
    if not fonte.exists():
        erro(f"gravação não encontrada: {fonte}")
    info = info_video(fonte)
    sw, sh = info["largura"], info["altura"]
    palavras = []
    if c.get("transcricao"):
        tp = achar(c["transcricao"])
        if tp.exists():
            palavras = ler_json(tp).get("palavras", [])
        else:
            print(f"Aviso: transcrição não encontrada ({tp}). Os cortes saem sem legenda.")
    marca = mesclar(MARCA, c.get("marca"))
    padrao = mesclar(PADRAO, c.get("padrao"))
    so = {int(x) for x in a.so.split(",")} if a.so else None

    out = Path(a.saida).resolve()
    out.mkdir(parents=True, exist_ok=True)
    fontes_tmp = out / "_fontes"
    fontes_tmp.mkdir(exist_ok=True)
    for f in FONTS_DIR.iterdir():
        if f.suffix.lower() in (".ttf", ".otf"):
            shutil.copy2(f, fontes_tmp / f.name)
    for extra in (marca.get("arquivos_fonte") or []):
        p = achar(extra)
        if p.exists():
            shutil.copy2(p, fontes_tmp / p.name)

    relatorio = []
    for i, corte in enumerate(c.get("cortes", []), 1):
        if so and i not in so:
            continue
        cfg = mesclar(padrao, {k: v for k, v in corte.items() if k in PADRAO})
        ini, fim = float(corte["inicio"]), float(corte["fim"])
        if palavras:
            ini, fim = snap(palavras, ini, fim)
        fim = min(fim, info["duracao"])
        dur = fim - ini
        if dur <= 1:
            print(f"Corte {i}: trecho inválido, pulando.")
            continue
        nome = nome_arquivo(i, corte.get("titulo"))
        ass = out / f"{nome}.ass"
        titulo = corte.get("titulo") if cfg.get("titulo") else None
        gerar_ass(ass, palavras, ini, dur, cfg, marca, titulo)
        g = grafo(cfg, sw, sh) + f";[base]ass={ass.name}:fontsdir=_fontes"
        if a.previa:
            g += ",scale=540:960"
        g += "[v]"
        arq = out / (nome + ("-previa" if a.previa else "") + ".mp4")
        cmd = [exe("ffmpeg"), "-hide_banner", "-loglevel", "error", "-y", "-ss", f"{ini:.3f}", "-i", str(fonte), "-t", f"{dur:.3f}",
               "-filter_complex", g, "-map", "[v]", "-map", "0:a?", "-r", "30",
               "-c:v", "libx264", "-preset", "ultrafast" if a.previa else "medium", "-crf", "30" if a.previa else "20",
               "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "128k" if a.previa else "192k", "-movflags", "+faststart", arq.name]
        t0 = time.time()
        print(f"Corte {i}: {hms(ini)}–{hms(fim)} ({dur:.0f}s) · {cfg['layout']} · gerando...", flush=True)
        p = subprocess.run(cmd, cwd=out, capture_output=True, text=True, encoding="utf-8", errors="replace")
        if p.returncode != 0:
            print("\n".join(p.stderr.strip().splitlines()[-12:]), file=sys.stderr)
            erro(f"falha ao gerar o corte {i}")
        ass.unlink(missing_ok=True)
        capa = out / f"{nome}.jpg"
        subprocess.run([exe("ffmpeg"), "-hide_banner", "-loglevel", "error", "-y", "-ss", f"{min(1.5, dur / 2):.2f}", "-i", arq.name,
                        "-frames:v", "1", "-q:v", "4", capa.name], cwd=out)
        relatorio.append({"corte": i, "arquivo": str(arq), "capa": str(capa), "titulo": corte.get("titulo"), "inicio": round(ini, 2),
                          "fim": round(fim, 2), "duracao": round(dur, 1), "layout": cfg["layout"],
                          "legenda": cfg["legenda"].get("estilo"), "tempo_gerando_s": round(time.time() - t0, 1)})
        print(f"  ok em {time.time() - t0:.0f}s -> {arq.name}")
    shutil.rmtree(fontes_tmp, ignore_errors=True)
    salvar_json(out / "relatorio.json", relatorio)
    print(f"\n{len(relatorio)} corte(s) em {out}")


if __name__ == "__main__":
    main()
