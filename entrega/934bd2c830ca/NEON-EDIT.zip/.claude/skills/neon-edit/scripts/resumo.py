#!/usr/bin/env python3
"""
Gera um resumo da live para o Claude ler e escolher os momentos: a fala em blocos
com o horário de cada um e a marcação dos trechos de volume alto.

Uso:
    python resumo.py transcricao.json [--picos picos.json] [--bloco 15] [--pasta resumo]

Cria resumo/parte-01.txt, parte-02.txt... (cada parte cabe numa leitura).
Cada linha:  [01:02:15] [ALTO] texto falado nesses segundos
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from comum import hms, ler_json  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("transcricao")
    ap.add_argument("--picos")
    ap.add_argument("--bloco", type=float, default=15, help="segundos por linha")
    ap.add_argument("--pasta", default="resumo")
    ap.add_argument("--linhas_por_parte", type=int, default=350)
    a = ap.parse_args()

    palavras = ler_json(a.transcricao).get("palavras", [])
    vol, base = [], 0.0
    if a.picos:
        d = ler_json(a.picos)
        vol = d.get("volume_db", [])
        if vol:
            ordenado = sorted(vol)
            base = ordenado[int(len(ordenado) * 0.85)]  # 15% mais altos da live
    linhas, atual, ini_bloco = [], [], None
    for w in palavras:
        if ini_bloco is None:
            ini_bloco = w["ini"]
        if w["ini"] - ini_bloco >= a.bloco and atual:
            linhas.append((ini_bloco, " ".join(atual)))
            atual, ini_bloco = [], w["ini"]
        atual.append(w["w"])
    if atual:
        linhas.append((ini_bloco, " ".join(atual)))

    def marca(t):
        if not vol:
            return ""
        trecho = vol[int(t):int(t + a.bloco)]
        return " [ALTO]" if trecho and max(trecho) >= base else ""

    pasta = Path(a.pasta)
    pasta.mkdir(exist_ok=True)
    for f in pasta.glob("parte-*.txt"):
        f.unlink()
    partes = [linhas[i:i + a.linhas_por_parte] for i in range(0, len(linhas), a.linhas_por_parte)] or [[]]
    for k, parte in enumerate(partes, 1):
        txt = "\n".join(f"[{hms(t)}]{marca(t)} {texto}" for t, texto in parte)
        (pasta / f"parte-{k:02d}.txt").write_text(txt + "\n", encoding="utf-8")
    print(f"{len(linhas)} blocos em {len(partes)} parte(s) na pasta {pasta}/")


if __name__ == "__main__":
    main()
