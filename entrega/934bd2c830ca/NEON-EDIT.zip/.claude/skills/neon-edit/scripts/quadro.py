#!/usr/bin/env python3
"""
Tira uma foto (quadro) da gravação com uma grade de coordenadas por cima,
para o Claude ver onde fica a câmera (webcam) e o jogo e preencher o cortes.json.

Uso:
    python quadro.py live.mp4 --t 600 [--saida quadro.png]

A grade marca a porcentagem da largura e da altura (0 a 100) a cada 10%.
Também gera quadro-limpo.png, sem a grade.
"""
import argparse
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from comum import exe, FONTS_DIR, erro, exigir_ffmpeg, info_video  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("--t", type=float, default=None, help="segundo da gravação (padrão: 10% da duração)")
    ap.add_argument("--saida", default="quadro.png")
    a = ap.parse_args()
    exigir_ffmpeg()
    i = info_video(a.video)
    t = a.t if a.t is not None else i["duracao"] * 0.1
    saida = Path(a.saida)
    limpo = saida.with_name(saida.stem + "-limpo" + saida.suffix)
    r = subprocess.run([exe("ffmpeg"), "-hide_banner", "-loglevel", "error", "-y", "-ss", f"{t:.2f}", "-i", a.video,
                        "-frames:v", "1", str(limpo)], capture_output=True, text=True)
    if r.returncode != 0:
        erro(r.stderr[-600:])
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:
        print(f"Quadro salvo em {limpo} (instale Pillow para a versão com grade: pip install pillow)")
        return
    im = Image.open(limpo).convert("RGB")
    w, h = im.size
    d = ImageDraw.Draw(im, "RGBA")
    try:
        f = ImageFont.truetype(str(FONTS_DIR / "SpaceGrotesk-Bold.ttf"), max(14, h // 45))
    except OSError:
        f = ImageFont.load_default()
    for k in range(1, 10):
        x, y = w * k / 10, h * k / 10
        d.line([(x, 0), (x, h)], fill=(255, 230, 0, 150), width=2)
        d.line([(0, y), (w, y)], fill=(255, 46, 147, 150), width=2)
        d.text((x + 4, 4), f"{k * 10}", font=f, fill=(255, 230, 0, 255), stroke_width=3, stroke_fill=(0, 0, 0, 255))
        d.text((4, y + 2), f"{k * 10}", font=f, fill=(255, 46, 147, 255), stroke_width=3, stroke_fill=(0, 0, 0, 255))
    im.save(saida)
    print(f"Quadro do segundo {t:.0f} salvo em {saida} (com grade) e {limpo} (sem grade). Resolução {w}x{h}.")


if __name__ == "__main__":
    main()
