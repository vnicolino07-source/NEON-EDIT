#!/usr/bin/env python3
"""
Confere se o NEON EDIT está pronto para usar neste computador.

Uso:
    python verificar.py                 # confere o que está instalado
    python verificar.py --testar        # também gera um corte de teste de 3 segundos
    python verificar.py --baixar-modelo # também baixa o modelo de transcrição (uns 500 MB, uma vez só)

Não instala nada. Mostra o que falta e o comando para instalar.
No final imprime "TUDO PRONTO" ou "FALTA: ...".
"""
import importlib.util
import os
import platform
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from comum import FONTS_DIR, achar_exe  # noqa: E402

SO = {"Windows": "windows", "Darwin": "mac"}.get(platform.system(), "linux")

COMO_INSTALAR = {
    "ffmpeg": {
        "windows": "winget install -e --id Gyan.FFmpeg --accept-source-agreements --accept-package-agreements",
        "mac": "brew install ffmpeg",
        "linux": "sudo apt install -y ffmpeg",
    },
    "pacotes": {
        "windows": f'"{sys.executable}" -m pip install --upgrade faster-whisper pillow',
        "mac": f'"{sys.executable}" -m pip install --upgrade faster-whisper pillow',
        "linux": f'"{sys.executable}" -m pip install --upgrade faster-whisper pillow',
    },
}


def linha(nome, ok, extra=""):
    print(f"  {nome:<18} {'ok' if ok else 'FALTANDO'}{('  ' + extra) if extra else ''}")


def tem_libass(ffmpeg):
    try:
        r = subprocess.run([ffmpeg, "-hide_banner", "-filters"], capture_output=True, text=True,
                           encoding="utf-8", errors="replace")
        return any(l.split()[1:2] == ["ass"] for l in r.stdout.splitlines() if len(l.split()) > 1)
    except Exception:
        return False


def teste_corte(ffmpeg):
    """Gera 3 s de vídeo com legenda usando as fontes da skill. Confirma FFmpeg + libass + fontes."""
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        (tmp / "_fontes").mkdir()
        for f in FONTS_DIR.glob("*.[ot]tf"):
            (tmp / "_fontes" / f.name).write_bytes(f.read_bytes())
        (tmp / "t.ass").write_text(
            "[Script Info]\nScriptType: v4.00+\nPlayResX: 1080\nPlayResY: 1920\n\n"
            "[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, "
            "Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, "
            "Alignment, MarginL, MarginR, MarginV, Encoding\n"
            "Style: L,Inter Display Black,80,&H00FFFFFF,&H00FFFFFF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,6,0,2,60,60,520,1\n\n"
            "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
            "Dialogue: 0,0:00:00.00,0:00:03.00,L,,0,0,0,,TESTE AÇÃO NEON\n", encoding="utf-8")
        cmd = [ffmpeg, "-hide_banner", "-loglevel", "error", "-y",
               "-f", "lavfi", "-i", "color=c=0x0A0A12:s=1080x1920:d=3",
               "-f", "lavfi", "-i", "sine=f=440:d=3",
               "-vf", "ass=t.ass:fontsdir=_fontes", "-c:v", "libx264", "-preset", "ultrafast",
               "-c:a", "aac", "-shortest", "teste.mp4"]
        r = subprocess.run(cmd, cwd=tmp, capture_output=True, text=True, encoding="utf-8", errors="replace")
        ok = r.returncode == 0 and (tmp / "teste.mp4").exists() and (tmp / "teste.mp4").stat().st_size > 1000
        return ok, (r.stderr or "")[-400:]


def main():
    testar = "--testar" in sys.argv
    baixar = "--baixar-modelo" in sys.argv
    falta = []

    print(f"Sistema: {platform.system()} {platform.release()}  |  Python {sys.version.split()[0]}")
    py_ok = sys.version_info >= (3, 9)
    linha("Python 3.9+", py_ok)
    if not py_ok:
        falta.append("python")

    ffmpeg, ffprobe = achar_exe("ffmpeg"), achar_exe("ffprobe")
    linha("FFmpeg", bool(ffmpeg and ffprobe), ffmpeg or "")
    if not (ffmpeg and ffprobe):
        falta.append("ffmpeg")
    elif not tem_libass(ffmpeg):
        linha("legendas (libass)", False, "este FFmpeg não tem suporte a legendas; instale a versão completa")
        falta.append("ffmpeg")
    else:
        linha("legendas (libass)", True)

    fw = importlib.util.find_spec("faster_whisper") is not None
    linha("transcritor", fw, "faster-whisper")
    pil = importlib.util.find_spec("PIL") is not None
    linha("Pillow", pil)
    if not (fw and pil):
        falta.append("pacotes")

    fontes = sorted(p.name for p in FONTS_DIR.glob("*.[ot]tf"))
    linha("fontes", len(fontes) >= 2, ", ".join(fontes))
    if len(fontes) < 2:
        falta.append("fontes")

    if testar and "ffmpeg" not in falta:
        ok, msg = teste_corte(ffmpeg)
        linha("corte de teste", ok, "" if ok else msg)
        if not ok:
            falta.append("teste")

    if baixar and fw:
        print("\nBaixando o modelo de transcrição 'small' (uma vez só, pode levar alguns minutos)...")
        from faster_whisper import WhisperModel
        WhisperModel("small", device="cpu", compute_type="int8")
        linha("modelo small", True)

    print()
    if not falta:
        print("TUDO PRONTO")
        return
    print("FALTA: " + ", ".join(dict.fromkeys(falta)))
    for item in dict.fromkeys(falta):
        if item in COMO_INSTALAR:
            print(f"  {item}: {COMO_INSTALAR[item][SO]}")
        elif item == "python":
            print("  python: instale o Python 3.12 (Windows: winget install -e --id Python.Python.3.12)")
        elif item == "fontes":
            print("  fontes: a pasta fonts da skill está incompleta; baixe o NEON EDIT de novo.")
    if os.name == "nt" and "ffmpeg" in falta:
        print("  Depois de instalar o FFmpeg, rode este verificador de novo (não precisa fechar o Claude).")
    sys.exit(2)


if __name__ == "__main__":
    main()
