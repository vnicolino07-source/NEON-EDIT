#!/usr/bin/env python3
"""
Transcreve a gravação com o tempo de cada palavra (para escolher os momentos e para as legendas).

Uso:
    python transcrever.py live.mp4 [--saida transcricao.json] [--modelo small] [--idioma pt]
    python transcrever.py live.mp4 --janelas picos.json --margem 60     # só em volta dos picos (bem mais rápido)
    python transcrever.py live.mp4 --trechos 3600-3720,5400-5500        # só trechos específicos (segundos)

Usa faster-whisper (recomendado) ou openai-whisper, o que estiver instalado.
Modelos: tiny, base, small (padrão), medium. Maior = mais preciso e mais lento.

Saída (transcricao.json):
    {"palavras": [{"w": "texto", "ini": 12.34, "fim": 12.71}, ...], "trechos": [[ini, fim], ...]}
Os tempos são sempre da gravação original.
"""
import argparse
import importlib.util
import subprocess
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from comum import exe, erro, exigir_ffmpeg, hms, info_video, ler_json, salvar_json  # noqa: E402


def extrair_audio(video, ini, fim, destino):
    cmd = [exe("ffmpeg"), "-hide_banner", "-loglevel", "error", "-y"]
    if ini is not None:
        cmd += ["-ss", f"{ini:.3f}"]
    cmd += ["-i", str(video)]
    if fim is not None and ini is not None:
        cmd += ["-t", f"{fim - ini:.3f}"]
    cmd += ["-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", str(destino)]
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode != 0:
        erro(p.stderr[-800:])


def juntar_trechos(trechos, duracao):
    trechos = sorted([max(0.0, a), min(duracao, b)] for a, b in trechos if b > a)
    out = []
    for a, b in trechos:
        if out and a <= out[-1][1] + 5:
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b])
    return out


class Transcritor:
    def __init__(self, modelo, idioma, gpu=False):
        self.idioma = idioma
        if importlib.util.find_spec("faster_whisper"):
            from faster_whisper import WhisperModel
            self.tipo = "faster"
            print(f"Carregando faster-whisper ({modelo})... na primeira vez ele baixa o modelo.")
            # CPU por padrão: funciona em qualquer computador. --gpu só se a placa NVIDIA estiver configurada.
            if gpu:
                self.m = WhisperModel(modelo, device="cuda", compute_type="float16")
            else:
                self.m = WhisperModel(modelo, device="cpu", compute_type="int8")
        elif importlib.util.find_spec("whisper"):
            import whisper
            self.tipo = "openai"
            print(f"Carregando openai-whisper ({modelo})... na primeira vez ele baixa o modelo.")
            self.m = whisper.load_model(modelo)
        else:
            erro('nenhum transcritor instalado. Peça ao Claude: "instala o NEON EDIT pra mim".')

    def palavras(self, wav, deslocamento):
        out = []
        if self.tipo == "faster":
            segs, _ = self.m.transcribe(str(wav), language=self.idioma, word_timestamps=True,
                                        vad_filter=True, beam_size=1)
            for s in segs:
                for w in (s.words or []):
                    t = w.word.strip()
                    if t:
                        out.append({"w": t, "ini": round(w.start + deslocamento, 3), "fim": round(w.end + deslocamento, 3)})
        else:
            r = self.m.transcribe(str(wav), language=self.idioma, word_timestamps=True, fp16=False)
            for s in r.get("segments", []):
                for w in s.get("words", []):
                    t = w["word"].strip()
                    if t:
                        out.append({"w": t, "ini": round(w["start"] + deslocamento, 3), "fim": round(w["end"] + deslocamento, 3)})
        return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("--saida", default="transcricao.json")
    ap.add_argument("--modelo", default="small")
    ap.add_argument("--idioma", default="pt")
    ap.add_argument("--gpu", action="store_true", help="usa placa NVIDIA (só se já estiver configurada)")
    ap.add_argument("--janelas", help="picos.json do sinais.py: transcreve só em volta dos picos")
    ap.add_argument("--margem", type=float, default=60, help="segundos antes e depois de cada pico")
    ap.add_argument("--trechos", help="lista ini-fim em segundos, separada por vírgula")
    a = ap.parse_args()
    exigir_ffmpeg()
    info = info_video(a.video)
    if not info["tem_audio"]:
        erro("a gravação não tem áudio.")
    dur = info["duracao"]

    if a.trechos:
        trechos = [[float(x.split("-")[0]), float(x.split("-")[1])] for x in a.trechos.split(",")]
    elif a.janelas:
        picos = ler_json(a.janelas).get("picos", [])
        trechos = [[p["t"] - a.margem, p["t"] + a.margem] for p in picos]
    else:
        trechos = [[0.0, dur]]
    trechos = juntar_trechos(trechos, dur)
    total = sum(b - a_ for a_, b in trechos)
    print(f"Vou transcrever {hms(total)} de áudio em {len(trechos)} trecho(s).")

    tr = Transcritor(a.modelo, a.idioma, a.gpu)
    todas = []
    t0 = time.time()
    with tempfile.TemporaryDirectory() as tmp:
        for k, (ini, fim) in enumerate(trechos, 1):
            wav = Path(tmp) / f"t{k}.wav"
            inteiro = (ini == 0.0 and fim == dur)
            extrair_audio(a.video, None if inteiro else ini, None if inteiro else fim, wav)
            todas += tr.palavras(wav, 0.0 if inteiro else ini)
            print(f"  trecho {k}/{len(trechos)} ({hms(ini)}–{hms(fim)}) ok — {len(todas)} palavras até agora")
    todas.sort(key=lambda w: w["ini"])
    salvar_json(a.saida, {"palavras": todas, "trechos": trechos, "idioma": a.idioma, "modelo": a.modelo})
    print(f"Pronto em {hms(time.time() - t0)}. {len(todas)} palavras salvas em {a.saida}")


if __name__ == "__main__":
    main()
