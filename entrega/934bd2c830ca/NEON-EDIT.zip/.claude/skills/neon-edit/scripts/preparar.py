#!/usr/bin/env python3
"""
Confere o ambiente e lê as informações da gravação.

Uso:
    python preparar.py caminho/da/live.mp4

Mostra: duração, resolução, se tem áudio, e se FFmpeg e o transcritor estão instalados.
Não instala nada.
"""
import importlib.util
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from comum import achar_exe, hms, info_video  # noqa: E402


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    video = Path(sys.argv[1])
    print("Ambiente:")
    print(f"  Python ......... {sys.version.split()[0]}")
    for exe in ("ffmpeg", "ffprobe"):
        print(f"  {exe:<14} {'ok' if achar_exe(exe) else 'FALTANDO'}")
    fw = importlib.util.find_spec("faster_whisper") is not None
    ow = importlib.util.find_spec("whisper") is not None
    print(f"  faster-whisper . {'ok' if fw else 'faltando'}")
    print(f"  openai-whisper . {'ok' if ow else 'faltando'}")
    if not (fw or ow):
        print("  -> Falta o transcritor. Rode o verificar.py e siga a instalação do CLAUDE.md.")
    if not video.exists():
        print(f"\nArquivo não encontrado: {video}")
        sys.exit(1)
    if not (achar_exe("ffmpeg") and achar_exe("ffprobe")):
        sys.exit(1)
    i = info_video(video)
    print("\nGravação:")
    print(f"  Arquivo ........ {video.name}")
    print(f"  Duração ........ {hms(i['duracao'])} ({i['duracao']:.0f} s)")
    print(f"  Resolução ...... {i['largura']}x{i['altura']} @ {i['fps']} fps")
    print(f"  Áudio .......... {'sim' if i['tem_audio'] else 'NÃO (sem áudio não dá para legendar nem achar os momentos pela fala)'}")
    horas = i["duracao"] / 3600
    if horas > 0.5:
        print("\nDica: em gravações longas, rode primeiro o sinais.py e transcreva só as janelas")
        print("      com mais movimento (transcrever.py --janelas picos.json). É bem mais rápido.")


if __name__ == "__main__":
    main()
