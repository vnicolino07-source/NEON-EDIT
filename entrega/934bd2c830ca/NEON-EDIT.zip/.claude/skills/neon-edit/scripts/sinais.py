#!/usr/bin/env python3
"""
Mede o volume da gravação segundo a segundo e encontra os picos (gritos, risadas,
reações, momentos de agito). Usa só o FFmpeg, então é rápido mesmo em lives longas.

Uso:
    python sinais.py live.mp4 [--saida picos.json] [--max 30]

Saída (picos.json):
    {"duracao": ..., "volume_db": [... um valor por segundo ...],
     "picos": [{"t": 3721.0, "pontuacao": 2.4, "inicio_sugerido": 3700.0}, ...]}
"""
import argparse
import re
import statistics
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from comum import exe, exigir_ffmpeg, hms, info_video, salvar_json  # noqa: E402


def volume_por_segundo(video):
    cmd = [exe("ffmpeg"), "-hide_banner", "-nostats", "-i", str(video), "-vn", "-ac", "1",
           "-af", "aresample=8000,asetnsamples=n=8000:p=0,astats=metadata=1:reset=1,"
                  "ametadata=print:key=lavfi.astats.Overall.RMS_level:file=-",
           "-f", "null", "-"]
    p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if p.returncode != 0:
        print("\n".join(p.stderr.splitlines()[-10:]), file=sys.stderr)
        sys.exit(1)
    vals = []
    for m in re.finditer(r"RMS_level=(-?[\d.]+|-inf|inf)", p.stdout):
        v = m.group(1)
        vals.append(-90.0 if "inf" in v else max(-90.0, float(v)))
    return vals


def achar_picos(vol, maximo, janela=90, distancia=40):
    n = len(vol)
    if n == 0:
        return []
    # suaviza em 3 s e compara com a mediana dos arredores
    suave = [sum(vol[max(0, i - 1):i + 2]) / len(vol[max(0, i - 1):i + 2]) for i in range(n)]
    pont = []
    for i in range(n):
        viz = suave[max(0, i - janela):min(n, i + janela)]
        med = statistics.median(viz)
        desv = statistics.pstdev(viz) or 1.0
        pont.append((suave[i] - med) / desv)
    ordem = sorted(range(n), key=lambda i: pont[i], reverse=True)
    escolhidos = []
    for i in ordem:
        if pont[i] < 1.0 or len(escolhidos) >= maximo:
            break
        if all(abs(i - j) >= distancia for j in escolhidos):
            escolhidos.append(i)
    escolhidos.sort()
    return [{"t": float(i), "hora": hms(i), "pontuacao": round(pont[i], 2),
             "inicio_sugerido": float(max(0, i - 20))} for i in escolhidos]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("--saida", default="picos.json")
    ap.add_argument("--max", type=int, default=30, help="quantos picos guardar")
    a = ap.parse_args()
    exigir_ffmpeg()
    i = info_video(a.video)
    if not i["tem_audio"]:
        print("A gravação não tem áudio: não há como medir os picos.")
        sys.exit(1)
    print(f"Medindo o volume de {hms(i['duracao'])} de gravação...")
    vol = volume_por_segundo(a.video)
    picos = achar_picos(vol, a.max)
    salvar_json(a.saida, {"duracao": i["duracao"], "volume_db": [round(v, 1) for v in vol], "picos": picos})
    print(f"{len(picos)} picos encontrados. Salvo em {a.saida}")
    for p in picos[:15]:
        print(f"  {p['hora']:>8}  intensidade {p['pontuacao']}")


if __name__ == "__main__":
    main()
