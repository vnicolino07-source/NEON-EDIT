# Layouts e legendas

Todos os cortes saem em 1080x1920 (9:16), 30 fps.

## Layouts

| Nome | Como fica | Quando usar | Precisa de |
|---|---|---|---|
| `camera-jogo` | Câmera em cima, jogo embaixo, título na divisão | Live com webcam | `camera` |
| `jogo-camera` | Jogo em cima, câmera embaixo, título na divisão | Quando o jogo é o mais importante | `camera` |
| `cheia` | Um recorte vertical da tela | Sem câmera, ou quando a ação fica num ponto só | `foco_x` (opcional) |
| `jogo-borrado` | A tela inteira no meio e o fundo desfocado | Quando não dá para cortar as laterais (mapa, HUD, texto) | nada |

Ajustes:

- `divisao`: quanto da altura a câmera ocupa (padrão 0.40 = 40%).
- `camera` e `jogo`: caixas em % da tela original: `{"x": 78, "y": 22, "l": 22, "a": 30}`. Use o `quadro.py` para medir.
- `foco_x`: ponto do recorte horizontal do jogo (0 esquerda, 50 centro, 100 direita).

## Legendas

`"legenda": {"estilo": "marca-texto", "maiusculas": true, "palavras_por_linha": 3, "tamanho": 80, "ligada": true}`

| Estilo | Visual |
|---|---|
| `marca-texto` | A palavra falada ganha um fundo na cor de destaque, como marca-texto |
| `karaoke` | A palavra falada muda para a cor de destaque |
| `simples` | Frase inteira em branco com contorno, sem destaque |

## Cores e fontes (bloco `marca`)

```json
"marca": {
  "fonte_legenda": "Inter Display Black",
  "fonte_titulo": "Inter Display Black",
  "cor_texto": "#FFFFFF",
  "cor_destaque": "#FFE600",
  "cor_texto_destaque": "#0A0A12",
  "cor_contorno": "#000000",
  "cor_faixa": "#FF2E93",
  "cor_texto_faixa": "#FFFFFF",
  "arquivos_fonte": ["minha-fonte.ttf"]
}
```

Fontes que já vêm na skill: **Inter Display Black** e **Space Grotesk** (Bold). Para usar a fonte da pessoa, coloque o arquivo .ttf/.otf na pasta de trabalho, liste em `arquivos_fonte` e use o nome da família em `fonte_legenda`.
