# Como escolher os melhores momentos de uma live

Leia todas as partes do resumo antes de escolher. Marque os candidatos e depois escolha os melhores, sem repetir assunto.

## O que faz um bom corte

1. **Começa forte.** Os primeiros 2 segundos já têm ação, uma frase de impacto, uma pergunta ou uma reação. Se o momento bom começa depois de uma enrolação, comece o corte mais perto dele.
2. **Tem começo, meio e fim.** A pessoa entende o que aconteceu sem ter visto a live. Termine logo depois do desfecho (a risada, a resposta, o resultado), sem arrastar.
3. **Tem emoção.** Picos marcados como [ALTO] no resumo costumam ser gritos, risadas, sustos, vitórias, derrotas e reações ao chat. Confirme pela fala que o pico é interessante e não só barulho.
4. **Uma ideia só.** Uma história, uma dica, uma opinião ou um momento engraçado por corte.
5. **Duração certa.** Entre 20 e 60 segundos, a não ser que a pessoa peça outra. Mais curto se o momento for só uma reação.

## Tipos de momento que costumam funcionar

- Reação forte a algo que aconteceu no jogo (susto, morte, conquista, bug engraçado).
- Interação com o chat (alguém pediu algo e a pessoa fez, ou uma resposta engraçada).
- Opinião polêmica ou frase marcante, dita com convicção.
- História curta contada durante a live.
- Dica ou explicação útil, com começo e fim claros.
- Primeira vez fazendo algo, desafio, aposta.

## Evite

- Trechos que dependem de algo que aconteceu muito antes para fazer sentido.
- Silêncio longo, menus, loading, pausa para ir ao banheiro.
- Brigas com pessoas reais, dados pessoais, conteúdo que pode ser removido pela plataforma.
- Dois cortes sobre o mesmo momento.

## Títulos

- Até 8 palavras, em linguagem de conversa, descrevendo o que acontece ("O chat pediu e ele fez", "Primeira coisa que fiz no jogo").
- Nada de mentira ou exagero que o vídeo não mostra.
- Sem citar nomes de outras pessoas sem necessidade.

## Lista para aprovação

Mostre assim:

| Nº | Início | Fim | Duração | Título | Por que funciona |
|---|---|---|---|---|---|
| 1 | 01:02:15 | 01:02:52 | 37 s | ... | reação forte + desfecho engraçado |
