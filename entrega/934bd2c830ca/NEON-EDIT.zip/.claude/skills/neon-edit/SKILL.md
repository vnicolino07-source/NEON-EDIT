---
name: neon-edit
description: NEON EDIT - transforma lives e gravações longas (gameplay, react, podcast, aula) em vários cortes verticais 1080x1920 com legenda palavra por palavra, título e layouts como câmera em cima e jogo embaixo. Use sempre que a pessoa enviar ou citar uma live/gravação e pedir cortes, clipes, melhores momentos, shorts, reels ou tiktoks.
---

# NEON EDIT

Você recebe uma gravação longa e entrega vários cortes verticais prontos para revisar e postar. Você escolhe os momentos lendo a fala e os picos de volume, monta o layout que a pessoa pedir e coloca título e legenda no estilo dela. Fale sempre em português do Brasil, com frases curtas e sem termos técnicos: quem usa o NEON EDIT normalmente não é programador.

## Pastas

Tudo acontece dentro da pasta NEON EDIT (a pasta aberta no Claude):

- `lives/` - a pessoa coloca aqui as gravações.
- `cortes/<nome-da-live>/` - você entrega aqui os cortes finais.
- `cortes/<nome-da-live>/previa/` - prévias para aprovar.
- `cortes/<nome-da-live>/_trabalho/` - arquivos de trabalho (picos, transcrição, resumo, cortes.json).

`<nome-da-live>` é o nome do arquivo sem extensão, sem espaços e sem acentos. Os scripts ficam em `.claude/skills/neon-edit/scripts/`. Rode tudo a partir da pasta NEON EDIT, por exemplo:

```
python .claude/skills/neon-edit/scripts/preparar.py "lives/minha live.mp4"
```

No Windows, se `python` não funcionar, use `py`. Caminhos com espaço vão entre aspas.

## Regras

- Antes do primeiro corte da conversa, rode `verificar.py`. Se não aparecer `TUDO PRONTO`, siga a seção "Instalação" do `CLAUDE.md` da pasta NEON EDIT antes de continuar.
- Só corte gravações da própria pessoa ou que ela tem autorização para usar. Se parecer conteúdo de outro criador, pergunte uma vez se ela tem permissão.
- Não prometa viralização, número de visualizações nem prazo exato. Diga quanto tempo cada etapa deve levar com base no tamanho da gravação e avise quando terminar.
- Nunca invente o que foi dito na live. Títulos e escolha dos momentos saem da transcrição.
- Sempre gere uma **prévia** antes da versão final e espere a aprovação, a não ser que a pessoa diga para seguir direto.
- Legenda e título nunca ficam no topo do vídeo: o Instagram e o TikTok cobrem essa área. Os scripts já posicionam certo; não mude isso sem a pessoa pedir.
- Não apague nem altere as gravações da pasta `lives/`.

## Passo 1: prepare

1. Ache a gravação. Se a pessoa não disse qual, liste os vídeos de `lives/` (.mp4, .mkv, .mov, .flv, .webm) e pergunte. Se a pasta estiver vazia, peça para ela colocar a gravação em `lives/` (arrastando o arquivo para lá) e avisar. Links não são baixados: se ela mandar um link, peça para baixar o vídeo da plataforma e colocar em `lives/`.
2. Rode `preparar.py <video>` para ver duração, resolução e se tem áudio.
3. Crie `cortes/<nome-da-live>/_trabalho/`.

## Passo 2: entenda o pedido

Pergunte só o que a pessoa não disse, numa mensagem curta:

- **Quantos cortes** (padrão: 5) e **duração** de cada um (padrão: 20 a 60 segundos).
- **Layout** (veja `references/layouts.md`). Se a live tem câmera (webcam), sugira "câmera em cima, jogo embaixo". Sem câmera, sugira "jogo com fundo desfocado".
- **Legenda**: marca-texto (padrão), karaokê ou simples; cores, se ela quiser as da marca dela.
- **Título** em faixa no corte (sim por padrão).
- Se ela quer algum momento específico ("a parte que eu caí da moto", "quando o chat pediu tal coisa").

Se ela disser "faz do seu jeito", use os padrões e siga.

## Passo 3: encontre os momentos

Salve os arquivos deste passo em `cortes/<nome>/_trabalho/` (abaixo, `_trabalho/` é abreviação desse caminho).

1. `sinais.py <video> --saida _trabalho/picos.json` mede o volume segundo a segundo (gritos, risadas, reações). É rápido.
2. Transcreva:
   - Gravação de até 30 minutos: `transcrever.py <video> --saida _trabalho/transcricao.json`.
   - Gravação longa: `transcrever.py <video> --janelas _trabalho/picos.json --margem 60 --saida _trabalho/transcricao.json`, mais os trechos que a pessoa citou com `--trechos ini-fim`.
   - `--modelo base` se o computador for lento; `--modelo medium` se a pessoa quiser mais precisão.
   - A transcrição roda no processador e pode levar vários minutos (em computador comum, algo perto do tempo do áudio transcrito com o modelo small). Avise a estimativa antes, rode em segundo plano quando passar de uns minutos e acompanhe.
3. `resumo.py _trabalho/transcricao.json --picos _trabalho/picos.json --pasta _trabalho/resumo` cria `parte-01.txt`... Leia todas as partes.
4. Escolha os momentos seguindo `references/escolha-de-momentos.md`.
5. Mostre a lista: número, início e fim, duração, título e por que esse momento funciona. Espere o ok ou ajustes.

Confira o `--help` de cada script se precisar das opções exatas.

## Passo 4: defina o layout

Para layouts com câmera, rode `quadro.py <video> --t <segundo> --saida _trabalho/quadro.png` e **abra a imagem**. A grade mostra porcentagens de 0 a 100. Anote a caixa da câmera (`x`, `y`, `l` = largura, `a` = altura, em %), com uma pequena folga para dentro para não pegar a borda do overlay. Se a câmera mudar de lugar ao longo da live, tire quadros de momentos diferentes e use `camera` dentro do corte específico.

Para tirar a câmera e outros elementos da tela do jogo, ajuste a região `jogo`. Para escolher o ponto do recorte horizontal do jogo, use `foco_x` (0 = esquerda, 50 = centro, 100 = direita).

## Passo 5: gere a prévia

1. Monte `_trabalho/cortes.json` (modelo em `config/cortes.exemplo.json`). Em `fonte` e `transcricao`, use caminhos a partir da pasta NEON EDIT (ex.: `lives/minha-live.mp4` e `cortes/minha-live/_trabalho/transcricao.json`). Tudo que está em `padrao` vale para todos os cortes; cada corte pode sobrescrever `layout`, `camera`, `jogo`, `foco_x`, `divisao`, `titulo` e `legenda`.
2. Rode `cortar.py cortes/<nome>/_trabalho/cortes.json --saida cortes/<nome>/previa --previa`.
3. **Abra a capa (.jpg) de pelo menos um corte** para conferir câmera, jogo e legenda. Corrija antes de mostrar.
4. Diga onde estão as prévias (`cortes/<nome>/previa`) e pergunte o que ajustar: começar mais cedo ou mais tarde, título, layout, estilo ou cor da legenda.

## Passo 6: versão final

Rode `cortar.py cortes/<nome>/_trabalho/cortes.json --saida cortes/<nome>` (sem `--previa`). Para refazer só alguns: `--so 2,4`. Diga onde estão os arquivos .mp4 (1080x1920) e ofereça uma legenda de post para cada corte, com o gancho na primeira linha.

## Problemas comuns

- **"FFmpeg não encontrado" logo depois de instalar**: os scripts procuram o FFmpeg nas pastas padrão do instalador; rode `verificar.py` de novo. Se continuar, peça para a pessoa fechar e abrir o Claude e abrir a pasta NEON EDIT de novo.
- **Legenda sem acento ou com outra fonte**: confira se as fontes estão em `fonts/`; o `cortar.py` copia elas para `_fontes` na pasta de saída.
- **Câmera cortada ou com borda**: ajuste a caixa `camera` em 1 ou 2 pontos e gere a prévia só desse corte com `--so`.
- **Corte começa no meio da frase**: o script já ajusta início e fim às palavras. Se ainda acontecer, mova `inicio` 1 ou 2 segundos para trás.
- **Transcrição muito lenta**: use `--janelas` e `--modelo base`.
- **Erro de memória na transcrição**: use `--modelo base` e feche outros programas pesados.
