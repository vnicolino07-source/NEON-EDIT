# Exemplos aprovados (referências de qualidade)

Vídeos editados com este motor e aprovados pelo titular. Servem para mostrar **o nível de qualidade esperado**:
ritmo, precisão das legendas, efeitos literais, acabamento. **Não são modelos para copiar**: cada vídeo novo tem a sua
própria direção (`neon-editor/references/18-direcao-adaptativa.md`).

| Pasta | Vídeo | Situação |
|---|---|---|
| `v002/` | "O Claude acabou de matar os editores de vídeo" (52 s) | aprovado em 29/10/2026; incluído com os direitos verificados (ver `v002/DIREITOS.md`) |

## Adicionar um vídeo aprovado novo

1. Copie `_modelo/` para `<id>/`.
2. Preencha `FICHA.md`: números, direção completa, componentes, correções pedidas e o que o tornou aprovado.
3. Coloque:
   - o vídeo aprovado (≤ 720p, para o pacote ficar leve; o master fica com o titular);
   - a composição (`codigo/Video.tsx`), `cortes.json`, `correcoes.json` e a marca usada.
4. Preencha `DIREITOS.md`. Só inclua no pacote distribuído se todos os itens estiverem liberados.
5. Atualize a tabela acima e `neon-editor/references/16-casos-aprovados.md`.
