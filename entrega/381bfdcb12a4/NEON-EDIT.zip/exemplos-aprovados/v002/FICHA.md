# v002 — "O Claude acabou de matar os editores de vídeo"

- **Aprovado em:** 29/10/2026, na primeira prévia, sem pedidos de correção.
- **Arquivo no pacote:** `v002_aprovado_720x1280.mp4`, a prévia aprovada (H.264, AAC, −14,7 LUFS). O master 1080×1920 (−14,4 LUFS / −1,0 dBTP) fica com o titular.
- **Números:**
  - bruto 96,3 s → 52,3 s a 1,15×;
  - 229 palavras (4,4/s);
  - 50 eventos visuais (maior intervalo 1,81 s);
  - 38 efeitos sonoros.
- **Linguagem visual:** "a própria edição vira o efeito". O que a pessoa pede ao editor acontece na tela no mesmo instante.
- **Direção completa:** `neon-editor/references/16-casos-aprovados.md` (tabela por tempo).
- **Código:**
  - `codigo/Video.tsx` (a composição, que depende do motor original e dos dados do vídeo);
  - `codigo/entry-v002.tsx`;
  - `codigo/cortes.json` e `codigo/correcoes.json` (decisões de corte e de texto);
  - `codigo/marca-neon.json` (a marca usada);
  - `codigo/mapa_sugerido.md` (o que o analisador do kit sugere para este vídeo).
- **Para reproduzir:** é preciso o bruto, que não está no pacote. O procedimento está no pacote privado do titular. O pipeline do kit reproduz exatamente os dados aprovados.
- **Defeito menor encontrado depois da aprovação:** o campo de comentário do CTA é 96 px mais largo que o card. Foi corrigido na demonstração do kit; o vídeo aprovado não foi alterado.
