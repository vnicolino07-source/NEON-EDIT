/**
 * V002 — "O Claude acabou de matar os editores de vídeo" (WhatsApp Video 2026-10-29 at 11.03.13)
 * Direção própria: palavra explodindo no gancho; tela vira celular; texto gigante atrás da cabeça;
 * tela cortada no meio; a tela desce e a explicação sobe (exatamente como a fala pede).
 */
import React from 'react';
import {AbsoluteFill, Img, interpolate, useCurrentFrame} from 'remotion';
import {COLOR, FONT, SPACE} from '../../brand/neon';
import {holdRender} from '../../engine/render';
import {buildBlocks, blockAt} from '../../engine/captions';
import {fgSrc, frameSrc} from '../../engine/Plate';
import {SoundTrack, Sfx} from '../../engine/SoundTrack';
import {FPS, T, TE, TOTAL_FRAMES, WORDS} from '../../engine/timing';
import {easeBrand, easeCss, phase, pop, popOut} from '../../motion/neonMotion';
import {ensureNeonFonts, NeonCaption, camRect} from '../../components/neon/NeonLayout';
import {Label, NeonPrompt, NeonToasts} from '../../components/neon/NeonCards';
import {ShatterText3D} from '../../components/experimental/ShatterText3D';
import {IdentityCard, KineticGiantText, LiveExplain, OnePrompt, PostPanel, ReferenceScan, SelectionBox, StepTrack, TemplateCard} from '../../components/experimental/V002Motions';

ensureNeonFonts(() => holdRender('fonts'));

// ---------------- tempos (todos derivados das palavras faladas) ----------------
const S = {
	matar: T('matar'), editores: T('editores'), esse: T('esse', 1), prompt1: T('prompt', 1), mandei: T('mandei'),
	edita: T('edita', 1), identidade: T('identidade'), visual: T('visual'), efeitos: T('efeitos'),
	passo: T('passo', 1), simples: T('simples'), gravo: T('gravo'), jogo: T('jogo'), mando: T('mando'), jeito: T('jeito'),
	ele2: T('ele', 4), pronto: T('pronto', 1), postar: T('postar'), visualiz: T('visualizacoes'),
	tudo1: T('tudo', 1), aqui2: T('aqui', 2), se1: T('se', 1), texto: T('texto'), gigante: T('gigante'), cabeca: T('cabeca'), colocar2: T('colocar', 2),
	se2: T('se', 2), corte: T('corte'), meio: T('meio'), isso1: TE('isso', 1),
	se3: T('se', 3), baixo: T('baixo'), tela3: T('tela', 3), cima: T('cima'), tambem: T('tambem'),
	tudo2: T('tudo', 2), prompt2: T('prompt', 2), modelo: T('modelo'), referencia: T('referencia'), estilo: T('estilo'),
	gostou: T('gostou'), comenta: T('comenta'), ia: T('ia'), direct: T('direct'),
};
const END = TOTAL_FRAMES / FPS;
const clamp = (x: number) => Math.max(0, Math.min(1, x));
const ramp = (t: number, a: number, b: number) => interpolate(t, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: (x) => x * x * (3 - 2 * x)});
const win = (t: number, a: number, b: number, d = 0.3) => ramp(t, a - d, a) * (1 - ramp(t, b, b + d));

// ---------------- layouts do apresentador ----------------
const R = {
	full: {left: 0, top: 0, width: 1080, height: 1920, radius: 0},
	split: camRect(1),
	phone: {left: 60, top: 330, width: 560, height: 996, radius: 64},
};
const modes = (t: number) => {
	const split = Math.max(win(t, S.edita - 0.05, S.passo - 0.25), win(t, S.gravo - 0.1, S.ele2 - 0.25), win(t, S.baixo + 0.05, S.gostou - 0.25, 0.4));
	const phone = win(t, S.pronto - 0.05, S.tudo1 - 0.25, 0.35);
	return {split, phone, full: Math.max(0, 1 - split - phone)};
};
// enquadramento em tela cheia: degraus nas palavras de ênfase
const REFRAMES: [number, number][] = [
	[0, 1.16], [S.editores + 0.4, 1.06], [S.esse, 1.1], [S.passo, 1.04], [T('fazer', 1), 1.09], [S.simples, 1.14], [S.ele2, 1.05],
	[S.tudo1, 1.0], [S.se1, 1.06], [S.cabeca, 1.12], [S.se2, 1.04], [S.gostou, 1.12], [S.comenta, 1.05], [S.direct, 1.1],
];
const zoomAt = (t: number) => {
	let z = REFRAMES[0][1];
	let prev = z;
	for (const [at, v] of REFRAMES) {
		if (t < at) break;
		z = prev + (v - prev) * ramp(t, at - 0.04, at + 0.2);
		prev = v;
	}
	return z;
};
const FACE = {x: 540, y: 760};

const Stage: React.FC<{frame: number; t: number; behind?: React.ReactNode; cutout: boolean}> = ({frame, t, behind, cutout}) => {
	const m = modes(t);
	const rect = (k: 'left' | 'top' | 'width' | 'height' | 'radius') => m.full * R.full[k] + m.split * R.split[k] + m.phone * R.phone[k];
	const r = {left: rect('left'), top: rect('top'), width: rect('width'), height: rect('height'), radius: rect('radius')};
	// transformação da imagem dentro do retângulo
	const z = zoomAt(t);
	const sFull = z, txFull = (1 - z) * FACE.x, tyFull = (1 - z) * FACE.y;
	const sSplit = R.split.width / 1080, txSplit = 0, tySplit = R.split.height * 0.3 - FACE.y * sSplit;
	const sPhone = R.phone.width / 1080, txPhone = 0, tyPhone = (R.phone.height - 1920 * sPhone) / 2;
	const s = m.full * sFull + m.split * sSplit + m.phone * sPhone;
	const tx = m.full * txFull + m.split * txSplit + m.phone * txPhone;
	const ty = m.full * tyFull + m.split * tySplit + m.phone * tyPhone;
	// tela cortada no meio
	const cut = phase(t, S.meio - 0.05, 0.4, easeBrand) * (1 - phase(t, S.isso1 - 0.05, 0.3, easeCss));
	const laser = phase(t, S.corte, 0.35, easeCss) * (1 - phase(t, S.meio + 0.1, 0.25));
	const content = (
		<div style={{position: 'absolute', left: 0, top: 0, width: 1080, height: 1920, transformOrigin: '0 0', transform: `translate(${tx}px, ${ty}px) scale(${s})`}}>
			<Img src={frameSrc(frame)} style={{position: 'absolute', width: 1080, height: 1920}} />
			{behind ? <AbsoluteFill>{behind}</AbsoluteFill> : null}
			{cutout ? <Img src={fgSrc(frame)} style={{position: 'absolute', width: 1080, height: 1920}} /> : null}
		</div>
	);
	const half = (top: boolean) => (
		<div style={{position: 'absolute', left: 0, top: top ? 0 : r.height / 2, width: r.width, height: r.height / 2, overflow: 'hidden', transform: `translate(${(top ? -1 : 1) * 46 * cut}px, ${(top ? -1 : 1) * 60 * cut}px) rotate(${(top ? -1 : 1) * 2.2 * cut}deg)`, boxShadow: cut > 0.01 ? `0 0 0 ${4 * cut}px ${COLOR.lime}` : undefined}}>
			<div style={{position: 'absolute', left: 0, top: top ? 0 : -r.height / 2, width: r.width, height: r.height}}>{content}</div>
		</div>
	);
	return (
		<div style={{position: 'absolute', left: r.left, top: r.top, width: r.width, height: r.height, borderRadius: r.radius, overflow: cut > 0.001 ? 'visible' : 'hidden', background: COLOR.cam, boxShadow: m.phone > 0.01 ? `0 0 0 ${18 * m.phone}px ${COLOR.panel}, 0 0 0 ${22 * m.phone}px ${COLOR.line}` : undefined}}>
			{cut > 0.001 ? (
				<>
					{half(true)}
					{half(false)}
				</>
			) : (
				<div style={{position: 'absolute', inset: 0, borderRadius: r.radius, overflow: 'hidden'}}>{content}</div>
			)}
			{laser > 0 ? <div style={{position: 'absolute', left: 0, top: r.height / 2 - 4, height: 8, width: `${laser * 100}%`, background: COLOR.lime, boxShadow: `0 0 30px ${COLOR.lime}, 0 0 60px ${COLOR.lime}`, borderRadius: 4}} /> : null}
		</div>
	);
};

// ---------------- legendas ----------------
const BLOCKS = [
	'O Claude acabou de *matar*', '!os editores de vídeo', 'Esse vídeo aqui', 'foi editado', '!com um só prompt', 'que eu mandei', 'para o Claude',
	'e ele edita', 'com toda a minha', '*identidade* visual', 'e todos os *efeitos*', 'que eu gosto', 'no meu vídeo',
	'E o passo a passo', 'para ele fazer', 'toda essa edição', 'é *simples*', 'Eu gravo esse vídeo', 'aqui com a câmera', 'do meu *celular*',
	'Pego ele', 'jogo pra uma *pasta*', 'e mando o Claude', 'editar pra mim', 'de acordo com', 'o *jeito* que eu gosto', 'dos meus vídeos',
	'Ele edita', 'deixa o vídeo *pronto*', 'para eu postar', 'nos meus reels', 'e ganhar *visualizações*', 'tá bom?',
	'Ele faz *tudo*', 'o que eu quiser', 'nesse vídeo aqui', 'Se eu quiser colocar', '!um texto gigante', '!atrás da minha cabeça', 'ele vai colocar',
	'Se eu quiser', 'que ele corte', 'essa tela no *meio*', 'ele vai fazer isso', 'Se eu quiser', 'que a minha tela', 'fique pra *baixo*',
	'!e a tela dele', '!dá a explicação', '!do que ele tá falando', 'fica em *cima*', 'ele vai fazer', 'isso também', 'tá bom?',
	'!Tudo com um só prompt', 'de acordo com', 'o *modelo* de vídeo', 'que eu gosto', 'Eu só preciso', 'mandar uma *referência*', 'para ele',
	'Ele já entendeu', 'o *estilo* de vídeo', 'que eu gosto', 'Gostou dessa *ferramenta*?', 'Comenta aí *IA*', 'aqui nos comentários', 'que eu vou te enviar', 'lá no seu *direct*',
];
const blocks = buildBlocks(BLOCKS);

// ---------------- efeitos sonoros ----------------
export const SFX: Sfx[] = [
	{at: 0, name: 'impact', vol: 0.3},
	{at: S.matar, name: 'laser', vol: 0.22},
	{at: S.editores, name: 'shatter', vol: 0.34},
	{at: S.prompt1 - 0.25, name: 'pop', vol: 0.22},
	{at: S.mandei + 0.05, name: 'whoosh_short', vol: 0.2},
	{at: S.edita - 0.15, name: 'whoosh', vol: 0.2},
	{at: S.identidade, name: 'click', vol: 0.2},
	{at: S.efeitos, name: 'pop', vol: 0.2},
	{at: S.passo - 0.2, name: 'whoosh', vol: 0.18},
	{at: S.simples, name: 'pop', vol: 0.2},
	{at: S.gravo - 0.15, name: 'whoosh', vol: 0.18},
	{at: S.jogo + 0.2, name: 'whoosh_short', vol: 0.2},
	{at: S.mando, name: 'click', vol: 0.22},
	{at: S.jeito, name: 'ding', vol: 0.18},
	{at: S.pronto - 0.1, name: 'whoosh', vol: 0.22},
	{at: S.postar, name: 'click', vol: 0.3},
	{at: S.visualiz, name: 'riser', vol: 0.14},
	{at: S.tudo1, name: 'pop', vol: 0.2},
	{at: S.texto - 0.4, name: 'reverse', vol: 0.2},
	{at: S.texto + 0.05, name: 'impact', vol: 0.3},
	{at: S.colocar2, name: 'impact', vol: 0.18},
	{at: S.corte, name: 'laser', vol: 0.3},
	{at: S.meio, name: 'whoosh', vol: 0.26},
	{at: S.isso1 - 0.05, name: 'whoosh_short', vol: 0.2},
	{at: S.baixo - 0.1, name: 'whoosh', vol: 0.24},
	{at: S.tela3, name: 'pop', vol: 0.2},
	{at: S.cima, name: 'whoosh_short', vol: 0.2},
	{at: S.tudo2, name: 'pop', vol: 0.22},
	{at: S.prompt2 + 0.1, name: 'whoosh_short', vol: 0.18},
	{at: S.modelo, name: 'click', vol: 0.2},
	{at: S.referencia - 0.1, name: 'whoosh_short', vol: 0.2},
	{at: S.estilo, name: 'ding', vol: 0.18},
	{at: S.gostou - 0.15, name: 'whoosh', vol: 0.2},
	{at: S.comenta, name: 'pop', vol: 0.22},
	...Array.from({length: 2}, (_, i) => ({at: S.ia + i * 0.08, name: 'type', vol: 0.2})),
	{at: S.ia + 0.3, name: 'click', vol: 0.26},
	{at: S.direct, name: 'pop', vol: 0.24},
];

// eventos visuais declarados (auditoria dos 2 s)
export const VISUAL_EVENTS: [number, string][] = [
	[0, 'EDITORES DE VÍDEO 3D + enquadramento próximo'], [S.matar, 'risco vermelho'], [S.editores, 'palavra explode'], [S.editores + 0.4, 'reenquadramento'],
	[S.esse, 'reenquadramento'], [S.prompt1 - 0.25, '1 prompt'], [S.mandei, 'prompt enviado'], [S.edita - 0.05, 'tela desce / identidade'],
	[S.identidade, 'cores'], [S.visual, 'fontes'], [S.efeitos, 'efeitos'], [S.passo - 0.25, 'tela cheia + passo a passo'], [T('fazer', 1), 'reenquadramento'], [S.simples, 'simples + reenquadramento'],
	[S.gravo - 0.1, 'trilha de etapas'], [T('celular'), 'celular gravando'], [S.jogo, 'pasta'], [S.mando, 'Claude'], [S.mando + 0.7, 'lendo o guia'], [S.jeito, 'do meu jeito'],
	[S.ele2 - 0.25, 'tela cheia'], [S.pronto - 0.05, 'vira celular'], [S.postar, 'postar'], [S.visualiz, 'visualizações'], [S.tudo1, 'seleção do quadro'],
	[S.se1, 'reenquadramento'], [S.texto, 'TEXTO GIGANTE atrás'], [S.cabeca, 'reenquadramento'], [S.colocar2, 'texto trava'], [S.se2, 'texto sai'],
	[S.corte, 'laser'], [S.meio, 'tela cortada'], [S.isso1, 'tela volta'], [S.baixo, 'tela desce'], [S.tela3, 'explicação em cima'],
	[T('falando'), 'explicação ao vivo'], [S.cima, 'seta para cima'], [S.tambem, 'pulso'], [S.tudo2, '1 prompt'], [S.prompt2 + 0.1, 'prompt enviado'], [S.modelo, 'modelo de vídeo'],
	[T('gosto', 3), 'modelo completo'], [S.referencia, 'referência'], [T('entendeu'), 'varredura'], [S.estilo, 'estilo entendido'],
	[S.gostou - 0.25, 'tela cheia + GOSTOU?'], [S.comenta, 'campo de comentário'], [S.ia, 'IA digitado'], [T('enviar'), 'enviado'], [S.direct, 'DM'],
];

export const Video: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
	const frame = useCurrentFrame();
	const t = frame / FPS;
	const m = modes(t);

	const hookOn = t < S.editores + 1.0;
	const giantOn = t >= S.texto - 0.1 && t < S.se2 + 0.1;
	const behind = (
		<>
			{hookOn ? <ShatterText3D t={t} lines={['EDITORES', 'DE VÍDEO']} accentLine={1} strikeAt={S.matar} explodeAt={S.editores + 0.08} y={1.85} /> : null}
			{giantOn ? <KineticGiantText t={t - S.texto} lines={['TEXTO', 'GIGANTE']} landAt={0} lockAt={S.colocar2 - S.texto} exitAt={S.se2 - 0.25 - S.texto} top={230} /> : null}
		</>
	);
	const cutout = (hookOn || giantOn) && (frame <= 80 || (frame >= 800 && frame <= 930));

	// slot (área do card no layout dividido)
	const slotTop = SPACE.framePadY;
	let slot: React.ReactNode = null;
	if (t >= S.edita - 0.1 && t < S.passo) slot = <IdentityCard t={t - (S.edita - 0.05)} colorsAt={S.identidade - S.edita} fontsAt={S.visual - S.edita} fxAt={S.efeitos - S.edita} exitAt={S.passo - 0.35 - S.edita} />;
	if (t >= S.gravo - 0.15 && t < S.ele2) slot = <StepTrack t={t - (S.gravo - 0.1)} frame={frame} steps={[{label: 'grava', at: 0.1, icon: 'phone'}, {label: 'pasta', at: S.jogo - S.gravo + 0.1, icon: 'folder'}, {label: 'Claude edita', at: S.mando - S.gravo + 0.1, icon: 'spark'}]} doneAt={S.jeito - S.gravo + 0.1} exitAt={S.ele2 - 0.35 - (S.gravo - 0.1)} />;
	if (t >= S.tela3 - 0.15 && t < S.tudo2 - 0.1) slot = <LiveExplain t={t - (S.tela3 - 0.1)} abs={t} words={WORDS.filter((w) => w.start >= S.tela3 - 0.05 && w.start < S.tudo2).map((w) => ({w: w.w.replace(/[?,.]/g, ''), start: w.start}))} exitAt={S.tudo2 - 0.4 - (S.tela3 - 0.1)} />;
	if (t >= S.tudo2 - 0.15 && t < S.modelo) slot = <OnePrompt t={t - (S.tudo2 - 0.1)} sendAt={S.prompt2 + 0.1 - (S.tudo2 - 0.1)} exitAt={S.modelo - 0.3 - (S.tudo2 - 0.1)} />;
	if (t >= S.modelo - 0.1 && t < S.referencia - 0.1) slot = <TemplateCard t={t - (S.modelo - 0.05)} exitAt={S.referencia - 0.45 - (S.modelo - 0.05)} />;
	if (t >= S.referencia - 0.2 && t < S.gostou) slot = <ReferenceScan t={t - (S.referencia - 0.15)} scanAt={T('entendeu') - S.referencia} styleAt={S.estilo - S.referencia + 0.15} exitAt={S.gostou - 0.4 - (S.referencia - 0.15)} />;

	// captions: posição acompanha o retângulo do apresentador
	const capY = m.full * 1470 + m.split * (camRect(1).top + camRect(1).height * 0.84) + m.phone * 1520;
	const b = blockAt(blocks, t);
	return (
		<AbsoluteFill style={{background: COLOR.ink, fontFamily: FONT.display, color: COLOR.text}}>
			<Stage frame={frame} t={t} behind={behind} cutout={cutout} />
			{slot ? <div style={{position: 'absolute', left: SPACE.framePadX, top: slotTop, width: 1080 - 2 * SPACE.framePadX, height: 1920 * SPACE.slotMinHeight, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{slot}</div> : null}

			{/* tela cheia: "1 prompt" acima da cabeça */}
			{t >= S.prompt1 - 0.3 && t < S.edita + 0.2 ? (
				<div style={{position: 'absolute', left: SPACE.framePadX, top: 110, background: COLOR.panel, border: `${SPACE.border}px solid ${COLOR.line}`, borderRadius: 56, padding: '30px 44px', ...(t > S.edita - 0.15 ? popOut(t, S.edita - 0.15) : {})}}>
					<OnePrompt t={t - (S.prompt1 - 0.25)} sendAt={S.mandei + 0.1 - (S.prompt1 - 0.25)} exitAt={S.edita - 0.15 - (S.prompt1 - 0.25)} />
				</div>
			) : null}
			{/* passo a passo é simples */}
			{t >= S.passo - 0.3 && t < S.gravo ? (
				<div style={{position: 'absolute', left: 0, right: 0, top: 150, textAlign: 'center', ...pop(t - (S.passo - 0.2), 0), ...(t > S.gravo - 0.35 ? popOut(t, S.gravo - 0.35) : {})}}>
					<Label style={{fontSize: 44, color: COLOR.lime}}>o passo a passo</Label>
					<div style={{fontFamily: FONT.display, fontWeight: 700, fontSize: 150, letterSpacing: '-0.03em', lineHeight: 1, marginTop: 10, color: COLOR.text, textShadow: '0 10px 40px rgba(0,0,0,0.5)'}}>
						é{' '}
						<span style={{position: 'relative', zIndex: 0, padding: '0 16px', color: t > S.simples + 0.2 ? COLOR.ink : COLOR.text}}>
							<span style={{position: 'absolute', inset: 0, background: COLOR.lime, borderRadius: 16, zIndex: -1, transform: `scaleX(${phase(t, S.simples, 0.35, easeCss)})`, transformOrigin: 'left'}} />
							simples
						</span>
					</div>
				</div>
			) : null}
			{/* celular: painel de postagem */}
			{t >= S.pronto - 0.05 && t < S.tudo1 ? (
				<div style={{position: 'absolute', left: 655, top: 520, transform: 'scale(1.3)', transformOrigin: '0 0'}}>
					<PostPanel t={t - (S.pronto + 0.05)} postAt={S.postar - S.pronto - 0.05} viewsAt={S.visualiz - S.pronto - 0.05} exitAt={S.tudo1 - 0.35 - S.pronto - 0.05} />
				</div>
			) : null}
			{/* alças de seleção: "tudo o que eu quiser nesse vídeo aqui" */}
			{t >= S.tudo1 - 0.05 && t < S.se1 + 0.1 ? <SelectionBox t={t - S.tudo1} exitAt={S.se1 - 0.2 - S.tudo1} label="esse vídeo" /> : null}
			{/* seta: a explicação fica em cima */}
			{t >= S.cima - 0.1 && t < S.tudo2 - 0.2 ? (
				<div style={{position: 'absolute', right: 90, top: 760, width: 120, height: 120, borderRadius: 30, background: COLOR.lime, display: 'grid', placeItems: 'center', ...pop(t - S.cima, 0), transform: `${pop(t - S.cima, 0).transform} translateY(${-Math.abs(Math.sin((t - S.cima) * 6)) * 18}px)`}}>
					<svg width="70" height="70" viewBox="0 0 24 24" fill="none" stroke={COLOR.ink} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
						<path d="M12 19V5M5 12l7-7 7 7" />
					</svg>
				</div>
			) : null}
			{/* GOSTOU? */}
			{t >= S.gostou - 0.2 && t < S.comenta + 0.1 ? (
				<div style={{position: 'absolute', left: 0, right: 0, top: 170, textAlign: 'center', fontFamily: FONT.display, fontWeight: 700, fontSize: 210, letterSpacing: '-0.04em', color: COLOR.lime, textShadow: '0 12px 40px rgba(0,0,0,0.5)', ...pop(t - (S.gostou - 0.15), 0), ...(t > S.comenta - 0.2 ? popOut(t, S.comenta - 0.2, 0.25) : {})}}>
					gostou?
				</div>
			) : null}
			{/* CTA */}
			{t >= S.comenta - 0.1 ? (
				<div style={{position: 'absolute', left: SPACE.framePadX, top: 150, width: 1080 - 2 * SPACE.framePadX, display: 'flex', flexDirection: 'column', gap: 30, background: COLOR.panel, border: `${SPACE.border}px solid ${COLOR.line}`, borderRadius: 56, padding: 48, boxSizing: 'border-box', ...pop(t - (S.comenta - 0.1), 0)}}>
					<Label style={{fontSize: 40, ...pop(t - S.comenta, 0)}}>comenta nos comentários</Label>
					<NeonPrompt t={t - S.comenta} text="IA" typeStart={S.ia - S.comenta} typeEnd={S.ia - S.comenta + 0.18} sendAt={S.ia - S.comenta + 0.3} />
					{t >= S.direct - 0.1 ? <NeonToasts t={t - S.direct} items={[{title: 'Direct', sub: 'te envio por aqui', icon: 'bell'}]} /> : null}
				</div>
			) : null}

			{b && !b.hidden ? (
				<div style={{position: 'absolute', left: 0, right: 0, top: capY, transform: 'translateY(-50%)'}}>
					<NeonCaption t={t} words={b.toks.map((k) => ({text: k.text, start: k.start, hl: k.hl}))} size={m.split > 0.5 ? 64 : 76} />
				</div>
			) : null}
			{withAudio ? <SoundTrack sfx={SFX} total={TOTAL_FRAMES} /> : null}
		</AbsoluteFill>
	);
};
void END;
void clamp;
