# Mapa sugerido (rascunho heurístico) — v002

Duração 52.3s · assunto provável: **criatividade_design, tecnologia** (criatividade_design 16, tecnologia 8, marketing 4, educacao 2)
Eventos visuais: mínimo 27 (regra dos 2 s), alvo ~52 (1 por segundo, como os aprovados).

Vocabulário do assunto (ideias, não obrigação):
- **criatividade_design**: metáforas — paleta de cores; camadas de edição; linha do tempo; seleção com alças; antes/depois
  componentes — IdentityCard, SelectionBox, TemplateCard, ReferenceScan, PresenterStage (cortes de tela, celular), KineticGiantText, ShatterText3D; 3D — ShatterText3D, KineticGiantText (2D com profundidade)
  movimento — a própria edição vira o efeito: tela cortada, quadro selecionado, camadas; sons — whoosh, laser, click, pop; criar — linha do tempo multipista com cortes acontecendo; quadro virando camadas isométricas; evitar — copiar o estilo de outro criador
- **tecnologia**: metáforas — rede neural/nós conectados; interface futurista; código digitando; chip/circuito acendendo; terminal; varredura/scan; partículas de dados
  componentes — Network3D, TechHUD, CodeWindow, NeonPrompt, NeonProgress, OnePrompt, StepTrack, LiveExplain, ReferenceScan, TemplateCard; 3D — Network3D (IA, conexões), ShatterText3D (afirmação forte), Text3D
  movimento — preciso e digital: digitação, varreduras, anéis girando, pulsos em linhas; sons — type, click, laser, whoosh_short, riser; criar — circuito acendendo trilhas; holograma girando sobre a mão; tela de app com cursor real; fluxo de dados entre ícones; evitar — interfaces com logotipo de terceiros; chamar de 3D o que é 2D

| tempo | frase | intenções | sugestão |
|---|---|---|---|
| 0.05–2.36 | O Claude acabou de matar os editores de vídeo | gancho, afirmacao_forte | impacto no quadro 1: palavra-âncora com ação (ShatterText3D/Text3D), transformação do quadro ou objeto ligado à frase · tipografia cinética (KineticStack), 3D ou reenquadramento forte na palavra |
| 2.36–7.71 | Esse vídeo aqui foi editado com um só prompt que eu mandei para o Claude e ele edita com toda a minha identidade visual | — | sem gatilho: reenquadramento, transformação do elemento atual ou tipografia na palavra-chave |
| 7.71–10.00 | e todos os efeitos que eu gosto no meu vídeo | — | sem gatilho: reenquadramento, transformação do elemento atual ou tipografia na palavra-chave |
| 10.00–12.63 | E o passo a passo para ele fazer toda essa edição é simples | lista, afirmacao_forte | NeonChecklist / NeonSteps / StepTrack marcando na palavra de cada item · tipografia cinética (KineticStack), 3D ou reenquadramento forte na palavra |
| 12.90–14.97 | eu gravo esse vídeo aqui com a câmera do meu celular | acao | demonstração em etapas sincronizada com cada verbo (StepTrack, interface ilustrativa) |
| 15.03–20.70 | Pego ele jogo pra uma pasta e mando o Claude editar pra mim de acordo com o jeito que eu gosto dos meus vídeos | acao | demonstração em etapas sincronizada com cada verbo (StepTrack, interface ilustrativa) |
| 20.74–25.15 | Ele edita deixa o vídeo pronto para eu postar nos meus reels e ganhar visualizações tá bom? | resultado | transformação de estado: botão vira "feito", barra completa, Stamp |
| 25.15–27.03 | Ele faz tudo o que eu quiser nesse vídeo aqui | — | sem gatilho: reenquadramento, transformação do elemento atual ou tipografia na palavra-chave |
| 27.15–30.63 | Se eu quiser colocar um texto gigante atrás da minha cabeça ele vai colocar | pedido_literal | EXECUTE exatamente o que a frase descreve, no instante da fala (ex.: PresenterStage cut, KineticGiantText atrás, layout que desce) |
| 30.68–34.37 | Se eu quiser que ele corte essa tela no meio ele vai fazer isso | pedido_literal | EXECUTE exatamente o que a frase descreve, no instante da fala (ex.: PresenterStage cut, KineticGiantText atrás, layout que desce) |
| 34.37–39.03 | Se eu quiser que a minha tela fique pra baixo e a tela dele dá a explicação do que ele tá falando fica em | pedido_literal, acao | EXECUTE exatamente o que a frase descreve, no instante da fala (ex.: PresenterStage cut, KineticGiantText atrás, layout que desce) · demonstração em etapas sincronizada com cada verbo (StepTrack, interface ilustrativa) |
| 39.03–41.05 | cima ele vai fazer isso também tá bom? | — | sem gatilho: reenquadramento, transformação do elemento atual ou tipografia na palavra-chave |
| 41.24–44.45 | Tudo com um só prompt de acordo com o modelo de vídeo que eu gosto | — | sem gatilho: reenquadramento, transformação do elemento atual ou tipografia na palavra-chave |
| 44.68–46.25 | Eu só preciso mandar uma referência para ele | — | sem gatilho: reenquadramento, transformação do elemento atual ou tipografia na palavra-chave |
| 46.39–48.30 | Ele já entendeu o estilo de vídeo que eu gosto | — | sem gatilho: reenquadramento, transformação do elemento atual ou tipografia na palavra-chave |
| 48.35–52.27 | Gostou dessa ferramenta Comenta aí IA aqui nos comentários que eu vou te enviar lá no seu direct | cta | NeonPrompt digitando a palavra falada + envio + NeonToasts (dentro de card) |

Próximo passo: decidir, frase a frase, entre REUTILIZAR, ADAPTAR ou CRIAR (references/18), variar a estrutura em
relação aos vídeos anteriores e declarar os VISUAL_EVENTS.