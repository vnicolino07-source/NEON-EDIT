# Direitos de distribuição — v002 (verificação de 29/10/2026)

| Elemento | Titular / licença | Liberado para o pacote? |
|---|---|---|
| Imagem e voz da pessoa no vídeo | o próprio titular do NEON EDITOR, que pediu a inclusão do v002 como referência (instrução de 29/10/2026) | **sim**, com a recomendação de formalizar por escrito uma autorização de uso de imagem para fins comerciais |
| Texto falado (roteiro) | titular | sim |
| Identidade visual Neon (cores e composição) | titular | sim, como exemplo (não é a marca padrão do kit) |
| Fontes Space Grotesk / JetBrains Mono | SIL OFL 1.1 (licenças em `neon-editor/motor/public/fonts/`) | sim |
| Trilha e efeitos sonoros | sintetizados pelo kit (`pipeline/sfx.py`) | sim |
| Gráficos, 3D e interfaces | criados no projeto; interfaces genéricas, sem logotipos de terceiros | sim |
| Marcas citadas na fala ("Claude", "reels", "direct") | Anthropic / Meta; menção nominativa na fala, sem logotipos | sim (uso descritivo); não use as marcas na publicidade do produto sem conferir as regras de cada empresa |

**Conclusão:** nenhum elemento de terceiros protegido foi encontrado. O vídeo foi incluído na versão aprovada (prévia v1,
720×1280, idêntica bit a bit ao arquivo aprovado). O master 1080×1920 fica com o titular.

**Pendência registrada:** autorização de uso de imagem por escrito antes da venda (recomendação, não impede a auditoria).
