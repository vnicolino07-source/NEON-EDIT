# Direitos de distribuição — <id>

| Elemento | Titular / licença | Liberado para o pacote? |
|---|---|---|
| Imagem e voz da pessoa no vídeo | | |
| Texto falado (roteiro) | | |
| Identidade visual (cores, fontes) | | |
| Fontes | | |
| Trilha e efeitos sonoros | | |
| Imagens, ícones, logotipos, prints de terceiros | | |
| Marcas citadas na fala | | |

Pendências:
