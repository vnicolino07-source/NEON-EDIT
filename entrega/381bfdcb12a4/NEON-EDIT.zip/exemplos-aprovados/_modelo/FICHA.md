# <id> — "<título>"

- Aprovado em: <data> (prévia v<n>)
- Bruto → final: <x> s → <y> s a <velocidade>×; <palavras> palavras (<p>/s); <eventos> eventos (maior intervalo <g> s); <sfx> efeitos sonoros
- Master: <onde está> · arquivo no pacote: <arquivo>
- Linguagem visual escolhida (uma frase):
- Direção (tempo → fala → efeito → componente → layout):
- Componentes novos criados:
- Correções pedidas pelo cliente e o que mudou:
- O que tornou o vídeo aprovado:
