# NEON EDITOR — kit de edição de vídeos verticais com Claude

> **Status: versão candidata (1.1.0-rc1), preparada para AUDITORIA. Não está pronta para venda.** Falta a validação numa instalação limpa
> (`testes-portabilidade/PROCEDIMENTO.md`). Ver `docs/PENDENCIAS.md`.

O NEON EDITOR transforma um vídeo bruto gravado no celular (pessoa falando para a câmera, 9:16) num vídeo editado com:
cortes secos de silêncios e repetições, aceleração de 1,15× com tom preservado, legenda sincronizada palavra por palavra,
motion graphics e 3D que demonstram o que é dito, efeitos sonoros e trilha discretos, na identidade visual da pessoa,
em 1080×1920. O fluxo inclui sempre uma prévia completa para aprovação antes do arquivo final.

Ele é uma **skill** para o Claude (pasta `neon-editor/`, com `SKILL.md`) + um **motor** (Remotion + Three.js) +
um **pipeline** (Python + ffmpeg + modelos de transcrição e recorte) + **verificações automáticas**.

## Começar

1. **Instale a skill** no Claude: Claude Code → copie a pasta `neon-editor/` para `~/.claude/skills/` (ou para
   `.claude/skills/` do projeto); claude.ai/app → envie a pasta `neon-editor` compactada como skill.
   A pasta precisa continuar inteira (o `SKILL.md` aponta para `references/`, `motor/`, `pipeline/`, `qa/`).
2. **Abra uma conversa do Claude com acesso a comandos** (Claude Code, ou o app desktop ligado ao seu computador com
   shell) e diga: **"instala o NEON EDITOR"**. O Claude verifica o ambiente, mostra o que falta e pede sua autorização
   antes de instalar qualquer coisa.
3. Diga **"configura minha marca"**: o Claude pergunta nome, cores, fontes, estilo e referências, grava sua identidade e
   mostra uma demonstração com ela.
4. **Vídeo a partir de um tema (sem gravar nada):** diga **"faz um vídeo sobre <tema> no estilo <estilo>"**. São 14
   estilos prontos — quadro-negro, tipografia cinética, infográfico, telas de celular, jornal antigo, blueprint,
   retrô/VHS, flat, mapa, argila 3D, colagem, partículas, linha e ilustrado — ou **descreva o visual que você quer**
   (cores, clima, tipo de imagem) ou mande um vídeo de referência: o Claude monta o estilo sob medida
   (`neon-editor/references/21` e `22`). A vitrine dos estilos está em `motor/src/videos/estilos_teste2`.
5. Mande um vídeo e diga **"edita esse vídeo"**. Você recebe a **PRÉVIA PARA APROVAÇÃO**, pede ajustes se quiser, aprova,
   e recebe o final em 1080×1920.

## O que tem aqui

| Pasta | Conteúdo |
|---|---|
| `neon-editor/` | **a skill** (tudo que o Claude precisa): `SKILL.md`, guias em `references/`, motor, pipeline, QA, instalador, configurações, casos de teste |
| `exemplos-aprovados/` | o vídeo v002 aprovado (referência de qualidade), com ficha, código, decisões e verificação de direitos |
| `docs/` | arquitetura, recuperação de contexto (para continuar o desenvolvimento sem histórico), pendências |
| `testes-portabilidade/` | procedimento e critérios objetivos para validar o kit numa máquina limpa |
| `MANIFESTO.md` | lista dos arquivos que entram no pacote comercial, com o que foi deixado de fora e por quê |
| `LICENCAS.md` | licenças do código, das fontes e das ferramentas de terceiros |

## Requisitos

Windows 10/11, macOS 12+ ou Linux x64; 8 GB de RAM (16 recomendados); ~3 GB livres (modelos + ferramentas);
Node.js 18+, ffmpeg completo (com rubberband), Python 3.10+. O instalador guiado explica e instala com sua permissão.
Renderizar é pesado: sem GPU, conte ~0,5–1,5 s por quadro (um vídeo de 50 s leva de 10 a 40 min, conforme a máquina).
