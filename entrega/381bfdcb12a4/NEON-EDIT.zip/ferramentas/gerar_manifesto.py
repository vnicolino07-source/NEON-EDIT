#!/usr/bin/env python3
"""Gera MANIFESTO.md e manifesto.json: arquivos do pacote comercial com tamanho e SHA-256, e o que fica de fora.
Uso: python ferramentas/gerar_manifesto.py   (na raiz do kit)"""
import hashlib, json, datetime
from pathlib import Path
R = Path(__file__).resolve().parent.parent
FORA = ['node_modules', '__pycache__', 'public/frames', 'public/fg', 'public/audio', 'public/bundle.js', 'motor/out', 'evals/results', 'config/ferramentas.json', 'config/perfil.json']
def fora(p):
    s = p.as_posix()
    return any(f in s for f in FORA) or p.name.startswith('.') or s in ('MANIFESTO.md', 'manifesto.json')
itens = []
for p in sorted(R.rglob('*')):
    if p.is_file() and not fora(p.relative_to(R)):
        b = p.read_bytes()
        itens.append({'arquivo': p.relative_to(R).as_posix(), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()})
(R / 'manifesto.json').write_text(json.dumps({'versao': '1.1.0-rc1', 'gerado': f'{datetime.datetime.now():%Y-%m-%d %H:%M}', 'arquivos': itens}, indent=1, ensure_ascii=False), encoding='utf-8')
grupos = {}
for i in itens:
    g = '/'.join(i['arquivo'].split('/')[:2]) if i['arquivo'].startswith('neon-editor/') else i['arquivo'].split('/')[0]
    grupos.setdefault(g, []).append(i)
L = ['# Manifesto do pacote (versão 1.1.0-rc1 — candidata, NÃO validada para venda)', '',
     f'Gerado por `ferramentas/gerar_manifesto.py` em {datetime.datetime.now():%d/%m/%Y %H:%M}. Hashes em `manifesto.json`.', '',
     f'**{len(itens)} arquivos, {sum(i["bytes"] for i in itens) / 1e6:.1f} MB.**', '', '## Incluídos', '', '| Grupo | Arquivos | Tamanho |', '|---|---|---|']
L += [f'| `{g}` | {len(v)} | {sum(i["bytes"] for i in v) / 1e3:.0f} kB |' for g, v in grupos.items()]
L += ['', '## Gerados na máquina do comprador (não vão no pacote)', '',
      '- `motor/node_modules/` (npm install), modelos de transcrição e recorte (`instalador/baixar_modelos.py`)',
      '- `config/ferramentas.json`, `config/perfil.json`, marcas do comprador',
      '- `motor/public/{frames,fg,audio,bundle.js}`, `projetos/` (dados de cada vídeo). `motor/src/data/*` vai com os dados sintéticos da demonstração, para o motor compilar antes do primeiro vídeo', '',
      '## Deixados de fora de propósito (privados do titular)', '',
      '- Vídeos brutos e masters do titular e os projetos completos das edições (do v002 entra só a prévia aprovada 720p, como referência).',
      '- Biblioteca Neon original, guia pessoal e catálogo de referências com nomes de criadores (a marca Neon entra só como parte do exemplo v002, autorizado).',
      '- Vídeos de referência de terceiros.',
      '- Pacote de testes privado (regressão do v002) — fica em `PACOTE DE TESTES PRIVADO/` na pasta do titular.', '',
      '## Itens que dependem de decisão do titular antes da venda', '',
      '- `neon-editor/references/14-direcao-criativa.md` e `16-casos-aprovados.md` citam trechos da fala dos vídeos aprovados como exemplo. Autorize ou peça para anonimizar.',
      '- `LICENCAS.md`: definir a licença comercial do kit e conferir as licenças de terceiros (em especial a do Remotion para clientes empresas).',
      '- Nome comercial: o kit usa "NEON EDITOR" e prefixos `Neon*` no código (técnicos). Confirme o nome.']
(R / 'MANIFESTO.md').write_text('\n'.join(L) + '\n', encoding='utf-8')
print(len(itens), 'arquivos')
