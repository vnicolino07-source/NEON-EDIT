# Recuperação de contexto (para uma sessão nova do Claude, sem histórico)

Você está assumindo o desenvolvimento do **NEON EDITOR**, um editor de vídeos verticais operado pelo Claude.
Não existe memória da conversa em que ele foi criado. Tudo o que importa está nos arquivos abaixo. Não suponha nada que
não esteja escrito; quando faltar informação, pergunte ao titular.

## Leia nesta ordem

1. `LEIA-ME-PRIMEIRO.md` — o que é e o estado atual (versão candidata, não validada para venda).
2. `neon-editor/references/17-pendencias-e-limitacoes.md` — o que falta e o que nunca foi testado.
3. `neon-editor/SKILL.md` — o fluxo operacional completo (é o que o Claude segue para editar).
4. `neon-editor/references/16-casos-aprovados.md` — o padrão de qualidade (dois vídeos aprovados) e por quê.
5. `neon-editor/references/12-solucao-de-problemas.md` — todos os erros já vistos, com causa e teste.
6. `docs/ARQUITETURA.md` — fluxo de dados e decisões técnicas.
7. `MANIFESTO.md` — o que vai no pacote e o que ficou de fora.
8. `neon-editor/references/18-direcao-adaptativa.md` e `19-referencias-destiladas.md` — como decidir a direção de cada vídeo novo.
9. `exemplos-aprovados/` — o v002 aprovado (vídeo, ficha, código, direitos).
10. `RELATORIO_DE_EXPORTACAO.md` — o estado exato deste pacote e o que foi testado.

## História em uma página

- **28/10/2026 — A1.** Primeiro vídeo do cliente (Victor). A v1 (sem aceleração, estilo claro) foi recusada; a v2 foi
  aprovada depois das correções que viraram as regras de ritmo: impacto no quadro 1, regra dos 2 s, cortes pela fala,
  1,15× depois dos cortes, prévia completa antes do final.
- **29/10/2026 — identidade.** O cliente definiu a "Biblioteca Neon" (tema escuro, um acento #C6F432, Space Grotesk +
  JetBrains Mono) como identidade, com liberdade criativa: a biblioteca é referência, não catálogo fechado; preservar as
  cores naturais da imagem; cada vídeo com direção própria; motion novo entra no acervo só depois de aprovado.
- **29/10/2026 — v002.** Segundo vídeo, aprovado na primeira prévia, com motions novos (palavra 3D explodindo, texto
  gigante atrás da cabeça, tela cortada no meio, apresentador virando celular, explicação ao vivo). Final 1080×1920
  exportado.
- **29/10/2026 — consolidação.** O cliente pediu para transformar o sistema num produto instalável. Foi criado este kit:
  marca por configuração (a identidade Neon ficou fora do pacote), pipeline por linha de comando, verificações
  automáticas, instalador com autorização, testes de portabilidade.

## Verificações já feitas (no ambiente de desenvolvimento, Linux na nuvem, 2 CPUs, sem GPU)

| Teste | Resultado |
|---|---|
| Pipeline do kit sobre o bruto do v002 (mesmos `cortes.json`/`correcoes.json`) | EDL, `words.json`, quadros e máscaras **idênticos** aos aprovados; voz idêntica deslocada 6 ms (o kit mede 26 ms de atraso; o aprovado usou 20 ms fixos) |
| Motor do kit com a marca Neon renderizando a composição do v002 | 19 de 20 quadros idênticos pixel a pixel; 1 com diferença máxima de 9/255 |
| `qa_layout.mjs` com os três erros reais do v002 reintroduzidos | os três detectados (fonte Times, "GIGANTE" cortado, card vazando) |
| QA completo do v002 final | sem falhas (−14,4 LUFS, −1,0 dBTP, 1080×1920, 50 eventos, maior intervalo 1,81 s) |
| Demonstração sintética com a marca "exemplo-aurora" | render, layout, ritmo OK |
| `qa_latencia.py` | atraso real 28,1 ms, medido 28 ms |
| `qa/teste_rapido.py` numa cópia limpa do kit (modo sem npm) | todas as etapas OK |
| `qa_layout.mjs` no v002 aprovado | achou um defeito menor que passou na aprovação: campo do CTA 96 px mais largo que o card |

## Como continuar

- Para **editar**: siga `neon-editor/SKILL.md`.
- Para **evoluir o kit**: trabalhe numa cópia; mantenha os componentes aprovados intactos (não simplifique); toda mudança
  de comportamento precisa passar por: teste de regressão do v002 (se o titular fornecer o bruto, que é privado),
  `qa/teste_rapido.py` com duas marcas e os casos em `neon-editor/evals/`.
- **Não declare o produto pronto para venda** sem o teste de portabilidade em máquina limpa
  (`testes-portabilidade/PROCEDIMENTO.md`) aprovado pelo titular.
