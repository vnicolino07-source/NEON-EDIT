# Arquitetura do NEON EDITOR

```
vídeo bruto ──► pipeline/neon.py ───────────────────────────► projetos/<id>/
                 preparar  (ffprobe, voz 16k/48k, energia 10 ms)    data/bruto.json, db10ms.npy
                 transcrever (sherpa-onnx + Parakeet TDT v3)        data/words_raw.json
                 [Claude lê, decide] cortes.json, correcoes.json
                 edl       (cortes pela fala + 1,15×, quantizado)   data/edl.json
                 palavras  (mapeia p/ timeline final + correções)   data/words.json
                 quadros   (1080×1920 da timeline final)            public/frames/f_*.jpg
                 voz       (cortes + rubberband + tratamento + atraso medido)  public/audio/voice.wav, data/voice_env.json
                 recortes  (u2net + filtro guiado + EMA)            public/fg/fg_*.webp
                 vincular  ─────────────────────────────────────► motor/src/data, motor/public/{frames,fg,audio}

config/marcas/<id>.json ── neon.py marca usar ──► motor/src/brand/marca.json ──► brand/neon.ts (tokens)

motor/ (Remotion + Three.js)
  src/videos/<id>/Video.tsx   ← a DIREÇÃO do vídeo (escrita pelo Claude): legendas, cenas, efeitos, SFX, VISUAL_EVENTS
  src/components/...          ← biblioteca (cards, layouts, 3D, experimentais)
  src/engine/...              ← tempo das palavras (T/TE), legendas verificadas, Plate, SoundTrack, holdRender
  render: A) npx remotion render   B) harness/build.cjs + harness/render.mjs (Playwright + ffmpeg)

pipeline/neon.py mixar + finalizar ──► MP4 (prévia 720×1280 / final 1080×1920, −14 LUFS)
qa/ ──► relatório + folha de contato
```

## Decisões de projeto

| Decisão | Por quê |
|---|---|
| Tempos sempre derivados de palavras (`T('palavra', n)`) | um corte novo não desalinha nada; a direção lê como o roteiro |
| Legendas escritas à mão, verificadas palavra a palavra (`buildBlocks`) | controle editorial (quebras, destaque, ocultar) sem risco de divergir do áudio |
| Correções por tempo do bruto, não por índice | a transcrição pode ser refeita sem invalidar as correções |
| Aceleração depois dos cortes, quantizada por segmento em quadros inteiros | voz e imagem nunca derivam |
| Marca em JSON → tokens; nomes de tokens históricos | componentes aprovados funcionam com qualquer marca sem reescrita |
| Render determinístico (estado = função do quadro), `holdRender` para recursos | qualquer quadro pode ser renderizado isoladamente e em paralelo |
| Recortes só nos intervalos necessários | o modelo de segmentação é caro (~1 s/quadro na CPU) |
| Efeitos sonoros e trilha sintetizados | sem dependência de licenças de áudio |
| Dois caminhos de render | o oficial (Remotion CLI) para máquinas normais; o local (harness) para ambientes sem npm, e foi o que produziu os vídeos aprovados |

## Arquivos de dados

| Arquivo | Formato |
|---|---|
| `words_raw.json` | `[{w, s, e}]` segundos do bruto |
| `cortes.json` | `{velocidade, respiro_final, janelas: [{de, ate, rotulo, inicio_exato?, fim_exato?}]}` |
| `correcoes.json` | `{trocar: [{em, de, para}], remover: [{em, de}], inserir: [{texto, inicio, fim}]}` |
| `edl.json` | `{segments: [{src_start, src_end, cut_start, dst_start, frames, dst_frame, speed, label}], duration, speed, cut_duration}` |
| `words.json` | `[{w, start, end, src}]` segundos da timeline final |
| `voice_env.json` | `[0–1]` por quadro (RMS / máximo) |
| `meta.json` (render) | `{TOTAL_FRAMES, FPS, SFX: [{at, name, vol}], events: [[t, rótulo]]}` |
