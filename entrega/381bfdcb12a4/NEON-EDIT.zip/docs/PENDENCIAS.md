# Pendências

O documento vivo está dentro da skill, para viajar com ela: `neon-editor/references/17-pendencias-e-limitacoes.md`.
