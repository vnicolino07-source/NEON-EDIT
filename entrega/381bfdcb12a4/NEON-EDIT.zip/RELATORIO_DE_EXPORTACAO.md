# Relatório de exportação — NEON_EDITOR_KIT_AUDITORIA (versão 1.1.0-rc1)

Gerado em 29/10/2026 para **auditoria técnica independente**. **Não está pronto para venda.** A edição inédita
completa e o teste de portabilidade em máquina limpa ficaram para uma sessão nova, por decisão do titular.

## Novidades da 1.1.0-rc1 (23/11/2026)

- **Vídeos a partir de tema** (guia 20) e **14 estilos visuais** (guia 21): argila 3D, colagem, partículas, linha,
  ilustrado (proposto) + quadro-negro, kinetic, infográfico, interface, jornal, blueprint, retrô, flat e mapa
  (`motor/src/estilos/`). Linha validado num vídeo completo (prévia com narração, QA ok); os demais renderizados e
  checados em quadros e na vitrine `estilos_teste2` (34 s com narração, QA de layout ok) — status "parcial".
- **Estilo sob medida** (guia 22): a pessoa descreve ou mostra um vídeo de referência → ficha de estilo → peças → prévia →
  ficha salva em `config/estilos_pessoais/`.
- Legenda `KCap` com `font/ink/dim/weight/glow`; 5 famílias novas (OFL); mapa-múndi Natural Earth; `qa_layout` aceita
  `data-qa="decor"` para texto decorativo fora da tela.

## 1. Conteúdo

- Arquivos e tamanho: 164 arquivos (162 listados no manifesto + o próprio manifesto em .md e .json), 14,7 MB — ver `MANIFESTO.md` (lista com SHA-256 em `manifesto.json`). O maior arquivo é o vídeo de referência
  aprovado (12,5 MB).
- Não incluído (privado do titular):
  - vídeos brutos;
  - masters 1080×1920;
  - os 8 vídeos de referência de terceiros e as medições por vídeo;
  - o pacote de regressão do v002.

```
LEIA-ME-PRIMEIRO.md · RELATORIO_DE_EXPORTACAO.md · MANIFESTO.md · manifesto.json · LICENCAS.md
docs/                     arquitetura, recuperação de contexto
testes-portabilidade/     procedimento + modelo de resultado (teste em máquina limpa)
ferramentas/              gerador do manifesto
exemplos-aprovados/       v002 aprovado (vídeo 720p, ficha, direitos, código) + _modelo para novos
neon-editor/              A SKILL (instale esta pasta)
  SKILL.md                ponto de entrada
  references/00–19        guias por etapa (instalação, configuração, análise, transcrição, cortes, legendas, motion,
                          3D, áudio, identidade, render, QA, problemas, componentes, direção, entrega, casos
                          aprovados, pendências, direção adaptativa, referências destiladas)
  motor/                  Remotion + Three.js: src (marca, engine, componentes, composições), harness (render local),
                          public (fontes OFL, efeitos sonoros sintetizados), package.json com versões fixas
  pipeline/               neon.py (preparar, transcrever, rever, formantes, texto, edl, palavras, mapa, quadros, voz,
                          recortes, sfx, vincular, marca, mixar, finalizar), demo.py, sfx.py, direcao.py
  qa/                     qa_tudo, qa_legendas, qa_ritmo, qa_layout, qa_render, qa_audio, qa_marca, qa_latencia,
                          qa_movimento, teste_rapido
  instalador/             verificar_ambiente (.py/.sh/.ps1), instalar.py, baixar_modelos.py, preparar_modo_sem_npm.py
  config/                 marcas (padrão, exemplo-aurora), schema, estilos, perfil/ferramentas/referências de exemplo,
                          vocabulario_visual.json
  evals/                  4 casos de teste da skill
```

## 2. Dependências (instaladas pelo comprador, com autorização)

| Item | Detalhe |
|---|---|
| Base | Node.js ≥ 18, ffmpeg com rubberband, Python ≥ 3.10 |
| Python | numpy, scipy, Pillow; onnxruntime e opencv-contrib (para recortes) |
| npm | Remotion 4.0.539 (cli + player), Three.js 0.170.0, React 19.2; esbuild + playwright (render local) |
| Modelos | sherpa-onnx 1.13.8 + Parakeet TDT v3 int8 (≈ 640 MB); u2net_human_seg (≈ 168 MB) |

URLs e SHA-256 estão em `neon-editor/references/00-instalacao.md`.

## 3. Funcionalidades implementadas

- **Pipeline completo:** transcrição com tempo por palavra; correção pelo ataque de energia; detecção de palavra-fantasma; cortes pela fala com aceleração de 1,15× quantizada; voz tratada com o atraso medido e compensado; quadros 1080×1920; recortes; efeitos e trilha sintetizados; mixagem com ducking; master em −14 LUFS em duas passagens.
- **Motor:** marca por configuração (JSON → tokens). Componentes:
  - 12 cards da biblioteca;
  - palco do apresentador com 3 layouts e a tela cortada;
  - 10 motions aprovados no v002;
  - 3D (texto que explode, texto, queda, relógio);
  - **direção adaptativa:** 11 componentes em `adaptativo/` (8 em 2D, 3 em 3D) e 8 em `criativos/`.
- **Direção adaptativa:**
  - guia 18;
  - vocabulário visual por assunto;
  - analisador de intenções e assunto (`neon.py mapa` e `direcao.py`).
- **Controle de qualidade automático:** 10 verificações e o relatório consolidado.
- **Instalação guiada:** verificação sem instalar nada; instalação item a item só com autorização; download dos modelos com conferência de SHA-256.
- **Primeiro uso:** a skill faz a configuração da marca e do perfil por perguntas e oferece 5 estilos, com status honesto (comprovado, parcial, proposto).

## 4. Testes executados (resultados reais)

**Numa cópia isolada do pacote**, montada a partir dos arquivos do pacote. Dependências externas por variáveis de
ambiente (código-fonte do Remotion/Three.js do GitHub, binário e modelo do sherpa-onnx), sem caminhos do projeto original:

| Teste | Resultado |
|---|---|
| Compilação de todos os scripts Python e checagem de sintaxe Node | OK |
| Validação da skill (formato oficial de skills) | OK |
| `qa_marca` (padrao, exemplo-aurora) | OK |
| `teste_rapido` com a marca exemplo-aurora: demonstração sintética, marca, compilação, quadros, layout, ritmo, vídeo de 3 s com áudio, arquivo | todas as etapas OK; avisou corretamente que faltava `config/ferramentas.json` (modelos configurados só por variável) |
| Vitrine da direção adaptativa (11 componentes) | compila; `qa_ritmo` OK (maior intervalo 1,6 s); `qa_layout` sem falhas; quadros renderizados |
| Vitrine geral (12 cards + 3D) | quadros renderizados |
| Vitrine criativa (`criativos/`) | compila; `qa_layout` sem falhas (12 quadros) |
| `qa_latencia` | atraso real 28,1 ms × medido 28 ms |
| **Pipeline num vídeo diferente do v002** (25 s do bruto do A1) | preparar, transcrever, edl, palavras, mapa, voz (atraso 28 ms, residual 0), quadros (458/458), recortes: OK |
| `qa_legendas` nesse trecho | acusou 1 palavra em silêncio. Mostra o QA funcionando; numa edição real seria corrigida em `correcoes.json` |

**No ambiente de desenvolvimento**, com os dados privados do titular:

| Teste | Resultado |
|---|---|
| Regressão do pipeline no v002 | EDL, palavras, quadros e máscaras idênticos aos aprovados. Duas exceções: o fim da 1ª palavra, por causa da correção da duração mínima feita depois; e a voz 6 ms mais adiantada, porque agora o atraso é medido em vez dos 20 ms fixos |
| Motor do kit com a marca Neon e a composição do v002 | 19 de 20 quadros idênticos pixel a pixel |
| `qa_layout` com os erros reais do v002 reintroduzidos | os 3 detectados; achou também um defeito menor no v002 aprovado |
| Medição das 8 referências externas | ver `neon-editor/references/19-referencias-destiladas.md` |

## 5. Ainda não validado

1. Edição inédita completa (bruto → prévia aprovada) com o kit, numa sessão sem histórico.
2. Windows e macOS (nenhum teste).
3. `npm install` e o render oficial do Remotion (`npx remotion render`).
4. Transcrição pelo pacote Python `sherpa-onnx` (caminho de Windows e macOS).
5. `instalar.py` e `baixar_modelos.py` de ponta a ponta, e os comandos winget/brew/apt.
6. Componentes adaptativos e criativos num vídeo aprovado por cliente.
7. Os 4 casos de `evals/`, que nunca foram executados com e sem a skill.

## 6. Limitações

- Render por software: ≈ 0,5–1,5 s por quadro.
- Só 9:16.
- Tema claro não aprovado.
- Não há geração de imagem ou vídeo por IA.
- O 3D é feito de primitivas e texto.
- O analisador de direção é heurístico (palavras-chave).
- Alguns componentes aprovados têm textos padrão do v002.
- A ponte de arquivos do app desktop limita cada arquivo a 30 MB.

Lista completa: `neon-editor/references/17-pendencias-e-limitacoes.md`.

## 7. Pendências de licenciamento

- Definir a licença comercial do kit.
- Conferir a licença do Remotion para compradores empresas (licença própria, paga acima de certo porte).
- Atribuição do modelo Parakeet (CC-BY-4.0).
- Builds do ffmpeg com rubberband são GPL (instalados pelo comprador).
- v002: elementos verificados sem material de terceiros (`exemplos-aprovados/v002/DIREITOS.md`). Recomenda-se uma autorização de uso de imagem por escrito.
- Trechos da fala do titular citados nos guias 14 e 16: autorizar ou anonimizar.

## 8. Instalação em ambiente limpo (resumo)

1. Extraia o ZIP. Instale a pasta `neon-editor/` como skill: Claude Code → `~/.claude/skills/neon-editor/`; ou envie a pasta compactada como skill no app.
2. Numa conversa com execução de comandos, diga "instala o NEON EDITOR". O Claude roda `instalador/verificar_ambiente.py`, mostra o que falta e pede autorização.
3. Instale com `python instalador/instalar.py` (confirma cada item) e `python instalador/baixar_modelos.py --destino <pasta> [--recortes]`. Depois rode `cd motor && npm install`.
4. Confira com `python qa/teste_rapido.py`: precisa terminar com "AMBIENTE PRONTO para editar".
5. Diga "configura minha marca" e depois mande um vídeo com "edita esse vídeo".
6. Para a auditoria: siga `testes-portabilidade/PROCEDIMENTO.md` e preencha `RESULTADO_MODELO.md`.
