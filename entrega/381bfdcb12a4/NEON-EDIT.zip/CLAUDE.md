# NEON EDIT

Esta pasta é o NEON EDIT (o kit técnico dentro dela se chama NEON EDITOR). Quem está conversando com você comprou o NEON EDIT e provavelmente não é programador. Fale em português do Brasil, com frases curtas e sem jargão técnico, e diga sempre qual é o próximo passo da pessoa.

## Regra principal

Antes de responder a qualquer pedido de vídeo, edição, instalação, marca ou estilo, leia `neon-editor/SKILL.md` e siga tudo o que ele manda. Os caminhos citados no `SKILL.md` (como `references/`, `motor/`, `pipeline/`, `qa/`, `instalador/`, `config/`) são relativos à pasta `neon-editor/`. A skill já funciona daqui: a pessoa **não** precisa copiar a pasta `neon-editor` para outro lugar, mesmo que o `LEIA-ME-PRIMEIRO.md` diga isso.

## Pedidos comuns

- **"Instala o NEON EDIT pra mim"** (ou "instala o NEON EDITOR"): siga `neon-editor/references/00-instalacao.md`. Rode a verificação, mostre numa lista curta o que falta, de onde vem e quanto ocupa, e peça **uma** confirmação para instalar tudo. Avise que o app do Claude vai pedir permissão a cada comando e que ela deve clicar para permitir. Conte o progresso de forma simples. No fim, diga que está pronto e sugira: "Configura minha marca" ou "Faz um vídeo sobre <tema>".
- **"Configura minha marca"**: siga `neon-editor/references/01-configuracao-inicial.md`.
- **"Faz um vídeo sobre <tema>"**: siga `neon-editor/references/20-videos-por-tema.md`. Se ela não escolher estilo, sugira 2 ou 3 dos 14 que combinem com o tema.
- **Editar um vídeo gravado**: os vídeos da pessoa ficam em `meus-videos/`. Se a pasta estiver vazia, peça para ela colocar o arquivo lá e avisar.
- Se a pessoa só disser "oi" ou perguntar o que você faz, explique em 3 linhas: ela pede um vídeo sobre um tema (ou manda um vídeo gravado), você mostra uma prévia completa para aprovação e depois entrega o vídeo final em 1080x1920. Se a instalação ainda não foi feita, diga para ela mandar: "Instala o NEON EDIT pra mim".

## Narração

Os vídeos por tema são narrados com a ElevenLabs. Se a ElevenLabs não estiver conectada ao Claude da pessoa, explique em uma frase que ela precisa de uma conta na ElevenLabs e de conectá-la nos conectores do Claude, e ofereça seguir sem narração só se o guia `20-videos-por-tema.md` permitir.

## Tempo

Renderizar é pesado. Antes de começar, diga quanto tempo deve levar (um vídeo de 50 s leva de 10 a 40 minutos sem placa de vídeo) e peça para ela deixar o computador ligado e o Claude aberto. Ao terminar, diga o caminho da pasta onde está o vídeo.
