# Resultado do teste de portabilidade

- Data:
- Plataforma (SO, versão, CPU, RAM, GPU):
- Modalidade do Claude e modelo:
- Versão do kit (MANIFESTO):
- O que já estava instalado antes:
- Observador:

| # | Verificação | Passou? | Evidência / observação |
|---|---|---|---|
| 1 | Skill carregada | | |
| 2 | Instruções reconhecidas | | |
| 3 | Dependências identificadas | | |
| 4 | Instalação | | |
| 5 | Identidade configurada | | |
| 6 | Vídeo processado | | |
| 7 | Legendas | | |
| 8 | Cortes | | |
| 9 | Motion graphics | | |
| 10 | 3D | | |
| 11 | Efeitos sonoros | | |
| 12 | Render termina | | |
| 13 | Arquivo reproduzível | | |
| 14 | Qualidade (nota do titular) | | |
| 15 | Tempos (instalação / configuração / edição / render) | | |

Intervenções manuais necessárias:

Erros encontrados (com mensagem):

Conclusão (aprovado / reprovado) e correções a fazer no kit:
