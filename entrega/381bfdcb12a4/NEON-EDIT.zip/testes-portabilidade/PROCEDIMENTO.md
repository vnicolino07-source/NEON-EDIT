# Teste de portabilidade (obrigatório antes de vender)

Objetivo: provar que uma pessoa sem acesso ao histórico de desenvolvimento, numa máquina limpa, com outra conta do
Claude, consegue instalar, configurar uma marca diferente e editar um vídeo com qualidade próxima à dos vídeos
aprovados, **usando só os arquivos do kit**. O sistema só é considerado validado depois de uma execução real.

## Preparação

| Item | Exigência |
|---|---|
| Máquina | Windows 11 **e** macOS (um teste em cada); sem Node, ffmpeg ou Python pré-instalados (ou documente o que já havia) |
| Conta | conta do Claude sem conversas anteriores sobre o editor e sem memória sobre ele |
| Modalidade | Claude Code (terminal ou app) **ou** app desktop ligado ao computador com shell |
| Kit | somente os arquivos listados no `MANIFESTO.md` (pasta `neon-editor/` instalada como skill) |
| Marca | diferente da Neon e da Aurora (ex.: "Café Lua", acento #E85D3A) |
| Vídeo bruto | vertical, 30–90 s, uma pessoa falando para a câmera, com pelo menos: um falso começo, uma frase repetida, uma pausa longa e um nome próprio; autorização de uso |
| Observador | anota tempo, perguntas que o Claude fez, erros e intervenções manuais |

## Roteiro (frases exatas para digitar)

1. "instala o NEON EDITOR" → deve verificar, listar o que falta, **pedir autorização**, instalar, rodar o teste rápido.
2. "configura minha marca: Café Lua, cor principal #E85D3A, visual escuro, sem logo, estilo dinâmico com legendas, 3D e efeitos" →
   deve criar a marca, validar, mostrar a demonstração.
3. Anexe o bruto: "edita esse vídeo" → deve entregar a PRÉVIA PARA APROVAÇÃO.
4. Peça uma correção simples ("tira o efeito do segundo X" ou "a legenda está grande") → nova prévia v2.
5. "aprovado" → final 1080×1920.

## Critérios objetivos

| # | Verificação | Como medir | Passa se |
|---|---|---|---|
| 1 | Skill carregada | o Claude cita/segue o SKILL.md (verifica ambiente antes de editar) | sim |
| 2 | Instruções reconhecidas | fluxo com prévia antes do final | sim |
| 3 | Dependências identificadas | saída do `verificar_ambiente` | lista correta do que faltava |
| 4 | Instalação | pediu autorização antes de cada instalação; `verificar_ambiente` final | PRONTO, sem intervenção manual além de autorizar (ou com as intervenções anotadas) |
| 5 | Identidade configurada | `qa_marca.py` + demonstração | sem falhas; cores e fontes da marca nos quadros |
| 6 | Vídeo processado | `projetos/<id>/data/*` | EDL e words gerados |
| 7 | Legendas | `qa_legendas.py` + `buildBlocks` | 0 falhas; erros de transcrição restantes ≤ 1 por minuto (contagem manual) |
| 8 | Cortes | escuta | falso começo, repetição e pausa longa removidos; nenhuma palavra cortada ao meio |
| 9 | Motion graphics | folha de contato | ≥ 1 efeito literal ligado a uma frase; nenhum texto cortado (`qa_layout`) |
| 10 | 3D | folha de contato | pelo menos um elemento 3D renderizado (se o estilo pedir) |
| 11 | Efeitos sonoros | `meta.json` + escuta | SFX presentes, voz sempre inteligível |
| 12 | Render termina | arquivos | prévia e final gerados |
| 13 | Arquivo reproduzível | `qa_render.py`, abrir no celular | 0 falhas; toca no celular e no Instagram (rascunho) |
| 14 | Qualidade próxima dos aprovados | `qa_tudo.py` + avaliação do titular comparando com os vídeos aprovados | maior intervalo ≤ 2 s; −14 ± 1 LUFS; nota do titular ≥ 8/10 |
| 15 | Tempo total | relógio | registrar (instalação, configuração, edição até a prévia) |

**Resultado:** aprovado só se 1–13 passarem nas duas plataformas e 14 tiver nota ≥ 8. Preencha
`testes-portabilidade/RESULTADO_<data>_<plataforma>.md` com o modelo de `RESULTADO_MODELO.md` e anexe a folha de contato,
o relatório de QA e o vídeo final.
