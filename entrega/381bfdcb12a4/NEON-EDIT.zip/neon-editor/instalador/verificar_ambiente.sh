#!/usr/bin/env sh
# Verificação mínima (macOS/Linux) para quando ainda não há Python. Não instala nada.
cd "$(dirname "$0")/.." || exit 1
falta=0
chk() { if command -v "$1" >/dev/null 2>&1; then printf 'OK    %-10s %s\n' "$1" "$($1 $2 2>&1 | head -n1)"; else printf 'FALTA %-10s %s\n' "$1" "$3"; falta=1; fi; }
chk node -v "Node.js LTS: https://nodejs.org (ou brew install node / apt install nodejs)"
chk npm -v "vem com o Node.js"
chk ffmpeg -version "ffmpeg completo: brew install ffmpeg / apt install ffmpeg"
chk python3 --version "Python 3.10+: https://python.org (ou brew install python / apt install python3)"
if command -v ffmpeg >/dev/null 2>&1; then
  if ffmpeg -hide_banner -filters 2>/dev/null | grep -q rubberband; then echo "OK    rubberband (filtro do ffmpeg)"; else echo "FALTA rubberband: instale um build completo do ffmpeg"; falta=1; fi
fi
if command -v python3 >/dev/null 2>&1; then echo; echo "Verificação completa:"; python3 instalador/verificar_ambiente.py; exit $?; fi
exit $falta
