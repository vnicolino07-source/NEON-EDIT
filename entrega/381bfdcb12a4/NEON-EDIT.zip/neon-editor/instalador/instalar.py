#!/usr/bin/env python3
"""
Instalação guiada do NEON EDITOR. Mostra cada passo e PEDE CONFIRMAÇÃO antes de executar.
Nada é instalado sem um "s" da pessoa (ou --sim, que só deve ser usado com autorização explícita para TODOS os passos).

Uso: python instalador/instalar.py [--sim] [--destino-modelos <pasta>] [--recortes]
Passos: (1) ferramentas de sistema que faltarem (via winget / Homebrew / apt — você confirma cada comando),
        (2) pacotes Python, (3) npm install do motor, (4) modelos, (5) verificação + teste rápido.
"""
import argparse, json, platform, shutil, subprocess, sys
from pathlib import Path

KIT = Path(__file__).resolve().parent.parent
SO = platform.system()


def confirmar(msg, sim):
    if sim:
        print(f'[--sim] {msg}')
        return True
    return input(f'{msg}\nExecutar? [s/N] ').strip().lower() in ('s', 'sim', 'y', 'yes')


def executar(cmd, sim, cwd=None):
    txt = ' '.join(cmd)
    if not confirmar(f'→ {txt}', sim):
        print('  pulado')
        return False
    r = subprocess.run(cmd, cwd=cwd)
    print('  ok' if r.returncode == 0 else f'  falhou (código {r.returncode})')
    return r.returncode == 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--sim', action='store_true')
    ap.add_argument('--destino-modelos', default=str(Path.home() / 'neon-editor-modelos'))
    ap.add_argument('--recortes', action='store_true')
    a = ap.parse_args()
    r = subprocess.run([sys.executable, str(KIT / 'instalador' / 'verificar_ambiente.py'), '--json'], capture_output=True, text=True)
    itens = json.loads(r.stdout)
    falta = {i['item']: i for i in itens if not i['ok']}
    print('Faltando:', ', '.join(falta) or 'nada')

    # 1) sistema
    gerenciador = {'Windows': 'winget', 'Darwin': 'brew', 'Linux': 'apt-get'}.get(SO)
    if gerenciador and not shutil.which(gerenciador):
        gerenciador = None
    sis = []
    if 'Node.js ≥ 18' in falta:
        sis.append({'Windows': ['winget', 'install', '-e', '--id', 'OpenJS.NodeJS.LTS'], 'Darwin': ['brew', 'install', 'node'], 'Linux': ['sudo', 'apt-get', 'install', '-y', 'nodejs', 'npm']}[SO])
    if 'ffmpeg' in falta or 'ffmpeg com filtro rubberband' in falta:
        sis.append({'Windows': ['winget', 'install', '-e', '--id', 'Gyan.FFmpeg'], 'Darwin': ['brew', 'install', 'ffmpeg'], 'Linux': ['sudo', 'apt-get', 'install', '-y', 'ffmpeg']}[SO])
    for c in sis:
        if gerenciador:
            executar(c, a.sim)
        else:
            print('Instale manualmente pelo site oficial:', ' '.join(c))
    # 2) Python
    pips = [i['como_resolver'].split('pip install ')[1].split()[0] for n, i in falta.items() if n.startswith('Python:') and 'pip install' in i['como_resolver']]
    if not a.recortes:
        pips = [p for p in pips if p not in ('onnxruntime', 'opencv-contrib-python-headless')]
    if SO != 'Linux' and 'sherpa-onnx' not in pips and not any(i['ok'] for i in itens if i['item'] == 'Python: sherpa-onnx'):
        pips.append('sherpa-onnx')
    if pips:
        executar([sys.executable, '-m', 'pip', 'install', '--user', *pips], a.sim)
    # 3) motor
    if any(n.startswith('motor: ') and n != 'motor: marca ativa (src/brand/marca.json)' for n in falta):
        npm = 'npm.cmd' if SO == 'Windows' else 'npm'
        executar([npm, 'install'], a.sim, cwd=KIT / 'motor')
    # 4) modelos
    if 'Modelo Parakeet TDT v3 int8' in falta or (a.recortes and 'Modelo u2net_human_seg.onnx' in falta):
        cmd = [sys.executable, str(KIT / 'instalador' / 'baixar_modelos.py'), '--destino', a.destino_modelos] + (['--recortes'] if a.recortes else []) + (['--sim'] if a.sim else [])
        subprocess.run(cmd)
    # marca padrão
    if not (KIT / 'motor' / 'src' / 'brand' / 'marca.json').exists():
        subprocess.run([sys.executable, str(KIT / 'pipeline' / 'neon.py'), 'marca', 'usar', 'padrao', '--motor', str(KIT / 'motor')])
    # 5) verificação
    subprocess.run([sys.executable, str(KIT / 'instalador' / 'verificar_ambiente.py')])
    if confirmar('Rodar o teste rápido (gera a demonstração e renderiza alguns quadros, ~2–5 min)?', a.sim):
        subprocess.run([sys.executable, str(KIT / 'qa' / 'teste_rapido.py')])


if __name__ == '__main__':
    main()
