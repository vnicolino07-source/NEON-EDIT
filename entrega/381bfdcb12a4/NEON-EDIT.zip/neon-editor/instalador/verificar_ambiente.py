#!/usr/bin/env python3
"""
Verifica o ambiente do NEON EDITOR sem instalar nada.
Uso: python instalador/verificar_ambiente.py [--json]
Saída: tabela com cada dependência (ok / falta / versão antiga), a versão encontrada e como resolver.
Código de saída 0 = pronto para editar; 1 = falta algo obrigatório.
"""
import importlib, json, os, platform, re, shutil, subprocess, sys
from pathlib import Path

KIT = Path(__file__).resolve().parent.parent
SO = platform.system()  # Windows | Darwin | Linux


def run(cmd):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        return (r.stdout + r.stderr).strip()
    except Exception:
        return ''


def ver(s):
    m = re.search(r'(\d+)\.(\d+)(?:\.(\d+))?', s or '')
    return tuple(int(x or 0) for x in m.groups()) if m else None


def dica(item):
    d = {
        'node': {'Windows': 'winget install OpenJS.NodeJS.LTS', 'Darwin': 'brew install node', 'Linux': 'instale o Node.js LTS (nodejs.org ou o gerenciador da distribuição)'},
        'ffmpeg': {'Windows': 'winget install Gyan.FFmpeg  (build completo, inclui rubberband)', 'Darwin': 'brew install ffmpeg', 'Linux': 'sudo apt install ffmpeg  (ou equivalente)'},
        'python': {'Windows': 'winget install Python.Python.3.12', 'Darwin': 'brew install python@3.12', 'Linux': 'sudo apt install python3 python3-pip'},
    }
    return d.get(item, {}).get(SO, '')


itens = []


def add(nome, ok, versao, obrig, como, detalhe=''):
    itens.append({'item': nome, 'ok': bool(ok), 'versao': versao or '—', 'obrigatorio': obrig, 'como_resolver': '' if ok else como, 'detalhe': detalhe})


# Sistema
add('Sistema operacional', True, f'{SO} {platform.release()} ({platform.machine()})', True, '')
# Python
pv = sys.version_info
add('Python ≥ 3.10', pv >= (3, 10), platform.python_version(), True, dica('python'))
# Node
nv = run(['node', '-v']) if shutil.which('node') else ''
add('Node.js ≥ 18', ver(nv) and ver(nv) >= (18, 0, 0), nv, True, dica('node'))
add('npm', bool(shutil.which('npm') or shutil.which('npm.cmd')), run(['npm', '-v']) if shutil.which('npm') else '', True, 'vem com o Node.js')
# ffmpeg
fv = run(['ffmpeg', '-version']).splitlines()[0] if shutil.which('ffmpeg') else ''
add('ffmpeg', bool(fv), fv[:40], True, dica('ffmpeg'))
add('ffprobe', bool(shutil.which('ffprobe')), '', True, 'vem com o ffmpeg')
rb = 'rubberband' in run(['ffmpeg', '-hide_banner', '-filters']) if fv else False
add('ffmpeg com filtro rubberband', rb, 'sim' if rb else 'não', True, 'instale um build completo do ffmpeg (o build mínimo não acelera a voz com tom preservado)')
lra = 'loudnorm' in run(['ffmpeg', '-hide_banner', '-filters']) if fv else False
add('ffmpeg com loudnorm', lra, 'sim' if lra else 'não', True, 'build completo do ffmpeg')
# Python pacotes
for mod, pip, obrig, uso in [('numpy', 'numpy', True, 'áudio e cortes'), ('scipy', 'scipy', True, 'áudio'), ('PIL', 'pillow', True, 'demonstração'),
                             ('onnxruntime', 'onnxruntime', False, 'recortes'), ('cv2', 'opencv-contrib-python-headless', False, 'recortes'),
                             ('sherpa_onnx', 'sherpa-onnx', False, 'transcrição sem binário')]:
    try:
        m = importlib.import_module(mod)
        v = getattr(m, '__version__', 'ok')
        extra = ''
        if mod == 'cv2' and not hasattr(m, 'ximgproc'):
            add(f'Python: {pip} (com ximgproc)', False, v, obrig, f'pip install {pip}  (o opencv comum não tem o filtro guiado)', uso)
            continue
        add(f'Python: {pip}', True, v, obrig, '', uso)
    except Exception:
        add(f'Python: {pip}', False, '', obrig, f'pip install {pip}', uso)
# Ferramentas de modelo
cfg = {}
fp = KIT / 'config' / 'ferramentas.json'
if fp.exists():
    cfg = json.loads(fp.read_text(encoding='utf-8'))
asr_bin = os.environ.get('NEON_ASR_BIN', cfg.get('asr_bin', ''))
asr_model = os.environ.get('NEON_ASR_MODEL', cfg.get('asr_model', ''))
u2 = os.environ.get('NEON_U2NET', cfg.get('u2net', ''))
add('config/ferramentas.json', fp.exists(), str(fp) if fp.exists() else '', True, 'python instalador/baixar_modelos.py --destino <pasta>')
tem_sherpa_py = any(i['item'] == 'Python: sherpa-onnx' and i['ok'] for i in itens)
add('Transcrição: binário sherpa-onnx-offline ou pacote Python', bool(asr_bin and Path(asr_bin).exists()) or tem_sherpa_py, asr_bin or ('pacote Python' if tem_sherpa_py else ''), True,
    'Linux: baixar_modelos.py baixa o binário; Windows/macOS: pip install sherpa-onnx')
ok_model = bool(asr_model) and all((Path(asr_model) / f).exists() for f in ['encoder.int8.onnx', 'decoder.int8.onnx', 'joiner.int8.onnx', 'tokens.txt'])
add('Modelo Parakeet TDT v3 int8', ok_model, asr_model, True, 'python instalador/baixar_modelos.py (~640 MB)')
add('Modelo u2net_human_seg.onnx', bool(u2) and Path(u2).exists(), u2, False, 'python instalador/baixar_modelos.py --recortes (~168 MB)', 'só para elementos atrás da pessoa')
# Motor: node_modules (npm install) ou modo sem npm (NEON_VENDOR + NEON_NODE_TOOLS, ver references/10)
nm = KIT / 'motor' / 'node_modules'
vendor = os.environ.get('NEON_VENDOR', '')
tools_nm = [Path(p) for p in [os.environ.get('NEON_NODE_TOOLS', ''), '/opt/npm-tools/node_modules'] if p]
def pkgver(pkg):
    for base in [nm] + tools_nm:
        pj = base / pkg / 'package.json'
        if pj.exists():
            return json.loads(pj.read_text(encoding='utf-8'))['version'], str(base)
    if vendor and pkg == 'remotion' and (Path(vendor) / 'remotion/packages/core/package.json').exists():
        return json.loads((Path(vendor) / 'remotion/packages/core/package.json').read_text())['version'] + ' (NEON_VENDOR)', vendor
    if vendor and pkg == 'three' and (Path(vendor) / 'threejs/build/three.module.js').exists():
        return 'r' + re.search(r"REVISION = '(\d+)'", (Path(vendor) / 'threejs/build/three.module.js').read_text()[:4000] or '').group(1) + ' (NEON_VENDOR)', vendor
    return '', ''
modo_local = all(pkgver(p)[0] for p in ['remotion', 'three', 'react', 'esbuild', 'playwright'])
for pkg, obrig in [('remotion', True), ('three', True), ('react', True), ('@remotion/cli', not modo_local), ('esbuild', False), ('playwright', False)]:
    v, onde = pkgver(pkg)
    add(f'motor: {pkg}', bool(v), v, obrig, 'cd motor && npm install', ('renderizador local' if pkg in ('esbuild', 'playwright') else '') + (f' [{onde}]' if onde and onde != str(nm) else ''))
add('Render: caminho disponível', modo_local or bool(pkgver('@remotion/cli')[0]), 'renderizador local' if modo_local else ('Remotion CLI' if pkgver('@remotion/cli')[0] else ''), True, 'cd motor && npm install')
add('motor: marca ativa (src/brand/marca.json)', (KIT / 'motor' / 'src' / 'brand' / 'marca.json').exists(), '', True, 'python pipeline/neon.py marca usar padrao --motor motor')
add('Perfil da pessoa (config/perfil.json)', (KIT / 'config' / 'perfil.json').exists(), '', False, 'faça a configuração inicial (references/01-configuracao-inicial.md)')

if '--json' in sys.argv:
    print(json.dumps(itens, ensure_ascii=False, indent=1))
else:
    w = max(len(i['item']) for i in itens)
    for i in itens:
        st = 'OK   ' if i['ok'] else ('FALTA' if i['obrigatorio'] else 'opc. ')
        print(f"{st} {i['item']:<{w}}  {i['versao'][:48]:<48}  {i['como_resolver']}")
faltam = [i for i in itens if i['obrigatorio'] and not i['ok']]
if '--json' not in sys.argv:
    print(f"\n{'PRONTO para editar' if not faltam else f'{len(faltam)} item(ns) obrigatório(s) faltando'} — nada foi instalado por este script.")
sys.exit(0 if not faltam else 1)
