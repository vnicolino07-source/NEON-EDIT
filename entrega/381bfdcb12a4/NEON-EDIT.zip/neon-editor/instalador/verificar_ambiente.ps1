# Verificação mínima (Windows PowerShell) para quando ainda não há Python. Não instala nada.
Set-Location (Join-Path $PSScriptRoot "..")
$falta = $false
function Chk($cmd, $arg, $dica) {
  $c = Get-Command $cmd -ErrorAction SilentlyContinue
  if ($c) { $v = (& $cmd $arg 2>&1 | Select-Object -First 1); Write-Output ("OK    {0,-10} {1}" -f $cmd, $v) }
  else { Write-Output ("FALTA {0,-10} {1}" -f $cmd, $dica); $script:falta = $true }
}
Chk "node" "-v" "winget install OpenJS.NodeJS.LTS"
Chk "npm" "-v" "vem com o Node.js"
Chk "ffmpeg" "-version" "winget install Gyan.FFmpeg"
Chk "py" "--version" "winget install Python.Python.3.12"
if (Get-Command ffmpeg -ErrorAction SilentlyContinue) {
  if ((ffmpeg -hide_banner -filters 2>&1 | Out-String) -match "rubberband") { Write-Output "OK    rubberband (filtro do ffmpeg)" }
  else { Write-Output "FALTA rubberband: instale o build completo (winget install Gyan.FFmpeg)"; $falta = $true }
}
if (Get-Command py -ErrorAction SilentlyContinue) { Write-Output ""; Write-Output "Verificação completa:"; py instalador\verificar_ambiente.py; exit $LASTEXITCODE }
if ($falta) { exit 1 } else { exit 0 }
