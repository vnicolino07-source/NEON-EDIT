#!/usr/bin/env python3
"""
Baixa os modelos de transcrição e recorte das releases oficiais no GitHub, confere o SHA-256, descompacta e grava
config/ferramentas.json. PEDE CONFIRMAÇÃO antes de baixar (use --sim apenas se a pessoa autorizou explicitamente).

Uso: python instalador/baixar_modelos.py --destino <pasta> [--recortes] [--binario-linux] [--sim]
"""
import argparse, hashlib, json, platform, sys, tarfile, urllib.request
from pathlib import Path

KIT = Path(__file__).resolve().parent.parent
ITENS = {
    'parakeet': ('https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-nemo-parakeet-tdt-0.6b-v3-int8.tar.bz2',
                 '5793d0fd397c5778d2cf2126994d58e9d56b1be7c04d13c7a15bb1b4eafb16bf', '≈ 640 MB', 'modelo de transcrição Parakeet TDT v3 (int8)'),
    'sherpa_linux': ('https://github.com/k2-fsa/sherpa-onnx/releases/download/v1.13.8/sherpa-onnx-v1.13.8-linux-x64-static.tar.bz2',
                     'd265986f7b990026e45bca573415575140106a2c663014924037d8f2c2e297cc', '≈ 160 MB', 'binário sherpa-onnx 1.13.8 (Linux x64)'),
    'u2net': ('https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2net_human_seg.onnx',
              '01eb6a29a5c4d8edb30b56adad9bb3a2a0535338e480724a213e0acfd2d1c73c', '≈ 168 MB', 'modelo de recorte de pessoas u2net_human_seg'),
}


def sha256(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()


def baixar(url, dst):
    print(f'baixando {url}')
    with urllib.request.urlopen(url) as r, open(dst, 'wb') as f:
        total = int(r.headers.get('Content-Length', 0))
        n = 0
        for b in iter(lambda: r.read(1 << 20), b''):
            f.write(b)
            n += len(b)
            if total:
                print(f'\r  {n / 1e6:.0f}/{total / 1e6:.0f} MB', end='', flush=True)
    print()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--destino', required=True)
    ap.add_argument('--recortes', action='store_true', help='também o u2net (elementos atrás da pessoa)')
    ap.add_argument('--binario-linux', action='store_true', help='também o binário sherpa-onnx para Linux x64')
    ap.add_argument('--sim', action='store_true', help='não perguntar (só com autorização explícita da pessoa)')
    a = ap.parse_args()
    D = Path(a.destino).expanduser().resolve()
    lista = ['parakeet'] + (['u2net'] if a.recortes else []) + (['sherpa_linux'] if a.binario_linux or (platform.system() == 'Linux' and platform.machine() in ('x86_64', 'AMD64')) else [])
    print('Será baixado para', D)
    for k in lista:
        print(f'  - {ITENS[k][3]} ({ITENS[k][2]}) de {ITENS[k][0]}')
    if not a.sim and input('Confirmar? [s/N] ').strip().lower() not in ('s', 'sim', 'y', 'yes'):
        print('cancelado; nada foi baixado')
        sys.exit(1)
    D.mkdir(parents=True, exist_ok=True)
    cfg_p = KIT / 'config' / 'ferramentas.json'
    cfg = json.loads(cfg_p.read_text(encoding='utf-8')) if cfg_p.exists() else {'threads': 2}
    for k in lista:
        url, sha, _, _ = ITENS[k]
        arq = D / url.rsplit('/', 1)[1]
        if not arq.exists() or sha256(arq) != sha:
            baixar(url, arq)
        s = sha256(arq)
        if s != sha:
            print(f'ERRO: SHA-256 diferente para {arq.name} ({s}). O arquivo foi alterado ou a release mudou; não será usado.')
            sys.exit(1)
        print(f'  SHA-256 ok: {arq.name}')
        if arq.suffix == '.bz2':
            with tarfile.open(arq) as t:
                t.extractall(D, filter='data') if sys.version_info >= (3, 12) else t.extractall(D)
        if k == 'parakeet':
            cfg['asr_model'] = str(D / 'sherpa-onnx-nemo-parakeet-tdt-0.6b-v3-int8').replace('\\', '/')
        elif k == 'u2net':
            cfg['u2net'] = str(arq).replace('\\', '/')
        elif k == 'sherpa_linux':
            cfg['asr_bin'] = str(D / 'sherpa-onnx-v1.13.8-linux-x64-static' / 'bin' / 'sherpa-onnx-offline').replace('\\', '/')
    cfg.setdefault('asr_bin', '')
    cfg_p.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding='utf-8')
    print('config/ferramentas.json atualizado:', json.dumps(cfg, ensure_ascii=False))
    if not cfg.get('asr_bin'):
        print('Sem binário: a transcrição usará o pacote Python sherpa-onnx (pip install sherpa-onnx).')


if __name__ == '__main__':
    main()
