#!/usr/bin/env python3
"""
Modo sem npm (ambientes onde o npm está bloqueado mas o GitHub funciona, como algumas sessões na nuvem):
clona o código-fonte do Remotion 4.0.539 (core + player) e do Three.js r170 (build + examples/jsm) e mostra as variáveis
de ambiente para o renderizador local. Ainda é preciso ter esbuild, react, react-dom e playwright disponíveis
(NEON_NODE_TOOLS apontando para um node_modules que os contenha). PEDE CONFIRMAÇÃO antes de baixar.

Uso: python instalador/preparar_modo_sem_npm.py --destino <pasta> [--sim]
"""
import argparse, subprocess, sys
from pathlib import Path

REPOS = [
    ('remotion', 'https://github.com/remotion-dev/remotion', 'v4.0.539', ['packages/core', 'packages/player']),
    ('threejs', 'https://github.com/mrdoob/three.js', 'r170', ['build', 'examples/jsm']),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--destino', required=True)
    ap.add_argument('--sim', action='store_true')
    a = ap.parse_args()
    D = Path(a.destino).expanduser().resolve()
    print('Será clonado (somente as pastas necessárias) para', D)
    for n, url, tag, paths in REPOS:
        print(f'  - {url} @ {tag}: {", ".join(paths)}')
    if not a.sim and input('Confirmar? [s/N] ').strip().lower() not in ('s', 'sim', 'y', 'yes'):
        print('cancelado'); sys.exit(1)
    D.mkdir(parents=True, exist_ok=True)
    for n, url, tag, paths in REPOS:
        if not (D / n).exists():
            subprocess.run(['git', 'clone', '-q', '--depth', '1', '--branch', tag, '--filter=blob:none', '--sparse', url, str(D / n)], check=True)
        subprocess.run(['git', '-C', str(D / n), 'sparse-checkout', 'set', *paths], check=True)
    ok = (D / 'remotion/packages/core/src/index.ts').exists() and (D / 'threejs/build/three.module.js').exists() and (D / 'threejs/examples/jsm/loaders/TTFLoader.js').exists()
    print('OK' if ok else 'FALHA: arquivos esperados não encontrados')
    print(f'\nDefina antes de compilar:\n  NEON_VENDOR={D}\n  NEON_NODE_TOOLS=<node_modules com esbuild, react, react-dom, scheduler e playwright>')
    sys.exit(0 if ok else 1)


if __name__ == '__main__':
    main()
