#!/usr/bin/env python3
"""Teste rápido de instalação/portabilidade: gera a demonstração sintética, ativa a marca, compila, renderiza quadros,
verifica layout/fontes, renderiza 3 s de vídeo com áudio e confere o arquivo. Não usa vídeo de ninguém.
Uso: python qa/teste_rapido.py [--marca padrao] [--caminho harness|remotion] [--trabalho <pasta>]"""
import argparse, json, os, subprocess, sys, time
from pathlib import Path
KIT = Path(__file__).resolve().parent.parent; M = KIT / 'motor'; PY = sys.executable
ap = argparse.ArgumentParser(); ap.add_argument('--marca', default='padrao'); ap.add_argument('--caminho', choices=['harness', 'remotion'], default='harness')
ap.add_argument('--trabalho', default=str(KIT.parent / 'neon-trabalho'))
a = ap.parse_args(); T = Path(a.trabalho); T.mkdir(parents=True, exist_ok=True); res = []
def passo(nome, cmd, **kw):
    t0 = time.time(); r = subprocess.run(cmd, capture_output=True, text=True, **kw); ok = r.returncode == 0
    res.append((nome, ok, round(time.time() - t0, 1), (r.stdout + r.stderr).strip()[-1500:]))
    print(('OK   ' if ok else 'FALHA') + f' {nome} ({res[-1][2]}s)'); 
    if not ok: print((r.stdout + r.stderr)[-1500:])
    return ok
demo = T / 'projetos' / '_demo'
if not (demo / 'data' / 'words.json').exists():
    passo('gerar demonstração sintética', [PY, str(KIT / 'pipeline' / 'demo.py'), '--proj', str(demo)])
passo('validar marca', [PY, str(KIT / 'qa' / 'qa_marca.py'), str(KIT / 'config' / 'marcas' / f'{a.marca}.json')])
passo('ativar marca', [PY, str(KIT / 'pipeline' / 'neon.py'), 'marca', 'usar', a.marca, '--motor', str(M)])
passo('ligar demonstração ao motor', [PY, str(KIT / 'pipeline' / 'neon.py'), 'vincular', '--proj', str(demo), '--motor', str(M)])
if not (M / 'public' / 'audio' / 'music.wav').exists():
    passo('gerar efeitos e trilha', [PY, str(KIT / 'pipeline' / 'neon.py'), 'sfx', '--motor', str(M)])
out = T / 'teste_rapido'; out.mkdir(exist_ok=True)
if a.caminho == 'harness':
    passo('compilar demonstração', ['node', 'harness/build.cjs', 'entry-demonstracao.tsx', 'bundle.js'], cwd=M)
    passo('metadados', ['node', 'harness/render.mjs', 'meta', str(out / 'meta.json')], cwd=M)
    meta = json.loads((out / 'meta.json').read_text()) if (out / 'meta.json').exists() else {'TOTAL_FRAMES': 300}
    fr = [str(round(meta['TOTAL_FRAMES'] * k / 12)) for k in range(12)]
    passo('quadros de teste', ['node', 'harness/render.mjs', 'stills', str(out / 'stills')] + fr, cwd=M, env={**os.environ, 'PREVIEW_W': '540'})
    passo('layout, fontes e cortes', ['node', str(KIT / 'qa' / 'qa_layout.mjs')] + fr)
    passo('ritmo declarado', [PY, str(KIT / 'qa' / 'qa_ritmo.py'), str(out / 'meta.json')])
    passo('vídeo curto (3 s, 720p)', ['node', 'harness/render.mjs', 'video', '0', '90', str(out / 'v.mp4')], cwd=M, env={**os.environ, 'PREVIEW_W': '720', 'CRF': '20'})
    passo('mixagem', [PY, str(M / 'harness' / 'mix.py'), str(M / 'public'), str(out / 'meta.json'), str(out / 'mix.wav'), str(M / 'src' / 'data' / 'voice_env.json')])
    passo('juntar áudio', ['ffmpeg', '-v', 'error', '-y', '-i', str(out / 'v.mp4'), '-i', str(out / 'mix.wav'), '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-shortest', str(out / 'teste.mp4')])
    passo('arquivo reproduzível', [PY, str(KIT / 'qa' / 'qa_render.py'), str(out / 'teste.mp4'), '--tipo', 'previa'])
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-pattern_type', 'glob', '-i', str(out / 'stills' / '*.jpg'), '-vf', 'scale=270:-1,tile=6x2', '-frames:v', '1', str(out / 'folha.jpg')])
else:
    passo('render Remotion (3 s)', ['npx', 'remotion', 'render', 'src/index.ts', 'Demonstracao', str(out / 'teste.mp4'), '--frames=0-89', '--scale=0.6667', '--codec=h264', '--crf=20', '--audio-codec=aac'], cwd=M)
    passo('arquivo reproduzível', [PY, str(KIT / 'qa' / 'qa_render.py'), str(out / 'teste.mp4'), '--tipo', 'previa'])
rel = out / 'resultado.json'; rel.write_text(json.dumps([{'etapa': n, 'ok': o, 'segundos': s, 'saida': x} for n, o, s, x in res], ensure_ascii=False, indent=1), encoding='utf-8')
ok = all(o for _, o, _, _ in res)
# o teste rápido não usa transcrição nem recorte (a demonstração é sintética): confira se essas ferramentas existem
v = subprocess.run([PY, str(KIT / 'instalador' / 'verificar_ambiente.py'), '--json'], capture_output=True, text=True)
faltam = [i['item'] for i in json.loads(v.stdout or '[]') if i['obrigatorio'] and not i['ok'] and not i['item'].startswith('motor:')]
print(('\nMOTOR E RENDER OK' if ok else '\nMOTOR/RENDER COM PROBLEMAS') + f' — detalhes em {rel}' + (f'; olhe {out / "folha.jpg"}' if a.caminho == 'harness' else ''))
if faltam:
    print('AINDA FALTA para editar vídeos reais: ' + '; '.join(faltam))
else:
    print('Transcrição e demais ferramentas configuradas: AMBIENTE PRONTO para editar.' if ok else '')
sys.exit(0 if ok and not faltam else 1)
