#!/usr/bin/env python3
"""Roda todas as verificações de uma edição e grava um relatório.
Uso: python qa/qa_tudo.py --proj projetos/<id> --meta motor/out/meta.json --video <arquivo.mp4> --tipo previa|final [--quadros 40]
Pré-requisito: motor compilado com a entrada da composição deste vídeo (motor/public/bundle.js)."""
import argparse, json, subprocess, sys, datetime
from pathlib import Path
Q = Path(__file__).resolve().parent
ap = argparse.ArgumentParser()
ap.add_argument('--proj', required=True); ap.add_argument('--meta', required=True); ap.add_argument('--video', required=True)
ap.add_argument('--tipo', choices=['previa', 'final'], required=True); ap.add_argument('--quadros', type=int, default=40)
a = ap.parse_args()
dur = json.load(open(a.meta, encoding='utf-8'))
dur = dur['TOTAL_FRAMES'] / dur['FPS']
etapas = [
    ('Legendas × voz', [sys.executable, str(Q / 'qa_legendas.py'), '--proj', a.proj]),
    ('Regra dos 2 s (eventos declarados)', [sys.executable, str(Q / 'qa_ritmo.py'), a.meta]),
    ('Layout, fontes e cortes de texto', ['node', str(Q / 'qa_layout.mjs'), '--amostra', str(a.quadros)]),
    ('Arquivo exportado', [sys.executable, str(Q / 'qa_render.py'), a.video, '--tipo', a.tipo, '--duracao', f'{dur:.4f}']),
    ('Áudio', [sys.executable, str(Q / 'qa_audio.py'), a.video, '--edl', str(Path(a.proj) / 'data' / 'edl.json')]),
    ('Movimento medido no vídeo (informativo)', [sys.executable, str(Q / 'qa_movimento.py'), a.video]),
]
linhas, ok = [f'# Relatório de QA — {Path(a.video).name}', f'{datetime.datetime.now():%Y-%m-%d %H:%M}', ''], True
for nome, cmd in etapas:
    r = subprocess.run(cmd, capture_output=True, text=True)
    info = nome.endswith('(informativo)')
    st = 'OK' if r.returncode == 0 else ('INFO' if info else 'FALHOU')
    ok &= r.returncode == 0 or info
    linhas += [f'## {nome}: {st}', '```', (r.stdout + r.stderr).strip()[-4000:], '```', '']
    print(f'{st:7s} {nome}')
linhas.append('**Resultado: ' + ('aprovado no QA automático (ainda falta a revisão visual da folha de contato)' if ok else 'há falhas — corrija antes de entregar') + '**')
out = Path(a.proj) / 'qa' / f'relatorio_{Path(a.video).stem}.md'
out.parent.mkdir(parents=True, exist_ok=True); out.write_text('\n'.join(linhas), encoding='utf-8')
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', a.video, '-vf', 'fps=1,scale=150:-1,tile=13x5', '-frames:v', '1', str(out.with_suffix('.jpg'))])
print('relatório:', out, '| folha de contato:', out.with_suffix('.jpg'))
sys.exit(0 if ok else 1)
