// Verificação automática de layout em quadros da composição compilada (motor/public/bundle.js):
//  - todo texto visível usa as fontes da marca ativa (pega o bug do "Times" do v002);
//  - nenhum texto visível sai da tela nem é cortado por um contêiner (pega o "GIGANTE" estourando);
//  - nenhum card (fundo = superfície da marca) passa da borda da tela (pega o card do CTA vazando);
//  - cores de texto e de fundo pertencem à paleta da marca (aviso, não falha: imagens reais e sombras são ignoradas);
//  - as fontes da marca carregaram.
// Uso: node qa/qa_layout.mjs <quadro> [<quadro>...]   (ou --amostra N para N quadros espalhados)
// Saída: lista de problemas por quadro; código 1 se houver FALHA.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath, pathToFileURL} from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const MOTOR = process.env.NEON_MOTOR || path.resolve(HERE, '../motor');
const PUB = path.join(MOTOR, 'public');
const marca = JSON.parse(fs.readFileSync(path.join(MOTOR, 'src/brand/marca.json'), 'utf8'));
const _req = createRequire(import.meta.url);
const _paths = [path.join(MOTOR, 'node_modules'), process.env.NEON_NODE_TOOLS, '/opt/npm-tools/node_modules'].filter(Boolean);
const _pw = await import(pathToFileURL(_req.resolve('playwright', {paths: _paths})).href);
const chromium = _pw.chromium ?? _pw.default.chromium;

const types = {'.html': 'text/html', '.js': 'text/javascript', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.ttf': 'font/ttf', '.otf': 'font/otf', '.woff2': 'font/woff2', '.wav': 'audio/wav', '.png': 'image/png', '.svg': 'image/svg+xml'};
const server = http.createServer((req, res) => {
	const p = path.join(PUB, decodeURIComponent(req.url.split('?')[0]));
	fs.readFile(p.endsWith(path.sep) || p.endsWith('/') ? p + 'index.html' : p, (e, d) => {
		if (e) { res.writeHead(404); return res.end(); }
		res.writeHead(200, {'Content-Type': types[path.extname(p)] || 'application/octet-stream'});
		res.end(d);
	});
});
await new Promise((r) => server.listen(0, r));
const browser = await chromium.launch({args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist']});
const page = await browser.newPage({viewport: {width: 540, height: 960}});
const pageErr = [];
page.on('pageerror', (e) => pageErr.push(e.message));
await page.goto(`http://127.0.0.1:${server.address().port}/index.html?w=540`);
await page.waitForFunction(() => typeof window.setFrame === 'function');
const meta = await page.evaluate(() => window.__meta);
let frames = process.argv.slice(2).filter((a) => /^\d+$/.test(a)).map(Number);
const ai = process.argv.indexOf('--amostra');
if (ai > 0) {
	const n = Number(process.argv[ai + 1]);
	frames = Array.from({length: n}, (_, i) => Math.round(((i + 0.5) / n) * (meta.TOTAL_FRAMES - 1)));
}
const hexes = Object.values(marca.cores).map((h) => h.toLowerCase());
const cards = [marca.cores.superficie, marca.cores.superficie2].filter(Boolean).map((h) => h.toLowerCase());
// fontes dos estilos explicativos (motor/src/estilos/base.tsx · ensureXFonts) também são do kit
const fams = [marca.fontes.titulo.familia, marca.fontes.mono.familia, 'XInter', 'XGaramond', 'XMono', 'XGiz', 'XAnton', 'XMaquina', 'XRetro', 'XJornal', ...(process.env.NEON_FONTES_EXTRA || '').split(',').filter(Boolean)].map((f) => f.toLowerCase());
let falhas = 0;
const checar = async (f) => {
	await page.evaluate((f) => window.setFrame(f), f);
	return page.evaluate(({fams, hexes, cards}) => {
		const root = document.querySelector('#root').firstElementChild;
		const R = root.getBoundingClientRect();
		const out = {fonte: [], corte: [], cor: []};
		const vis = (el) => {
			let o = 1;
			for (let e = el; e && e !== document.body; e = e.parentElement) {
				const cs = getComputedStyle(e);
				o *= Number(cs.opacity);
				if (cs.display === 'none' || cs.visibility === 'hidden') return 0;
			}
			return o;
		};
		const toHex = (c) => {
			const m = c.match(/rgba?\(([\d.]+),\s*([\d.]+),\s*([\d.]+)(?:,\s*([\d.]+))?/);
			if (!m) return null;
			if (m[4] !== undefined && Number(m[4]) < 0.9) return 'transparente';
			return '#' + [m[1], m[2], m[3]].map((v) => Math.round(Number(v)).toString(16).padStart(2, '0')).join('');
		};
		const near = (h) => hexes.some((p) => {
			const a = [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
			const b = [1, 3, 5].map((i) => parseInt(p.slice(i, i + 2), 16));
			return Math.max(...a.map((v, i) => Math.abs(v - b[i]))) <= 6;
		}) || ['#ffffff', '#000000'].includes(h);
		const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
		const seen = new Set();
		for (let n = walker.nextNode(); n; n = walker.nextNode()) {
			const txt = n.textContent.trim();
			const el = n.parentElement;
			if (!txt || seen.has(el)) continue;
			seen.add(el);
			if (el.closest('[data-qa="decor"]')) continue; // texto decorativo (ex.: marquee de fundo) — de propósito fora da tela
			if (vis(el) < 0.05) continue;
			const cs = getComputedStyle(el);
			const fam = cs.fontFamily.split(',')[0].replace(/['"]/g, '').trim().toLowerCase();
			if (!fams.includes(fam)) out.fonte.push(`"${txt.slice(0, 30)}" em ${cs.fontFamily.split(',')[0]}`);
			if (!document.fonts.check(`${cs.fontWeight} 20px ${cs.fontFamily.split(',')[0]}`)) out.fonte.push(`fonte não carregada: ${cs.fontFamily.split(',')[0]} ${cs.fontWeight}`);
			// área visível = tela ∩ ancestrais com overflow hidden
			const range = document.createRange();
			range.selectNodeContents(n);
			const b = range.getBoundingClientRect();
			let L = R.left, T = R.top, Rt = R.right, B = R.bottom;
			for (let e = el; e && e !== root; e = e.parentElement) {
				const s = getComputedStyle(e);
				if (s.overflow !== 'visible' || s.overflowX !== 'visible') {
					const q = e.getBoundingClientRect();
					L = Math.max(L, q.left); T = Math.max(T, q.top); Rt = Math.min(Rt, q.right); B = Math.min(B, q.bottom);
				}
			}
			const tol = 2;
			if (b.width > 0 && (b.left < L - tol || b.right > Rt + tol || b.top < T - tol || b.bottom > B + tol)) {
				const k = R.width / 1080;
				out.corte.push(`"${txt.slice(0, 30)}" (${Math.round((b.left - R.left) / k)},${Math.round((b.top - R.top) / k)} → ${Math.round((b.right - R.left) / k)},${Math.round((b.bottom - R.top) / k)} px) sai da área visível`);
			}
			for (const c of [cs.color, getComputedStyle(el).backgroundColor]) {
				const h = toHex(c);
				if (h && h !== 'transparente' && !near(h)) out.cor.push(`"${txt.slice(0, 20)}" usa ${h}, fora da paleta`);
			}
		}
		// cards (fundo = superfície da marca) que passam da borda da tela
		for (const el of root.querySelectorAll('div')) {
			const h = toHex(getComputedStyle(el).backgroundColor);
			if (!h || !cards.includes(h) || vis(el) < 0.5) continue;
			const q = el.getBoundingClientRect();
			const k = R.width / 1080;
			if (q.width > 0 && (q.left < R.left - 2 || q.right > R.right + 2 || q.top < R.top - 2 || q.bottom > R.bottom + 2))
				out.corte.push(`card ${Math.round(q.width / k)}×${Math.round(q.height / k)} px em (${Math.round((q.left - R.left) / k)},${Math.round((q.top - R.top) / k)}) passa da borda da tela`);
			// elemento com fundo de card que transborda o card em que está (ex.: campo de prompt mais largo que o card do CTA)
			for (let e = el.parentElement; e && e !== root; e = e.parentElement) {
				const he = toHex(getComputedStyle(e).backgroundColor);
				if (!he || !cards.includes(he)) continue;
				const pq = e.getBoundingClientRect();
				if (q.left < pq.left - 2 || q.right > pq.right + 2) out.corte.push(`elemento de ${Math.round(q.width / k)} px transborda o card de ${Math.round(pq.width / k)} px que o contém`);
				break;
			}
		}
		return out;
	}, {fams, hexes, cards});
};
for (const f of frames) {
	const r = await checar(f);
	// cortes que somem 0,2 s depois são de animação de entrada/saída (transitórios): viram aviso, não falha
	if (r.corte.length) {
		const depois = await checar(Math.min(f + 6, meta.TOTAL_FRAMES - 1));
		const chave = (s) => s.split(' (')[0].split(' em (')[0];
		const fica = new Set(depois.corte.map(chave));
		r.transitorio = r.corte.filter((c) => !fica.has(chave(c)));
		r.corte = r.corte.filter((c) => fica.has(chave(c)));
	}
	const p = [...r.fonte.map((s) => 'FALHA fonte: ' + s), ...r.corte.map((s) => 'FALHA corte: ' + s), ...(r.transitorio || []).map((s) => 'AVISO corte só durante a animação: ' + s), ...[...new Set(r.cor)].map((s) => 'AVISO cor: ' + s)];
	falhas += r.fonte.length + r.corte.length;
	console.log(`quadro ${f} (${(f / meta.FPS).toFixed(2)}s): ${p.length ? '\n  ' + p.join('\n  ') : 'ok'}`);
}
if (pageErr.length) {
	console.log('FALHA: erros na página:\n  ' + [...new Set(pageErr)].slice(0, 10).join('\n  '));
	falhas++;
}
console.log(falhas ? `${falhas} falha(s)` : 'OK: fontes da marca e nenhum texto cortado');
await browser.close();
server.close();
process.exit(falhas ? 1 : 0);
