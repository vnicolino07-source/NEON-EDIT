#!/usr/bin/env python3
"""Loudness, pico real, clipping e estalos nas emendas do áudio exportado.
Uso: python qa/qa_audio.py arquivo.mp4 [--edl projetos/<id>/data/edl.json] [--alvo -14]"""
import argparse, json, re, subprocess, sys
import numpy as np
ap = argparse.ArgumentParser(); ap.add_argument('arquivo'); ap.add_argument('--edl'); ap.add_argument('--alvo', type=float, default=-14)
a = ap.parse_args(); falhas, avisos = [], []
o = subprocess.run(['ffmpeg', '-nostats', '-i', a.arquivo, '-af', 'ebur128=peak=true', '-f', 'null', '-'], capture_output=True, text=True).stderr
s = o[o.rfind('Summary:'):]
I = float(re.search(r'I:\s+(-?[\d.]+) LUFS', s).group(1)); TP = float(re.search(r'Peak:\s+(-?[\d.]+|-inf) dBFS', s).group(1))
print(f'loudness integrado {I:.1f} LUFS · pico real {TP:.1f} dBTP')
if abs(I - a.alvo) > 1: falhas.append(f'loudness {I:.1f} LUFS fora de {a.alvo} ± 1')
if TP > -0.9: falhas.append(f'pico real {TP:.1f} dBTP acima de −1')
raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', a.arquivo, '-ac', '1', '-ar', '48000', '-f', 's16le', '-'], capture_output=True).stdout
x = np.frombuffer(raw, np.int16).astype(np.float32) / 32768
clip = int(np.sum(np.abs(x) > 0.999))
if clip > 10: falhas.append(f'{clip} amostras em clipping')
if a.edl:
    E = json.load(open(a.edl, encoding='utf-8'))['segments']
    for sgm in E[1:]:
        i = int(sgm['dst_start'] * 48000)
        w = x[max(0, i - 48):i + 48]
        if len(w) > 2 and np.max(np.abs(np.diff(w))) > 0.3: falhas.append(f"possível estalo na emenda em {sgm['dst_start']:.2f}s")
for t in avisos: print('AVISO:', t)
for t in falhas: print('FALHA:', t)
sys.exit(1 if falhas else 0)
