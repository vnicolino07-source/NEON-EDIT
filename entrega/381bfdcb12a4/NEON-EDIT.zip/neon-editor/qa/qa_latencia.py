#!/usr/bin/env python3
"""Mede o atraso que a cadeia de voz do pipeline introduz neste ffmpeg (sinal de teste com rajadas em tempos conhecidos).
Medido no desenvolvimento: afftdn ≈ 25 ms + rubberband ≈ 3 ms ≈ 28 ms. `neon.py voz` mede e compensa em cada vídeo;
este teste confirma que a medição automática está coerente com o ffmpeg instalado.
Uso: python qa/qa_latencia.py"""
import subprocess, sys, tempfile
from pathlib import Path
import numpy as np, scipy.io.wavfile as w
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'pipeline'))
import neon
sr, sp = 48000, 1.15
T = [1.0, 2.5, 4.0, 6.3, 8.1]
x = np.random.default_rng(1).standard_normal(sr * 10) * 0.001
for t in T:
    i, n = int(t * sr), int(0.08 * sr)
    x[i:i + n] += np.sin(2 * np.pi * 800 * np.arange(n) / sr) * 0.5
d = Path(tempfile.mkdtemp())
w.write(d / 'i.wav', sr, (x * 32767).astype(np.int16))
rb = ('rubberband=tempo=1.15:pitch=1:transients=crisp:detector=compound:phase=laminar:window=standard:smoothing=off:'
      'formant=preserved:pitchq=quality:channels=together')
subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', str(d / 'i.wav'), '-af', rb + ',' + neon.VOZ_CADEIA, '-ar', '48000', str(d / 'o.wav')], check=True)
y = w.read(d / 'o.wav')[1].astype(float) / 32768
env = np.convolve(np.abs(y), np.ones(48) / 48, 'same')
real = []
for t in T:
    c = t / sp
    i0 = int((c - 0.1) * sr)
    seg = env[i0:int((c + 0.15) * sr)]
    real.append((i0 + np.argmax(seg > 0.5 * seg.max())) / sr * 1000 - c * 1000)
real = float(np.median(real))
med = neon.medir_atraso(x.astype(np.float32), y.astype(np.float32), sr, sp)
print(f'atraso real (rajadas): {real:.1f} ms · medido pela correlação do pipeline: {med} ms')
ok = abs(real - med) <= 4
print('OK' if ok else 'FALHA: a medição automática diverge do atraso real; confira a sincronia labial manualmente')
sys.exit(0 if ok else 1)
