#!/usr/bin/env python3
"""Valida uma marca: formato das cores, contraste mínimo e arquivos de fonte/logo.
Uso: python qa/qa_marca.py config/marcas/<id>.json [--motor motor]"""
import json, re, sys
from pathlib import Path
args = sys.argv[1:]; p = Path(args[0])
motor = Path(args[args.index('--motor') + 1]) if '--motor' in args else Path(__file__).resolve().parent.parent / 'motor'
m = json.loads(p.read_text(encoding='utf-8')); C = m['cores']; falhas, avisos = [], []
for k in ['fundo', 'superficie', 'borda', 'acento', 'texto', 'texto_secundario', 'alerta']:
    if not re.match(r'^#[0-9A-Fa-f]{6}$', C.get(k, '')): falhas.append(f'cor "{k}" ausente ou fora de #RRGGBB')
def lum(h):
    r = [int(h[i:i + 2], 16) / 255 for i in (1, 3, 5)]
    r = [c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4 for c in r]
    return 0.2126 * r[0] + 0.7152 * r[1] + 0.0722 * r[2]
def cr(a, b):
    la, lb = sorted([lum(a), lum(b)], reverse=True); return (la + 0.05) / (lb + 0.05)
if not falhas:
    for (a, b, mn, nome) in [('texto', 'superficie', 7, 'texto sobre card'), ('texto', 'fundo', 7, 'texto sobre fundo'),
                             ('texto_secundario', 'superficie', 4.5, 'rótulo sobre card'), ('fundo', 'acento', 4.5, 'texto do destaque (cor do fundo sobre o acento)'),
                             ('acento', 'superficie', 3, 'acento sobre card')]:
        v = cr(C[a], C[b]); (falhas if v < mn else []).append(f'contraste {nome}: {v:.1f}:1 (mínimo {mn}:1)')
        print(f'contraste {nome}: {v:.1f}:1')
    if lum(C['fundo']) > 0.5: avisos.append('tema claro: tecnicamente suportado, mas os componentes foram aprovados no tema escuro — gere a demonstração e confira')
for k in ['titulo', 'mono']:
    f = m['fontes'][k]
    for key in ['variavel', 'arquivo_3d']:
        if key in f and not (motor / 'public' / f[key]).exists(): falhas.append(f'fonte {f[key]} não está em motor/public/')
if 'arquivo_3d' not in m['fontes']['titulo']: avisos.append('sem arquivo_3d: o texto 3D usará o arquivo variável (pode falhar no Three.js)')
if m.get('logo') and not (motor / 'public' / m['logo']).exists(): falhas.append(f'logo {m["logo"]} não encontrado')
for s in avisos: print('AVISO:', s)
for s in falhas: print('FALHA:', s)
print('OK' if not falhas else 'marca recusada'); sys.exit(1 if falhas else 0)
