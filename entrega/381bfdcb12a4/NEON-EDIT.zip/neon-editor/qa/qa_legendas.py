#!/usr/bin/env python3
"""Confere words.json contra a voz final: palavra em silêncio, curta demais, fora do vídeo, buracos dentro de frase.
Uso: python qa/qa_legendas.py --proj projetos/<id>   (usa data/words.json, data/edl.json e public/audio/voice.wav)"""
import argparse, json, sys
from pathlib import Path
import numpy as np, scipy.io.wavfile as wf
ap = argparse.ArgumentParser(); ap.add_argument('--proj', required=True); ap.add_argument('--limiar', type=float, default=-50)
a = ap.parse_args(); P = Path(a.proj)
W = json.load(open(P / 'data' / 'words.json', encoding='utf-8'))
dur = json.load(open(P / 'data' / 'edl.json', encoding='utf-8'))['duration']
sr, x = wf.read(P / 'public' / 'audio' / 'voice.wav'); x = x.astype(np.float32) / 32768
if x.ndim > 1: x = x.mean(1)
def db(t0, t1):
    s = x[max(0, int(t0 * sr)):max(int(t0 * sr) + 1, int(t1 * sr))]
    return 20 * np.log10(np.sqrt(np.mean(s ** 2)) + 1e-9)
falhas, avisos = [], []
silencioso = float(np.abs(x).max()) < 1e-4
for i, w in enumerate(W):
    if w['end'] - w['start'] < 0.07: avisos.append(f"#{i} '{w['w']}' dura {1000 * (w['end'] - w['start']):.0f} ms")
    if w['end'] > dur + 0.05 or w['start'] < 0: falhas.append(f"#{i} '{w['w']}' fora do vídeo ({w['start']:.2f}–{w['end']:.2f}s)")
    if not silencioso and db(w['start'], w['end']) < a.limiar: falhas.append(f"#{i} '{w['w']}' em {w['start']:.2f}s cai em silêncio na voz final (palavra fantasma ou fora de sincronia)")
    if i and W[i - 1]['end'] > w['start'] + 0.001: falhas.append(f"#{i} '{w['w']}' começa antes do fim da anterior")
for p, q in zip(W, W[1:]):
    if q['start'] - p['end'] > 0.6 and not p['w'].endswith(('?', '!', '.')):
        avisos.append(f"buraco de {q['start'] - p['end']:.2f}s entre '{p['w']}' ({p['end']:.2f}s) e '{q['w']}' — confira o corte")
print(f'{len(W)} palavras, {dur:.2f}s, {len(W) / dur:.2f} palavras/s' + (' (voz muda: teste de energia ignorado)' if silencioso else ''))
for s in avisos: print('AVISO:', s)
for s in falhas: print('FALHA:', s)
sys.exit(1 if falhas else 0)
