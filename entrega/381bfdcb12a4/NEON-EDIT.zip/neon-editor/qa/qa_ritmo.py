#!/usr/bin/env python3
"""Regra dos 2 s: nenhum intervalo > 2 s entre eventos visuais DECLARADOS (VISUAL_EVENTS da composição, em meta.json).
Uso: python qa/qa_ritmo.py out/meta.json [--max 2.0]   → código de saída 1 se falhar."""
import json, sys
args = sys.argv[1:]
mx = float(args[args.index('--max') + 1]) if '--max' in args else 2.0
m = json.load(open(args[0], encoding='utf-8'))
dur = m['TOTAL_FRAMES'] / m['FPS']
ev = sorted(m.get('events', []), key=lambda e: e[0]) + [[dur, 'fim']]
if len(ev) < 2:
    print('FALHA: nenhum evento visual declarado (VISUAL_EVENTS vazio)'); sys.exit(1)
if ev[0][0] > mx:
    ev = [[0, 'início']] + ev
worst, bad = 0, []
for (a, la), (b, lb) in zip(ev, ev[1:]):
    g = b - a
    worst = max(worst, g)
    if g > mx:
        bad.append(f'{a:6.2f} → {b:6.2f} ({g:.2f}s): "{la}" → "{lb}"')
print(f'{len(ev) - 1} eventos em {dur:.2f}s | média {dur / (len(ev) - 1):.2f}s | maior intervalo {worst:.2f}s')
if bad:
    print('FALHA:\n' + '\n'.join(bad)); sys.exit(1)
print('OK: nenhum intervalo acima de %.1f s' % mx)
