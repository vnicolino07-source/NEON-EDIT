#!/usr/bin/env python3
"""Confere o arquivo exportado: especificação técnica, quadros pretos, congelamentos e duração.
Uso: python qa/qa_render.py arquivo.mp4 --tipo previa|final [--duracao 52.27]"""
import argparse, json, re, subprocess, sys
ap = argparse.ArgumentParser(); ap.add_argument('arquivo'); ap.add_argument('--tipo', choices=['previa', 'final'], required=True); ap.add_argument('--duracao', type=float)
a = ap.parse_args(); falhas, avisos = [], []
info = json.loads(subprocess.run(['ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', a.arquivo], capture_output=True, text=True).stdout or '{}')
if not info.get('streams'): print('FALHA: arquivo ilegível'); sys.exit(1)
v = next((s for s in info['streams'] if s['codec_type'] == 'video'), None); au = next((s for s in info['streams'] if s['codec_type'] == 'audio'), None)
W, H = (1080, 1920) if a.tipo == 'final' else (720, 1280)
if not v: falhas.append('sem vídeo')
else:
    if (int(v['width']), int(v['height'])) != (W, H): falhas.append(f"resolução {v['width']}×{v['height']} (esperado {W}×{H})")
    if v['codec_name'] != 'h264': falhas.append(f"codec {v['codec_name']} (esperado h264)")
    if v.get('pix_fmt') != 'yuv420p': falhas.append(f"pix_fmt {v.get('pix_fmt')} (esperado yuv420p)")
    if v.get('r_frame_rate') != '30/1': falhas.append(f"fps {v.get('r_frame_rate')} (esperado 30/1)")
if not au: falhas.append('sem áudio')
else:
    if au['codec_name'] != 'aac': falhas.append(f"áudio {au['codec_name']} (esperado aac)")
    if au.get('sample_rate') != '48000': avisos.append(f"áudio a {au.get('sample_rate')} Hz (padrão 48000)")
dur = float(info['format']['duration'])
if a.duracao and abs(dur - a.duracao) > 1 / 30 + 0.03: falhas.append(f'duração {dur:.3f}s (composição {a.duracao:.3f}s)')
if v and au and abs(float(v.get('duration', dur)) - float(au.get('duration', dur))) > 0.1: falhas.append(f"vídeo {float(v['duration']):.2f}s e áudio {float(au['duration']):.2f}s com durações diferentes")
if a.tipo == 'final':
    with open(a.arquivo, 'rb') as f: head = f.read(64 * 1024)
    if b'moov' not in head: avisos.append('sem faststart (moov no fim do arquivo)')
o = subprocess.run(['ffmpeg', '-v', 'info', '-i', a.arquivo, '-vf', 'blackdetect=d=0.1:pix_th=0.06,freezedetect=n=0.001:d=2.5', '-an', '-f', 'null', '-'], capture_output=True, text=True).stderr
for m in re.findall(r'black_start:([\d.]+) black_end:([\d.]+)', o): falhas.append(f'quadros pretos {m[0]}–{m[1]}s')
for m in re.findall(r'freeze_start: ([\d.]+)', o): avisos.append(f'imagem congelada > 2,5 s a partir de {m}s (confira a regra dos 2 s)')
print(f"{a.arquivo}: {v and v['width']}×{v and v['height']}, {dur:.2f}s, {int(info['format'].get('size', 0)) / 1e6:.1f} MB")
for s in avisos: print('AVISO:', s)
for s in falhas: print('FALHA:', s)
sys.exit(1 if falhas else 0)
