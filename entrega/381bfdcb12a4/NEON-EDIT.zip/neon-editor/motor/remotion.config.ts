import {Config} from '@remotion/cli/config';
Config.setVideoImageFormat('jpeg');
Config.setJpegQuality(95);
// WebGL (Three.js) no Chrome headless
Config.setChromiumOpenGlRenderer('angle');
Config.setConcurrency(2);
