// Empacota uma composição para o renderizador local (esbuild + Playwright), alternativa ao `npx remotion render`.
// Uso: node harness/build.cjs <entry.tsx> [bundle.js]
// Resolução de pacotes:
//   - padrão: node_modules do motor (depois de `npm install`);
//   - NEON_VENDOR=<pasta>: usa o código-fonte do Remotion/Three.js clonado do GitHub (ambientes sem npm; ver references/10);
//   - NEON_NODE_TOOLS=<pasta node_modules>: onde procurar esbuild/react/react-dom/scheduler se não estiverem no motor.
const path = require('path');
const MOTOR = path.resolve(__dirname, '..');
const extra = [MOTOR + '/node_modules', ...(process.env.NEON_NODE_TOOLS ? [process.env.NEON_NODE_TOOLS] : []), '/opt/npm-tools/node_modules'];
const req = (m) => require(require.resolve(m, {paths: extra}));
const esbuild = req('esbuild');
const V = process.env.NEON_VENDOR;
const vendorMap = V && {
	remotion: V + '/remotion/packages/core/src/index.ts',
	'remotion/no-react': V + '/remotion/packages/core/src/no-react.ts',
	'@remotion/player': V + '/remotion/packages/player/src/index.ts',
	three: V + '/threejs/build/three.module.js',
};
const plugin = {
	name: 'alias',
	setup(b) {
		if (vendorMap) {
			b.onResolve({filter: /^(remotion|remotion\/no-react|@remotion\/player|three)$/}, (a) => ({path: vendorMap[a.path]}));
			b.onResolve({filter: /^three\/examples\/jsm\//}, (a) => ({path: V + '/threejs/' + a.path.replace(/^three\//, '')}));
		}
		b.onResolve({filter: /^(react|react-dom|scheduler)(\/.*)?$/}, (a) => ({path: require.resolve(a.path, {paths: extra})}));
	},
};
esbuild
	.build({entryPoints: [path.resolve(__dirname, process.argv[2] || 'entry-modelo.tsx')], bundle: true, format: 'iife', outfile: path.join(MOTOR, 'public', process.argv[3] || 'bundle.js'), jsx: 'automatic', plugins: [plugin], nodePaths: extra, define: {'process.env.NODE_ENV': '"production"'}, logLevel: 'warning', minify: true, sourcemap: false})
	.then(() => console.log('bundle ok'), (e) => { console.error(e.message); process.exit(1); });
