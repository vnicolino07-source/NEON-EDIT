import React, {useState} from 'react';
import {createRoot} from 'react-dom/client';
import {flushSync} from 'react-dom';
import {Thumbnail} from '@remotion/player';
import {VitrineCriativa as Vitrine, VITRINE_CRIATIVA_FRAMES as VITRINE_FRAMES} from '../src/library/VitrineCriativa';

const PW = Number(new URLSearchParams(location.search).get('w') || 1080);
let setF: (f: number) => void = () => {};
const App = () => {
	const [f, sf] = useState(0);
	setF = sf;
	return <Thumbnail component={Vitrine} compositionWidth={1080} compositionHeight={1920} frameToDisplay={f} durationInFrames={VITRINE_FRAMES} fps={30} style={{width: PW, height: (PW * 1920) / 1080}} />;
};
const raf = () => new Promise((r) => requestAnimationFrame(() => r(null)));
const w = window as any;
w.__meta = {TOTAL_FRAMES: VITRINE_FRAMES, FPS: 30};
w.setFrame = async (f: number) => {
	flushSync(() => setF(f));
	await raf();
	for (let i = 0; i < 400; i++) {
		if (!((w.__pending ?? 0) > 0 || Array.from(document.images).some((im) => !im.complete))) break;
		await new Promise((r) => setTimeout(r, 10));
	}
	await document.fonts.ready;
	await raf();
	return true;
};
createRoot(document.getElementById('root')!).render(<App />);
