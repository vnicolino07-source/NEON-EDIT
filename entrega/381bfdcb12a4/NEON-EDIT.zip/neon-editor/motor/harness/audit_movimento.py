# Auditoria objetiva no vídeo renderizado: mudança visual localizada (blocos), fora das faixas de legenda.
import subprocess, numpy as np, sys
raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', sys.argv[1], '-vf', 'scale=90:160,format=gray', '-f', 'rawvideo', '-'], capture_output=True).stdout
fr = np.frombuffer(raw, np.uint8).reshape(-1, 160, 90).astype(np.float32)
mask = np.ones((160, 90), bool); mask[116:134, :] = False; mask[58:72, :] = False
D = np.abs(np.diff(fr, axis=0)) * mask
B = D.reshape(len(D), 10, 16, 9, 10).mean(axis=(2, 4))  # 10x9 blocos
score = np.sort(B.reshape(len(B), -1), axis=1)[:, -6:].mean(1)  # média dos 6 blocos que mais mudam
base = np.median(score); thr = base * 2.2
ev = np.where(score > thr)[0] / 30
cl = []
for t in ev:
    if not cl or t - cl[-1] > 0.2: cl.append(t)
cl = [0] + cl + [len(fr) / 30]
g = np.diff(cl)
print(f'mediana {base:.2f} limiar {thr:.2f} | eventos {len(cl)-2} | maior intervalo {g.max():.2f}s')
for a, b in zip(cl, cl[1:]):
    if b - a > 2.0: print(f'  {a:.2f}–{b:.2f} ({b-a:.2f}s)')
