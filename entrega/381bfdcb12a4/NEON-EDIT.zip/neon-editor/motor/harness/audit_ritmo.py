# Auditoria da regra de dinamismo: nenhum intervalo > 2 s sem intervenção visual declarada
import json, sys
m = json.load(open(sys.argv[1])); dur = m['TOTAL_FRAMES'] / m['FPS']
ev = sorted([e for e in m['events']], key=lambda e: e[0]) + [[dur, 'fim']]
worst = 0; bad = []
for (a, la), (b, lb) in zip(ev, ev[1:]):
    g = b - a; worst = max(worst, g)
    if g > 2.0: bad.append(f'{a:6.2f} → {b:6.2f} ({g:.2f}s): "{la}" → "{lb}"')
print(f'{len(ev)-1} eventos em {dur:.2f}s | média {dur/(len(ev)-1):.2f}s | maior intervalo {worst:.2f}s')
print('\n'.join(bad) if bad else 'OK: nenhum intervalo acima de 2 s')
