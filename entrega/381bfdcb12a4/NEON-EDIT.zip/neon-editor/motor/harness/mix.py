# Mixagem final: voz tratada + trilha com ducking + efeitos (mesmos tempos/volumes de src/lib/direction.ts)
import json, sys, numpy as np, scipy.io.wavfile as w
PUB = sys.argv[1]; META = sys.argv[2]; OUT = sys.argv[3]
meta = json.load(open(META))
SR = 48000; FPS = meta['FPS']; N = int(meta['TOTAL_FRAMES'] / FPS * SR)
def load(p):
    sr, x = w.read(p); x = x.astype(np.float32) / 32768
    if x.ndim > 1: x = x.mean(1)
    assert sr == SR, p
    return x
voice = load(f'{PUB}/audio/voice.wav')[:N]; voice = np.pad(voice, (0, N - len(voice)))
music = load(f'{PUB}/audio/music.wav')[:N]; music = np.pad(music, (0, N - len(music)))
env = json.load(open(sys.argv[4]))
# ducking idêntico a SoundTrack.musicVolume
vol = np.zeros(meta['TOTAL_FRAMES'])
for f in range(len(vol)):
    v = max(env[k] for k in range(max(0, f - 6), min(len(env), f + 7)))
    speech = min(1, v * 4)
    vol[f] = (0.16 - 0.1 * speech) * min(1, f / 20) * min(1, (len(vol) - f) / 30)
g = np.interp(np.arange(N) / SR * FPS, np.arange(len(vol)), vol)
mix = voice + music * g
cache = {}
for s in meta['SFX']:
    x = cache.setdefault(s['name'], load(f"{PUB}/sfx/{s['name']}.wav"))
    a = int(round(round(s['at'] * FPS) / FPS * SR))
    if a < 0: x = x[-a:]; a = 0
    L = min(len(x), N - a)
    if L > 0: mix[a:a + L] += x[:L] * s['vol']
peak = np.max(np.abs(mix))
if peak > 0.98: mix *= 0.98 / peak
w.write(OUT, SR, (mix * 32767).astype(np.int16))
print('mix ok', round(N / SR, 2), 's peak', round(float(peak), 3))
