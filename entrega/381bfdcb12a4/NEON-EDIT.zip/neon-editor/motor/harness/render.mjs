// Uso: node render.mjs video <inicio> <fim> <saida.mp4>   |   node render.mjs stills <saida_dir> f1 f2 ...
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {createRequire} from 'node:module';
import {fileURLToPath, pathToFileURL} from 'node:url';
// Playwright: do motor (npm install -D playwright) ou de NEON_NODE_TOOLS / /opt/npm-tools (ambiente na nuvem)
const _req = createRequire(import.meta.url);
const _paths = [path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../node_modules'), process.env.NEON_NODE_TOOLS, '/opt/npm-tools/node_modules'].filter(Boolean);
const _pw = await import(pathToFileURL(_req.resolve('playwright', {paths: _paths})).href);
const chromium = _pw.chromium ?? _pw.default.chromium;
const PUB = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../public');
const types = {'.html': 'text/html', '.js': 'text/javascript', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.ttf': 'font/ttf', '.wav': 'audio/wav', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml', '.otf': 'font/otf', '.woff2': 'font/woff2', '.woff': 'font/woff', '.mp3': 'audio/mpeg'};
const server = http.createServer((req, res) => {
	const p = path.join(PUB, decodeURIComponent(req.url.split('?')[0]));
	fs.readFile(p.endsWith('/') ? p + 'index.html' : p, (e, d) => {
		if (e) { res.writeHead(404); return res.end(); }
		res.writeHead(200, {'Content-Type': types[path.extname(p)] || 'application/octet-stream'});
		res.end(d);
	});
});
await new Promise((r) => server.listen(0, r));
const port = server.address().port;

const browser = await chromium.launch({args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--disable-web-security']});
const PW = Number(process.env.PREVIEW_W || 1080);
const page = await browser.newPage({viewport: {width: PW, height: Math.round((PW * 1920) / 1080)}, deviceScaleFactor: 1});
const errs = [];
page.on('pageerror', (e) => errs.push(e.message));
page.on('console', (m) => { if (m.type() === 'error') errs.push(m.text()); });
await page.goto(`http://127.0.0.1:${port}/index.html?w=${PW}`);
await page.waitForFunction(() => typeof window.setFrame === 'function');
const mode = process.argv[2];
if (mode === 'meta') {
	const meta = await page.evaluate(() => window.__meta);
	fs.writeFileSync(process.argv[3], JSON.stringify(meta, null, 1));
} else if (mode === 'stills') {
	const out = process.argv[3];
	fs.mkdirSync(out, {recursive: true});
	for (const f of process.argv.slice(4).map(Number)) {
		await page.evaluate((f) => window.setFrame(f), f);
		await page.screenshot({path: `${out}/f${String(f).padStart(5, '0')}.jpg`, type: 'jpeg', quality: 92});
	}
} else {
	const [a, b, out] = [Number(process.argv[3]), Number(process.argv[4]), process.argv[5]];
	const ff = spawn('ffmpeg', ['-v', 'error', '-y', '-f', 'image2pipe', '-framerate', '30', '-c:v', 'mjpeg', '-i', '-', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', process.env.CRF || '14', '-pix_fmt', 'yuv420p', '-r', '30', out], {stdio: ['pipe', 'inherit', 'inherit']});
	const t0 = Date.now();
	for (let f = a; f < b; f++) {
		await page.evaluate((f) => window.setFrame(f), f);
		const buf = await page.screenshot({type: 'jpeg', quality: 95});
		if (!ff.stdin.write(buf)) await new Promise((r) => ff.stdin.once('drain', r));
		if ((f - a) % 60 === 0) console.log(`frame ${f} (${((Date.now() - t0) / 1000 / Math.max(1, f - a + 1)).toFixed(2)} s/f)`);
	}
	ff.stdin.end();
	await new Promise((r) => ff.on('close', r));
}
if (errs.length) console.log('ERROS NA PÁGINA:\n' + [...new Set(errs)].slice(0, 20).join('\n'));
await browser.close();
server.close();
