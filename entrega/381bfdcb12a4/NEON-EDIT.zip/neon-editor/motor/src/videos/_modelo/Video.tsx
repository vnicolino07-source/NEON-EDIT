/**
 * MODELO DE VÍDEO (ponto de partida para "edita esse vídeo").
 * Copie esta pasta para src/videos/<id-do-video>/ e preencha:
 *  1) BLOCKS (legendas) a partir de src/data/words.json do vídeo atual;
 *  2) CENAS: cada cena = janela de tempo (derivada das palavras com T()) + layout + card/3D;
 *  3) SFX e VISUAL_EVENTS (auditoria da regra dos 2 s).
 * Os textos abaixo são de EXEMPLO — troque tudo pelo conteúdo do vídeo novo. Para uma direção completa, veja
 * src/videos/demonstracao/Video.tsx (mesma estrutura do vídeo aprovado v002).
 */
import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {holdRender} from '../../engine/render';
import {buildBlocks} from '../../engine/captions';
import {Plate} from '../../engine/Plate';
import {SoundTrack, Sfx} from '../../engine/SoundTrack';
import {FPS, T, TOTAL_FRAMES} from '../../engine/timing';
import {NeonCaptionTrack} from '../../components/neon/NeonCaptionTrack';
import {ensureNeonFonts, NeonFrame} from '../../components/neon/NeonLayout';
import {NeonChecklist, NeonPrompt} from '../../components/neon/NeonCards';

ensureNeonFonts(() => holdRender('fonts'));

// 1) legendas (EXEMPLO — gerar a partir da transcrição do vídeo atual)
export const BLOCKS: string[] = [];

// 2) cenas: [início, fim, layout(0 tela cheia | 1 dividido), card]
type Cena = {a: number; b: number; split: number; slot?: (t: number) => React.ReactNode; behind?: (t: number) => React.ReactNode};
const CENAS: Cena[] = [
	{a: 0, b: 5, split: 0},
	{a: 5, b: 10, split: 1, slot: (t) => <NeonPrompt t={t} text="exemplo de comando" typeStart={0.3} typeEnd={2} sendAt={2.2} exitAt={4.6} />},
	{a: 10, b: 14, split: 1, slot: (t) => <NeonChecklist t={t} label="exemplo" items={['um', 'dois', 'três']} exitAt={3.6} />},
];

// 3) efeitos e eventos (EXEMPLO)
export const SFX: Sfx[] = [{at: 5, name: 'whoosh', vol: 0.2}];
export const VISUAL_EVENTS: [number, string][] = CENAS.map((c) => [c.a, 'cena']);

const blocks = BLOCKS.length ? buildBlocks(BLOCKS) : [];
void T;

export const Video: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
	const frame = useCurrentFrame();
	const t = frame / FPS;
	const c = CENAS.find((x) => t >= x.a && t < x.b) ?? CENAS[CENAS.length - 1];
	const prev = CENAS[CENAS.indexOf(c) - 1];
	// transição de layout de 0,35 s na entrada da cena
	const split = prev ? interpolate(t, [c.a, c.a + 0.35], [prev.split, c.split], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) : c.split;
	return (
		<AbsoluteFill>
			<NeonFrame split={split} slot={c.slot?.(t - c.a)} caption={<NeonCaptionTrack t={t} blocks={blocks} />}>
				<Plate frame={frame} behind={c.behind?.(t - c.a)} />
			</NeonFrame>
			{withAudio ? <SoundTrack sfx={SFX} total={TOTAL_FRAMES} /> : null}
		</AbsoluteFill>
	);
};
