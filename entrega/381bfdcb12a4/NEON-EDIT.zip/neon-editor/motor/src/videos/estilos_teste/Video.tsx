/** Teste visual dos estilos explicativos (sem narração própria): 0–6 linha · 6–12 partículas · 12–18 argila · 18–24 colagem */
import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {FPS} from '../../engine/timing';
import {ensureXFonts, KCap, BigStat, TopTitle, Handle, Grain, Pop} from '../../estilos/base';
import {LINHA, LineIcon, LinhaBg, OrbitDot, Tag, Trace, SquareGrid} from '../../estilos/linha';
import {DotField, textPts, galaxy, sphere, iconPts, waveGrid, animateWave} from '../../estilos/particulas';
import {ArgilaStage, ArgilaBg, ARGILA} from '../../estilos/argila3d';
import {PaperBg, TapedPhoto, RedactedDoc, TornStrip, Scraps, Silhueta, COLAGEM} from '../../estilos/colagem';

export const SFX = [];
export const VISUAL_EVENTS: [number, string][] = [];
const P = {e: textPts('E=mc²', 230), y: textPts('1905', 260), gal: galaxy(400), sph: sphere(320), olho: iconPts('olho', 640), wave: waveGrid()};
export const Video: React.FC<{withAudio?: boolean}> = () => {
	ensureXFonts();
	const t = useCurrentFrame() / FPS;
	return (
		<AbsoluteFill style={{background: '#000'}}>
			{t < 6 ? <>
				<LinhaBg t={t} />
				<LineIcon t={t} name="cabeca" at={0.2} size={420} x={360} y={720} label="VOCÊ" labelPos="bottom" />
				<LineIcon t={t} name="cabeca" at={0.9} size={420} x={720} y={720} label="ALGUÉM" labelPos="bottom" />
				<Trace t={t} at={1.8} d="M420 560 C520 440 620 440 700 560" color={LINHA.accent} />
				<LineIcon t={t} name="orbita" at={2.8} size={260} x={540} y={420} />
				<OrbitDot t={t} at={3.2} cx={540} cy={420} r={115} />
				<Tag t={t} at={3.3} x={540} y={250} text="A MENTE SELECIONA" />
				<SquareGrid t={t} at={4} cols={6} rows={4} lit={7} cell={70} x={330} y={960} />
				<KCap t={t} kind="suave" accent={LINHA.accent} hl={new Set(['corte', 'live'])} />
				<Handle text="@seuperfil" color="#BDB6AE" />
			</> : null}
			{t >= 6 && t < 12 ? <>
				<div style={{position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 40%, #151515, #000 70%)'}} />
				<DotField t={t} keys={[{at: 6, pts: P.y}, {at: 7.4, pts: P.e}, {at: 8.8, pts: P.gal, spin: 0.4, tilt: 1.1}, {at: 10.2, pts: animateWave(P.wave, t), tilt: 0.9, spin: 0.15}, {at: 11.2, pts: P.olho}]} />
				<Grain t={t} o={0.08} />
				<KCap t={t} kind="suave" accent="#FFFFFF" />
			</> : null}
			{t >= 12 && t < 18 ? <>
				<ArgilaBg t={t} kind={t < 15 ? 'estudio' : 'cidade'} />
				<ArgilaStage t={t} shots={[{obj: 'calendario', at: 12, ate: 13.4, args: {dia: '8'}}, {obj: 'barras', at: 13.5, ate: 14.9, args: {valores: [0.5, 0.65, 1]}}, {obj: 'moeda', at: 15, ate: 16.2}, {obj: 'celular', at: 16.3, ate: 18, args: {texto: 'AO VIVO'}}]} />
				<TopTitle t={t} at={12.1} until={13.4} text="Dia 8 de outubro" color="#FFFFFF" accent={ARGILA.accent} hl={['8']} />
				{t > 13.5 && t < 15 ? <BigStat t={t} at={13.5} value="+38%" label="exemplo ilustrativo" color={ARGILA.accent} y={300} size={150} /> : null}
				<KCap t={t} kind="escuro" accent={ARGILA.accent} hl={new Set(['corte', 'live', 'gta'])} />
			</> : null}
			{t >= 18 ? <>
				<PaperBg t={t} />
				<Scraps t={t} at={18} seed={4} />
				<TapedPhoto t={t} at={18.2} until={20.4} caption="Retrato, 1905"><Silhueta label="FOTO LIBERADA AQUI" /></TapedPhoto>
				<RedactedDoc t={t} at={20.5} until={22.6} title="Um padrão que você normalizou." circle={3} circleAt={21.6} />
				<TornStrip t={t} at={22.7} text="alguns passos à frente" y={760} />
				<KCap t={t} kind="papel" accent={COLAGEM.accent} hl={new Set(['corte', 'live', 'perfil'])} />
				<Grain t={t} o={0.05} />
			</> : null}
			<Pop t={t} at={999}><div /></Pop>
		</AbsoluteFill>
	);
};
