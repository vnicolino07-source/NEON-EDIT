/**
 * VITRINE DA DIREÇÃO ADAPTATIVA — três "assuntos" (empreendedorismo, tecnologia, marketing) com vocabulário visual
 * diferente, sobre os quadros sintéticos da demonstração. Serve para testar os componentes de
 * components/adaptativo/ com qualquer marca. NÃO é um modelo para copiar: mostra o alcance, não uma receita.
 */
import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {COLOR, FONT, SPACE} from '../../brand/neon';
import {holdRender} from '../../engine/render';
import {Sfx} from '../../engine/SoundTrack';
import {ensureNeonFonts} from '../../components/neon/NeonLayout';
import {Label} from '../../components/neon/NeonCards';
import {layoutWeights, PresenterStage, zoomSteps} from '../../components/experimental/PresenterStage';
import {CodeWindow, FunnelCard, GrowthChart, KineticStack, MetricTiles, Stamp, TechHUD, VersusCard} from '../../components/adaptativo/Adaptativos';
import {Bars3D, Coins3D, Network3D} from '../../components/adaptativo/Adaptativos3D';

ensureNeonFonts(() => holdRender('fonts'));
const FPS = 30;
export const ADAPTATIVO_FRAMES = 540;

export const SFX: Sfx[] = [
	{at: 0, name: 'impact', vol: 0.26}, {at: 0.3, name: 'paper', vol: 0.18}, {at: 2.8, name: 'whoosh', vol: 0.22}, {at: 4.4, name: 'pop', vol: 0.2},
	{at: 6, name: 'whoosh', vol: 0.22}, {at: 6.2, name: 'riser', vol: 0.14}, {at: 9, name: 'whoosh_short', vol: 0.2}, {at: 10.6, name: 'type', vol: 0.2},
	{at: 12, name: 'whoosh', vol: 0.22}, {at: 12.4, name: 'pop', vol: 0.2}, {at: 14.8, name: 'click', vol: 0.2}, {at: 16.6, name: 'impact', vol: 0.28}, {at: 17.1, name: 'click', vol: 0.26},
];
export const VISUAL_EVENTS: [number, string][] = [
	[0, 'moedas 3D + tipografia'], [0.6, 'palavra 2'], [1.2, 'palavra 3 destacada'], [2.0, 'pilhas crescem'], [2.8, 'tela desce + gráfico'], [3.6, 'linha cresce'],
	[4.4, 'indicadores'], [5.2, 'indicador 2'], [6, 'tela cheia + rede 3D'], [7.2, 'rede completa'], [8.2, 'reenquadramento'], [9, 'HUD tecnológico'],
	[10.6, 'código digitando'], [11.4, 'linhas'], [12, 'funil'], [12.8, 'etapa 2'], [13.6, 'etapa 3'], [14.8, 'comparação'], [15.8, 'vencedor'], [16.6, 'barras 3D'], [17.1, 'carimbo'],
];

const Tag: React.FC<{text: string}> = ({text}) => (
	<div style={{position: 'absolute', left: SPACE.framePadX, bottom: 120, background: COLOR.panel, border: `${SPACE.border}px solid ${COLOR.line}`, borderRadius: 999, padding: '14px 30px'}}>
		<Label style={{fontSize: 30}} color={COLOR.lime}>
			{text}
		</Label>
	</div>
);

export const Video: React.FC = () => {
	const frame = useCurrentFrame();
	const t = frame / FPS;
	const m = layoutWeights(t, {split: [[2.8, 5.8], [9, 11.8], [12, 16.4]]});
	const zoom = zoomSteps(t, [[0, 1.12], [2.0, 1.04], [6, 1.14], [8.2, 1.04], [16.6, 1.1]]);
	const behind = (
		<>
			{t < 2.9 ? <Coins3D t={t - 0.2} count={15} span={1.6} exitAt={2.5} /> : null}
			{t >= 5.9 && t < 9.1 ? <Network3D t={t - 6} nodes={44} y={1.55} scale={0.78} exitAt={2.7} width={1080} height={1920} /> : null}
			{t >= 16.4 ? (
				<div style={{position: 'absolute', left: 0, top: 40}}>
					<Bars3D t={t - 16.5} values={[3, 4, 6, 9]} />
				</div>
			) : null}
		</>
	);
	let slot: React.ReactNode = null;
	if (t >= 2.8 && t < 4.5) slot = <GrowthChart t={t - 2.8} label="crescimento" values={[12, 18, 15, 27, 34, 52]} labels={['jan', 'fev', 'mar', 'abr', 'mai', 'jun']} exitAt={1.4} />;
	if (t >= 4.4 && t < 5.9) slot = <MetricTiles t={t - 4.4} items={[{label: 'clientes', trend: 'up', at: 0}, {label: 'custo', trend: 'down', at: 0.8}]} exitAt={1.15} />;
	if (t >= 9 && t < 10.7) slot = <TechHUD t={t - 9} title="sistema ativo" lines={['lendo o vídeo', 'transcrevendo', 'montando cenas']} exitAt={1.35} />;
	if (t >= 10.6 && t < 12) slot = <CodeWindow t={t - 10.6} file="editor.ts" code={['const video = await carregar()', 'for (const cena of plano) {', '  render(cena)', '}']} charsPerSec={70} exitAt={1.05} />;
	if (t >= 12 && t < 14.9) slot = <FunnelCard t={t - 12} label="funil" stages={[{text: 'alcance', at: 0.2}, {text: 'interesse', at: 0.8}, {text: 'compra', at: 1.6}]} exitAt={2.5} />;
	if (t >= 14.8 && t < 16.5) slot = <VersusCard t={t - 14.8} label="comparação" a={{title: 'antes', items: ['manual', 'lento']}} b={{title: 'agora', items: ['automático', 'rápido']}} winner="b" winnerAt={1.0} exitAt={1.35} />;
	const tag = t < 6 ? 'assunto: empreendedorismo' : t < 12 ? 'assunto: tecnologia' : 'assunto: marketing';
	return (
		<AbsoluteFill style={{background: COLOR.ink, fontFamily: FONT.display, color: COLOR.text}}>
			<PresenterStage frame={frame % 540} t={t} weights={m} zoom={zoom} behind={behind} cutout={t < 2.9 || (t >= 5.9 && t < 9.1) || t >= 16.4} />
			{slot ? (
				<div style={{position: 'absolute', left: SPACE.framePadX, top: SPACE.framePadY, width: 1080 - 2 * SPACE.framePadX, height: 1920 * SPACE.slotMinHeight, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{slot}</div>
			) : null}
			{t < 2.8 ? (
				<div style={{position: 'absolute', left: 70, top: 1180}}>
					<KineticStack t={t} words={[{text: 'lucro', at: 0}, {text: 'que', at: 0.6, size: 90}, {text: 'cresce', at: 1.2, hl: true}]} exitAt={2.5} />
				</div>
			) : null}
			{t >= 16.4 ? (
				<>
					<div style={{position: 'absolute', left: 0, right: 0, top: 1240, textAlign: 'center'}}>
						<Stamp t={t - 16.5} at={0.6} text="aprovado" />
					</div>
				</>
			) : null}
			<Tag text={tag} />
		</AbsoluteFill>
	);
};
