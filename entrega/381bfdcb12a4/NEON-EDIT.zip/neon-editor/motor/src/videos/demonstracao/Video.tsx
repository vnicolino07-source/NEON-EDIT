/**
 * DEMONSTRAÇÃO DO MOTOR (dados sintéticos de `pipeline/demo.py`, nenhum vídeo real).
 * Serve para: (1) teste de instalação e portabilidade, (2) ver a marca ativa aplicada a componentes avançados,
 * (3) exemplo de COMO se escreve a direção de um vídeo: todo tempo vem de T('palavra', n), cada efeito demonstra a frase.
 *
 * Estrutura igual à do vídeo aprovado v002 (ver references/16-casos-aprovados.md), com texto genérico.
 */
import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {COLOR, FONT, SPACE} from '../../brand/neon';
import {holdRender} from '../../engine/render';
import {buildBlocks, blockAt} from '../../engine/captions';
import {SoundTrack, Sfx} from '../../engine/SoundTrack';
import {FPS, T, TE, TOTAL_FRAMES, WORDS} from '../../engine/timing';
import {phase, easeCss, pop} from '../../motion/neonMotion';
import {ensureNeonFonts, NeonCaption} from '../../components/neon/NeonLayout';
import {Label, NeonPrompt, NeonToasts} from '../../components/neon/NeonCards';
import {ShatterText3D} from '../../components/experimental/ShatterText3D';
import {captionY, layoutWeights, PresenterStage, zoomSteps} from '../../components/experimental/PresenterStage';
import {KineticGiantText, LiveExplain, OnePrompt, PostPanel} from '../../components/experimental/V002Motions';

ensureNeonFonts(() => holdRender('fonts'));

const S = {
	motor: T('motor'), primeiro: T('primeiro'), explode: T('explode'), tela1: T('tela', 1), depois: T('depois'), celular: T('celular'),
	pronto: T('pronto'), postar: T('postar'), agora: T('agora'), texto: T('texto'), cabeca: T('cabeca'), se: T('se'), corta: T('corta'),
	meio: T('meio'), meioFim: TE('meio'), desce: T('desce'), explicacao: T('explicacao'), cima: T('cima'), tudo: T('tudo'), prompt: T('prompt'),
	comenta: T('comenta'), demo: T('demo'), comentarios: T('comentarios'),
};

const BLOCKS = [
	'Este vídeo de', 'demonstração mostra', 'o *motor* do editor', 'funcionando', 'Primeiro uma palavra', 'em três dimensões',
	'*explode* na tela', 'Depois o vídeo', 'vira um *celular*', 'e fica pronto', 'para *postar*', 'Agora um', '!texto gigante',
	'!aparece atrás', '!da minha cabeça', 'Se eu pedir', 'ele *corta*', 'essa tela no *meio*', 'A minha tela *desce*', '!e a explicação',
	'!fica em cima', 'Tudo com um', '!só prompt', 'Comenta aí *demo*', 'nos comentários',
];
const blocks = buildBlocks(BLOCKS);

export const SFX: Sfx[] = [
	{at: 0, name: 'impact', vol: 0.3},
	{at: S.motor, name: 'laser', vol: 0.22},
	{at: S.explode, name: 'shatter', vol: 0.34},
	{at: S.depois - 0.1, name: 'whoosh', vol: 0.22},
	{at: S.postar, name: 'click', vol: 0.3},
	{at: S.postar + 0.6, name: 'riser', vol: 0.14},
	{at: S.texto - 0.4, name: 'reverse', vol: 0.2},
	{at: S.texto + 0.05, name: 'impact', vol: 0.3},
	{at: S.corta, name: 'laser', vol: 0.3},
	{at: S.meio, name: 'whoosh', vol: 0.26},
	{at: S.desce - 0.1, name: 'whoosh', vol: 0.24},
	{at: S.cima, name: 'whoosh_short', vol: 0.2},
	{at: S.tudo, name: 'pop', vol: 0.22},
	{at: S.prompt + 0.1, name: 'whoosh_short', vol: 0.18},
	{at: S.comenta, name: 'pop', vol: 0.22},
	{at: S.demo, name: 'type', vol: 0.2},
	{at: S.demo + 0.35, name: 'click', vol: 0.26},
	{at: S.comentarios + 0.3, name: 'ding', vol: 0.18},
];

export const VISUAL_EVENTS: [number, string][] = [
	[0, 'título 3D + zoom'], [S.motor, 'risco'], [T('funcionando'), 'reenquadramento'], [S.primeiro, 'reenquadramento'], [T('dimensoes'), 'tremor'],
	[S.explode, 'explosão'], [S.depois - 0.05, 'vira celular'], [S.celular, 'painel'], [S.pronto, 'reenquadramento do painel'], [S.postar, 'postado'],
	[S.postar + 0.6, 'curva'], [S.agora - 0.25, 'tela cheia'], [S.texto, 'texto gigante atrás'], [S.cabeca, 'texto trava'], [S.se, 'texto sai'],
	[S.corta, 'laser'], [S.meio, 'tela cortada'], [S.meioFim + 0.5, 'tela volta'], [S.desce, 'tela desce'], [S.explicacao, 'explicação ao vivo'],
	[S.cima, 'seta'], [S.tudo, '1 prompt'], [S.prompt + 0.1, 'enviado'], [S.comenta, 'CTA'], [S.demo, 'palavra digitada'], [S.comentarios + 0.3, 'notificação'],
];

// largura interna do card do CTA (largura do card − 2 × padding): os campos internos não podem ser mais largos que isso
const CARD_IN = 1080 - 2 * SPACE.framePadX - 2 * 48;

const REFRAMES: [number, number][] = [[0, 1.14], [T('funcionando'), 1.05], [S.primeiro, 1.1], [S.agora, 1.02], [S.cabeca, 1.1], [S.se, 1.04], [S.comenta, 1.1]];

export const Video: React.FC<{withAudio?: boolean}> = ({withAudio = true}) => {
	const frame = useCurrentFrame();
	const t = frame / FPS;
	const m = layoutWeights(t, {split: [[S.desce - 0.05, S.comenta - 0.25]], phone: [[S.depois - 0.05, S.agora - 0.25]]});
	const hookOn = t < S.explode + 1.0;
	const giantOn = t >= S.texto - 0.1 && t < S.se + 0.1;
	const behind = (
		<>
			{hookOn ? <ShatterText3D t={t} lines={['MOTOR', 'DO EDITOR']} accentLine={1} strikeAt={S.motor} explodeAt={S.explode + 0.08} y={1.85} /> : null}
			{giantOn ? <KineticGiantText t={t - S.texto} lines={['TEXTO', 'GIGANTE']} landAt={0} lockAt={S.cabeca - S.texto} exitAt={S.se - 0.25 - S.texto} top={230} /> : null}
		</>
	);
	let slot: React.ReactNode = null;
	if (t >= S.desce - 0.1 && t < S.tudo - 0.1)
		slot = <LiveExplain t={t - (S.desce - 0.05)} abs={t} words={WORDS.filter((w) => w.start >= S.desce - 0.05 && w.start < S.tudo).map((w) => ({w: w.w, start: w.start}))} exitAt={S.tudo - 0.4 - (S.desce - 0.05)} />;
	if (t >= S.tudo - 0.15 && t < S.comenta) slot = <OnePrompt t={t - (S.tudo - 0.1)} sendAt={S.prompt + 0.1 - (S.tudo - 0.1)} exitAt={S.comenta - 0.35 - (S.tudo - 0.1)} />;
	const b = blockAt(blocks, t);
	return (
		<AbsoluteFill style={{background: COLOR.ink, fontFamily: FONT.display, color: COLOR.text}}>
			<PresenterStage frame={frame} t={t} weights={m} zoom={zoomSteps(t, REFRAMES)} behind={behind} cutout={hookOn || giantOn} cut={{laserAt: S.corta, splitAt: S.meio, joinAt: S.meioFim + 0.5}} />
			{slot ? (
				<div style={{position: 'absolute', left: SPACE.framePadX, top: SPACE.framePadY, width: 1080 - 2 * SPACE.framePadX, height: 1920 * SPACE.slotMinHeight, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{slot}</div>
			) : null}
			{t >= S.depois - 0.05 && t < S.agora ? (
				<div style={{position: 'absolute', left: 655, top: 520, transform: 'scale(1.3)', transformOrigin: '0 0'}}>
					<PostPanel t={t - S.depois} postAt={S.postar - S.depois} viewsAt={S.postar + 0.6 - S.depois} exitAt={S.agora - 0.35 - S.depois} />
				</div>
			) : null}
			{t >= S.cima - 0.1 && t < S.tudo - 0.2 ? (
				<div style={{position: 'absolute', right: 90, top: 760, width: 120, height: 120, borderRadius: 30, background: COLOR.lime, display: 'grid', placeItems: 'center', ...pop(t - S.cima, 0)}}>
					<svg width="70" height="70" viewBox="0 0 24 24" fill="none" stroke={COLOR.ink} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
						<path d="M12 19V5M5 12l7-7 7 7" />
					</svg>
				</div>
			) : null}
			{t >= S.comenta - 0.1 ? (
				<div style={{position: 'absolute', left: SPACE.framePadX, top: 150, width: 1080 - 2 * SPACE.framePadX, display: 'flex', flexDirection: 'column', gap: 30, background: COLOR.panel, border: `${SPACE.border}px solid ${COLOR.line}`, borderRadius: 56, padding: 48, boxSizing: 'border-box', ...pop(t - (S.comenta - 0.1), 0)}}>
					<Label style={{fontSize: 40}}>comenta a palavra</Label>
					<NeonPrompt t={t - S.comenta} width={CARD_IN} text="DEMO" typeStart={S.demo - S.comenta} typeEnd={S.demo - S.comenta + 0.25} sendAt={S.demo - S.comenta + 0.35} />
					{t >= S.comentarios + 0.3 ? <NeonToasts t={t - (S.comentarios + 0.3)} width={CARD_IN} items={[{title: 'Comentário recebido', sub: 'demonstração', icon: 'bell'}]} /> : null}
				</div>
			) : null}
			{b && !b.hidden ? (
				<div style={{position: 'absolute', left: 0, right: 0, top: captionY(m), transform: 'translateY(-50%)', opacity: 1 - phase(t, TOTAL_FRAMES / FPS - 0.2, 0.2, easeCss)}}>
					<NeonCaption t={t} words={b.toks.map((k) => ({text: k.text, start: k.start, hl: k.hl}))} size={m.split > 0.5 ? 64 : 76} />
				</div>
			) : null}
			{withAudio ? <SoundTrack sfx={SFX} total={TOTAL_FRAMES} /> : null}
		</AbsoluteFill>
	);
};
