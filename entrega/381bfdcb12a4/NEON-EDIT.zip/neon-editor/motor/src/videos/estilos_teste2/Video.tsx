/** Teste visual dos 9 estilos da biblioteca ampliada (usa as palavras do projeto vinculado só para a legenda).
 * 0 quadro · 3.8 kinetic · 7.6 infográfico · 11.4 interface · 15.2 jornal · 19 blueprint · 22.8 retrô · 26.6 flat · 30.4 mapa */
import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {FPS} from '../../engine/timing';
import {ensureXFonts, KCap, XFONT} from '../../estilos/base';
import {QUADRO, QuadroBg, GizDefs, GizIcon, GizText, GizMark, Apagador} from '../../estilos/quadro';
import {KINETIC, KineticStack, BgMarquee, Slam} from '../../estilos/kinetic';
import {INFO, InfoBg, Counter, BarChart, PictoGrid, FonteTag} from '../../estilos/infografico';
import {UI, UiBg, Phone, ChatScreen, Notif, Encenacao} from '../../estilos/interface';
import {JORNAL, JornalBg, PrimeiraPagina, Carimbo} from '../../estilos/jornal';
import {BP, BlueprintBg, BpIcon, Cota, Chamada, Engrenagem} from '../../estilos/blueprint';
import {RETRO, RetroBg, ChromeText, VHS, Glitch} from '../../estilos/retro';
import {FLAT, FlatBg, Forma, Boneco, FlatIcon, ListaItem, Cobertura} from '../../estilos/flat';
import {MAPA, WorldMap} from '../../estilos/mapa';

export const SFX = [];
export const VISUAL_EVENTS: [number, string][] = [];
const S = [0, 3.8, 7.6, 11.4, 15.2, 19, 22.8, 26.6, 30.4, 40];
export const Video: React.FC<{withAudio?: boolean}> = () => {
	ensureXFonts();
	const t = useCurrentFrame() / FPS;
	const sc = S.findIndex((a, i) => t >= a && t < S[i + 1]);
	const s = S[sc];
	return (
		<AbsoluteFill style={{background: '#000'}}>
			{sc === 0 ? <>
				<QuadroBg t={t} />
				<GizDefs />
				<GizText t={t} at={0.1} text="Por que adiamos?" x={540} y={300} size={110} />
				<GizMark t={t} at={1.0} kind="sublinha" x={250} y={430} w={580} h={40} />
				<GizIcon t={t} name="cerebro" at={1.2} size={380} x={540} y={800} />
				<GizMark t={t} at={2.1} kind="seta" x={720} y={760} w={220} h={90} color={QUADRO.rosa} />
				<GizText t={t} at={2.3} text="emoção!" x={830} y={880} size={72} color={QUADRO.amarelo} rot={-6} />
				<GizMark t={t} at={2.6} kind="circulo" x={330} y={590} w={420} h={420} color={QUADRO.azul} />
				<Apagador t={t} at={3.2} />
				<KCap t={t} kind="suave" font={XFONT.giz} size={68} ink={QUADRO.giz} dim="rgba(237,235,228,.35)" accent={QUADRO.amarelo} hl={new Set(['preguica', 'tempo'])} />
			</> : null}
			{sc === 1 ? <>
				<div style={{position: 'absolute', inset: 0, background: KINETIC.bg}} />
				<BgMarquee t={t} words={['CÉREBRO', 'EMOÇÃO']} />
				<KineticStack t={t} big={new Set(['carleton', 'canada'])} hl={new Set(['carleton', 'canada', 'anos'])} />
				<Slam t={t} at={6.6} until={7.5} text="ANOS" y={1350} size={200} />
			</> : null}
			{sc === 2 ? <>
				<InfoBg t={t} />
				<Counter t={t} at={7.7} to={20} suffix="%" label="exemplo de contador (dado ilustrativo)" y={250} size={170} />
				<BarChart t={t} at={8.4} data={[{label: 'SEG', v: 2}, {label: 'TER', v: 3}, {label: 'QUA', v: 5}, {label: 'QUI', v: 4}, {label: 'SEX', v: 8, hl: true}]} y={620} h={420} />
				<PictoGrid t={t} at={10.2} n={10} cols={10} lit={2} cell={84} y={1110} />
				<FonteTag t={t} at={8} text="FONTE: DADO ILUSTRATIVO" y={1230} />
				<KCap t={t} kind="escuro" accent={INFO.accent} y={1450} hl={new Set(['emocao'])} />
			</> : null}
			{sc === 3 ? <>
				<UiBg t={t} />
				<Phone t={t} at={11.4} y={720} scale={0.82}>
					<ChatScreen t={t} title="Você do futuro" msgs={[{at: 11.9, who: 'eu', text: 'Amanhã eu faço, prometo'}, {at: 13.0, who: 'ele', text: 'Você disse isso ontem 😅'}, {at: 14.2, who: 'eu', text: 'Hoje não dá...'}]} />
					<Notif t={t} at={12.3} until={13.6} app="Lembrete" text="Entregar o relatório — atrasado" y={150} alerta />
				</Phone>
				<Encenacao t={t} at={11.6} />
				<KCap t={t} kind="pilula" accent={UI.accent} y={1500} />
			</> : null}
			{sc === 4 ? <>
				<JornalBg t={t} mesa />
				<PrimeiraPagina t={t} at={15.2} data="12 DE MARÇO DE 1987" kicker="CIÊNCIA" title="Adiar é fugir de emoção" foto={<div style={{position: 'absolute', inset: 0, background: 'radial-gradient(circle at 50% 40%, #9a8f7a, #4a4236)'}} />} />
				<Carimbo t={t} at={17.2} text="CONFIRMADO" x={700} y={900} />
				<KCap t={t} kind="papel" font={XFONT.maquina} weight={700} accent={JORNAL.marca} ink="#FFF6E0" y={1480} />
			</> : null}
			{sc === 5 ? <>
				<BlueprintBg t={t} carimbo="PROJETO 036 — MOTIVAÇÃO" />
				<BpIcon t={t} name="lampada" at={19.1} size={460} x={540} y={680} />
				<Cota t={t} at={20.2} x1={310} y1={440} x2={310} y2={920} off={-60} label="48 cm" />
				<Chamada t={t} at={20.8} x={540} y={560} tx={800} ty={400} text="IDEIA" />
				<Chamada t={t} at={21.3} x={540} y={940} tx={760} ty={1080} text="BASE" />
				<Engrenagem t={t} at={19.5} x={260} y={1110} r={90} speed={0.9} />
				<Engrenagem t={t} at={19.6} x={404} y={1110} r={62} teeth={8} speed={-1.3} color={BP.accent} />
				<KCap t={t} kind="suave" font={XFONT.mono} size={46} ink={BP.line} dim="rgba(220,235,255,.4)" accent={BP.accent} y={1420} />
			</> : null}
			{sc === 6 ? <>
				<Glitch t={t} at={[22.8, 24.6]}>
					<RetroBg t={t} horizon={1000} />
					<ChromeText t={t} at={23.0} text="FUTURO" sub="VOCÊ • 2049" y={520} />
				</Glitch>
				<KCap t={t} kind="suave" font={XFONT.retro} weight={700} size={42} ink="#FFFFFF" glow={RETRO.rosa} accent={RETRO.ciano} y={1450} />
				<VHS t={t} />
			</> : null}
			{sc === 7 ? <>
				<FlatBg t={t} />
				<Boneco t={t} at={26.7} x={300} y={980} cor={FLAT.c2} acao="pensa" />
				<FlatIcon t={t} at={27.2} name="escada" x={780} y={520} bg={FLAT.c3} />
				<Forma t={t} at={27.0} kind="estrela" x={860} y={820} size={120} color={FLAT.c4} rot={12} />
				<Forma t={t} at={27.1} kind="anel" x={160} y={360} size={120} color={FLAT.c1} />
				<ListaItem t={t} at={28.2} n={1} text="Passo menor" y={1080} cor={FLAT.c1} />
				<Cobertura t={t} at={29.6} cor={MAPA.bg} />
				<KCap t={t} kind="pilula" accent={FLAT.c4} y={1420} />
			</> : null}
			{sc === 8 ? <>
				<WorldMap t={t} cams={[{at: 30.4, foco: [0, 20], zoom: 1}, {at: 32.0, foco: 'Canada', zoom: 2.6}, {at: 33.4, foco: 'Brazil', zoom: 2.2}]} hl={[{at: 31.0, pais: 'Canada'}, {at: 32.6, pais: 'Brazil', cor: MAPA.rota}]} pinos={[{at: 31.4, onde: [-75.7, 45.4], label: 'Ottawa'}]} rotas={[{at: 32.2, de: [-75.7, 45.4], para: 'Brazil', dur: 1.3}]} />
				<KCap t={t} kind="escuro" accent={MAPA.hl} y={1450} />
			</> : null}
		</AbsoluteFill>
	);
};
