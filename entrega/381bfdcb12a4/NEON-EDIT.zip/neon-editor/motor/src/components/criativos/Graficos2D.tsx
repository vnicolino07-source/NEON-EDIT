/**
 * [NOVOS — kit 1.0.0-rc2] Vocabulário visual 2D para direção criativa adaptativa (negócios, marketing, tecnologia,
 * educação...). Todos usam só tokens da marca e são determinísticos por quadro. `t` = segundos desde a entrada.
 * Situação (conferida em 29/10, 15h): compila, renderiza na VitrineCriativa e passa no qa_layout (amostra de 12 quadros). Nenhum aprovado por cliente.
 *
 * Regra de conteúdo: números, nomes e percentuais SÓ quando ditos na fala (ou confirmados pela pessoa).
 */
import React from 'react';
import {COLOR, FONT, RADIUS, SPACE, TYPE, alpha} from '../../brand/neon';
import {easeBrand, easeCss, easeStandard, phase, pop, popOut} from '../../motion/neonMotion';

const clamp = (x: number) => Math.max(0, Math.min(1, x));
const out = (t: number, at?: number) => (at !== undefined && t >= at ? popOut(t, at) : {});
const mono: React.CSSProperties = {fontFamily: FONT.mono, letterSpacing: '0.1em', textTransform: 'uppercase', color: COLOR.mute};
const card: React.CSSProperties = {background: COLOR.panel, border: `${SPACE.border}px solid ${COLOR.line}`, borderRadius: RADIUS.card, boxSizing: 'border-box'};
const fmt = (n: number, dec = 0) => n.toLocaleString('pt-BR', {minimumFractionDigits: dec, maximumFractionDigits: dec});

/** Painel de indicadores: cada número sobe do zero quando é dito; mini-gráfico opcional por indicador. */
export const MetricBoard: React.FC<{
	t: number;
	title?: string;
	items: {label: string; value: number; prefix?: string; suffix?: string; decimals?: number; at: number; trend?: number[]; delta?: string}[];
	exitAt?: number;
	width?: number;
}> = ({t, title, items, exitAt, width = 1080 - 2 * SPACE.framePadX}) => (
	<div style={{width, ...card, padding: 40, display: 'flex', flexDirection: 'column', gap: 26, ...pop(t, 0), ...out(t, exitAt)}}>
		{title ? <div style={{...mono, fontSize: TYPE.label * 0.8}}>{title}</div> : null}
		<div style={{display: 'grid', gridTemplateColumns: `repeat(${Math.min(items.length, 2)}, 1fr)`, gap: 22}}>
			{items.map((it, i) => {
				const p = phase(t, it.at, 1.1, (x) => 1 - Math.pow(1 - x, 3));
				const on = phase(t, it.at - 0.15, 0.45, easeBrand);
				const tr = it.trend ?? [];
				const mx = Math.max(...tr, 1), mn = Math.min(...tr, 0);
				const pts = tr.map((v, k) => `${(k / Math.max(1, tr.length - 1)) * 100},${38 - ((v - mn) / Math.max(1e-6, mx - mn)) * 34}`).join(' ');
				return (
					<div key={i} style={{background: COLOR.panel2, border: `${SPACE.border}px solid ${COLOR.line}`, borderRadius: RADIUS.card * 0.6, padding: '24px 26px', opacity: on, transform: `translateY(${(1 - on) * 30}px)`, minWidth: 0}}>
						<div style={{...mono, fontSize: 30}}>{it.label}</div>
						<div style={{fontFamily: FONT.display, fontWeight: 700, fontSize: 116, letterSpacing: '-0.03em', lineHeight: 1.05, color: i === items.length - 1 ? COLOR.lime : COLOR.text, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap'}}>
							{it.prefix ?? ''}
							{fmt(it.value * p, it.decimals ?? 0)}
							{it.suffix ?? ''}
						</div>
						{it.delta ? (
							<span style={{display: 'inline-block', marginTop: 6, background: COLOR.limeSoft, color: COLOR.lime, borderRadius: 999, padding: '4px 16px', fontFamily: FONT.mono, fontSize: 24, opacity: phase(t, it.at + 0.6, 0.3)}}>{it.delta}</span>
						) : null}
						{tr.length > 1 ? (
							<svg viewBox="0 0 100 40" preserveAspectRatio="none" style={{width: '100%', height: 70, marginTop: 10}}>
								<polyline points={pts} fill="none" stroke={COLOR.lime} strokeWidth={2.4} vectorEffect="non-scaling-stroke" strokeLinejoin="round" strokeDasharray={300} strokeDashoffset={300 * (1 - phase(t, it.at + 0.2, 1.0, easeStandard))} />
							</svg>
						) : null}
					</div>
				);
			})}
		</div>
	</div>
);

/** Gráfico de linha com área: desenha da esquerda para a direita; ponto final pulsando no acento. */
export const LineChart: React.FC<{t: number; label?: string; values: number[]; xLabels?: string[]; drawAt?: number; drawDur?: number; endLabel?: string; exitAt?: number; width?: number; height?: number}> = ({
	t, label, values, xLabels, drawAt = 0.2, drawDur = 1.4, endLabel, exitAt, width = 1080 - 2 * SPACE.framePadX, height = 520,
}) => {
	const W = 1000, H = 420, pad = 30;
	const mx = Math.max(...values), mn = Math.min(0, ...values);
	const P = values.map((v, i) => [pad + (i / Math.max(1, values.length - 1)) * (W - 2 * pad), H - pad - ((v - mn) / Math.max(1e-6, mx - mn)) * (H - 2 * pad)]);
	const d = P.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
	const pr = phase(t, drawAt, drawDur, easeStandard);
	const len = P.reduce((a, p, i) => (i ? a + Math.hypot(p[0] - P[i - 1][0], p[1] - P[i - 1][1]) : 0), 0);
	const k = Math.min(P.length - 1, Math.floor(pr * (P.length - 1) + 1e-6));
	const last = P[P.length - 1];
	const pulse = 1 + 0.25 * Math.abs(Math.sin((t - drawAt - drawDur) * 4));
	return (
		<div style={{width, ...card, padding: 36, ...pop(t, 0), ...out(t, exitAt)}}>
			{label ? <div style={{...mono, fontSize: TYPE.label * 0.8, marginBottom: 14}}>{label}</div> : null}
			<svg viewBox={`0 0 ${W} ${H}`} style={{width: '100%', height: height - 120}}>
				{[0.25, 0.5, 0.75].map((g) => (
					<line key={g} x1={pad} x2={W - pad} y1={pad + g * (H - 2 * pad)} y2={pad + g * (H - 2 * pad)} stroke={COLOR.line} strokeWidth={2} strokeDasharray="6 10" />
				))}
				<defs>
					<linearGradient id="lc-area" x1="0" y1="0" x2="0" y2="1">
						<stop offset="0" stopColor={COLOR.lime} stopOpacity={0.35} />
						<stop offset="1" stopColor={COLOR.lime} stopOpacity={0} />
					</linearGradient>
					<clipPath id="lc-clip">
						<rect x={0} y={0} width={pad + pr * (W - 2 * pad)} height={H} />
					</clipPath>
				</defs>
				<path d={`${d} L${last[0]},${H - pad} L${P[0][0]},${H - pad} Z`} fill="url(#lc-area)" clipPath="url(#lc-clip)" />
				<path d={d} fill="none" stroke={COLOR.lime} strokeWidth={7} strokeLinejoin="round" strokeLinecap="round" strokeDasharray={len} strokeDashoffset={len * (1 - pr)} />
				{P.slice(0, k + 1).map((p, i) => (
					<circle key={i} cx={p[0]} cy={p[1]} r={i === P.length - 1 && pr >= 1 ? 14 * pulse : 8} fill={i === P.length - 1 && pr >= 1 ? COLOR.lime : COLOR.panel} stroke={COLOR.lime} strokeWidth={4} />
				))}
			</svg>
			{xLabels ? (
				<div style={{display: 'flex', justifyContent: 'space-between', ...mono, fontSize: 24, marginTop: 6}}>
					{xLabels.map((x, i) => <span key={i}>{x}</span>)}
				</div>
			) : null}
			{endLabel ? <div style={{marginTop: 14, fontFamily: FONT.display, fontWeight: 700, fontSize: 52, color: COLOR.lime, opacity: phase(t, drawAt + drawDur, 0.3)}}>{endLabel}</div> : null}
		</div>
	);
};

/** Fluxo A → B → C: cada nó acende na sua palavra; o conector desenha e um pulso viaja até o próximo nó. */
export const FlowDiagram: React.FC<{t: number; nodes: {label: string; sub?: string; at: number}[]; vertical?: boolean; exitAt?: number; width?: number}> = ({t, nodes, vertical = false, exitAt, width = 1080 - 2 * SPACE.framePadX}) => (
	<div style={{width, display: 'flex', flexDirection: vertical ? 'column' : 'row', alignItems: 'center', ...out(t, exitAt)}}>
		{nodes.map((n, i) => {
			const on = phase(t, n.at - 0.1, 0.5, easeBrand);
			const lit = t >= n.at;
			const next = nodes[i + 1];
			const link = next ? phase(t, n.at + 0.1, Math.max(0.2, next.at - n.at - 0.1), easeCss) : 0;
			return (
				<React.Fragment key={i}>
					<div style={{flex: vertical ? undefined : 1, minWidth: 0, width: vertical ? '100%' : undefined, ...card, background: lit ? COLOR.panel : COLOR.panel2, borderColor: lit ? COLOR.lime : COLOR.line, padding: '26px 18px', textAlign: 'center', opacity: Math.max(0.25, on), transform: `scale(${0.9 + 0.1 * on})`}}>
						<div style={{width: 64, height: 64, borderRadius: 20, margin: '0 auto 14px', background: lit ? COLOR.lime : COLOR.line, color: COLOR.ink, display: 'grid', placeItems: 'center', fontFamily: FONT.mono, fontWeight: 700, fontSize: 30}}>{i + 1}</div>
						<div style={{fontFamily: FONT.display, fontWeight: 700, fontSize: 40, lineHeight: 1.1, color: COLOR.text, overflowWrap: 'anywhere'}}>{n.label}</div>
						{n.sub ? <div style={{...mono, fontSize: 22, marginTop: 8}}>{n.sub}</div> : null}
					</div>
					{next ? (
						<div style={{position: 'relative', flex: 'none', width: vertical ? 8 : 46, height: vertical ? 46 : 8, background: COLOR.line, borderRadius: 4, overflow: 'hidden'}}>
							<div style={{position: 'absolute', left: 0, top: 0, width: vertical ? '100%' : `${link * 100}%`, height: vertical ? `${link * 100}%` : '100%', background: COLOR.lime}} />
						</div>
					) : null}
				</React.Fragment>
			);
		})}
	</div>
);

/** Interface tecnológica (HUD): grade, anel de varredura, linhas de "código/log" digitadas e chips de status. */
export const TechHUD: React.FC<{t: number; title: string; lines: {text: string; at: number}[]; status?: {label: string; at: number}[]; exitAt?: number; width?: number; height?: number}> = ({
	t, title, lines, status = [], exitAt, width = 1080 - 2 * SPACE.framePadX, height = 640,
}) => {
	const sweep = (t * 120) % 360;
	return (
		<div style={{position: 'relative', width, height, ...card, overflow: 'hidden', ...pop(t, 0), ...out(t, exitAt)}}>
			<svg width="100%" height="100%" style={{position: 'absolute', inset: 0}}>
				<defs>
					<pattern id="hud-grid" width="48" height="48" patternUnits="userSpaceOnUse">
						<path d="M48 0H0V48" fill="none" stroke={COLOR.line} strokeWidth="1.5" />
					</pattern>
				</defs>
				<rect width="100%" height="100%" fill="url(#hud-grid)" opacity={0.6} />
			</svg>
			<div style={{position: 'absolute', right: 40, top: 40, width: 220, height: 220}}>
				<svg viewBox="0 0 100 100" width="220" height="220">
					{[46, 34, 22].map((r) => <circle key={r} cx="50" cy="50" r={r} fill="none" stroke={COLOR.line} strokeWidth="1.2" />)}
					<path d={`M50 50 L${50 + 46 * Math.cos((sweep * Math.PI) / 180)} ${50 + 46 * Math.sin((sweep * Math.PI) / 180)}`} stroke={COLOR.lime} strokeWidth="2" />
					<circle cx="50" cy="50" r="46" fill="none" stroke={COLOR.lime} strokeWidth="1.6" strokeDasharray={`${40 + 30 * Math.sin(t * 2)} 300`} transform={`rotate(${sweep} 50 50)`} />
					<circle cx="50" cy="50" r={4 + 1.5 * Math.sin(t * 6)} fill={COLOR.lime} />
				</svg>
			</div>
			<div style={{position: 'absolute', left: 40, top: 36, right: 280}}>
				<div style={{...mono, fontSize: 24, color: COLOR.lime}}>● {title}</div>
				<div style={{marginTop: 24, display: 'flex', flexDirection: 'column', gap: 14}}>
					{lines.map((l, i) => {
						const n = Math.round(l.text.length * clamp((t - l.at) / Math.max(0.2, l.text.length * 0.03)));
						if (t < l.at) return null;
						return (
							<div key={i} style={{fontFamily: FONT.mono, fontSize: 30, color: COLOR.text, whiteSpace: 'pre-wrap', overflowWrap: 'anywhere'}}>
								<span style={{color: COLOR.mute}}>{'> '}</span>
								{l.text.slice(0, n)}
								{n < l.text.length && Math.floor(t * 4) % 2 === 0 ? <span style={{color: COLOR.lime}}>▍</span> : null}
							</div>
						);
					})}
				</div>
			</div>
			<div style={{position: 'absolute', left: 40, right: 40, bottom: 36, display: 'flex', gap: 14, flexWrap: 'wrap'}}>
				{status.map((s, i) => {
					const on = phase(t, s.at, 0.4, easeBrand);
					return (
						<span key={i} style={{fontFamily: FONT.mono, fontSize: 24, padding: '10px 18px', borderRadius: 999, border: `${SPACE.border}px solid ${COLOR.lime}`, color: COLOR.lime, background: alpha(COLOR.lime, 0.1), opacity: on, transform: `scale(${0.8 + 0.2 * on})`}}>
							✓ {s.label}
						</span>
					);
				})}
			</div>
		</div>
	);
};

/** Tipografia cinética sincronizada: as palavras entram na hora em que são ditas, empilhadas; destaque no acento. */
export const KineticWords: React.FC<{t: number; words: {text: string; start: number; hl?: boolean}[]; size?: number; align?: 'left' | 'center'; exitAt?: number; width?: number}> = ({
	t, words, size = TYPE.quote, align = 'left', exitAt, width = 1080 - 2 * SPACE.framePadX,
}) => (
	<div style={{width, textAlign: align, fontFamily: FONT.display, fontWeight: 700, fontSize: size, lineHeight: 1.02, letterSpacing: '-0.03em', ...out(t, exitAt)}}>
		{words.map((w, i) => {
			const p = phase(t, w.start - 0.05, 0.35, easeBrand);
			return (
				<span key={i} style={{display: 'inline-block', marginRight: '0.22em', opacity: clamp(p * 1.6), transform: `translateY(${(1 - p) * 0.5 * size}px) rotate(${(1 - p) * (i % 2 ? 4 : -4)}deg)`, color: w.hl ? COLOR.ink : COLOR.text, background: w.hl ? COLOR.lime : 'transparent', padding: w.hl ? '0 0.12em' : 0, borderRadius: w.hl ? RADIUS.hl : 0, textShadow: w.hl ? 'none' : '0 10px 40px rgba(0,0,0,0.45)'}}>
					{w.text}
				</span>
			);
		})}
	</div>
);
