/**
 * [NOVOS — kit 1.0.0-rc2] Cenas 3D reais (Three.js) para direção adaptativa. Materiais e luz seguem as regras aprovadas
 * (references/07): frente na cor da marca, lateral escura, chave de cima-esquerda + luz de borda no acento.
 * Tudo é função de `t` (determinístico). Geometrias procedurais: nenhum modelo ou textura de terceiros.
 * Situação (conferida em 29/10, 15h): compila, renderiza na VitrineCriativa e passa no qa_layout (amostra de 12 quadros). Nenhum aprovado por cliente.
 */
import React, {useCallback} from 'react';
import {staticFile} from 'remotion';
import * as THREE from 'three';
import {Font} from 'three/examples/jsm/loaders/FontLoader.js';
import {TTFLoader} from 'three/examples/jsm/loaders/TTFLoader.js';
import {TextGeometry} from 'three/examples/jsm/geometries/TextGeometry.js';
import {COLOR, FONT_FILES} from '../../brand/neon';
import {ThreeLayer, ThreeCtx} from '../three/ThreeLayer';

const smooth = (t: number, a: number, b: number) => {
	const x = Math.max(0, Math.min(1, (t - a) / (b - a)));
	return x * x * (3 - 2 * x);
};
const back = (x: number) => {
	const c = 1.7;
	const y = Math.max(0, Math.min(1, x)) - 1;
	return 1 + (c + 1) * y * y * y + c * y * y;
};
const rnd = (s: number) => {
	const x = Math.sin(s * 127.1 + 311.7) * 43758.5453;
	return x - Math.floor(x);
};
const luzes = (scene: THREE.Scene) => {
	scene.add(new THREE.AmbientLight(0xffffff, 0.8));
	const key = new THREE.DirectionalLight(0xffffff, 2.3);
	key.position.set(-4, 6, 9);
	scene.add(key);
	const rim = new THREE.PointLight(new THREE.Color(COLOR.lime), 30, 25);
	rim.position.set(4, -2, 5);
	scene.add(rim);
};
const mats = (accent: boolean) => [
	new THREE.MeshStandardMaterial({color: new THREE.Color(accent ? COLOR.lime : COLOR.text), roughness: 0.35, metalness: 0.05, transparent: true}),
	new THREE.MeshStandardMaterial({color: new THREE.Color(accent ? COLOR.limeDim : COLOR.line), roughness: 0.5, transparent: true}),
];

/** Gráfico de barras 3D: barras sobem em sequência com overshoot; a de destaque fica no acento. */
type BarsSt = {bars: THREE.Mesh[]; group: THREE.Group};
export const Bars3D: React.FC<{t: number; values: number[]; highlight?: number; growAt?: number; stagger?: number; exitAt?: number; y?: number; size?: number}> = ({
	t, values, highlight = values.length - 1, growAt = 0.2, stagger = 0.15, exitAt, y = 0, size = 1,
}) => {
	const init = useCallback(({scene, camera}: Omit<ThreeCtx<BarsSt>, 'state'>): BarsSt => {
		camera.position.set(0, 0, 11);
		luzes(scene);
		const group = new THREE.Group();
		const mx = Math.max(...values, 1e-6);
		const n = values.length;
		const bars = values.map((v, i) => {
			const h = Math.max(0.05, (v / mx) * 3.0);
			const geo = new THREE.BoxGeometry(0.75, h, 0.75);
			geo.translate(0, h / 2, 0);
			const m = new THREE.Mesh(geo, mats(i === highlight)[0]);
			m.position.set((i - (n - 1) / 2) * 1.05, 0, 0);
			group.add(m);
			return m;
		});
		const base = new THREE.Mesh(new THREE.BoxGeometry(n * 1.05 + 0.6, 0.08, 1.4), new THREE.MeshStandardMaterial({color: new THREE.Color(COLOR.line), roughness: 0.6}));
		base.position.y = -0.04;
		group.add(base);
		scene.add(group);
		return {bars, group};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);
	const update = useCallback(
		(c: ThreeCtx<BarsSt>, t: number) => {
			c.state.bars.forEach((b, i) => b.scale.set(1, Math.max(0.001, back((t - growAt - i * stagger) / 0.7)), 1));
			const o = exitAt !== undefined ? smooth(t, exitAt, exitAt + 0.35) : 0;
			c.state.group.position.y = y - 4 * o;
			// cabe na largura visível (≈ 4 unidades em z = 0 com a câmera padrão)
			c.state.group.scale.setScalar(size * Math.min(1, 3.3 / (c.state.bars.length * 1.05 + 0.6)));
			c.state.group.rotation.set(0.12, -0.45 + 0.25 * Math.sin(t * 0.6), 0);
		},
		[growAt, stagger, exitAt, y, size],
	);
	return <ThreeLayer t={t} init={init} update={update} />;
};

/** Rede 3D (IA, conexões, sistemas): nós aparecem, arestas se ligam, pulsos viajam pelas conexões. */
type NetSt = {nodes: THREE.Mesh[]; edges: {line: THREE.Line; a: number; b: number}[]; pulses: THREE.Mesh[]; group: THREE.Group};
export const Network3D: React.FC<{t: number; count?: number; buildAt?: number; buildDur?: number; pulseAt?: number; exitAt?: number; y?: number; size?: number; seed?: number}> = ({
	t, count = 22, buildAt = 0, buildDur = 1.2, pulseAt, exitAt, y = 0, size = 1, seed = 3,
}) => {
	const init = useCallback(({scene, camera}: Omit<ThreeCtx<NetSt>, 'state'>): NetSt => {
		camera.position.set(0, 0, 11);
		luzes(scene);
		const group = new THREE.Group();
		const P = Array.from({length: count}, (_, i) => {
			const u = rnd(seed + i * 3), v = rnd(seed + i * 3 + 1), r = 1.3 + 0.6 * rnd(seed + i * 3 + 2);
			const th = 2 * Math.PI * u, ph = Math.acos(2 * v - 1);
			return new THREE.Vector3(r * Math.sin(ph) * Math.cos(th), r * Math.cos(ph) * 0.8, r * Math.sin(ph) * Math.sin(th));
		});
		const nodes = P.map((p, i) => {
			const m = new THREE.Mesh(new THREE.SphereGeometry(i % 5 === 0 ? 0.24 : 0.14, 24, 16), new THREE.MeshStandardMaterial({color: new THREE.Color(i % 5 === 0 ? COLOR.lime : COLOR.text), roughness: 0.3, transparent: true}));
			m.position.copy(p);
			group.add(m);
			return m;
		});
		const edges: NetSt['edges'] = [];
		P.forEach((p, i) => {
			const near = P.map((q, j) => [p.distanceTo(q), j] as [number, number]).filter(([, j]) => j !== i).sort((a, b) => a[0] - b[0]).slice(0, 2);
			near.forEach(([, j]) => {
				if (edges.some((e) => (e.a === j && e.b === i) || (e.a === i && e.b === j))) return;
				const g = new THREE.BufferGeometry().setFromPoints([p, P[j]]);
				const line = new THREE.Line(g, new THREE.LineBasicMaterial({color: new THREE.Color(COLOR.lime), transparent: true, opacity: 0}));
				group.add(line);
				edges.push({line, a: i, b: j});
			});
		});
		const pulses = edges.slice(0, 8).map(() => {
			const m = new THREE.Mesh(new THREE.SphereGeometry(0.09, 12, 8), new THREE.MeshBasicMaterial({color: new THREE.Color(COLOR.lime), transparent: true, opacity: 0}));
			group.add(m);
			return m;
		});
		scene.add(group);
		return {nodes, edges, pulses, group};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);
	const update = useCallback(
		(c: ThreeCtx<NetSt>, t: number) => {
			const {nodes, edges, pulses, group} = c.state;
			const o = exitAt !== undefined ? smooth(t, exitAt, exitAt + 0.4) : 0;
			nodes.forEach((m, i) => {
				const a = back((t - buildAt - (i / nodes.length) * buildDur * 0.6) / 0.5);
				m.scale.setScalar(Math.max(0.001, a * (1 - o)));
			});
			edges.forEach((e, k) => {
				(e.line.material as THREE.LineBasicMaterial).opacity = 0.55 * smooth(t, buildAt + buildDur * 0.4 + (k / edges.length) * buildDur * 0.6, buildAt + buildDur + 0.2) * (1 - o);
			});
			pulses.forEach((m, k) => {
				const e = edges[(k * 3) % edges.length];
				const on = pulseAt !== undefined && t >= pulseAt;
				const u = on ? ((t - pulseAt! + k * 0.17) * 0.9) % 1 : 0;
				m.position.lerpVectors(nodes[e.a].position, nodes[e.b].position, u);
				(m.material as THREE.MeshBasicMaterial).opacity = on ? (1 - o) : 0;
			});
			group.rotation.set(0.15, t * 0.35, 0);
			group.position.y = y;
			group.scale.setScalar(size * (1 + 0.15 * o));
		},
		[buildAt, buildDur, pulseAt, exitAt, y, size],
	);
	return <ThreeLayer t={t} init={init} update={update} />;
};

/** Símbolo 3D procedural (sem assets de terceiros): engrenagem, seta de crescimento, alvo, coração, play, estrela,
 * balão de conversa, moeda, ou um caractere da fonte da marca (`glyph`, ex.: "$", "%", "?", "@", "1"). */
export type SymbolKind = 'gear' | 'arrow' | 'target' | 'heart' | 'play' | 'star' | 'bubble' | 'coin' | 'glyph';
const shapeOf = (kind: SymbolKind): THREE.Shape | THREE.Shape[] => {
	const s = new THREE.Shape();
	if (kind === 'gear') {
		const n = 10, r1 = 1.0, r2 = 1.25;
		for (let i = 0; i < n * 4; i++) {
			const a = (i / (n * 4)) * Math.PI * 2, r = i % 4 < 2 ? r2 : r1;
			const x = r * Math.cos(a), y = r * Math.sin(a);
			if (i === 0) s.moveTo(x, y); else s.lineTo(x, y);
		}
		s.closePath();
		const hole = new THREE.Path();
		hole.absarc(0, 0, 0.42, 0, Math.PI * 2, true);
		s.holes.push(hole);
	} else if (kind === 'arrow') {
		// seta de crescimento: haste + ponta, inclinada 40°
		const P: [number, number][] = [[-0.22, -1.3], [0.22, -1.3], [0.22, 0.35], [0.62, 0.35], [0, 1.3], [-0.62, 0.35], [-0.22, 0.35]];
		const c = Math.cos(-0.7), sn = Math.sin(-0.7);
		P.map(([x, y]) => [x * c - y * sn, x * sn + y * c]).forEach(([x, y], i) => (i ? s.lineTo(x, y) : s.moveTo(x, y)));
		s.closePath();
	} else if (kind === 'target') {
		s.absarc(0, 0, 1.25, 0, Math.PI * 2, false);
		const h = new THREE.Path(); h.absarc(0, 0, 0.95, 0, Math.PI * 2, true); s.holes.push(h);
		const s2 = new THREE.Shape(); s2.absarc(0, 0, 0.7, 0, Math.PI * 2, false);
		const h2 = new THREE.Path(); h2.absarc(0, 0, 0.42, 0, Math.PI * 2, true); s2.holes.push(h2);
		const s3 = new THREE.Shape(); s3.absarc(0, 0, 0.2, 0, Math.PI * 2, false);
		return [s, s2, s3];
	} else if (kind === 'heart') {
		s.moveTo(0, -1.1); s.bezierCurveTo(-1.4, -0.1, -1.1, 1.1, 0, 0.45); s.bezierCurveTo(1.1, 1.1, 1.4, -0.1, 0, -1.1);
	} else if (kind === 'play') {
		s.moveTo(-0.8, -1.0); s.lineTo(1.1, 0); s.lineTo(-0.8, 1.0); s.closePath();
	} else if (kind === 'star') {
		for (let i = 0; i < 10; i++) {
			const a = Math.PI / 2 + (i / 10) * Math.PI * 2, r = i % 2 ? 0.5 : 1.25;
			if (i === 0) s.moveTo(r * Math.cos(a), r * Math.sin(a)); else s.lineTo(r * Math.cos(a), r * Math.sin(a));
		}
		s.closePath();
	} else if (kind === 'bubble') {
		s.moveTo(-1.1, 0.9); s.lineTo(1.1, 0.9); s.quadraticCurveTo(1.3, 0.9, 1.3, 0.7); s.lineTo(1.3, -0.4); s.quadraticCurveTo(1.3, -0.6, 1.1, -0.6);
		s.lineTo(-0.2, -0.6); s.lineTo(-0.7, -1.1); s.lineTo(-0.6, -0.6); s.lineTo(-1.1, -0.6); s.quadraticCurveTo(-1.3, -0.6, -1.3, -0.4); s.lineTo(-1.3, 0.7); s.quadraticCurveTo(-1.3, 0.9, -1.1, 0.9);
	} else {
		s.absarc(0, 0, 1.2, 0, Math.PI * 2, false);
	}
	return s;
};
type SymSt = {group: THREE.Group; mesh: THREE.Object3D};
export const Symbol3D: React.FC<{t: number; kind: SymbolKind; glyph?: string; accent?: boolean; at?: number; spin?: number; exitAt?: number; x?: number; y?: number; size?: number}> = ({
	t, kind, glyph = '$', accent = true, at = 0, spin = 0.6, exitAt, x = 0, y = 0, size = 1,
}) => {
	const init = useCallback(async ({scene, camera}: Omit<ThreeCtx<SymSt>, 'state'>): Promise<SymSt> => {
		camera.position.set(0, 0, 10);
		luzes(scene);
		const group = new THREE.Group();
		let geo: THREE.BufferGeometry;
		if (kind === 'glyph') {
			const buf = await (await fetch(staticFile(FONT_FILES.display3d))).arrayBuffer();
			const font = new Font(new TTFLoader().parse(buf));
			geo = new TextGeometry(glyph, {font, size: 2.2, depth: 0.6, curveSegments: 10, bevelEnabled: true, bevelThickness: 0.06, bevelSize: 0.04, bevelSegments: 4});
		} else if (kind === 'coin') {
			geo = new THREE.CylinderGeometry(1.2, 1.2, 0.28, 64);
			geo.rotateX(Math.PI / 2);
		} else {
			geo = new THREE.ExtrudeGeometry(shapeOf(kind), {depth: 0.5, bevelEnabled: true, bevelThickness: 0.08, bevelSize: 0.06, bevelSegments: 4, curveSegments: 24});
		}
		geo.center();
		const mesh = new THREE.Mesh(geo, mats(accent));
		group.add(mesh);
		scene.add(group);
		return {group, mesh};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);
	const update = useCallback(
		(c: ThreeCtx<SymSt>, t: number) => {
			const a = back((t - at) / 0.6);
			const o = exitAt !== undefined ? smooth(t, exitAt, exitAt + 0.35) : 0;
			c.state.group.scale.setScalar(Math.max(0.001, size * a * (1 - o)));
			c.state.group.position.set(x, y + 0.12 * Math.sin(t * 2.2), 0);
			c.state.group.rotation.set(0.15 * Math.sin(t * 1.3), (t - at) * spin * Math.PI + 0.3, 0);
		},
		[at, spin, exitAt, x, y, size],
	);
	return <ThreeLayer t={t} init={init} update={update} />;
};
