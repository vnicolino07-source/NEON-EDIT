/**
 * Objetos 3D REAIS (Three.js) na paleta Neon. A biblioteca Neon não define materiais 3D:
 * cores vêm dos tokens; rugosidade, metalicidade e luz são [derivado] e foram validados nos vídeos aprovados.
 * `t` = segundos desde o início do componente.
 */
import React, {useCallback} from 'react';
import {staticFile} from 'remotion';
import * as THREE from 'three';
import {Font} from 'three/examples/jsm/loaders/FontLoader.js';
import {TTFLoader} from 'three/examples/jsm/loaders/TTFLoader.js';
import {TextGeometry} from 'three/examples/jsm/geometries/TextGeometry.js';
import {COLOR, FONT_FILES} from '../../brand/neon';
import {ThreeLayer, ThreeCtx} from './ThreeLayer';

const hex = (c: string) => new THREE.Color(c);
const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
const spring = (t: number, a: number, dur = 0.6) => {
	if (t <= a) return 0;
	const x = Math.min(1, (t - a) / dur);
	return x >= 1 ? 1 : 1 - Math.exp(-6 * x) * Math.cos(x * Math.PI * 2.2);
};
const smooth = (t: number, a: number, b: number) => {
	const x = clamp01((t - a) / (b - a));
	return x * x * (3 - 2 * x);
};
const rand = (s: number) => {
	const x = Math.sin(s * 127.1 + 311.7) * 43758.5453;
	return x - Math.floor(x);
};

/** Texto extrudado 3D (Space Grotesk 700), com sombra numa "parede" invisível. Para palavra/frase âncora atrás do apresentador. */
type TxtSt = {group: THREE.Group; lines: THREE.Mesh[]};
export const Text3D: React.FC<{
	t: number;
	lines: string[]; // até 2 linhas
	lineTimes?: number[]; // entrada de cada linha (s)
	y?: number; // altura do grupo (mundo; ~1.9 = topo, acima da cabeça)
	size?: number; // escala base
	growAt?: number; // cresce para ocupar o fundo
	spinAt?: number; // volta completa em Y
	exitAt?: number;
	accentLine?: number; // linha em neon (as outras em texto claro)
}> = ({t, lines, lineTimes = [0, 0.25], y = 1.9, size = 0.5, growAt, spinAt, exitAt, accentLine = lines.length - 1}) => {
	const init = useCallback(async ({scene, camera}: Omit<ThreeCtx<TxtSt>, 'state'>): Promise<TxtSt> => {
		camera.position.set(0, 0, 10);
		const buf = await (await fetch(staticFile(FONT_FILES.display3d))).arrayBuffer();
		const font = new Font(new TTFLoader().parse(buf));
		const group = new THREE.Group();
		const meshes = lines.map((txt, i) => {
			const geo = new TextGeometry(txt, {font, size: 1, depth: 0.4, curveSegments: 8, bevelEnabled: true, bevelThickness: 0.04, bevelSize: 0.025, bevelSegments: 4});
			geo.center();
			const front = new THREE.MeshStandardMaterial({color: hex(i === accentLine ? COLOR.lime : COLOR.text), roughness: 0.35, metalness: 0.05});
			const side = new THREE.MeshStandardMaterial({color: hex(i === accentLine ? COLOR.limeDim : COLOR.line), roughness: 0.5});
			const m = new THREE.Mesh(geo, [front, side]);
			m.castShadow = true;
			group.add(m);
			return m;
		});
		scene.add(group);
		scene.add(new THREE.AmbientLight(0xffffff, 0.85));
		const key = new THREE.DirectionalLight(0xffffff, 2.4);
		key.position.set(-4, 6, 9);
		key.castShadow = true;
		key.shadow.mapSize.set(2048, 2048);
		Object.assign(key.shadow.camera, {left: -8, right: 8, top: 8, bottom: -8});
		key.shadow.radius = 6;
		scene.add(key);
		const catcher = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), new THREE.ShadowMaterial({opacity: 0.25}));
		catcher.position.z = -2.2;
		catcher.receiveShadow = true;
		scene.add(catcher);
		return {group, lines: meshes};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);
	const update = useCallback(
		(c: ThreeCtx<TxtSt>, t: number) => {
			const n = c.state.lines.length;
			c.state.lines.forEach((m, i) => {
				const a = spring(t, lineTimes[i] ?? 0);
				m.scale.setScalar(Math.max(0.001, a));
				m.position.set(0, (n - 1) * 0.62 - i * 1.24, -6 * (1 - a));
			});
			const g = growAt !== undefined ? smooth(t, growAt, growAt + 0.8) : 0;
			const sp = spinAt !== undefined ? smooth(t, spinAt, spinAt + 0.8) : 0;
			const out = exitAt !== undefined ? smooth(t, exitAt, exitAt + 0.35) : 0;
			c.state.group.scale.setScalar(size * (1 + 0.6 * g));
			c.state.group.position.set(0, y - 0.7 * g + 6 * out, 0);
			c.state.group.rotation.set(-0.1 + 0.05 * Math.sin(t * 0.9), 0.1 * Math.sin(t * 0.7) + Math.PI * 2 * sp, 0.02 * Math.sin(t * 0.5));
		},
		[growAt, spinAt, exitAt, lineTimes, size, y],
	);
	return <ThreeLayer t={t} init={init} update={update} shadows />;
};

/** Objetos planos caindo com volume, rotação e flexão (papel, notas, cards). `draw` desenha a textura (canvas 640×280). */
type FallSt = {items: {mesh: THREE.Mesh; base: Float32Array; spawn: number; x0: number; z: number; speed: number; ph: number; rs: number[]; scale: number}[]};
export const Falling3D: React.FC<{
	t: number;
	draw: (g: CanvasRenderingContext2D, w: number, h: number) => void;
	waves: {at: number; count: number; span: number}[];
	layer: 'behind' | 'front'; // behind = entre fundo e recorte do apresentador; front = só nas laterais
	endAt?: number;
	seed?: number;
}> = ({t, draw, waves, layer, endAt, seed = 1}) => {
	const init = useCallback(({scene, camera}: Omit<ThreeCtx<FallSt>, 'state'>): FallSt => {
		camera.position.set(0, 0, 10);
		scene.add(new THREE.HemisphereLight(0xffffff, 0x334433, 1.5));
		const d = new THREE.DirectionalLight(0xffffff, 2.0);
		d.position.set(-3, 5, 6);
		scene.add(d);
		const cv = document.createElement('canvas');
		cv.width = 640;
		cv.height = 280;
		draw(cv.getContext('2d')!, 640, 280);
		const tex = new THREE.CanvasTexture(cv);
		tex.colorSpace = THREE.SRGBColorSpace;
		const items: FallSt['items'] = [];
		waves.forEach((wv, wi) => {
			for (let i = 0; i < wv.count; i++) {
				const s = seed * 1000 + wi * 100 + i * 13.7;
				const side = i % 2 ? 1 : -1;
				const z = layer === 'behind' ? -0.5 - rand(s + 1) * 2 : 2.4 + rand(s + 1) * 1.2;
				const x0 = layer === 'behind' ? (rand(s + 2) * 2 - 1) * 2.2 : side * (1.15 + rand(s + 2) * 0.4);
				const geo = new THREE.PlaneGeometry(1.5, 0.66, 18, 4);
				const m = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({map: tex, roughness: 0.6, side: THREE.DoubleSide, transparent: true}));
				scene.add(m);
				items.push({mesh: m, base: Float32Array.from(geo.attributes.position.array as Float32Array), spawn: wv.at + rand(s + 3) * wv.span, x0, z, speed: 2.1 + rand(s + 4) * 1.1, ph: rand(s + 5) * 6.28, rs: [rand(s + 6) * 4 - 2, rand(s + 7) * 3 - 1.5, rand(s + 8) * 2 - 1], scale: layer === 'front' ? 0.42 + rand(s + 9) * 0.18 : 0.6 + rand(s + 9) * 0.35});
			}
		});
		return {items};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);
	const update = useCallback(
		(c: ThreeCtx<FallSt>, t: number) => {
			const fade = endAt !== undefined ? 1 - clamp01((t - (endAt - 0.35)) / 0.3) : 1;
			for (const n of c.state.items) {
				const age = t - n.spawn;
				const m = n.mesh;
				m.visible = age >= 0;
				if (age < 0) continue;
				m.position.set(n.x0 + 0.3 * Math.sin(age * 1.9 + n.ph), 4.4 + (n.z < 0 ? -n.z * 0.4 : 0) - n.speed * age, n.z);
				m.rotation.set(n.rs[0] * age + n.ph, n.rs[1] * age, 0.6 * Math.sin(age * 1.6 + n.ph) + n.rs[2]);
				m.scale.setScalar(n.scale);
				const pos = m.geometry.attributes.position as THREE.BufferAttribute;
				for (let i = 0; i < pos.count; i++) pos.setZ(i, 0.13 * Math.sin(n.base[i * 3] * 2.2 + age * 6 + n.ph) + 0.05 * Math.sin(n.base[i * 3 + 1] * 4 + age * 3));
				pos.needsUpdate = true;
				m.geometry.computeVertexNormals();
				(m.material as THREE.MeshStandardMaterial).opacity = Math.min(1, age * 4) * fade;
			}
		},
		[endAt],
	);
	return <ThreeLayer t={t} init={init} update={update} />;
};

/** Relógio 3D com ponteiros acelerando até `slowAt` e desacelerando. Para tempo, prazo, economia de tempo. */
type ClockSt = {clock: THREE.Group; minute: THREE.Mesh; hour: THREE.Mesh};
export const Clock3D: React.FC<{t: number; slowAt: number; exitAt?: number; width?: number; height?: number}> = ({t, slowAt, exitAt, width = 1080, height = 900}) => {
	const init = useCallback(({scene, camera}: Omit<ThreeCtx<ClockSt>, 'state'>): ClockSt => {
		camera.position.set(0, 0, 9);
		camera.fov = 34;
		camera.aspect = width / height;
		camera.updateProjectionMatrix();
		const clock = new THREE.Group();
		const body = new THREE.Mesh(new THREE.CylinderGeometry(1.75, 1.75, 0.45, 96), new THREE.MeshStandardMaterial({color: hex(COLOR.panel), roughness: 0.5}));
		body.rotation.x = Math.PI / 2;
		clock.add(body);
		const rim = new THREE.Mesh(new THREE.TorusGeometry(1.76, 0.14, 32, 128), new THREE.MeshStandardMaterial({color: hex(COLOR.lime), roughness: 0.3, metalness: 0.3, emissive: hex(COLOR.lime), emissiveIntensity: 0.25}));
		rim.position.z = 0.2;
		clock.add(rim);
		const dial = new THREE.Mesh(new THREE.CircleGeometry(1.62, 96), new THREE.MeshStandardMaterial({color: hex(COLOR.panel2), roughness: 0.6}));
		dial.position.z = 0.231;
		dial.receiveShadow = true;
		clock.add(dial);
		const tickMat = new THREE.MeshStandardMaterial({color: hex(COLOR.mute)});
		for (let i = 0; i < 12; i++) {
			const big = i % 3 === 0;
			const tk = new THREE.Mesh(new THREE.BoxGeometry(big ? 0.09 : 0.05, big ? 0.3 : 0.18, 0.04), tickMat);
			const a = (i / 12) * Math.PI * 2;
			tk.position.set(Math.sin(a) * 1.38, Math.cos(a) * 1.38, 0.25);
			tk.rotation.z = -a;
			clock.add(tk);
		}
		const mk = (len: number, w: number, z: number, color: string) => {
			const g = new THREE.BoxGeometry(w, len, 0.06);
			g.translate(0, len / 2 - 0.12, 0);
			const m = new THREE.Mesh(g, new THREE.MeshStandardMaterial({color: hex(color)}));
			m.position.z = z;
			m.castShadow = true;
			clock.add(m);
			return m;
		};
		const hour = mk(0.85, 0.13, 0.33, COLOR.text);
		const minute = mk(1.3, 0.08, 0.42, COLOR.lime);
		scene.add(clock);
		scene.add(new THREE.AmbientLight(0xffffff, 0.9));
		const key = new THREE.DirectionalLight(0xffffff, 2.0);
		key.position.set(-3, 4, 7);
		key.castShadow = true;
		scene.add(key);
		return {clock, minute, hour};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);
	const update = useCallback(
		(c: ThreeCtx<ClockSt>, t: number) => {
			const p = spring(t, 0.05, 0.7);
			const out = exitAt !== undefined ? smooth(t, exitAt, exitAt + 0.3) : 0;
			const ang = t < slowAt ? 14 * t : 14 * slowAt + (14 / 3) * (1 - Math.exp(-3 * (t - slowAt)));
			c.state.clock.scale.setScalar(Math.max(0.001, p * (1 - 0.6 * out)));
			c.state.clock.rotation.set(0.12 + 0.05 * Math.sin(t * 1.3), -0.5 * (1 - p) + 0.22 * Math.sin(t * 0.9), 0);
			c.state.minute.rotation.z = -ang;
			c.state.hour.rotation.z = -ang / 12 - 1.2;
		},
		[slowAt, exitAt],
	);
	return <ThreeLayer t={t} init={init} update={update} width={width} height={height} shadows />;
};
