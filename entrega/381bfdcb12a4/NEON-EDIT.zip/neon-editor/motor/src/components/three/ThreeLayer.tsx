import React, {useLayoutEffect, useRef, useState} from 'react';
import * as THREE from 'three';
import {holdRender} from '../../engine/render';
const W = 1080;
const H = 1920;

export type ThreeCtx<S> = {renderer: THREE.WebGLRenderer; scene: THREE.Scene; camera: THREE.PerspectiveCamera; state: S};

/**
 * Camada Three.js determinística: o estado da cena é calculado a partir do tempo
 * (frame) e renderizado de forma síncrona a cada quadro — sem relógio do navegador.
 */
export function ThreeLayer<S>({
	t,
	init,
	update,
	width = W,
	height = H,
	style,
	shadows = false,
}: {
	t: number;
	init: (ctx: Omit<ThreeCtx<S>, 'state'>) => Promise<S> | S;
	update: (ctx: ThreeCtx<S>, t: number) => void;
	width?: number;
	height?: number;
	style?: React.CSSProperties;
	shadows?: boolean;
}) {
	const canvasRef = useRef<HTMLCanvasElement>(null);
	const ctxRef = useRef<ThreeCtx<S> | null>(null);
	const [ready, setReady] = useState(false);

	useLayoutEffect(() => {
		const done = holdRender('three-init');
		const renderer = new THREE.WebGLRenderer({canvas: canvasRef.current!, antialias: true, alpha: true, preserveDrawingBuffer: true});
		renderer.setPixelRatio(1);
		renderer.setSize(width, height, false);
		renderer.setClearColor(0x000000, 0);
		renderer.outputColorSpace = THREE.SRGBColorSpace;
		renderer.toneMapping = THREE.ACESFilmicToneMapping;
		renderer.toneMappingExposure = 1.05;
		if (shadows) {
			renderer.shadowMap.enabled = true;
			renderer.shadowMap.type = THREE.PCFSoftShadowMap;
		}
		const scene = new THREE.Scene();
		const camera = new THREE.PerspectiveCamera(36, width / height, 0.1, 200);
		let alive = true;
		Promise.resolve(init({renderer, scene, camera})).then(
			(state) => {
				if (!alive) return done();
				ctxRef.current = {renderer, scene, camera, state};
				setReady(true);
				done();
			},
			(e) => {
				console.error(e);
				done();
			},
		);
		return () => {
			alive = false;
			renderer.dispose();
			renderer.forceContextLoss();
		};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);

	useLayoutEffect(() => {
		const c = ctxRef.current;
		if (!c) return;
		update(c, t);
		c.renderer.render(c.scene, c.camera);
	}, [t, ready, update]);

	return <canvas ref={canvasRef} width={width} height={height} style={{position: 'absolute', left: 0, top: 0, width, height, ...style}} />;
}
