/**
 * Layout e legenda da Biblioteca Neon.
 * - NeonFrame: quadro 9:16 com área do card no topo (≥ 38% da altura) e área do vídeo arredondada embaixo [exato da biblioteca].
 *   `split` 0→1 permite transicionar de tela cheia (0) para o layout da biblioteca (1). A tela cheia é [derivado] do vídeo aprovado.
 * - NeonCaption: legenda 2–3 palavras, Space Grotesk 700 branca, palavra-chave com fundo neon e texto ink [exato].
 */
import React from 'react';
import {AbsoluteFill, staticFile} from 'remotion';
import {CAPTION, COLOR, FONT, FONT_FILES, RADIUS, SHADOW, SPACE, TYPE} from '../../brand/neon';

export const W = 1080;
export const H = 1920;
const lerp = (a: number, b: number, p: number) => a + (b - a) * p;

/** retângulo da área do vídeo no layout da biblioteca */
export const camRect = (split: number) => {
	const top = lerp(0, SPACE.framePadY + H * SPACE.slotMinHeight + SPACE.gap, split); // 64 + 730 + 48 ≈ 841
	const side = lerp(0, SPACE.framePadX, split);
	const bottom = lerp(0, SPACE.framePadY, split);
	return {left: side, top, width: W - 2 * side, height: H - top - bottom, radius: lerp(0, RADIUS.cam, split)};
};
/** retângulo da área do card (topo) */
export const slotRect = () => ({left: SPACE.framePadX, top: SPACE.framePadY, width: W - 2 * SPACE.framePadX, height: H * SPACE.slotMinHeight});

/**
 * children = camada do apresentador (renderizada em 1080×1920 e enquadrada na área do vídeo).
 * `focusY` = altura do rosto no quadro original, para manter o rosto visível no recorte da área do vídeo.
 */
export const NeonFrame: React.FC<{split: number; children: React.ReactNode; slot?: React.ReactNode; focusY?: number; zoom?: number; caption?: React.ReactNode}> = ({split, children, slot, focusY = 760, zoom = 1, caption}) => {
	const r = camRect(split);
	// no layout dividido, escala o quadro para a largura da área e posiciona o rosto a 30% da altura da área
	const s = lerp(zoom, (r.width / W) * zoom, split);
	const ty = lerp((1 - zoom) * focusY, r.height * 0.3 - focusY * s, split);
	const tx = lerp((1 - zoom) * (W / 2), (r.width - W * s) / 2, split);
	return (
		<AbsoluteFill style={{background: COLOR.ink}}>
			<div style={{position: 'absolute', left: r.left, top: r.top, width: r.width, height: r.height, borderRadius: r.radius, overflow: 'hidden', background: COLOR.cam}}>
				<div style={{position: 'absolute', left: 0, top: 0, width: W, height: H, transformOrigin: '0 0', transform: `translate(${tx}px, ${ty}px) scale(${s})`}}>{children}</div>
				{caption ? <div style={{position: 'absolute', left: 0, right: 0, bottom: `${SPACE.captionBottom * 100}%`}}>{caption}</div> : null}
			</div>
			{slot ? <div style={{position: 'absolute', ...slotRect(), display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{slot}</div> : null}
		</AbsoluteFill>
	);
};

export type CapWord = {text: string; start: number; hl?: boolean};
/** legenda Neon: bloco de 2–3 palavras; cada palavra aparece quando é falada; destaque com fundo neon */
export const NeonCaption: React.FC<{t: number; words: CapWord[]; size?: number}> = ({t, words, size = TYPE.caption}) => (
	<div style={{textAlign: 'center', fontFamily: FONT.display, fontWeight: CAPTION.weight, fontSize: size, color: COLOR.text, textShadow: SHADOW.caption, lineHeight: 1.25, padding: '0 60px'}}>
		{words.map((w, i) => {
			const a = Math.max(0, Math.min(1, (t - w.start + 0.04) / 0.12));
			const style: React.CSSProperties = w.hl
				? {background: COLOR.lime, color: COLOR.ink, padding: `0 ${6 * 4}px`, borderRadius: RADIUS.hl, textShadow: 'none'}
				: {};
			return (
				<span key={i} style={{display: 'inline-block', margin: '0 10px', opacity: a, transform: `translateY(${(1 - a) * 10}px)`, ...style}}>
					{w.text}
				</span>
			);
		})}
	</div>
);

const fontCss = `
@font-face{font-family:'${FONT_FILES.displayFamily}';font-weight:${FONT_FILES.displayWeights};src:url(${staticFile(FONT_FILES.display)})}
@font-face{font-family:'${FONT_FILES.monoFamily}';font-weight:${FONT_FILES.monoWeights};src:url(${staticFile(FONT_FILES.mono)})}
`;
let injected = false;
export const ensureNeonFonts = (hold?: () => () => void) => {
	if (injected || typeof document === 'undefined') return;
	injected = true;
	const st = document.createElement('style');
	st.textContent = fontCss;
	document.head.appendChild(st);
	const done = hold?.();
	Promise.all([`700 20px '${FONT_FILES.displayFamily}'`, `500 20px '${FONT_FILES.displayFamily}'`, `400 20px '${FONT_FILES.displayFamily}'`, `400 20px '${FONT_FILES.monoFamily}'`, `500 20px '${FONT_FILES.monoFamily}'`].map((f) => document.fonts.load(f))).then(
		() => done?.(),
		() => done?.(),
	);
};
