/**
 * BIBLIOTECA NEON — os 12 cards da identidade visual reescritos como componentes Remotion.
 * Todos recebem `t` = segundos desde a entrada do card (use <Sequence> ou t - início).
 * Os textos e números são SEMPRE parâmetros: nunca use os valores de exemplo da biblioteca como fatos.
 */
import React from 'react';
import {COLOR, FONT, MOTION, RADIUS, SCALE, SPACE, TYPE, alpha} from '../../brand/neon';
import {cascadeDelay, check, countUp, drop, grow, mark, pop, popOut, pulse, rise, scan, strike, typed, typedBetween} from '../../motion/neonMotion';

type Base = {t: number; exitAt?: number; width?: number; style?: React.CSSProperties};
const S = SCALE;
const exitStyle = (t: number, exitAt?: number) => (exitAt !== undefined && t >= exitAt ? popOut(t, exitAt) : {});
const merge = (a: React.CSSProperties, b: React.CSSProperties) => {
	const tr = [a.transform, b.transform].filter(Boolean).join(' ');
	return {...a, ...b, opacity: (a.opacity as number ?? 1) * (b.opacity as number ?? 1), transform: tr || undefined};
};

export const NeonCard: React.FC<{children: React.ReactNode; style?: React.CSSProperties}> = ({children, style}) => (
	<div style={{width: '100%', background: COLOR.panel, border: `${SPACE.border}px solid ${COLOR.line}`, borderRadius: RADIUS.card, padding: SPACE.cardPad, fontFamily: FONT.display, color: COLOR.text, boxSizing: 'border-box', ...style}}>{children}</div>
);
export const Label: React.FC<{children: React.ReactNode; color?: string; style?: React.CSSProperties}> = ({children, color = COLOR.mute, style}) => (
	<div style={{fontFamily: FONT.mono, fontSize: TYPE.label, letterSpacing: '0.1em', textTransform: 'uppercase', color, ...style}}>{children}</div>
);
const Wrap: React.FC<Base & {children: React.ReactNode; anim?: React.CSSProperties}> = ({t, exitAt, width = 1080 - 2 * SPACE.framePadX, style, children, anim}) => (
	<div style={merge(merge({width, ...style}, anim ?? pop(t)), exitStyle(t, exitAt))}>{children}</div>
);
const CheckSvg: React.FC<{draw: number; size: number; color?: string; stroke?: number}> = ({draw, size, color = COLOR.ink, stroke = 3}) => (
	<svg width={size} height={size} viewBox="0 0 12 12" fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
		<path d="M2 6.5l2.5 2.5L10 3" strokeDasharray={20} strokeDashoffset={20 * (1 - draw)} />
	</svg>
);

/** 01 Contador — número grande que sobe do zero. Para dados, resultados e quantidades REAIS ditos na fala. */
export const NeonCounter: React.FC<Base & {label: string; value: number; prefix?: string; suffix?: string; line1: string; line2?: string; from?: number; countDelay?: number; countDur?: number}> = (p) => (
	<Wrap {...p}>
		<NeonCard>
			<Label>{p.label}</Label>
			<div style={{display: 'flex', alignItems: 'flex-end', gap: 10 * S, marginTop: 6 * S}}>
				<div style={{fontSize: TYPE.big, fontWeight: 700, lineHeight: 0.9, color: COLOR.lime, fontVariantNumeric: 'tabular-nums', letterSpacing: '-0.03em'}}>
					{p.prefix ?? ''}
					{countUp(p.t, p.value, p.countDelay, p.countDur, p.from ?? 0).toLocaleString('pt-BR')}
					{p.suffix ?? ''}
				</div>
				<div style={{fontSize: 14 * S, lineHeight: 1.2, paddingBottom: 4 * S}}>
					{p.line1}
					{p.line2 ? (
						<>
							<br />
							<span style={{color: COLOR.lime}}>{p.line2}</span>
						</>
					) : null}
				</div>
			</div>
		</NeonCard>
	</Wrap>
);

/** 02 Checklist — itens marcados em sequência (0,6 s; depois a cada 0,5 s ou nos tempos informados). */
export const NeonChecklist: React.FC<Base & {label: string; items: string[]; checkTimes?: number[]}> = (p) => (
	<Wrap {...p}>
		<NeonCard>
			<Label style={{marginBottom: 4 * S}}>{p.label}</Label>
			{p.items.map((it, i) => {
				const c = p.checkTimes ? check(p.t, 0, p.checkTimes[i], 0) : check(p.t, i);
				return (
					<div key={i} style={{display: 'flex', alignItems: 'center', gap: 10 * S, padding: `${7 * S}px 0`, fontSize: TYPE.body, borderBottom: i < p.items.length - 1 ? `${S}px solid ${COLOR.line}` : 'none'}}>
						<span style={{width: 18 * S, height: 18 * S, borderRadius: RADIUS.box, border: `${1.5 * S}px solid ${c.fill > 0.5 ? COLOR.lime : COLOR.line}`, background: c.fill > 0 ? alpha(COLOR.lime, c.fill) : 'transparent', display: 'grid', placeItems: 'center', flex: 'none'}}>
							<CheckSvg draw={c.draw} size={12 * S} />
						</span>
						{it}
					</div>
				);
			})}
		</NeonCard>
	</Wrap>
);

/** 03 Antes e depois — o antigo é riscado (vermelho) e o novo acende. Valores precisam vir da fala. */
export const NeonBeforeAfter: React.FC<Base & {label: string; beforeLabel?: string; afterLabel?: string; before: string; after: string; strikeAt?: number; afterAt?: number}> = (p) => {
	const k = strike(p.t, p.strikeAt);
	return (
		<Wrap {...p}>
			<NeonCard>
				<Label style={{marginBottom: 8 * S}}>{p.label}</Label>
				<div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 * S}}>
					<div style={{borderRadius: 10 * S, padding: 10 * S, textAlign: 'center', background: COLOR.panel2}}>
						<Label>{p.beforeLabel ?? 'antes'}</Label>
						<div style={{fontSize: TYPE.value, fontWeight: 700, marginTop: 2 * S, position: 'relative', display: 'inline-block', color: COLOR.mute}}>
							{p.before}
							<div style={{position: 'absolute', left: -2 * S, right: -2 * S, top: '52%', height: 2 * S, background: COLOR.warn, transform: `scaleX(${k})`, transformOrigin: 'left'}} />
						</div>
					</div>
					<div style={{borderRadius: 10 * S, padding: 10 * S, textAlign: 'center', background: COLOR.lime, color: COLOR.ink, ...pop(p.t, p.afterAt ?? cascadeDelay(1))}}>
						<Label color={COLOR.limeOnDark}>{p.afterLabel ?? 'agora'}</Label>
						<div style={{fontSize: TYPE.value, fontWeight: 700, marginTop: 2 * S}}>{p.after}</div>
					</div>
				</div>
			</NeonCard>
		</Wrap>
	);
};

/** 04 Progresso — barra que enche (2,2 s) com etapas. Para mostrar algo acontecendo. */
export const NeonProgress: React.FC<Base & {label: string; status?: string; title: string; steps: string[]; growDelay?: number; growDur?: number}> = (p) => (
	<Wrap {...p}>
		<NeonCard>
			<div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
				<Label>{p.label}</Label>
				{p.status ? <Label color={COLOR.lime}>● {p.status}</Label> : null}
			</div>
			<div style={{fontSize: TYPE.title, fontWeight: 700, marginTop: 8 * S}}>{p.title}</div>
			<div style={{height: 8 * S, background: COLOR.line, borderRadius: RADIUS.bar, overflow: 'hidden', marginTop: 10 * S}}>
				<i style={{display: 'block', height: '100%', width: `${grow(p.t, p.growDelay, p.growDur) * 100}%`, background: COLOR.lime, borderRadius: RADIUS.bar}} />
			</div>
			<div style={{display: 'flex', justifyContent: 'space-between', fontFamily: FONT.mono, fontSize: TYPE.label, color: COLOR.mute, marginTop: 8 * S}}>
				{p.steps.map((s) => (
					<span key={s}>{s}</span>
				))}
			</div>
		</NeonCard>
	</Wrap>
);

/** 05 Caixa de prompt — texto digitado num campo de IA. `typeStart/typeEnd` sincronizam com a fala. */
export const NeonPrompt: React.FC<Base & {text: string; typeStart?: number; typeEnd?: number; sendAt?: number}> = (p) => {
	const ty = p.typeEnd !== undefined ? typedBetween(p.t, p.text, p.typeStart ?? 0, p.typeEnd) : typed(p.t, p.text, p.typeStart);
	const sent = p.sendAt !== undefined && p.t >= p.sendAt;
	const press = p.sendAt !== undefined ? Math.max(0, 1 - Math.abs(p.t - p.sendAt) / 0.12) : 0;
	return (
		<Wrap {...p}>
			<div style={{display: 'flex', alignItems: 'center', gap: 8 * S, background: COLOR.panel, border: `${S}px solid ${COLOR.line}`, borderRadius: RADIUS.pill, padding: `${8 * S}px ${8 * S}px ${8 * S}px ${14 * S}px`, fontFamily: FONT.display, color: COLOR.text}}>
				<span style={{flex: 1, fontSize: 13 * S, minHeight: '1.3em', whiteSpace: 'nowrap', overflow: 'hidden'}}>
					{ty.text}
					<span style={{display: 'inline-block', width: 2 * S, height: 14 * S, background: COLOR.lime, verticalAlign: -2 * S, marginLeft: S, opacity: ty.caretOn && !sent ? 1 : 0}} />
				</span>
				<span style={{width: 30 * S, height: 30 * S, borderRadius: '50%', background: COLOR.lime, display: 'grid', placeItems: 'center', flex: 'none', transform: `scale(${1 - 0.12 * press})`}}>
					{sent ? (
						<CheckSvg draw={1} size={14 * S} stroke={2.5} />
					) : (
						<svg width={14 * S} height={14 * S} viewBox="0 0 24 24" fill="none" stroke={COLOR.ink} strokeWidth={2.5}>
							<path d="M12 19V5M5 12l7-7 7 7" />
						</svg>
					)}
				</span>
			</div>
		</Wrap>
	);
};

/** 06 Notificação — avisos que caem do topo (o 2º 0,7 s depois). Para revelar um resultado. */
export const NeonToasts: React.FC<Base & {items: {title: string; sub?: string; icon?: 'check' | 'money' | 'bell'; at?: number}[]}> = (p) => (
	<div style={merge({width: p.width ?? 1080 - 2 * SPACE.framePadX, display: 'flex', flexDirection: 'column', gap: 8 * S, ...p.style}, exitStyle(p.t, p.exitAt))}>
		{p.items.map((it, i) => (
			<div key={i} style={{display: 'flex', gap: 10 * S, alignItems: 'center', background: COLOR.panel2, border: `${S}px solid ${COLOR.line}`, borderRadius: RADIUS.toast, padding: `${10 * S}px ${12 * S}px`, fontFamily: FONT.display, color: COLOR.text, ...drop(p.t, it.at ?? i * MOTION.drop.secondDelay)}}>
				<span style={{width: 34 * S, height: 34 * S, borderRadius: RADIUS.icon, background: COLOR.lime, display: 'grid', placeItems: 'center', flex: 'none'}}>
					<svg width={18 * S} height={18 * S} viewBox="0 0 24 24" fill="none" stroke={COLOR.ink} strokeWidth={2.2}>
						{it.icon === 'money' ? <path d="M12 3v18M17 7H9.5a3 3 0 000 6h5a3 3 0 010 6H6" /> : it.icon === 'bell' ? <path d="M6 8a6 6 0 0112 0c0 7 3 9 3 9H3s3-2 3-9M10 21h4" /> : <path d="M5 12l4 4L19 6" />}
					</svg>
				</span>
				<div>
					<b style={{fontSize: 13 * S, display: 'block'}}>{it.title}</b>
					{it.sub ? <span style={{fontSize: 12 * S, color: COLOR.mute}}>{it.sub}</span> : null}
				</div>
			</div>
		))}
	</div>
);

/** 07 Passo a passo — etapas numeradas em cascata (0,25 s + 0,3 s) ou nos tempos da fala. */
export const NeonSteps: React.FC<Base & {label: string; steps: string[]; stepTimes?: number[]}> = (p) => (
	<Wrap {...p}>
		<NeonCard>
			<Label style={{marginBottom: 4 * S}}>{p.label}</Label>
			{p.steps.map((s, i) => {
				const last = i === p.steps.length - 1;
				return (
					<div key={i} style={{display: 'flex', gap: 10 * S, alignItems: 'center', padding: `${6 * S}px 0`, ...pop(p.t, p.stepTimes?.[i] ?? cascadeDelay(i))}}>
						<span style={{width: 26 * S, height: 26 * S, borderRadius: '50%', border: `${1.5 * S}px solid ${COLOR.lime}`, color: last ? COLOR.ink : COLOR.lime, background: last ? COLOR.lime : 'transparent', fontFamily: FONT.mono, fontSize: 12 * S, display: 'grid', placeItems: 'center', flex: 'none'}}>{i + 1}</span>
						<p style={{margin: 0, fontSize: 14 * S}}>{s}</p>
					</div>
				);
			})}
		</NeonCard>
	</Wrap>
);

/** 08 Gráfico de barras — barras crescem (0,12 s entre elas); a última fica em neon. */
export const NeonBars: React.FC<Base & {label: string; values: number[]; delta?: string}> = (p) => {
	const max = Math.max(...p.values);
	return (
		<Wrap {...p}>
			<NeonCard>
				<div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
					<Label>{p.label}</Label>
					{p.delta ? <span style={{fontFamily: FONT.mono, fontSize: 12 * S, color: COLOR.lime, background: COLOR.limeSoft, padding: `${3 * S}px ${8 * S}px`, borderRadius: RADIUS.pill}}>{p.delta}</span> : null}
				</div>
				<div style={{display: 'flex', alignItems: 'flex-end', gap: 7 * S, height: 90 * S, paddingTop: 6 * S}}>
					{p.values.map((v, i) => (
						<i key={i} style={{flex: 1, height: `${(v / max) * 100}%`, background: i === p.values.length - 1 ? COLOR.lime : COLOR.line, borderRadius: `${4 * S}px ${4 * S}px ${2 * S}px ${2 * S}px`, transform: `scaleY(${rise(p.t, i)})`, transformOrigin: 'bottom'}} />
					))}
				</div>
			</NeonCard>
		</Wrap>
	);
};

/** 09 Frase de impacto — frase grande com marca-texto neon na palavra-chave (0,6 s). */
export const NeonQuote: React.FC<Base & {before: string; highlight: string; after?: string; markAt?: number; fontSize?: number}> = (p) => {
	const m = mark(p.t, p.markAt);
	return (
		<Wrap {...p}>
			<div style={{fontFamily: FONT.display, fontSize: p.fontSize ?? TYPE.quote, fontWeight: 700, lineHeight: 1.05, letterSpacing: '-0.02em', color: COLOR.text, textAlign: 'left'}}>
				{p.before}{' '}
				<span style={{position: 'relative', zIndex: 0, padding: `0 ${4 * S}px`, color: m.ink ? COLOR.ink : COLOR.text}}>
					<span style={{position: 'absolute', inset: 0, background: COLOR.lime, borderRadius: RADIUS.mark, zIndex: -1, transform: `scaleX(${m.p})`, transformOrigin: 'left'}} />
					{p.highlight}
				</span>
				{p.after ? ` ${p.after}` : ''}
			</div>
		</Wrap>
	);
};

/** 10 Imagem gerada — moldura com varredura neon ao revelar. `src` opcional; sem imagem mostra o placeholder. */
export const NeonImageReveal: React.FC<Base & {tag: string; src?: string; placeholder?: string}> = (p) => (
	<Wrap {...p}>
		<div style={{position: 'relative', width: '100%', aspectRatio: '16/10', borderRadius: 12 * S, overflow: 'hidden', border: `${S}px solid ${COLOR.line}`, background: `repeating-linear-gradient(135deg,${COLOR.panel2} 0 40px,${COLOR.panel3} 40px 80px)`}}>
			{p.src ? <img src={p.src} style={{position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover'}} /> : <div style={{position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', color: COLOR.mute, fontFamily: FONT.mono, fontSize: 11 * S, textAlign: 'center'}}>{p.placeholder ?? ''}</div>}
			<span style={{position: 'absolute', top: 8 * S, left: 8 * S, fontFamily: FONT.mono, fontSize: 10 * S, background: COLOR.ink, color: COLOR.lime, border: `${S}px solid ${COLOR.line}`, borderRadius: RADIUS.pill, padding: `${3 * S}px ${8 * S}px`}}>{p.tag}</span>
			<div style={{position: 'absolute', left: 0, right: 0, height: '30%', top: `${scan(p.t)}%`, background: `linear-gradient(to bottom,transparent,${COLOR.scanGlow},transparent)`}} />
		</div>
	</Wrap>
);

/** 11 Enquete — pergunta com resultado enchendo (0,9 s). Percentuais só se forem dados reais. */
export const NeonPoll: React.FC<Base & {question: string; options: {text: string; pct: number; win?: boolean}[]}> = (p) => (
	<Wrap {...p}>
		<NeonCard>
			<div style={{fontSize: 15 * S, fontWeight: 700, marginBottom: 10 * S}}>{p.question}</div>
			{p.options.map((o, i) => {
				const g = Math.max(0, Math.min(1, (p.t - MOTION.poll.delay) / MOTION.poll.dur));
				return (
					<div key={i} style={{position: 'relative', border: `${S}px solid ${COLOR.line}`, borderRadius: 10 * S, padding: `${8 * S}px ${10 * S}px`, marginTop: 6 * S, fontSize: 13 * S, display: 'flex', justifyContent: 'space-between', overflow: 'hidden'}}>
						<i style={{position: 'absolute', inset: 0, width: `${o.pct}%`, background: o.win ? COLOR.limeWin : COLOR.panel2, transform: `scaleX(${g})`, transformOrigin: 'left', zIndex: 0}} />
						<span style={{position: 'relative', zIndex: 1}}>{o.text}</span>
						<span style={{position: 'relative', zIndex: 1, fontFamily: FONT.mono, color: o.win ? COLOR.lime : COLOR.text}}>{o.pct}%</span>
					</div>
				);
			})}
		</NeonCard>
	</Wrap>
);

/** 12 Chamada final — palavra-chave digitada + botão pulsando. Use só a palavra realmente falada. */
export const NeonCTA: React.FC<Base & {kicker: string; word: string; button?: string; typeStart?: number; buttonAt?: number}> = (p) => {
	const ty = typed(p.t, p.word, p.typeStart);
	const bAt = p.buttonAt ?? 0.9;
	const pu = pulse(p.t, bAt + 0.7);
	return (
		<Wrap {...p} anim={{}}>
			<div style={{textAlign: 'center', width: '100%', fontFamily: FONT.display}}>
				<div style={{fontSize: 13 * S, color: COLOR.mute, ...pop(p.t, 0)}}>{p.kicker}</div>
				<div style={{fontSize: TYPE.cta, fontWeight: 700, color: COLOR.lime, letterSpacing: '-0.02em', lineHeight: 1.05, margin: `${4 * S}px 0 ${10 * S}px`}}>
					{ty.text}
					<span style={{display: 'inline-block', width: 2 * S, height: 30 * S, background: COLOR.lime, marginLeft: S, opacity: ty.caretOn && !ty.done ? 1 : 0}} />
				</div>
				{p.button ? (
					<span style={{display: 'inline-flex', gap: 6 * S, alignItems: 'center', background: COLOR.text, color: COLOR.ink, fontWeight: 700, fontSize: 13 * S, borderRadius: RADIUS.pill, padding: `${8 * S}px ${16 * S}px`, boxShadow: `0 0 0 ${pu.spread}px ${alpha(COLOR.lime, pu.alpha)}`, ...pop(p.t, bAt)}}>
						{p.button}
						<svg width={14 * S} height={14 * S} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5}>
							<path d="M9 6l6 6-6 6" />
						</svg>
					</span>
				) : null}
			</div>
		</Wrap>
	);
};
