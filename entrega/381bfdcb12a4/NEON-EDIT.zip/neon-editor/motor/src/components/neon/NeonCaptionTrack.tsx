import React from 'react';
import {Block, blockAt} from '../../engine/captions';
import {NeonCaption} from './NeonLayout';

/** legenda Neon da timeline inteira (blocos de engine/captions) */
export const NeonCaptionTrack: React.FC<{t: number; blocks: Block[]}> = ({t, blocks}) => {
	const b = blockAt(blocks, t);
	if (!b || b.hidden) return null;
	return <NeonCaption t={t} words={b.toks.map((k) => ({text: k.text, start: k.start, hl: k.hl}))} />;
};
