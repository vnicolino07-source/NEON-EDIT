/**
 * [KIT · DIREÇÃO ADAPTATIVA] Vocabulário visual extra para assuntos diferentes (negócios, marketing, tecnologia,
 * educação...). Todos: tokens da marca, determinísticos (`t` = segundos desde a entrada), textos e números como
 * parâmetros. Regras de uso em references/18-direcao-adaptativa.md.
 *
 * Situação: criados para o kit e testados na composição `DirecaoAdaptativa` (quadros + qa_layout). Ainda NÃO usados
 * num vídeo aprovado por cliente.
 */
import React from 'react';
import {COLOR, FONT, RADIUS, SPACE, TYPE, alpha} from '../../brand/neon';
import {countUp, easeBrand, easeCss, easeInOutCss, easeStandard, phase, pop, popOut} from '../../motion/neonMotion';
import {Label, NeonCard} from '../neon/NeonCards';

const W_SLOT = 1080 - 2 * SPACE.framePadX;
const out = (t: number, at?: number) => (at !== undefined && t >= at ? popOut(t, at) : {});
const clamp = (x: number) => Math.max(0, Math.min(1, x));

/**
 * Gráfico de linha com área que se desenha + rótulos nos pontos + valor final contando.
 * `values` define a FORMA (relativa). Só mostre `valueLabel`/`labels` numéricos se os números foram DITOS.
 */
export const GrowthChart: React.FC<{
	t: number;
	label: string;
	values: number[];
	labels?: string[];
	valueLabel?: {value: number; prefix?: string; suffix?: string};
	drawAt?: number;
	drawDur?: number;
	exitAt?: number;
	width?: number;
	height?: number;
}> = ({t, label, values, labels, valueLabel, drawAt = 0.3, drawDur = 1.4, exitAt, width = W_SLOT, height = 520}) => {
	const pad = 48;
	const cw = width - 2 * pad;
	const ch = height - 200;
	const mx = Math.max(...values);
	const mn = Math.min(0, ...values);
	const pts = values.map((v, i) => [(i / (values.length - 1)) * cw, ch - ((v - mn) / (mx - mn || 1)) * ch] as const);
	const d = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
	const len = pts.reduce((a, p, i) => (i ? a + Math.hypot(p[0] - pts[i - 1][0], p[1] - pts[i - 1][1]) : 0), 0);
	const k = phase(t, drawAt, drawDur, easeStandard);
	const area = `${d} L${cw},${ch} L0,${ch} Z`;
	return (
		<div style={{width, ...pop(t), ...out(t, exitAt)}}>
			<NeonCard style={{height, padding: pad, position: 'relative', overflow: 'hidden'}}>
				<div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'baseline'}}>
					<Label>{label}</Label>
					{valueLabel ? (
						<div style={{fontFamily: FONT.display, fontWeight: 700, fontSize: 96, color: COLOR.lime, letterSpacing: '-0.03em', fontVariantNumeric: 'tabular-nums'}}>
							{valueLabel.prefix ?? ''}
							{countUp(t, valueLabel.value, drawAt, drawDur)}
							{valueLabel.suffix ?? ''}
						</div>
					) : null}
				</div>
				<svg width={cw} height={ch + 10} style={{position: 'absolute', left: pad, bottom: pad + 50, overflow: 'visible'}}>
					<defs>
						<linearGradient id="gc-area" x1="0" y1="0" x2="0" y2="1">
							<stop offset="0" stopColor={COLOR.lime} stopOpacity={0.35} />
							<stop offset="1" stopColor={COLOR.lime} stopOpacity={0} />
						</linearGradient>
						<clipPath id="gc-clip">
							<rect x={0} y={-20} width={cw * k} height={ch + 40} />
						</clipPath>
					</defs>
					{[0.25, 0.5, 0.75, 1].map((g) => (
						<line key={g} x1={0} x2={cw} y1={ch * g} y2={ch * g} stroke={COLOR.line} strokeWidth={2} />
					))}
					<path d={area} fill="url(#gc-area)" clipPath="url(#gc-clip)" />
					<path d={d} fill="none" stroke={COLOR.lime} strokeWidth={8} strokeLinecap="round" strokeLinejoin="round" strokeDasharray={len} strokeDashoffset={len * (1 - k)} />
					{pts.map((p, i) => {
						const on = phase(t, drawAt + (drawDur * i) / (pts.length - 1) - 0.05, 0.3, easeBrand);
						return <circle key={i} cx={p[0]} cy={p[1]} r={14 * on} fill={i === pts.length - 1 ? COLOR.lime : COLOR.panel} stroke={COLOR.lime} strokeWidth={5} />;
					})}
				</svg>
				{labels ? (
					<div style={{position: 'absolute', left: pad, right: pad, bottom: pad - 6, display: 'flex', justifyContent: 'space-between', fontFamily: FONT.mono, fontSize: 28, color: COLOR.mute}}>
						{labels.map((l) => (
							<span key={l}>{l}</span>
						))}
					</div>
				) : null}
			</NeonCard>
		</div>
	);
};

/** Funil (marketing, vendas, processo que filtra): etapas entram em cascata na fala. */
export const FunnelCard: React.FC<{t: number; label: string; stages: {text: string; at: number}[]; exitAt?: number; width?: number}> = ({t, label, stages, exitAt, width = W_SLOT}) => (
	<div style={{width, ...pop(t), ...out(t, exitAt)}}>
		<NeonCard>
			<Label>{label}</Label>
			<div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14, marginTop: 28}}>
				{stages.map((s, i) => {
					const q = phase(t, s.at, 0.45, easeBrand);
					const wPct = 100 - (i * 60) / Math.max(1, stages.length - 1);
					const last = i === stages.length - 1;
					return (
						<div key={i} style={{width: `${wPct}%`, height: 92, borderRadius: 22, background: last ? COLOR.lime : alpha(COLOR.lime, 0.12 + 0.1 * i), border: `${SPACE.border}px solid ${last ? COLOR.lime : COLOR.line}`, display: 'grid', placeItems: 'center', fontFamily: FONT.display, fontWeight: 700, fontSize: 46, color: last ? COLOR.ink : COLOR.text, opacity: clamp(q * 2), transform: `scaleX(${0.6 + 0.4 * q})`}}>
							{s.text}
						</div>
					);
				})}
			</div>
		</NeonCard>
	</div>
);

/** Indicadores (KPIs). `value` só se o número foi DITO; sem número, use `trend` (seta) e o texto. */
export const MetricTiles: React.FC<{t: number; items: {label: string; value?: number; prefix?: string; suffix?: string; trend?: 'up' | 'down'; at: number}[]; exitAt?: number; width?: number}> = ({t, items, exitAt, width = W_SLOT}) => (
	<div style={{width, display: 'grid', gridTemplateColumns: `repeat(${Math.min(items.length, 2)}, 1fr)`, gap: SPACE.gap, ...out(t, exitAt)}}>
		{items.map((it, i) => {
			const q = phase(t, it.at, 0.55, easeBrand);
			const up = it.trend !== 'down';
			return (
				<div key={i} style={{...pop(t, it.at), boxSizing: 'border-box', background: COLOR.panel, border: `${SPACE.border}px solid ${COLOR.line}`, borderRadius: RADIUS.card, padding: 40, minHeight: 220}}>
					<Label style={{fontSize: 30}}>{it.label}</Label>
					<div style={{display: 'flex', alignItems: 'center', gap: 18, marginTop: 18}}>
						{it.value !== undefined ? (
							<span style={{fontFamily: FONT.display, fontWeight: 700, fontSize: 104, letterSpacing: '-0.03em', color: COLOR.text, fontVariantNumeric: 'tabular-nums'}}>
								{it.prefix ?? ''}
								{countUp(t, it.value, it.at, 1.0)}
								{it.suffix ?? ''}
							</span>
						) : null}
						{it.trend ? (
							<svg width={90} height={90} viewBox="0 0 24 24" style={{transform: `translateY(${(1 - q) * 30}px)`, opacity: q}}>
								<path d={up ? 'M4 17l6-6 4 4 6-7M14 8h6v6' : 'M4 7l6 6 4-4 6 7M14 16h6v-6'} fill="none" stroke={up ? COLOR.lime : COLOR.warn} strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round" />
							</svg>
						) : null}
					</div>
				</div>
			);
		})}
	</div>
);

/** HUD tecnológico: anéis girando, grade, varredura, cantos e linhas de dados digitando. Fundo de cena ou card. */
export const TechHUD: React.FC<{t: number; title: string; lines: string[]; lineStart?: number; lineStep?: number; exitAt?: number; width?: number; height?: number}> = ({t, title, lines, lineStart = 0.4, lineStep = 0.35, exitAt, width = W_SLOT, height = 640}) => {
	const rot = t * 40;
	const scanY = ((t * 0.6) % 1) * height;
	const intro = phase(t, 0, 0.6, easeBrand);
	const r = Math.min(width, height) * 0.36;
	const corner = (x: number, y: number, sx: number, sy: number) => (
		<path d={`M${x} ${y + sy * 60} L${x} ${y} L${x + sx * 60} ${y}`} stroke={COLOR.lime} strokeWidth={6} fill="none" strokeLinecap="round" />
	);
	return (
		<div style={{position: 'relative', width, height, borderRadius: RADIUS.card, background: COLOR.ink, border: `${SPACE.border}px solid ${COLOR.line}`, overflow: 'hidden', ...pop(t), ...out(t, exitAt)}}>
			<svg width={width} height={height} style={{position: 'absolute', inset: 0}}>
				<defs>
					<pattern id="hud-grid" width="60" height="60" patternUnits="userSpaceOnUse">
						<path d="M60 0H0V60" fill="none" stroke={alpha(COLOR.lime, 0.08)} strokeWidth={2} />
					</pattern>
				</defs>
				<rect width={width} height={height} fill="url(#hud-grid)" />
				<g transform={`translate(${width * 0.72} ${height * 0.5}) scale(${0.7 + 0.3 * intro})`} opacity={0.9}>
					<circle r={r} fill="none" stroke={alpha(COLOR.lime, 0.25)} strokeWidth={3} />
					<circle r={r * 0.78} fill="none" stroke={COLOR.lime} strokeWidth={6} strokeDasharray="40 22" transform={`rotate(${rot})`} />
					<circle r={r * 0.56} fill="none" stroke={alpha(COLOR.lime, 0.6)} strokeWidth={3} strokeDasharray="8 14" transform={`rotate(${-rot * 1.6})`} />
					<circle r={r * 0.3} fill={alpha(COLOR.lime, 0.15)} stroke={COLOR.lime} strokeWidth={4} />
					<circle r={r * 0.1 * (1 + 0.15 * Math.sin(t * 6))} fill={COLOR.lime} />
					<line x1={0} y1={0} x2={r * Math.cos((rot * Math.PI) / 90)} y2={r * Math.sin((rot * Math.PI) / 90)} stroke={COLOR.lime} strokeWidth={3} />
				</g>
				<rect x={0} y={scanY} width={width} height={4} fill={alpha(COLOR.lime, 0.35)} />
				{corner(24, 24, 1, 1)}
				{corner(width - 24, 24, -1, 1)}
				{corner(24, height - 24, 1, -1)}
				{corner(width - 24, height - 24, -1, -1)}
			</svg>
			<div style={{position: 'absolute', left: 64, top: 64, width: width * 0.48}}>
				<Label color={COLOR.lime}>{title}</Label>
				<div style={{marginTop: 26, display: 'flex', flexDirection: 'column', gap: 16}}>
					{lines.map((l, i) => {
						const at = lineStart + i * lineStep;
						const n = Math.floor(clamp((t - at) / 0.4) * l.length);
						return (
							<div key={i} style={{fontFamily: FONT.mono, fontSize: 32, color: i === lines.length - 1 ? COLOR.text : COLOR.mute, whiteSpace: 'nowrap', opacity: t >= at ? 1 : 0}}>
								<span style={{color: COLOR.lime}}>›</span> {l.slice(0, n)}
								{n < l.length && t >= at ? <span style={{color: COLOR.lime}}>▍</span> : null}
							</div>
						);
					})}
				</div>
			</div>
		</div>
	);
};

/** Janela de código digitando (tecnologia, automação, IA). `code` = linhas; destaque por tokens simples. */
export const CodeWindow: React.FC<{t: number; file: string; code: string[]; typeStart?: number; charsPerSec?: number; exitAt?: number; width?: number}> = ({t, file, code, typeStart = 0.3, charsPerSec = 45, exitAt, width = W_SLOT}) => {
	let budget = Math.max(0, (t - typeStart) * charsPerSec);
	const kw = /\b(const|function|return|if|for|await|import|from|export|new|def|class)\b/g;
	return (
		<div style={{width, ...pop(t), ...out(t, exitAt)}}>
			<div style={{background: COLOR.panel, border: `${SPACE.border}px solid ${COLOR.line}`, borderRadius: RADIUS.card, overflow: 'hidden', boxSizing: 'border-box'}}>
				<div style={{display: 'flex', alignItems: 'center', gap: 14, padding: '22px 32px', borderBottom: `${SPACE.border}px solid ${COLOR.line}`}}>
					{[COLOR.warn, COLOR.limeDim, COLOR.lime].map((c) => (
						<span key={c} style={{width: 22, height: 22, borderRadius: 11, background: c}} />
					))}
					<span style={{fontFamily: FONT.mono, fontSize: 28, color: COLOR.mute, marginLeft: 12}}>{file}</span>
				</div>
				<div style={{padding: '28px 36px', fontFamily: FONT.mono, fontSize: 34, lineHeight: 1.55}}>
					{code.map((line, i) => {
						const n = Math.min(line.length, Math.floor(budget));
						budget -= line.length;
						const shown = line.slice(0, Math.max(0, n));
						const parts = shown.split(kw);
						return (
							<div key={i} style={{display: 'flex', gap: 24, minHeight: '1.55em'}}>
								<span style={{color: COLOR.line, width: 40, textAlign: 'right'}}>{i + 1}</span>
								<span style={{color: COLOR.text, whiteSpace: 'pre'}}>
									{parts.map((p, j) => (j % 2 ? <span key={j} style={{color: COLOR.lime}}>{p}</span> : <span key={j}>{p}</span>))}
									{n > 0 && n < line.length ? <span style={{color: COLOR.lime}}>▍</span> : null}
								</span>
							</div>
						);
					})}
				</div>
			</div>
		</div>
	);
};

/** Tipografia cinética em crescendo: cada palavra entra na sua fala, a última (ou `hl`) ganha o acento. */
export const KineticStack: React.FC<{t: number; words: {text: string; at: number; hl?: boolean; size?: number}[]; exitAt?: number; align?: 'left' | 'center'}> = ({t, words, exitAt, align = 'left'}) => (
	<div style={{display: 'flex', flexDirection: 'column', alignItems: align === 'center' ? 'center' : 'flex-start', gap: 6, ...out(t, exitAt)}}>
		{words.map((w, i) => {
			const q = phase(t, w.at, 0.35, easeBrand);
			const size = w.size ?? 110 + i * 26;
			return (
				<div key={i} style={{fontFamily: FONT.display, fontWeight: 700, fontSize: size, lineHeight: 0.95, letterSpacing: '-0.035em', color: w.hl ? COLOR.ink : COLOR.text, background: w.hl ? COLOR.lime : 'transparent', borderRadius: 18, padding: w.hl ? '0 22px' : 0, opacity: clamp(q * 1.8), transform: `translateX(${(1 - q) * -80}px) skewX(${(1 - q) * -8}deg)`, textShadow: w.hl ? 'none' : '0 10px 40px rgba(0,0,0,0.45)'}}>
					{w.text}
				</div>
			);
		})}
	</div>
);

/** Carimbo (veredito na fala: "aprovado", "grátis", "erro"): cai girando com impacto. */
export const Stamp: React.FC<{t: number; text: string; tone?: 'acento' | 'alerta'; at?: number; exitAt?: number; rotate?: number}> = ({t, text, tone = 'acento', at = 0, exitAt, rotate = -8}) => {
	const q = phase(t, at, 0.28, easeInOutCss);
	const c = tone === 'alerta' ? COLOR.warn : COLOR.lime;
	return (
		<div style={{display: 'inline-block', padding: '18px 44px', border: `10px solid ${c}`, borderRadius: 24, color: c, fontFamily: FONT.display, fontWeight: 700, fontSize: 110, letterSpacing: '0.04em', textTransform: 'uppercase', opacity: q, transform: `rotate(${rotate}deg) scale(${2.2 - 1.2 * q})`, background: alpha(COLOR.ink, 0.35), ...out(t, exitAt)}}>
			{text}
		</div>
	);
};

/** Comparação lado a lado (A × B) com vencedor marcado na palavra. */
export const VersusCard: React.FC<{t: number; label: string; a: {title: string; items: string[]}; b: {title: string; items: string[]}; winner?: 'a' | 'b'; winnerAt?: number; exitAt?: number; width?: number}> = ({t, label, a, b, winner, winnerAt = 1.2, exitAt, width = W_SLOT}) => {
	const w = phase(t, winnerAt, 0.4, easeCss);
	const col = (side: 'a' | 'b', d: {title: string; items: string[]}, i: number) => {
		const win = winner === side;
		return (
			<div style={{flex: 1, boxSizing: 'border-box', borderRadius: 32, padding: 32, background: win ? alpha(COLOR.lime, 0.1 * w) : COLOR.panel2, border: `${SPACE.border}px solid ${win && w > 0.5 ? COLOR.lime : COLOR.line}`, opacity: winner && !win ? 1 - 0.45 * w : 1, ...pop(t, 0.2 + i * 0.3)}}>
				<div style={{fontFamily: FONT.display, fontWeight: 700, fontSize: 52, color: win && w > 0.5 ? COLOR.lime : COLOR.text}}>{d.title}</div>
				{d.items.map((it) => (
					<div key={it} style={{fontFamily: FONT.display, fontSize: 38, color: COLOR.mute, marginTop: 14}}>
						{it}
					</div>
				))}
			</div>
		);
	};
	return (
		<div style={{width, ...pop(t), ...out(t, exitAt)}}>
			<NeonCard>
				<Label>{label}</Label>
				<div style={{display: 'flex', gap: 24, marginTop: 26, alignItems: 'stretch'}}>
					{col('a', a, 0)}
					<div style={{alignSelf: 'center', fontFamily: FONT.mono, fontSize: 34, color: COLOR.mute}}>vs</div>
					{col('b', b, 1)}
				</div>
			</NeonCard>
		</div>
	);
};

void TYPE;
