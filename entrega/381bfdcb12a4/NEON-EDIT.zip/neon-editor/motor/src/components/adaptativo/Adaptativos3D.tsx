/**
 * [KIT · DIREÇÃO ADAPTATIVA] Cenas 3D genéricas (Three.js real), parametrizáveis e determinísticas.
 * - Network3D: rede de nós e conexões com pulsos (IA, tecnologia, comunidade, conexões, dados).
 * - Bars3D: gráfico de barras 3D crescendo (negócios, crescimento, comparação de grandezas DITAS).
 * - Coins3D: moedas 3D girando e caindo em pilha (dinheiro, economia, preço, lucro).
 * Situação: criados para o kit e testados na composição `DirecaoAdaptativa`; não usados em vídeo aprovado ainda.
 */
import React, {useCallback} from 'react';
import * as THREE from 'three';
import {COLOR} from '../../brand/neon';
import {ThreeLayer, ThreeCtx} from '../three/ThreeLayer';

const rnd = (s: number) => {
	const x = Math.sin(s * 127.1 + 311.7) * 43758.5453;
	return x - Math.floor(x);
};
const sm = (t: number, a: number, b: number) => {
	const x = Math.max(0, Math.min(1, (t - a) / (b - a)));
	return x * x * (3 - 2 * x);
};
const back = (x: number) => {
	const c = 1.70158;
	const y = Math.max(0, Math.min(1, x)) - 1;
	return 1 + (c + 1) * y * y * y + c * y * y;
};
const lights = (scene: THREE.Scene) => {
	scene.add(new THREE.AmbientLight(0xffffff, 0.75));
	const k = new THREE.DirectionalLight(0xffffff, 2.2);
	k.position.set(-4, 6, 8);
	scene.add(k);
	const rim = new THREE.PointLight(new THREE.Color(COLOR.lime), 40, 25);
	rim.position.set(4, -2, 5);
	scene.add(rim);
};

type NetSt = {group: THREE.Group; nodes: THREE.Mesh[]; edges: {a: number; b: number; line: THREE.Mesh; pulse: THREE.Mesh; ph: number}[]};
export const Network3D: React.FC<{t: number; nodes?: number; seed?: number; buildDur?: number; y?: number; scale?: number; exitAt?: number; width?: number; height?: number}> = ({t, nodes = 26, seed = 3, buildDur = 1.2, y = 0, scale = 1, exitAt, width = 1080, height = 1080}) => {
	const init = useCallback(({scene, camera}: Omit<ThreeCtx<NetSt>, 'state'>): NetSt => {
		camera.position.set(0, 0, 9);
		lights(scene);
		const group = new THREE.Group();
		const pts: THREE.Vector3[] = [];
		for (let i = 0; i < nodes; i++) {
			const u = rnd(seed * 100 + i), v = rnd(seed * 200 + i);
			const th = 2 * Math.PI * u, ph = Math.acos(2 * v - 1);
			const r = 2.2 + 0.5 * rnd(seed * 300 + i);
			pts.push(new THREE.Vector3(r * Math.sin(ph) * Math.cos(th), r * Math.cos(ph), r * Math.sin(ph) * Math.sin(th)));
		}
		const nodeMat = new THREE.MeshStandardMaterial({color: new THREE.Color(COLOR.text), roughness: 0.35, metalness: 0.2});
		const hubMat = new THREE.MeshStandardMaterial({color: new THREE.Color(COLOR.lime), emissive: new THREE.Color(COLOR.lime), emissiveIntensity: 0.6});
		const ns = pts.map((p, i) => {
			const m = new THREE.Mesh(new THREE.SphereGeometry(i % 7 === 0 ? 0.2 : 0.11, 20, 14), i % 7 === 0 ? hubMat : nodeMat);
			m.position.copy(p);
			group.add(m);
			return m;
		});
		const edges: NetSt['edges'] = [];
		// arestas como cilindros finos (linhas WebGL têm 1 px e somem no render por software)
		const lineMat = new THREE.MeshBasicMaterial({color: new THREE.Color(COLOR.lime), transparent: true, opacity: 0.55});
		const pulseMat = new THREE.MeshBasicMaterial({color: new THREE.Color(COLOR.lime)});
		pts.forEach((p, i) => {
			const near = pts.map((q, j) => [p.distanceTo(q), j] as const).filter(([, j]) => j !== i).sort((a, b) => a[0] - b[0]).slice(0, 2);
			near.forEach(([, j]) => {
				if (edges.some((e) => (e.a === j && e.b === i) || (e.a === i && e.b === j))) return;
				const len = p.distanceTo(pts[j]);
				const g = new THREE.CylinderGeometry(0.022, 0.022, len, 6);
				g.translate(0, len / 2, 0);
				g.rotateX(Math.PI / 2);
				const line = new THREE.Mesh(g, lineMat.clone());
				line.position.copy(p);
				line.lookAt(pts[j]);
				const pulse = new THREE.Mesh(new THREE.SphereGeometry(0.07, 10, 8), pulseMat);
				group.add(line, pulse);
				edges.push({a: i, b: j, line, pulse, ph: rnd(seed * 400 + i * 31 + j)});
			});
		});
		scene.add(group);
		return {group, nodes: ns, edges};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);
	const update = useCallback(
		(c: ThreeCtx<NetSt>, t: number) => {
			const {group, nodes: ns, edges} = c.state;
			const fade = exitAt !== undefined ? 1 - sm(t, exitAt, exitAt + 0.35) : 1;
			group.position.y = y;
			group.scale.setScalar(scale * (0.85 + 0.15 * back(t / 0.6)) * (0.9 + 0.1 * fade));
			group.rotation.set(0.25 + 0.05 * Math.sin(t * 0.7), t * 0.35, 0);
			ns.forEach((m, i) => {
				const k = back((t - (i / ns.length) * buildDur) / 0.35);
				m.scale.setScalar(Math.max(0.001, k * fade));
			});
			edges.forEach((e, i) => {
				const k = sm(t, (i / edges.length) * buildDur + 0.2, (i / edges.length) * buildDur + 0.5);
				(e.line.material as THREE.MeshBasicMaterial).opacity = 0.55 * k * fade;
				e.line.scale.set(1, 1, Math.max(0.001, k));
				const s = (t * 0.8 + e.ph) % 1;
				e.pulse.position.lerpVectors(ns[e.a].position, ns[e.b].position, s);
				e.pulse.visible = k > 0.9 && fade > 0.2;
			});
		},
		[buildDur, y, scale, exitAt],
	);
	return <ThreeLayer t={t} init={init} update={update} width={width} height={height} />;
};

type BarSt = {group: THREE.Group; bars: THREE.Mesh[]};
/** `values` relativos (forma). Números na tela só se ditos — use um card/legenda à parte para eles. */
export const Bars3D: React.FC<{t: number; values: number[]; growAt?: number; stagger?: number; exitAt?: number; width?: number; height?: number}> = ({t, values, growAt = 0.2, stagger = 0.18, exitAt, width = 1080, height = 900}) => {
	const init = useCallback(({scene, camera}: Omit<ThreeCtx<BarSt>, 'state'>): BarSt => {
		camera.position.set(0, 2.2, 9);
		camera.lookAt(0, 1, 0);
		lights(scene);
		const group = new THREE.Group();
		const mx = Math.max(...values);
		const n = values.length;
		const floor = new THREE.Mesh(new THREE.BoxGeometry(n * 1.2 + 0.6, 0.08, 2.2), new THREE.MeshStandardMaterial({color: new THREE.Color(COLOR.panel), roughness: 0.8}));
		floor.position.y = -0.04;
		group.add(floor);
		const bars = values.map((v, i) => {
			const last = i === n - 1;
			const g = new THREE.BoxGeometry(0.8, 1, 0.8);
			g.translate(0, 0.5, 0);
			const m = new THREE.Mesh(g, new THREE.MeshStandardMaterial({color: new THREE.Color(last ? COLOR.lime : COLOR.line), roughness: 0.4, metalness: 0.1}));
			m.position.x = (i - (n - 1) / 2) * 1.2;
			m.userData.h = (v / mx) * 3.6;
			group.add(m);
			return m;
		});
		scene.add(group);
		return {group, bars};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);
	const update = useCallback(
		(c: ThreeCtx<BarSt>, t: number) => {
			const fade = exitAt !== undefined ? 1 - sm(t, exitAt, exitAt + 0.35) : 1;
			c.state.group.rotation.y = -0.35 + 0.12 * Math.sin(t * 0.6);
			c.state.group.scale.setScalar(0.95 + 0.05 * fade);
			c.state.bars.forEach((b, i) => {
				const k = back((t - growAt - i * stagger) / 0.55);
				b.scale.set(1, Math.max(0.001, b.userData.h * k * fade), 1);
			});
		},
		[growAt, stagger, exitAt],
	);
	return <ThreeLayer t={t} init={init} update={update} width={width} height={height} />;
};

type CoinSt = {coins: {m: THREE.Mesh; x: number; z: number; spawn: number; land: number; spin: number}[]};
/** Moedas caindo e empilhando (dinheiro, lucro, economia). */
export const Coins3D: React.FC<{t: number; count?: number; span?: number; exitAt?: number; seed?: number; width?: number; height?: number}> = ({t, count = 14, span = 1.2, exitAt, seed = 5, width = 1080, height = 1080}) => {
	const init = useCallback(({scene, camera}: Omit<ThreeCtx<CoinSt>, 'state'>): CoinSt => {
		camera.position.set(0, 2.5, 9);
		camera.lookAt(0, 0, 0);
		lights(scene);
		const geo = new THREE.CylinderGeometry(0.55, 0.55, 0.12, 40);
		const mat = new THREE.MeshStandardMaterial({color: new THREE.Color(COLOR.lime), metalness: 0.65, roughness: 0.3});
		const edge = new THREE.MeshStandardMaterial({color: new THREE.Color(COLOR.limeDim), metalness: 0.6, roughness: 0.35});
		const coins: CoinSt['coins'] = [];
		const stacks = [-2.5, 2.5, -1.9, 1.9];
		for (let i = 0; i < count; i++) {
			const m = new THREE.Mesh(geo, [edge, mat, mat]);
			const st = i % stacks.length;
			const level = Math.floor(i / stacks.length);
			coins.push({m, x: stacks[st] + (rnd(seed + i) - 0.5) * 0.08, z: (rnd(seed * 3 + i) - 0.5) * 0.08, spawn: (i / count) * span, land: -1.6 + level * 0.13, spin: 6 + rnd(seed * 7 + i) * 6});
			scene.add(m);
		}
		return {coins};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);
	const update = useCallback(
		(c: ThreeCtx<CoinSt>, t: number) => {
			const fade = exitAt !== undefined ? 1 - sm(t, exitAt, exitAt + 0.35) : 1;
			for (const k of c.state.coins) {
				const age = t - k.spawn;
				k.m.visible = age >= 0 && fade > 0.02;
				if (age < 0) continue;
				const fall = 0.55;
				const p = Math.min(1, age / fall);
				const yy = 4.5 + (k.land - 4.5) * (p * p);
				const bounce = p >= 1 ? Math.max(0, 0.12 * Math.sin((age - fall) * 18) * Math.exp(-(age - fall) * 8)) : 0;
				k.m.position.set(k.x, yy + bounce, k.z);
				k.m.rotation.set(p < 1 ? k.spin * age : 0, p < 1 ? k.spin * 0.4 * age : 0, 0);
				k.m.scale.setScalar(fade);
			}
		},
		[exitAt],
	);
	return <ThreeLayer t={t} init={init} update={update} width={width} height={height} />;
};
