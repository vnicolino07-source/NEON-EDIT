/**
 * [APROVADO no v002, generalizado para o kit] Palco do apresentador com 3 layouts que se transformam um no outro
 * (tela cheia ↔ dividido da biblioteca ↔ "celular"), reenquadramento em degraus, elementos ATRÁS do apresentador
 * (com recorte) e a transição "tela cortada no meio" (laser + metades se afastando).
 *
 * Origem: videos/v002/Video.tsx (componente Stage). A lógica de desenho é a mesma; só os tempos viraram parâmetros.
 *
 * Uso típico (ver src/videos/demonstracao/Video.tsx):
 *   const m = layoutWeights(t, {split: [[a,b]], phone: [[c,d]]});
 *   <PresenterStage frame={frame} t={t} weights={m} zoom={zoomSteps(t, REFRAMES)} cut={{laserAt, splitAt, joinAt}} behind={...} cutout />
 */
import React from 'react';
import {AbsoluteFill, Img, interpolate} from 'remotion';
import {COLOR} from '../../brand/neon';
import {fgSrc, frameSrc} from '../../engine/Plate';
import {easeBrand, easeCss, phase} from '../../motion/neonMotion';
import {camRect} from '../neon/NeonLayout';

export type Weights = {full: number; split: number; phone: number};
export type Rect = {left: number; top: number; width: number; height: number; radius: number};

const ramp = (t: number, a: number, b: number) => interpolate(t, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: (x) => x * x * (3 - 2 * x)});
/** janela suave: sobe em `d` s antes de `a`, desce em `d` s depois de `b` */
export const win = (t: number, a: number, b: number, d = 0.3) => ramp(t, a - d, a) * (1 - ramp(t, b, b + d));

/** pesos dos layouts a partir de intervalos [início, fim] em segundos (o resto é tela cheia) */
export const layoutWeights = (t: number, iv: {split?: [number, number][]; phone?: [number, number][]}, d = 0.3): Weights => {
	const split = Math.max(0, ...(iv.split ?? []).map(([a, b]) => win(t, a, b, d)));
	const phone = Math.max(0, ...(iv.phone ?? []).map(([a, b]) => win(t, a, b, 0.35)));
	return {split, phone, full: Math.max(0, 1 - split - phone)};
};

/** reenquadramento em degraus de ~0,22 s: lista de [segundo, zoom] em ordem */
export const zoomSteps = (t: number, steps: [number, number][]) => {
	let z = steps[0][1];
	let prev = z;
	for (const [at, v] of steps) {
		if (t < at) break;
		z = prev + (v - prev) * ramp(t, at - 0.04, at + 0.2);
		prev = v;
	}
	return z;
};

export const STAGE_RECTS: {full: Rect; split: Rect; phone: Rect} = {
	full: {left: 0, top: 0, width: 1080, height: 1920, radius: 0},
	split: camRect(1) as Rect,
	phone: {left: 60, top: 330, width: 560, height: 996, radius: 64},
};

export const PresenterStage: React.FC<{
	frame: number;
	t: number;
	weights: Weights;
	/** zoom na tela cheia (1 = sem zoom) */
	zoom?: number;
	/** ponto do rosto em 1080×1920 (centro do zoom e do enquadramento no dividido) */
	face?: {x: number; y: number};
	/** elementos desenhados entre o fundo e o apresentador */
	behind?: React.ReactNode;
	/** desenha o recorte (fg) por cima do "behind" — só em quadros com máscara gerada e validada */
	cutout?: boolean;
	/** transição "tela cortada no meio": laser em laserAt, metades separam em splitAt, voltam em joinAt */
	cut?: {laserAt: number; splitAt: number; joinAt: number};
	rects?: {full: Rect; split: Rect; phone: Rect};
}> = ({frame, t, weights: m, zoom = 1, face = {x: 540, y: 760}, behind, cutout, cut: cutCfg, rects = STAGE_RECTS}) => {
	const R = rects;
	const rect = (k: keyof Rect) => m.full * R.full[k] + m.split * R.split[k] + m.phone * R.phone[k];
	const r = {left: rect('left'), top: rect('top'), width: rect('width'), height: rect('height'), radius: rect('radius')};
	const sFull = zoom, txFull = (1 - zoom) * face.x, tyFull = (1 - zoom) * face.y;
	const sSplit = R.split.width / 1080, txSplit = 0, tySplit = R.split.height * 0.3 - face.y * sSplit;
	const sPhone = R.phone.width / 1080, txPhone = 0, tyPhone = (R.phone.height - 1920 * sPhone) / 2;
	const s = m.full * sFull + m.split * sSplit + m.phone * sPhone;
	const tx = m.full * txFull + m.split * txSplit + m.phone * txPhone;
	const ty = m.full * tyFull + m.split * tySplit + m.phone * tyPhone;
	const cut = cutCfg ? phase(t, cutCfg.splitAt - 0.05, 0.4, easeBrand) * (1 - phase(t, cutCfg.joinAt - 0.05, 0.3, easeCss)) : 0;
	const laser = cutCfg ? phase(t, cutCfg.laserAt, 0.35, easeCss) * (1 - phase(t, cutCfg.splitAt + 0.1, 0.25)) : 0;
	const content = (
		<div style={{position: 'absolute', left: 0, top: 0, width: 1080, height: 1920, transformOrigin: '0 0', transform: `translate(${tx}px, ${ty}px) scale(${s})`}}>
			<Img src={frameSrc(frame)} style={{position: 'absolute', width: 1080, height: 1920}} />
			{behind ? <AbsoluteFill>{behind}</AbsoluteFill> : null}
			{cutout ? <Img src={fgSrc(frame)} style={{position: 'absolute', width: 1080, height: 1920}} /> : null}
		</div>
	);
	const half = (top: boolean) => (
		<div style={{position: 'absolute', left: 0, top: top ? 0 : r.height / 2, width: r.width, height: r.height / 2, overflow: 'hidden', transform: `translate(${(top ? -1 : 1) * 46 * cut}px, ${(top ? -1 : 1) * 60 * cut}px) rotate(${(top ? -1 : 1) * 2.2 * cut}deg)`, boxShadow: cut > 0.01 ? `0 0 0 ${4 * cut}px ${COLOR.lime}` : undefined}}>
			<div style={{position: 'absolute', left: 0, top: top ? 0 : -r.height / 2, width: r.width, height: r.height}}>{content}</div>
		</div>
	);
	return (
		<div style={{position: 'absolute', left: r.left, top: r.top, width: r.width, height: r.height, borderRadius: r.radius, overflow: cut > 0.001 ? 'visible' : 'hidden', background: COLOR.cam, boxShadow: m.phone > 0.01 ? `0 0 0 ${18 * m.phone}px ${COLOR.panel}, 0 0 0 ${22 * m.phone}px ${COLOR.line}` : undefined}}>
			{cut > 0.001 ? (
				<>
					{half(true)}
					{half(false)}
				</>
			) : (
				<div style={{position: 'absolute', inset: 0, borderRadius: r.radius, overflow: 'hidden'}}>{content}</div>
			)}
			{laser > 0 ? <div style={{position: 'absolute', left: 0, top: r.height / 2 - 4, height: 8, width: `${laser * 100}%`, background: COLOR.lime, boxShadow: `0 0 30px ${COLOR.lime}, 0 0 60px ${COLOR.lime}`, borderRadius: 4}} /> : null}
		</div>
	);
};

/** posição vertical da legenda que acompanha o layout atual */
export const captionY = (m: Weights) => m.full * 1470 + m.split * (camRect(1).top + camRect(1).height * 0.84) + m.phone * 1520;
