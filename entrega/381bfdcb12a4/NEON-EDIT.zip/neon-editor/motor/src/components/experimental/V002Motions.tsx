/**
 * [EXPERIMENTAIS v002] Motions criados para o vídeo "o Claude acabou de matar os editores".
 * Todos usam os tokens Neon (cores/fontes/acabamento). Viram acervo só depois de aprovados.
 * `t` = segundos desde o início do elemento, salvo indicação.
 */
import React from 'react';
import {Img} from 'remotion';
import {COLOR, FONT, FONT_FILES, RADIUS, SCALE as S, SPACE, TYPE} from '../../brand/neon';
import {easeBrand, easeCss, phase, pop, popOut} from '../../motion/neonMotion';
import {frameSrc} from '../../engine/Plate';
import {Label, NeonCard} from '../neon/NeonCards';

const clamp = (x: number) => Math.max(0, Math.min(1, x));
const out = (t: number, at?: number) => (at !== undefined && t >= at ? popOut(t, at) : {opacity: 1});
const mono: React.CSSProperties = {fontFamily: FONT.mono, letterSpacing: '0.1em', textTransform: 'uppercase'};

/** Texto gigante cinético em camadas (profundidade por cópias em contorno), para ficar ATRÁS do apresentador. */
export const KineticGiantText: React.FC<{t: number; lines: string[]; landAt?: number; lockAt?: number; exitAt?: number; top?: number}> = ({t, lines, landAt = 0, lockAt, exitAt, top = 140}) => {
	const p = phase(t, landAt, 0.5, easeBrand);
	const lock = lockAt !== undefined ? phase(t, lockAt, 0.3, easeBrand) : 0;
	const o = exitAt !== undefined ? 1 - clamp((t - exitAt) / 0.3) : 1;
	return (
		<div style={{position: 'absolute', left: 0, right: 0, top, textAlign: 'center', opacity: o, transform: `translateY(${(1 - p) * -260 - (1 - o) * 200}px) scale(${1.25 - 0.25 * p + 0.04 * lock})`}}>
			{lines.map((ln, i) => (
				<div key={i} style={{position: 'relative', fontFamily: FONT.display, fontWeight: 700, fontSize: 235, lineHeight: 0.86, letterSpacing: '-0.04em'}}>
					{[3, 2, 1].map((k) => (
						<div key={k} style={{position: 'absolute', inset: 0, color: 'transparent', WebkitTextStroke: `3px ${i === lines.length - 1 ? COLOR.lime : COLOR.text}`, opacity: 0.18 * (4 - k) * p, transform: `translate(${k * 14 * (1 - lock * 0.5)}px, ${k * 18}px)`}}>
							{ln}
						</div>
					))}
					<div style={{position: 'relative', color: i === lines.length - 1 ? COLOR.lime : COLOR.text, textShadow: `0 ${10 * S}px ${30 * S}px rgba(0,0,0,0.45)`}}>{ln}</div>
				</div>
			))}
		</div>
	);
};

/** Alças de seleção de editor em volta do quadro ("tudo o que eu quiser nesse vídeo"). */
export const SelectionBox: React.FC<{t: number; exitAt?: number; label: string}> = ({t, exitAt, label}) => {
	const p = phase(t, 0, 0.45, easeBrand);
	const inset = 70 + (1 - p) * 60;
	const o = exitAt !== undefined ? 1 - clamp((t - exitAt) / 0.25) : 1;
	const h = 34;
	const corners = [
		[inset, inset],
		[1080 - inset, inset],
		[inset, 1920 - inset * 1.6],
		[1080 - inset, 1920 - inset * 1.6],
	];
	return (
		<div style={{position: 'absolute', inset: 0, opacity: Math.min(1, p * 1.5) * o}}>
			<div style={{position: 'absolute', left: inset, top: inset, right: inset, bottom: inset * 1.6, border: `4px solid ${COLOR.lime}`, borderRadius: 8}} />
			{corners.map(([x, y], i) => (
				<div key={i} style={{position: 'absolute', left: x - h / 2, top: y - h / 2, width: h, height: h, background: COLOR.ink, border: `5px solid ${COLOR.lime}`, borderRadius: 6}} />
			))}
			<div style={{position: 'absolute', left: inset, top: inset - 70, background: COLOR.lime, color: COLOR.ink, padding: '8px 18px', borderRadius: 12, fontWeight: 700, fontSize: 30, ...mono}}>{label}</div>
		</div>
	);
};

/** Identidade visual da marca ativa: amostras de cor + espécimes de fonte entrando no ritmo da fala. */
export const IdentityCard: React.FC<{t: number; colorsAt: number; fontsAt: number; fxAt: number; exitAt?: number}> = ({t, colorsAt, fontsAt, fxAt, exitAt}) => {
	const sw = [
		[COLOR.ink, 'fundo'],
		[COLOR.panel, 'superfície'],
		[COLOR.line, 'borda'],
		[COLOR.lime, 'acento'],
		[COLOR.warn, 'alerta'],
	];
	const fx = ['contador', 'checklist', 'antes/depois', 'progresso', 'prompt', 'gráfico'];
	return (
		<div style={{width: 1080 - 2 * SPACE.framePadX, ...pop(t, 0), ...out(t, exitAt)}}>
			<NeonCard>
				<div style={{display: 'flex', justifyContent: 'space-between'}}>
					<Label>minha identidade visual</Label>
					<Label color={COLOR.lime}>● neon v1</Label>
				</div>
				<div style={{display: 'flex', gap: 22, marginTop: 34}}>
					{sw.map(([c, n], i) => {
						const q = phase(t, colorsAt + i * 0.12, 0.45, easeBrand);
						return (
							<div key={c} style={{flex: 1, opacity: Math.min(1, q * 2), transform: `translateY(${(1 - q) * 40}px)`}}>
								<div style={{height: 130, borderRadius: 24, background: c, border: `4px solid ${COLOR.line}`}} />
								<div style={{fontFamily: FONT.mono, fontSize: 24, color: COLOR.mute, marginTop: 10}}>{c}</div>
								<div style={{fontSize: 26, color: COLOR.text}}>{n}</div>
							</div>
						);
					})}
				</div>
				<div style={{display: 'flex', gap: 30, marginTop: 30, alignItems: 'baseline', opacity: phase(t, fontsAt, 0.4, easeCss), transform: `translateY(${(1 - phase(t, fontsAt, 0.5, easeBrand)) * 30}px)`}}>
					<div style={{fontFamily: FONT.display, fontWeight: 700, fontSize: 84, lineHeight: 1}}>{FONT_FILES.displayFamily}</div>
					<div style={{fontFamily: FONT.mono, fontSize: 34, color: COLOR.mute}}>{FONT_FILES.monoFamily}</div>
				</div>
				<div style={{display: 'flex', flexWrap: 'wrap', gap: 14, marginTop: 30}}>
					{fx.map((f, i) => {
						const q = phase(t, fxAt + i * 0.08, 0.4, easeBrand);
						return (
							<span key={f} style={{...mono, fontSize: 26, padding: '10px 18px', borderRadius: 999, border: `3px solid ${COLOR.lime}`, color: i % 2 ? COLOR.lime : COLOR.ink, background: i % 2 ? 'transparent' : COLOR.lime, opacity: q, transform: `scale(${0.6 + 0.4 * q})`}}>
								{f}
							</span>
						);
					})}
				</div>
			</NeonCard>
		</div>
	);
};

/** Trilha de etapas horizontal com ilustração da etapa ativa (gravar → pasta → Claude edita). */
/** Textos internos são parâmetros (padrões = os do vídeo aprovado v002, com o nome do guia genérico). */
export const StepTrack: React.FC<{t: number; steps: {label: string; at: number; icon: 'phone' | 'folder' | 'spark'}[]; frame: number; doneAt?: number; exitAt?: number; folder?: string; ask?: string; reading?: string; done?: string}> = ({t, steps, frame, doneAt, exitAt, folder = '/videos', ask = 'edita pra mim', reading = 'lendo GUIA_DE_EDICAO.md', done = 'do jeito que eu gosto'}) => {
	const active = steps.reduce((a, s, i) => (t >= s.at - 0.05 ? i : a), -1);
	const icon = (k: string, on: boolean) => {
		const c = on ? COLOR.ink : COLOR.lime;
		if (k === 'phone')
			return (
				<svg width="58" height="58" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2">
					<rect x="6" y="2" width="12" height="20" rx="3" />
					<circle cx="12" cy="18" r="1" />
				</svg>
			);
		if (k === 'folder')
			return (
				<svg width="58" height="58" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinejoin="round">
					<path d="M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
				</svg>
			);
		return (
			<svg width="58" height="58" viewBox="0 0 24 24">
				<path d="M12 2 L14 9 L21 10 L15 14 L17 21 L12 17 L7 21 L9 14 L3 10 L10 9 Z" fill={c} />
			</svg>
		);
	};
	const line = steps.length > 1 ? clamp((t - steps[0].at) / Math.max(0.1, steps[steps.length - 1].at - steps[0].at)) : 1;
	return (
		<div style={{width: 1080 - 2 * SPACE.framePadX, ...pop(t, 0), ...out(t, exitAt)}}>
			<NeonCard>
				<Label>o passo a passo</Label>
				{/* ilustração da etapa ativa */}
				<div style={{height: 330, position: 'relative', marginTop: 20, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
					{active === 0 ? (
						<div style={{width: 170, height: 300, borderRadius: 30, border: `6px solid ${COLOR.line}`, overflow: 'hidden', position: 'relative', ...pop(t, steps[0].at)}}>
							<Img src={frameSrc(frame)} style={{width: '100%', height: '100%', objectFit: 'cover'}} />
							<div style={{position: 'absolute', top: 10, left: 10, background: COLOR.warn, width: 18, height: 18, borderRadius: 9, opacity: Math.floor(t * 2) % 2 ? 1 : 0.3}} />
						</div>
					) : null}
					{active === 1 ? (
						<div style={{position: 'relative', width: 400, height: 300}}>
							<div style={{position: 'absolute', left: 115, bottom: 40, width: 170, height: 200, borderRadius: 24, border: `5px solid ${COLOR.line}`, overflow: 'hidden', transform: `translateY(${-160 + 160 * phase(t, steps[1].at, 0.6, easeCss)}px) rotate(${-12 + 12 * phase(t, steps[1].at, 0.6)}deg)`, opacity: 1 - phase(t, steps[1].at + 0.5, 0.2)}}>
								<Img src={frameSrc(frame)} style={{width: '100%', height: '100%', objectFit: 'cover'}} />
							</div>
							<svg width="400" height="230" viewBox="0 0 24 14" style={{position: 'absolute', bottom: 0, left: 0}}>
								<path d="M1 2.5a1.5 1.5 0 011.5-1.5h6l1.5 1.5h11.5A1.5 1.5 0 0123 4v8.5a1.5 1.5 0 01-1.5 1.5h-19A1.5 1.5 0 011 12.5z" fill={COLOR.panel2} stroke={COLOR.lime} strokeWidth="0.5" />
							</svg>
							<div style={{position: 'absolute', bottom: 40, width: '100%', textAlign: 'center', fontFamily: FONT.mono, color: COLOR.lime, fontSize: 30}}>{folder}</div>
						</div>
					) : null}
					{active === 2 ? (
						<div style={{display: 'flex', flexDirection: 'column', gap: 18, width: '86%', ...pop(t, steps[2].at)}}>
							<div style={{alignSelf: 'flex-end', background: COLOR.panel2, border: `4px solid ${COLOR.line}`, borderRadius: 30, padding: '18px 28px', fontSize: 40}}>{ask}</div>
							<div style={{display: 'flex', alignItems: 'center', gap: 16, fontSize: 36, color: COLOR.mute, opacity: phase(t, steps[2].at + 0.6, 0.3)}}>
								<span style={{width: 56, height: 56, borderRadius: 16, background: COLOR.lime, display: 'grid', placeItems: 'center'}}>{icon('spark', true)}</span>
								{reading}
							</div>
							{doneAt !== undefined ? (
								<div style={{display: 'flex', alignItems: 'center', gap: 16, fontSize: 40, color: COLOR.text, ...pop(t, doneAt)}}>
									<span style={{color: COLOR.lime, fontWeight: 700}}>✓</span> {done}
								</div>
							) : null}
						</div>
					) : null}
				</div>
				{/* trilha */}
				<div style={{position: 'relative', height: 120, marginTop: 10}}>
					<div style={{position: 'absolute', left: 60, right: 60, top: 58, height: 8, borderRadius: 4, background: COLOR.line}} />
					<div style={{position: 'absolute', left: 60, top: 58, height: 8, borderRadius: 4, background: COLOR.lime, width: `calc(${line * 100}% - ${line * 120}px)`}} />
					<div style={{position: 'absolute', inset: 0, display: 'flex', justifyContent: 'space-between'}}>
						{steps.map((s, i) => {
							const on = i <= active;
							const q = phase(t, s.at, 0.45, easeBrand);
							return (
								<div key={i} style={{display: 'flex', flexDirection: 'column', alignItems: 'center', width: 260}}>
									<div style={{width: 110, height: 110, borderRadius: 30, background: on ? COLOR.lime : COLOR.panel2, border: `4px solid ${on ? COLOR.lime : COLOR.line}`, display: 'grid', placeItems: 'center', transform: `scale(${1 + 0.12 * Math.sin(Math.PI * clamp(q))})`}}>{icon(s.icon, on)}</div>
									<div style={{fontSize: 34, marginTop: 12, color: on ? COLOR.text : COLOR.mute, fontWeight: 700}}>{s.label}</div>
								</div>
							);
						})}
					</div>
				</div>
			</NeonCard>
		</div>
	);
};

/** Card do lado do celular: botão publicar + tendência de visualizações (sem números inventados). */
export const PostPanel: React.FC<{t: number; postAt: number; viewsAt: number; exitAt?: number}> = ({t, postAt, viewsAt, exitAt}) => {
	const press = Math.max(0, 1 - Math.abs(t - postAt) / 0.12);
	const posted = t >= postAt;
	const line = phase(t, viewsAt, 0.9, easeCss);
	return (
		<div style={{width: 300, display: 'flex', flexDirection: 'column', gap: 24, ...pop(t, 0), ...out(t, exitAt)}}>
			<div style={{background: posted ? COLOR.lime : COLOR.text, color: COLOR.ink, borderRadius: 999, padding: '22px 0', textAlign: 'center', fontWeight: 700, fontSize: 40, transform: `scale(${1 - 0.1 * press})`}}>{posted ? '✓ postado' : 'Postar'}</div>
			<NeonCard style={{padding: 26, opacity: phase(t, viewsAt - 0.2, 0.3)}}>
				<div style={{display: 'flex', alignItems: 'center', gap: 12}}>
					<svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke={COLOR.lime} strokeWidth="2.2">
						<path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12z" />
						<circle cx="12" cy="12" r="3" />
					</svg>
					<Label style={{fontSize: 26}}>visualizações</Label>
				</div>
				<svg width="248" height="150" viewBox="0 0 100 60" style={{marginTop: 14}}>
					<path d="M2 55 L25 45 L45 48 L65 30 L98 6" fill="none" stroke={COLOR.lime} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="130" strokeDashoffset={130 * (1 - line)} />
				</svg>
			</NeonCard>
		</div>
	);
};

/** A "tela dele" explicando: transcreve em tempo real o que está sendo falado, em tipografia grande. */
export const LiveExplain: React.FC<{t: number; abs: number; words: {w: string; start: number}[]; exitAt?: number}> = ({t, abs, words, exitAt}) => {
	const shown = words.filter((w) => w.start <= abs + 0.02).slice(-7);
	return (
		<div style={{width: 1080 - 2 * SPACE.framePadX, ...pop(t, 0), ...out(t, exitAt)}}>
			<NeonCard style={{minHeight: 560}}>
				<div style={{display: 'flex', justifyContent: 'space-between'}}>
					<Label>a tela explica</Label>
					<Label color={COLOR.lime}>● ao vivo</Label>
				</div>
				<div style={{fontFamily: FONT.display, fontWeight: 700, fontSize: 92, lineHeight: 1.08, letterSpacing: '-0.02em', marginTop: 30}}>
					{shown.map((w, i) => {
						const q = clamp((abs - w.start + 0.04) / 0.14);
						const last = i === shown.length - 1;
						return (
							<span key={w.start} style={{display: 'inline-block', marginRight: 22, opacity: q, transform: `translateY(${(1 - q) * 20}px)`, color: last ? COLOR.ink : COLOR.text, background: last ? COLOR.lime : 'transparent', borderRadius: RADIUS.hl, padding: last ? '0 14px' : 0}}>
								{w.w}
							</span>
						);
					})}
				</div>
			</NeonCard>
		</div>
	);
};

/** Card de "modelo de vídeo": wireframe do layout (card em cima + vídeo embaixo) se montando. */
export const TemplateCard: React.FC<{t: number; exitAt?: number}> = ({t, exitAt}) => {
	const q = (i: number) => phase(t, 0.15 + i * 0.18, 0.45, easeBrand);
	return (
		<div style={{width: 1080 - 2 * SPACE.framePadX, display: 'flex', gap: 40, alignItems: 'center', ...pop(t, 0), ...out(t, exitAt)}}>
			<div style={{width: 300, height: 533, borderRadius: 36, border: `5px solid ${COLOR.line}`, background: COLOR.ink, padding: 18, display: 'flex', flexDirection: 'column', gap: 14, boxSizing: 'border-box'}}>
				<div style={{height: '36%', borderRadius: 18, border: `4px dashed ${COLOR.lime}`, opacity: q(0), transform: `scale(${0.8 + 0.2 * q(0)})`}} />
				<div style={{flex: 1, borderRadius: 18, background: COLOR.cam, border: `4px solid ${COLOR.line}`, opacity: q(1), position: 'relative'}}>
					<div style={{position: 'absolute', left: '20%', right: '20%', bottom: '18%', height: 22, borderRadius: 6, background: COLOR.lime, opacity: q(2)}} />
				</div>
			</div>
			<div style={{flex: 1}}>
				<Label>modelo de vídeo</Label>
				{['card no topo', 'vídeo embaixo', 'legenda neon'].map((s, i) => (
					<div key={s} style={{fontSize: 46, fontWeight: 700, marginTop: 18, opacity: q(i), color: COLOR.text}}>
						<span style={{color: COLOR.lime}}>✓</span> {s}
					</div>
				))}
			</div>
		</div>
	);
};

/** Referência → varredura → estilo entendido (chips). Cards de referência são genéricos (sem marca de terceiros). */
export const ReferenceScan: React.FC<{t: number; scanAt: number; styleAt: number; exitAt?: number}> = ({t, scanAt, styleAt, exitAt}) => {
	const scan = phase(t, scanAt, 1.1, easeCss);
	const chips = ['ritmo', 'cortes', 'legendas', 'cores'];
	return (
		<div style={{width: 1080 - 2 * SPACE.framePadX, ...pop(t, 0), ...out(t, exitAt)}}>
			<NeonCard>
				<Label>referência enviada</Label>
				<div style={{display: 'flex', gap: 30, marginTop: 26, alignItems: 'center'}}>
					<div style={{position: 'relative', width: 250, height: 444, borderRadius: 30, overflow: 'hidden', border: `4px solid ${COLOR.line}`, background: `linear-gradient(160deg, ${COLOR.panel2}, ${COLOR.ink})`, flex: 'none'}}>
						<svg width="90" height="90" viewBox="0 0 24 24" style={{position: 'absolute', left: 80, top: 177}}>
							<circle cx="12" cy="12" r="11" fill="none" stroke={COLOR.mute} strokeWidth="1.5" />
							<path d="M10 8 L16 12 L10 16 Z" fill={COLOR.mute} />
						</svg>
						<div style={{position: 'absolute', left: 0, right: 0, height: 70, top: `${-15 + scan * 110}%`, background: `linear-gradient(to bottom, transparent, ${COLOR.scanGlow}, ${COLOR.lime}, ${COLOR.scanGlow}, transparent)`, opacity: scan > 0 && scan < 1 ? 1 : 0}} />
						<div style={{position: 'absolute', left: 14, top: 14, ...mono, fontSize: 20, color: COLOR.lime, background: COLOR.ink, border: `3px solid ${COLOR.line}`, borderRadius: 999, padding: '4px 12px'}}>ref.mp4</div>
					</div>
					<div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 18}}>
						<div style={{fontSize: 40, color: COLOR.mute, opacity: phase(t, styleAt - 0.3, 0.3)}}>estilo entendido:</div>
						{chips.map((c, i) => {
							const q = phase(t, styleAt + i * 0.12, 0.45, easeBrand);
							return (
								<div key={c} style={{display: 'flex', alignItems: 'center', gap: 16, fontSize: 52, fontWeight: 700, opacity: Math.min(1, q * 2), transform: `translateX(${(1 - q) * 60}px)`}}>
									<span style={{width: 50, height: 50, borderRadius: 14, background: COLOR.lime, color: COLOR.ink, display: 'grid', placeItems: 'center', fontSize: 34}}>✓</span>
									{c}
								</div>
							);
						})}
					</div>
				</div>
			</NeonCard>
		</div>
	);
};

/** Pílula "1 prompt" com contador grande e envio (avião de papel saindo). */
export const OnePrompt: React.FC<{t: number; sendAt?: number; exitAt?: number; caption?: string}> = ({t, sendAt, exitAt, caption = 'prompt'}) => {
	const fly = sendAt !== undefined ? phase(t, sendAt, 0.6, easeCss) : 0;
	return (
		<div style={{display: 'flex', alignItems: 'center', gap: 34, ...pop(t, 0), ...out(t, exitAt)}}>
			<div style={{fontFamily: FONT.display, fontWeight: 700, fontSize: TYPE.big * 1.1, lineHeight: 0.85, color: COLOR.lime, letterSpacing: '-0.04em'}}>1</div>
			<div>
				<Label>só um</Label>
				<div style={{fontSize: 110, fontWeight: 700, lineHeight: 1, letterSpacing: '-0.03em'}}>{caption}</div>
			</div>
			<div style={{width: 120, height: 120, borderRadius: 60, background: COLOR.lime, display: 'grid', placeItems: 'center', transform: `translate(${fly * 300}px, ${-fly * 260}px) rotate(${fly * 20}deg)`, opacity: 1 - fly}}>
				<svg width="62" height="62" viewBox="0 0 24 24" fill="none" stroke={COLOR.ink} strokeWidth="2.4" strokeLinejoin="round">
					<path d="M22 2 L11 13 M22 2 L15 22 L11 13 L2 9 Z" />
				</svg>
			</div>
		</div>
	);
};
