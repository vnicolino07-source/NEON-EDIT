/**
 * [EXPERIMENTAL v002] Palavra 3D que é cortada por um risco vermelho e EXPLODE em letras.
 * Three.js real: cada letra é uma malha extrudada (Space Grotesk 700) com física simples determinística.
 * Parâmetros: text, accent (palavra/linha em neon), strikeAt, explodeAt, y, size.
 */
import React, {useCallback} from 'react';
import {staticFile} from 'remotion';
import * as THREE from 'three';
import {Font} from 'three/examples/jsm/loaders/FontLoader.js';
import {TTFLoader} from 'three/examples/jsm/loaders/TTFLoader.js';
import {TextGeometry} from 'three/examples/jsm/geometries/TextGeometry.js';
import {COLOR, FONT_FILES} from '../../brand/neon';
import {ThreeLayer, ThreeCtx} from '../three/ThreeLayer';

type L = {mesh: THREE.Mesh; home: THREE.Vector3; vel: THREE.Vector3; spin: THREE.Vector3};
type St = {letters: L[]; strike: THREE.Mesh; group: THREE.Group; width: number};
const rand = (s: number) => {
	const x = Math.sin(s * 91.7 + 13.3) * 43758.5453;
	return x - Math.floor(x);
};
const smooth = (t: number, a: number, b: number) => {
	const x = Math.max(0, Math.min(1, (t - a) / (b - a)));
	return x * x * (3 - 2 * x);
};

export const ShatterText3D: React.FC<{t: number; lines: string[]; accentLine?: number; strikeAt: number; explodeAt: number; y?: number; size?: number; introFrom?: number}> = ({t, lines, accentLine = 1, strikeAt, explodeAt, y = 2.15, size = 0.42, introFrom = -0.4}) => {
	const init = useCallback(async ({scene, camera}: Omit<ThreeCtx<St>, 'state'>): Promise<St> => {
		camera.position.set(0, 0, 10);
		const buf = await (await fetch(staticFile(FONT_FILES.display3d))).arrayBuffer();
		const font = new Font(new TTFLoader().parse(buf));
		const group = new THREE.Group();
		const letters: L[] = [];
		let width = 0;
		lines.forEach((line, li) => {
			const mats = [
				new THREE.MeshStandardMaterial({color: new THREE.Color(li === accentLine ? COLOR.lime : COLOR.text), roughness: 0.35}),
				new THREE.MeshStandardMaterial({color: new THREE.Color(li === accentLine ? COLOR.limeDim : COLOR.line), roughness: 0.5}),
			];
			// mede a linha inteira para centralizar
			const full = new TextGeometry(line, {font, size: 1, depth: 0.35});
			full.computeBoundingBox();
			const lw = full.boundingBox!.max.x - full.boundingBox!.min.x;
			width = Math.max(width, lw);
			let x = -lw / 2;
			[...line].forEach((ch, ci) => {
				const g = new TextGeometry(ch, {font, size: 1, depth: 0.35, curveSegments: 6, bevelEnabled: true, bevelThickness: 0.03, bevelSize: 0.02, bevelSegments: 3});
				g.computeBoundingBox();
				const adv = ch === ' ' ? 0.32 : g.boundingBox!.max.x - g.boundingBox!.min.x + 0.06;
				g.translate(-g.boundingBox!.min.x - adv / 2, 0, 0);
				const m = new THREE.Mesh(g, mats);
				const home = new THREE.Vector3(x + adv / 2, (lines.length - 1) * 0.6 - li * 1.2 - 0.35, 0);
				const s = li * 50 + ci;
				letters.push({mesh: m, home, vel: new THREE.Vector3((home.x / Math.max(1, lw / 2)) * 4 + (rand(s) - 0.5) * 3, 2 + rand(s + 1) * 4, 3 + rand(s + 2) * 5), spin: new THREE.Vector3(rand(s + 3) * 10 - 5, rand(s + 4) * 10 - 5, rand(s + 5) * 6 - 3)});
				group.add(m);
				x += adv;
			});
		});
		const strike = new THREE.Mesh(new THREE.BoxGeometry(1, 0.13, 0.05), new THREE.MeshBasicMaterial({color: new THREE.Color(COLOR.warn)}));
		strike.position.z = 0.5;
		group.add(strike);
		scene.add(group);
		scene.add(new THREE.AmbientLight(0xffffff, 0.9));
		const key = new THREE.DirectionalLight(0xffffff, 2.3);
		key.position.set(-4, 6, 9);
		scene.add(key);
		const rim = new THREE.PointLight(new THREE.Color(COLOR.lime), 30, 20);
		rim.position.set(3, -2, 4);
		scene.add(rim);
		return {letters, strike, group, width};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);
	const update = useCallback(
		(c: ThreeCtx<St>, t: number) => {
			const {letters, strike, group, width} = c.state;
			const intro = smooth(t, introFrom, introFrom + 0.35);
			group.scale.setScalar(size * (1.08 - 0.08 * intro));
			group.position.set(0, y, 0);
			group.rotation.set(-0.08, 0.06 * Math.sin(t * 1.3), 0);
			// risco vermelho atravessando
			const k = smooth(t, strikeAt, strikeAt + 0.22);
			strike.scale.set(Math.max(0.001, (width + 0.6) * k), 1, 1);
			strike.position.set(-(width + 0.6) / 2 + ((width + 0.6) * k) / 2, -0.05, 0.5);
			strike.rotation.z = -0.08;
			strike.visible = k > 0 && t < explodeAt + 0.05;
			const age = Math.max(0, t - explodeAt);
			letters.forEach((l) => {
				const m = l.mesh;
				if (t < explodeAt) {
					// tremor antes de explodir
					const sh = smooth(t, strikeAt + 0.1, explodeAt) * 0.04;
					m.position.set(l.home.x + Math.sin(t * 90 + l.home.x * 7) * sh, l.home.y + Math.cos(t * 80 + l.home.x * 5) * sh, 0);
					m.rotation.set(0, 0, 0);
				} else {
					m.position.set(l.home.x + l.vel.x * age, l.home.y + l.vel.y * age - 4.9 * age * age, l.vel.z * age);
					m.rotation.set(l.spin.x * age, l.spin.y * age, l.spin.z * age);
				}
				const mats = m.material as THREE.MeshStandardMaterial[];
				mats.forEach((mt) => {
					mt.transparent = true;
					mt.opacity = Math.min(intro, 1 - smooth(age, 0.5, 0.95));
				});
			});
		},
		[strikeAt, explodeAt, y, size, introFrom],
	);
	return <ThreeLayer t={t} init={init} update={update} />;
};
