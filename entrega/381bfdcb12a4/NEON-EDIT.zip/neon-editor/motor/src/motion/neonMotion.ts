// Comportamentos da Biblioteca Neon convertidos de CSS keyframes para funções por quadro (determinísticas).
import {Easing} from 'remotion';
import {EASE, MOTION} from '../brand/neon';

const bz = (c: readonly [number, number, number, number]) => Easing.bezier(c[0], c[1], c[2], c[3]);
export const easeBrand = bz(EASE.brand);
export const easeStandard = bz(EASE.standard);
export const easeInOutCss = bz(EASE.inOut);
export const easeCss = bz(EASE.css);
const clamp01 = (x: number) => Math.max(0, Math.min(1, x));

/** progresso 0→1 de uma animação que começa em `delay` e dura `dur` (t = segundos desde o início do componente) */
export const phase = (t: number, delay: number, dur: number, ease: (x: number) => number = (x) => x) => ease(clamp01((t - delay) / dur));

/** entrada padrão: sobe 14 px (×4) e escala .94→1 em .55 s com overshoot */
export const pop = (t: number, delay = 0, intensity = 1) => {
	const p = phase(t, delay, MOTION.pop.dur, easeBrand); // pode passar de 1 (overshoot)
	const lin = clamp01((t - delay) / MOTION.pop.dur);
	return {
		opacity: Math.min(1, lin * 1.6),
		transform: `translateY(${(1 - p) * MOTION.pop.fromY * intensity}px) scale(${1 - (1 - MOTION.pop.fromScale) * (1 - p) * intensity})`,
	};
};
/** saída simétrica (não definida na biblioteca; espelho da entrada, 0,3 s) [derivado] */
export const popOut = (t: number, start: number, dur = 0.3) => {
	const p = phase(t, start, dur, easeCss);
	return {opacity: 1 - p, transform: `translateY(${-p * MOTION.pop.fromY}px) scale(${1 - 0.04 * p})`};
};
export const cascadeDelay = (i: number, first = MOTION.cascadeFirst, step = MOTION.cascadeStep) => first + i * step;

/** queda do topo (notificação) */
export const drop = (t: number, delay = 0) => {
	const p = phase(t, delay, MOTION.drop.dur, easeBrand);
	return {opacity: Math.min(1, clamp01((t - delay) / MOTION.drop.dur) * 1.6), transform: `translateY(${(1 - p) * MOTION.drop.fromY}px)`};
};

/** número subindo do zero (easeOutCubic, 1,2 s) */
export const countUp = (t: number, end: number, delay: number = MOTION.count.start, dur: number = MOTION.count.dur, start = 0) => {
	const p = clamp01((t - delay) / dur);
	return Math.round(start + (end - start) * (1 - Math.pow(1 - p, 3)));
};

/** digitação: 55 ms por caractere a partir de 0,4 s; cursor piscando 1 s */
export const typed = (t: number, text: string, delay: number = MOTION.type.start, perChar: number = MOTION.type.perChar) => {
	const n = Math.max(0, Math.min(text.length, Math.floor((t - delay) / perChar) + 1));
	return {text: t < delay ? '' : text.slice(0, n), caretOn: Math.floor(t / (MOTION.blink / 2)) % 2 === 0, done: n >= text.length};
};
/** digitação sincronizada à fala: termina em `end` (útil quando o texto é falado) */
export const typedBetween = (t: number, text: string, start: number, end: number) => {
	const p = clamp01((t - start) / Math.max(0.05, end - start));
	const n = Math.round(text.length * p);
	return {text: text.slice(0, n), caretOn: Math.floor(t / 0.5) % 2 === 0, done: p >= 1};
};

/** risco que atravessa da esquerda (scaleX 0→1) */
export const strike = (t: number, delay: number = MOTION.strike.delay, dur: number = MOTION.strike.dur) => phase(t, delay, dur, easeCss);
/** barra de progresso (largura 0→100%) */
export const grow = (t: number, delay: number = MOTION.grow.delay, dur: number = MOTION.grow.dur) => phase(t, delay, dur, easeStandard);
/** barra do gráfico subindo (scaleY) */
export const rise = (t: number, i: number, delay = 0) => Math.max(0, phase(t, delay + i * MOTION.rise.stagger, MOTION.rise.dur, easeBrand));
/** marca-texto neon atrás da palavra + troca da cor do texto para ink */
export const mark = (t: number, delay: number = MOTION.mark.delay) => ({p: phase(t, delay, MOTION.mark.dur, easeCss), ink: t >= delay + (MOTION.mark.inkAt - MOTION.mark.delay)});
/** varredura vertical (top: -30% → 100%) */
export const scan = (t: number, delay: number = MOTION.scan.delay) => -30 + 130 * phase(t, delay, MOTION.scan.dur, easeInOutCss);
/** pulso do botão (anel neon que expande e some, período 1,6 s) */
export const pulse = (t: number, start: number = MOTION.pulse.start) => {
	if (t < start) return {spread: 0, alpha: 0};
	const x = ((t - start) % MOTION.pulse.period) / MOTION.pulse.period;
	const k = x < 0.5 ? x * 2 : (1 - x) * 2; // 0→1→0
	return {spread: MOTION.pulse.spread * (x < 0.5 ? k : 1), alpha: 0.5 * (x < 0.5 ? 1 - k : 0)};
};
/** checkbox: preenche (0,3 s) e desenha o check (0,35 s) */
export const check = (t: number, i: number, first: number = MOTION.check.first, step: number = MOTION.check.step) => {
	const d = first + i * step;
	return {fill: phase(t, d, MOTION.check.fill, easeCss), draw: phase(t, d, MOTION.check.draw, easeCss)};
};
