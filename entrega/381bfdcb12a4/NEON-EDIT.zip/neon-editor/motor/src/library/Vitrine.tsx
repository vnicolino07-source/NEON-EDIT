/**
 * Vitrine da BIBLIOTECA_DE_MOTIONS: renderiza cada componente funcional com textos de demonstração.
 * Serve para verificação visual — os textos aqui são rótulos de teste, não conteúdo de vídeo.
 */
import React from 'react';
import {AbsoluteFill, Img, useCurrentFrame} from 'remotion';
import {frameSrc} from '../engine/Plate';
import {COLOR, FONT, TYPE} from '../brand/neon';
import {holdRender} from '../engine/render';
import {NeonBars, NeonBeforeAfter, NeonChecklist, NeonCounter, NeonCTA, NeonImageReveal, NeonPoll, NeonProgress, NeonPrompt, NeonQuote, NeonSteps, NeonToasts} from '../components/neon/NeonCards';
import {ensureNeonFonts, NeonCaption, NeonFrame} from '../components/neon/NeonLayout';
import {Clock3D, Falling3D, Text3D} from '../components/three/Neon3D';

ensureNeonFonts(() => holdRender('fonts'));
const FPS = 30;
const presenter = (f: number) => <Img src={frameSrc(f % 90)} style={{width: 1080, height: 1920}} />;

type Item = {name: string; dur: number; slot?: (t: number) => React.ReactNode; three?: (t: number) => React.ReactNode; split?: number};
const ITEMS: Item[] = [
	{name: '01 contador', dur: 2.6, slot: (t) => <NeonCounter t={t} label="rótulo mono" value={128} line1="linha um" line2="linha neon" exitAt={2.3} />},
	{name: '02 checklist', dur: 2.8, slot: (t) => <NeonChecklist t={t} label="rótulo" items={['Item um', 'Item dois', 'Item três']} exitAt={2.5} />},
	{name: '03 antes e depois', dur: 2.6, slot: (t) => <NeonBeforeAfter t={t} label="comparação" before="antes" after="depois" exitAt={2.3} />},
	{name: '04 progresso', dur: 2.8, slot: (t) => <NeonProgress t={t} label="processando" status="ao vivo" title="Título da etapa" steps={['um', 'dois', 'três', 'quatro']} exitAt={2.5} />},
	{name: '05 prompt', dur: 2.8, slot: (t) => <NeonPrompt t={t} text="texto digitado no campo" sendAt={2.0} exitAt={2.5} />},
	{name: '06 notificação', dur: 2.6, slot: (t) => <NeonToasts t={t} items={[{title: 'Primeiro aviso', sub: 'detalhe'}, {title: 'Segundo aviso', sub: 'detalhe', icon: 'bell'}]} exitAt={2.3} />},
	{name: '07 passo a passo', dur: 2.6, slot: (t) => <NeonSteps t={t} label="como funciona" steps={['Primeiro passo', 'Segundo passo', 'Terceiro passo']} exitAt={2.3} />},
	{name: '08 gráfico', dur: 2.4, slot: (t) => <NeonBars t={t} label="série" values={[28, 36, 33, 52, 100]} exitAt={2.1} />},
	{name: '09 frase de impacto', dur: 2.6, slot: (t) => <NeonQuote t={t} before="Frase com a" highlight="palavra-chave" exitAt={2.3} />},
	{name: '10 imagem', dur: 2.4, slot: (t) => <NeonImageReveal t={t} tag="imagem" placeholder="espaço da imagem" exitAt={2.1} />},
	{name: '11 enquete', dur: 2.4, slot: (t) => <NeonPoll t={t} question="Pergunta?" options={[{text: 'Opção A', pct: 40}, {text: 'Opção B', pct: 60, win: true}]} exitAt={2.1} />},
	{name: '12 chamada final', dur: 2.8, slot: (t) => <NeonCTA t={t} kicker="comente a palavra" word="PALAVRA" button="Saiba mais" />},
	{name: '3D texto', dur: 3.2, split: 0, three: (t) => <Text3D t={t} lines={['TEXTO', '3D']} lineTimes={[0.1, 0.35]} growAt={1.6} exitAt={2.85} />},
	{name: '3D queda', dur: 3.0, split: 0, three: (t) => <Falling3D t={t} layer="behind" waves={[{at: 0, count: 14, span: 1.4}]} endAt={3.0} draw={(g, w, h) => {
		g.fillStyle = COLOR.panel; g.fillRect(0, 0, w, h); g.strokeStyle = COLOR.lime; g.lineWidth = 10; g.strokeRect(14, 14, w - 28, h - 28);
		g.fillStyle = COLOR.lime; g.font = `700 90px ${FONT.display}`; g.fillText('MARCA', 60, 170);
	}} />},
	{name: '3D relógio', dur: 3.0, slot: (t) => <div style={{position: 'relative', width: 1080, height: 730}}><div style={{position: 'absolute', left: 0, top: -85}}><Clock3D t={t} slowAt={1.8} width={1080} height={900} exitAt={2.7} /></div></div>},
];
export const VITRINE_FRAMES = Math.round(ITEMS.reduce((a, i) => a + i.dur, 0) * FPS);

export const Vitrine: React.FC = () => {
	const f = useCurrentFrame();
	const sec = f / FPS;
	let acc = 0;
	let item = ITEMS[0];
	for (const it of ITEMS) {
		if (sec < acc + it.dur) {
			item = it;
			break;
		}
		acc += it.dur;
	}
	const t = sec - acc;
	const split = item.split ?? 1;
	return (
		<AbsoluteFill style={{background: COLOR.ink}}>
			<NeonFrame
				split={split}
				slot={item.slot?.(t)}
				caption={<NeonCaption t={t} words={item.name.split(' ').map((w, i) => ({text: w, start: 0.05 + i * 0.15, hl: i === item.name.split(' ').length - 1}))} />}
			>
				{presenter(f)}
				{item.three ? <AbsoluteFill>{item.three(t)}</AbsoluteFill> : null}
			</NeonFrame>
			<div style={{position: 'absolute', right: 40, bottom: 30, fontFamily: FONT.mono, fontSize: TYPE.label * 0.6, color: COLOR.mute}}>vitrine · biblioteca de motions</div>
		</AbsoluteFill>
	);
};
