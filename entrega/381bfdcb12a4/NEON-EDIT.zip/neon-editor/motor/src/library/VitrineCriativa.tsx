/**
 * Vitrine dos componentes da DIREÇÃO ADAPTATIVA (criativos/): cada um alguns segundos, com textos e números de TESTE
 * (rótulos de demonstração, não conteúdo de vídeo). Serve para conferir render, marca e layout de cada componente.
 */
import React from 'react';
import {AbsoluteFill, Img, useCurrentFrame} from 'remotion';
import {COLOR, FONT, SPACE, TYPE} from '../brand/neon';
import {holdRender} from '../engine/render';
import {frameSrc} from '../engine/Plate';
import {ensureNeonFonts, NeonCaption, NeonFrame} from '../components/neon/NeonLayout';
import {FlowDiagram, KineticWords, LineChart, MetricBoard, TechHUD} from '../components/criativos/Graficos2D';
import {Bars3D, Network3D, Symbol3D} from '../components/criativos/Cenas3D';

ensureNeonFonts(() => holdRender('fonts'));
const FPS = 30;

type Item = {name: string; dur: number; split?: number; slot?: (t: number) => React.ReactNode; full?: (t: number) => React.ReactNode};
const ITEMS: Item[] = [
	{name: 'indicadores', dur: 3, slot: (t) => <MetricBoard t={t} title="painel de teste" items={[{label: 'rótulo A', value: 1280, at: 0.3, trend: [2, 3, 2.5, 4, 5]}, {label: 'rótulo B', value: 37, suffix: '%', at: 0.9, delta: '+ teste'}]} exitAt={2.7} />},
	{name: 'gráfico de linha', dur: 3, slot: (t) => <LineChart t={t} label="série de teste" values={[3, 4, 3.6, 5.2, 6.1, 8]} xLabels={['a', 'b', 'c', 'd', 'e', 'f']} endLabel="ponto final" exitAt={2.7} height={600} />},
	{name: 'fluxo', dur: 3, slot: (t) => <FlowDiagram t={t} nodes={[{label: 'Entrada', sub: 'etapa 1', at: 0.3}, {label: 'Processo', sub: 'etapa 2', at: 1.0}, {label: 'Resultado', sub: 'etapa 3', at: 1.7}]} exitAt={2.7} />},
	{name: 'interface tech', dur: 3.2, slot: (t) => <TechHUD t={t} title="sistema de teste" lines={[{text: 'analisando entrada…', at: 0.3}, {text: 'gerando composição', at: 1.0}, {text: 'pronto', at: 1.8}]} status={[{label: 'etapa 1', at: 1.2}, {label: 'etapa 2', at: 2.0}]} exitAt={2.9} height={700} />},
	{name: 'tipografia cinética', dur: 3, split: 0, full: (t) => <div style={{position: 'absolute', left: SPACE.framePadX, top: 170}}><KineticWords t={t} words={[{text: 'palavras', start: 0.2}, {text: 'entram', start: 0.5}, {text: 'na', start: 0.75}, {text: 'fala', start: 0.95, hl: true}]} exitAt={2.7} /></div>},
	{name: 'barras 3D', dur: 3.2, split: 0, full: (t) => <Bars3D t={t} values={[2, 3, 2.6, 4.2, 6]} growAt={0.2} exitAt={2.8} y={1.0} size={1} />},
	{name: 'rede 3D', dur: 3.2, split: 0, full: (t) => <Network3D t={t} buildAt={0.1} pulseAt={1.2} exitAt={2.8} y={2.3} size={0.8} />},
	{name: 'símbolos 3D', dur: 3.6, split: 0, full: (t) => (
		<>
			<Symbol3D t={t} kind="gear" at={0.1} x={-1.35} y={2.45} size={0.42} exitAt={3.2} />
			<Symbol3D t={t} kind="arrow" at={0.3} x={0} y={2.45} size={0.42} exitAt={3.2} />
			<Symbol3D t={t} kind="target" at={0.5} x={1.35} y={2.45} size={0.42} accent={false} exitAt={3.2} />
			<Symbol3D t={t} kind="heart" at={0.7} x={-1.35} y={1.05} size={0.42} exitAt={3.2} />
			<Symbol3D t={t} kind="glyph" glyph="$" at={0.9} x={0} y={1.05} size={0.42} exitAt={3.2} />
			<Symbol3D t={t} kind="bubble" at={1.1} x={1.35} y={1.05} size={0.42} accent={false} exitAt={3.2} />
		</>
	)},
];
export const VITRINE_CRIATIVA_FRAMES = Math.round(ITEMS.reduce((a, i) => a + i.dur, 0) * FPS);

export const VitrineCriativa: React.FC = () => {
	const f = useCurrentFrame();
	const sec = f / FPS;
	let acc = 0;
	let item = ITEMS[0];
	for (const it of ITEMS) {
		if (sec < acc + it.dur) {
			item = it;
			break;
		}
		acc += it.dur;
	}
	const t = sec - acc;
	return (
		<AbsoluteFill style={{background: COLOR.ink, fontFamily: FONT.display, color: COLOR.text}}>
			<NeonFrame split={item.split ?? 1} slot={item.slot?.(t)} caption={<NeonCaption t={t} words={item.name.split(' ').map((w, i) => ({text: w, start: 0.05 + i * 0.15, hl: i === 0}))} />}>
				<Img src={frameSrc(f % 90)} style={{width: 1080, height: 1920}} />
				{item.full ? <AbsoluteFill>{item.full(t)}</AbsoluteFill> : null}
			</NeonFrame>
			<div style={{position: 'absolute', right: 40, bottom: 30, fontFamily: FONT.mono, fontSize: TYPE.label * 0.6, color: COLOR.mute}}>vitrine · direção adaptativa</div>
		</AbsoluteFill>
	);
};
