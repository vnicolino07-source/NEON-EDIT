/**
 * ESTILO "KINETIC" — tipografia cinética: a própria fala vira palavras gigantes que batem, empilham e giram.
 * Bom para: frases de impacto, motivacional, opinião, manifesto, ganchos.
 * ATENÇÃO: aqui o texto grande JÁ É a legenda — não use KCap junto (uma leitura por vez).
 * As palavras vêm do words.json (WORDS); escolha quais ficam gigantes com `big` e quais ganham acento com `hl`.
 */
import React from 'react';
import {WORDS} from '../engine/timing';
import {XFONT, ph, easeBack, easeOut, clamp, lerp, nrm, chunkWords} from './base';

export const KINETIC = {bg: '#0B0B0B', ink: '#FFFFFF', accent: '#C6FF3D', dim: '#3A3A3A'} as const;
export type KineticPal = {bg: string; ink: string; accent: string; dim: string};

/** tremor curto de câmera em cada batida (some em 0,25 s) */
export const shake = (t: number, beats: number[], amp = 14) => {
	let x = 0, y = 0;
	for (const b of beats) { const k = 1 - clamp((t - b) / 0.25); if (t >= b && k > 0) { x += Math.sin((t - b) * 90) * amp * k; y += Math.cos((t - b) * 70) * amp * k * 0.6; } }
	return `translate(${x}px, ${y}px)`;
};

/**
 * Pilha de frases: cada bloco de fala (chunkWords) vira uma "lâmina" de 2–4 palavras em caixa alta, centralizada.
 * Palavras em `big` ocupam a linha inteira; `hl` pinta com acento. A lâmina anterior sobe e apaga.
 */
export const KineticStack: React.FC<{t: number; pal?: KineticPal; big?: Set<string>; hl?: Set<string>; max?: number; y?: number; size?: number; font?: string}> = ({t, pal = KINETIC, big = new Set(), hl = new Set(), max = 3, y = 860, size = 150, font = XFONT.impacto}) => {
	const chunks = chunkWords(max);
	const ci = chunks.findIndex((c, i) => t >= c.start - 0.05 && (i === chunks.length - 1 || t < chunks[i + 1].start - 0.05));
	if (ci < 0) return null;
	const beats = chunks.map((c) => c.start);
	const render = (idx: number, role: 'atual' | 'saindo') => {
		const c = chunks[idx];
		if (!c) return null;
		const ws = WORDS.slice(c.i0, c.i1 + 1);
		const kOut = role === 'saindo' ? ph(t, chunks[idx + 1].start - 0.05, 0.22) : 0;
		if (kOut >= 1) return null;
		return (
			<div key={idx} style={{position: 'absolute', left: 50, right: 50, top: y, transform: `translateY(-50%) translateY(${-kOut * 260}px) scale(${1 - kOut * 0.25})`, opacity: 1 - kOut, filter: `blur(${kOut * 8}px)`, display: 'flex', flexWrap: 'wrap', justifyContent: 'center', alignItems: 'baseline', gap: `0 ${size * 0.16}px`}}>
				{ws.map((w, j) => {
					const k = ph(t, w.start - 0.04, 0.16, easeBack);
					const isBig = big.has(nrm(w.w));
					const fs = isBig ? size * 1.7 : size * (ws.length > 2 ? 0.78 : 1);
					return <span key={j} style={{fontFamily: font, fontWeight: 800, fontSize: fs, lineHeight: 0.95, textTransform: 'uppercase', letterSpacing: '-0.01em', color: hl.has(nrm(w.w)) ? pal.accent : pal.ink, opacity: t >= w.start - 0.04 ? 1 : 0, transform: `scale(${lerp(1.6, 1, k)})`, display: 'inline-block', flexBasis: isBig ? '100%' : undefined, textAlign: 'center'}}>{w.w.replace(/[,.;:]$/, '')}</span>;
				})}
			</div>
		);
	};
	return <div style={{position: 'absolute', inset: 0, transform: shake(t, beats, 10)}}>{render(ci - 1, 'saindo')}{render(ci, 'atual')}</div>;
};

/** uma palavra/numero gigante que bate na tela (gancho, virada) com faixa de acento atrás */
export const Slam: React.FC<{t: number; at: number; until?: number; text: string; pal?: KineticPal; size?: number; y?: number; faixa?: boolean; rot?: number}> = ({t, at, until = 1e9, text, pal = KINETIC, size = 260, y = 820, faixa = true, rot = -4}) => {
	if (t < at - 0.02 || t > until + 0.3) return null;
	const k = ph(t, at, 0.18, easeBack);
	const kf = ph(t, at + 0.08, 0.25);
	const o = ph(t, until, 0.25);
	return (
		<div style={{position: 'absolute', left: 0, right: 0, top: y, transform: `translateY(-50%) rotate(${rot}deg) ${shake(t, [at], 18)}`, opacity: 1 - o, display: 'flex', justifyContent: 'center'}}>
			{faixa ? <div style={{position: 'absolute', left: -40, right: -40, top: '18%', bottom: '14%', background: pal.accent, transform: `scaleX(${kf})`, transformOrigin: 'left'}} /> : null}
			<span style={{position: 'relative', fontFamily: XFONT.impacto, fontSize: size, lineHeight: 1, color: faixa ? pal.bg : pal.ink, textTransform: 'uppercase', transform: `scale(${lerp(2.2, 1, k)})`, opacity: clamp(k * 2)}}>{text}</span>
		</div>
	);
};

/** palavras-fantasma gigantes rolando no fundo (textura de marca); escolha 1–3 palavras do tema */
export const BgMarquee: React.FC<{t: number; words: string[]; pal?: KineticPal; speed?: number}> = ({t, words, pal = KINETIC, speed = 80}) => (
	<div data-qa="decor" style={{position: 'absolute', inset: 0, overflow: 'hidden'}}>
		{[0, 1, 2, 3, 4, 5].map((r) => { const dir = r % 2 ? 1 : -1; const txt = Array.from({length: 6}).map(() => words.join(' • ')).join(' • '); return <div key={r} style={{position: 'absolute', top: 120 + r * 300, left: -2000 + ((t * speed * dir) % 1000), whiteSpace: 'nowrap', fontFamily: XFONT.impacto, fontSize: 230, color: 'transparent', WebkitTextStroke: `2px ${pal.dim}`, textTransform: 'uppercase', opacity: 0.55}}>{txt}</div>; })}
	</div>
);

/** contador de progresso no rodapé (dá sensação de ritmo) */
export const KineticBar: React.FC<{t: number; total: number; pal?: KineticPal}> = ({t, total, pal = KINETIC}) => <div style={{position: 'absolute', left: 80, right: 80, top: 1640, height: 6, background: pal.dim, borderRadius: 3}}><div style={{width: `${clamp(t / total) * 100}%`, height: '100%', background: pal.accent, borderRadius: 3}} /></div>;
export {easeOut};
