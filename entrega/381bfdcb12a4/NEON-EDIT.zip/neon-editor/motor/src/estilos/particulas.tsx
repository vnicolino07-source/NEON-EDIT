/**
 * ESTILO "PARTÍCULAS" — imagens e formas feitas de milhares de pontos, P&B com grão, morfando de uma forma pra outra.
 * Bom para: física, universo, mente, "a realidade não é o que parece", biografias de cientistas.
 * Fontes dos pontos: texto ("E=mc²", "1905"), ícones da LINHA (contorno), formas 3D procedurais
 * (esfera, galáxia, superfície de onda, átomo, anéis) e IMAGENS (retrato/objeto: pontos pela luminância).
 */
import React, {useLayoutEffect, useRef, useState} from 'react';
import {continueRender, delayRender, staticFile} from 'remotion';
import {rnd, clamp, easeInOut} from './base';
import {ICONS} from './linha';

export type Pts = {x: Float32Array; y: Float32Array; z: Float32Array; s: Float32Array; n: number};
const mk = (n: number): Pts => ({x: new Float32Array(n), y: new Float32Array(n), z: new Float32Array(n), s: new Float32Array(n), n});
export const DOTS_N = 5200;

// ----- formas procedurais (coordenadas em px, centro = 0,0) -----
export const sphere = (R = 300, n = DOTS_N): Pts => { const p = mk(n); for (let i = 0; i < n; i++) { const u = rnd(i + 1) * 2 - 1, a = rnd(i + 7) * Math.PI * 2, r = Math.sqrt(1 - u * u); p.x[i] = Math.cos(a) * r * R; p.y[i] = u * R; p.z[i] = Math.sin(a) * r * R; p.s[i] = 0.6 + rnd(i + 3) * 0.8; } return p; };
export const galaxy = (R = 380, n = DOTS_N): Pts => { const p = mk(n); for (let i = 0; i < n; i++) { const arm = i % 3, r = Math.pow(rnd(i + 2), 0.7) * R, a = arm * 2.094 + r / R * 5.2 + (rnd(i + 9) - 0.5) * 0.7; p.x[i] = Math.cos(a) * r + (rnd(i + 4) - 0.5) * 30; p.y[i] = (rnd(i + 5) - 0.5) * 30 * (1 - r / R); p.z[i] = Math.sin(a) * r; p.s[i] = r < 60 ? 1.6 : 0.5 + rnd(i) * 0.9; } return p; };
export const waveGrid = (w = 760, d = 520, n = DOTS_N): Pts => { const p = mk(n); const cols = Math.round(Math.sqrt(n * w / d)); for (let i = 0; i < n; i++) { const cx = i % cols, cz = Math.floor(i / cols); p.x[i] = (cx / cols - 0.5) * w; p.z[i] = (cz / (n / cols) - 0.5) * d; p.y[i] = 0; p.s[i] = 0.7; } return p; };
export const atom = (R = 300, n = DOTS_N): Pts => { const p = mk(n); for (let i = 0; i < n; i++) { const ring = i % 4; if (ring === 3 || i < n * 0.12) { const s = sphere(70, 1); const u = rnd(i) * 2 - 1, a = rnd(i + 1) * 6.28, r = Math.sqrt(1 - u * u) * 70; p.x[i] = Math.cos(a) * r; p.y[i] = u * 70; p.z[i] = Math.sin(a) * r; p.s[i] = 1.2; void s; continue; } const a = rnd(i + 3) * Math.PI * 2, tilt = ring * 1.05; const x = Math.cos(a) * R, y = Math.sin(a) * R * 0.32; p.x[i] = x * Math.cos(tilt) - y * Math.sin(tilt); p.y[i] = x * Math.sin(tilt) + y * Math.cos(tilt); p.z[i] = Math.sin(a) * R * 0.2; p.s[i] = 0.6; } return p; };
export const rings = (R = 320, n = DOTS_N): Pts => { const p = mk(n); for (let i = 0; i < n; i++) { const k = i % 5, r = R * (0.2 + k * 0.2) + (rnd(i) - 0.5) * 6, a = rnd(i + 1) * 6.28; p.x[i] = Math.cos(a) * r; p.y[i] = Math.sin(a) * r; p.z[i] = 0; p.s[i] = 0.5 + 0.5 * rnd(i + 2); } return p; };
export const dust = (R = 700, n = DOTS_N): Pts => { const p = mk(n); for (let i = 0; i < n; i++) { p.x[i] = (rnd(i + 11) - 0.5) * R * 1.4; p.y[i] = (rnd(i + 12) - 0.5) * R * 2.2; p.z[i] = (rnd(i + 13) - 0.5) * R; p.s[i] = 0.3 + rnd(i) * 0.6; } return p; };

// ----- a partir de texto, ícone (traço) e imagem -----
const fromCanvas = (draw: (g: CanvasRenderingContext2D, W: number, H: number) => void, W: number, H: number, n: number, invert = false, thr = 0.25): Pts => {
	const c = document.createElement('canvas'); c.width = W; c.height = H;
	const g = c.getContext('2d', {willReadFrequently: true})!;
	g.fillStyle = '#000'; g.fillRect(0, 0, W, H); draw(g, W, H);
	const d = g.getImageData(0, 0, W, H).data;
	const cand: number[] = [];
	for (let y = 0; y < H; y += 2) for (let x = 0; x < W; x += 2) { const i = (y * W + x) * 4; let l = (d[i] * 0.3 + d[i + 1] * 0.59 + d[i + 2] * 0.11) / 255; if (invert) l = 1 - l; if (l > thr) cand.push(x, y, l); }
	const p = mk(n); const m = cand.length / 3 || 1;
	for (let i = 0; i < n; i++) { let j = Math.floor(rnd(i + 21) * m); for (let tries = 0; tries < 4; tries++) { const l = cand[j * 3 + 2]; if (rnd(i * 7 + tries) < l) break; j = Math.floor(rnd(i * 13 + tries + 3) * m); } p.x[i] = (cand[j * 3] ?? W / 2) - W / 2 + (rnd(i + 31) - 0.5) * 2; p.y[i] = (cand[j * 3 + 1] ?? H / 2) - H / 2 + (rnd(i + 32) - 0.5) * 2; p.z[i] = (rnd(i + 33) - 0.5) * 20; p.s[i] = 0.5 + (cand[j * 3 + 2] ?? 0.5) * 0.9; }
	return p;
};
export const textPts = (txt: string, size = 260, font = `800 ${260}px XInter, sans-serif`, n = DOTS_N): Pts => fromCanvas((g, W, H) => { g.fillStyle = '#fff'; g.font = font.replace(/\d+px/, `${size}px`); g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(txt, W / 2, H / 2); }, 900, 600, n);
export const iconPts = (name: string, size = 560, n = DOTS_N): Pts => fromCanvas((g, W, H) => { g.strokeStyle = '#fff'; g.lineWidth = 2.2; g.lineCap = 'round'; g.lineJoin = 'round'; g.translate((W - size) / 2, (H - size) / 2); g.scale(size / 100, size / 100); (ICONS[name]?.d ?? []).forEach((d) => g.stroke(new Path2D(d))); }, 800, 800, n, false, 0.2);

// carregamento de imagens (pontos pela luminância) — cache por arquivo
const IMG: Record<string, Pts> = {};
export const useImagePts = (file: string | undefined, opts: {w?: number; invert?: boolean; thr?: number; n?: number} = {}) => {
	const [, set] = useState(0);
	useLayoutEffect(() => {
		if (!file || IMG[file]) return;
		const h = delayRender('img-dots ' + file);
		const im = new Image(); im.crossOrigin = 'anonymous';
		im.onload = () => { const w = opts.w ?? 760; const s = w / im.width; IMG[file] = fromCanvas((g) => { g.filter = 'contrast(1.25)'; g.drawImage(im, 0, 0, im.width * s, im.height * s); }, Math.round(im.width * s), Math.round(im.height * s), opts.n ?? DOTS_N, opts.invert, opts.thr ?? 0.18); set((x) => x + 1); continueRender(h); };
		im.onerror = () => { console.error('imagem não carregou', file); continueRender(h); };
		im.src = staticFile(file);
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [file]);
	return file ? IMG[file] : undefined;
};

export type Key = {at: number; pts: Pts | undefined; spin?: number; tilt?: number; scale?: number; x?: number; y?: number};
/**
 * Campo de pontos: em cada `at` os pontos migram (com dispersão) para a próxima forma.
 * spin = giro em Y (rad/s) para formas 3D; tilt = inclinação em X. Tudo calculado pelo tempo (determinístico).
 */
export const DotField: React.FC<{t: number; keys: Key[]; morph?: number; color?: string; w?: number; h?: number; cy?: number; glow?: boolean; fade?: number}> = ({t, keys, morph = 1.0, color = '255,255,255', w = 1080, h = 1920, cy = 760, glow = true, fade = 1}) => {
	const ref = useRef<HTMLCanvasElement>(null);
	useLayoutEffect(() => {
		const c = ref.current; if (!c) return;
		const g = c.getContext('2d')!; g.clearRect(0, 0, w, h);
		const valid = keys.filter((k) => k.pts);
		if (!valid.length) return;
		let ci = 0; for (let i = 0; i < valid.length; i++) if (t >= valid[i].at) ci = i;
		const cur = valid[ci], prev = valid[Math.max(0, ci - 1)];
		const kk = ci === 0 ? 1 : clamp((t - cur.at) / morph);
		const proj = (k: Key, i: number, tt: number) => { const P = k.pts!; const j = i % P.n; const sc = k.scale ?? 1; let x = P.x[j] * sc, y = P.y[j] * sc, z = P.z[j] * sc; const a = (k.spin ?? 0) * tt, ca = Math.cos(a), sa = Math.sin(a); const x2 = x * ca + z * sa, z2 = -x * sa + z * ca; const b = k.tilt ?? 0, cb = Math.cos(b), sb = Math.sin(b); const y2 = y * cb - z2 * sb, z3 = y * sb + z2 * cb; const f = 1100 / (1100 + z3); return [w / 2 + (k.x ?? 0) + x2 * f, cy + (k.y ?? 0) + y2 * f, f, P.s[j]]; };
		const wave = (k: Key) => k.pts && k.pts === WAVE_REF.current;
		void wave;
		g.globalCompositeOperation = 'lighter';
		const N = DOTS_N;
		for (let i = 0; i < N; i++) {
			const st = rnd(i + 51) * 0.35;
			const e = easeInOut(clamp((kk - st) / (1 - 0.35)));
			const A = proj(prev, i, t), B = proj(cur, i, t);
			const sc = Math.sin(e * Math.PI) * 120 * (rnd(i + 61) - 0.5);
			const x = A[0] + (B[0] - A[0]) * e + sc, y = A[1] + (B[1] - A[1]) * e + Math.sin(e * Math.PI) * 90 * (rnd(i + 71) - 0.5);
			const f = A[2] + (B[2] - A[2]) * e, s = A[3] + (B[3] - A[3]) * e;
			const tw = 0.55 + 0.45 * Math.sin(t * 3 + i);
			const r = Math.max(0.8, 1.7 * f * s);
			g.fillStyle = `rgba(${color},${clamp(0.25 + 0.6 * s * tw) * fade * Math.min(1, f)})`;
			g.fillRect(x - r / 2, y - r / 2, r, r);
		}
		g.globalCompositeOperation = 'source-over';
	});
	return <canvas ref={ref} width={w} height={h} style={{position: 'absolute', left: 0, top: 0, width: w, height: h, filter: glow ? 'drop-shadow(0 0 6px rgba(255,255,255,.35))' : undefined}} />;
};
const WAVE_REF = {current: null as Pts | null};
/** superfície de onda animada (frequência): desloca y dos pontos de uma waveGrid com o tempo */
export const animateWave = (base: Pts, t: number, amp = 60, freq = 0.012, speed = 2): Pts => { const p = mk(base.n); for (let i = 0; i < base.n; i++) { p.x[i] = base.x[i]; p.z[i] = base.z[i]; p.y[i] = Math.sin(base.x[i] * freq + t * speed) * amp * Math.cos(base.z[i] * freq * 0.7 + t * speed * 0.6); p.s[i] = base.s[i]; } return p; };
