/**
 * ESTILO "ILUSTRADO" — cenas pintadas (personagens + cenário) geradas por IA de imagem em estilo consistente,
 * animadas em 2,5D: camadas com paralaxe, câmera que passeia, personagem "respirando", piscadas e gestos simples.
 * Bom para: histórias (bíblicas, históricas, fábulas), narrativas com personagens, "era uma vez".
 * Status: PROPOSTO — depende de gerar os PNGs (fundo, personagens recortados). Ver references/21 (seção Ilustrado).
 */
import React from 'react';
import {Img, staticFile} from 'remotion';
import {ph, lerp, clamp} from './base';

export type Layer = {src: string; depth: number; y?: number; x?: number; w?: number; h?: number; scale?: number};
/** cena em camadas: depth 0 = fundo (move pouco), 1 = primeiro plano (move mais). pan = deslocamento da câmera em px */
export const ParallaxScene: React.FC<{t: number; at: number; until: number; layers: Layer[]; panX?: [number, number]; zoom?: [number, number]}> = ({t, at, until, layers, panX = [0, -120], zoom = [1.0, 1.08]}) => {
	if (t < at - 0.02 || t > until + 0.5) return null;
	const k = clamp((t - at) / Math.max(0.1, until - at));
	const fade = ph(t, at - 0.05, 0.35) * (1 - ph(t, until, 0.4));
	const px = lerp(panX[0], panX[1], k), z = lerp(zoom[0], zoom[1], k);
	return (
		<div style={{position: 'absolute', inset: 0, overflow: 'hidden', opacity: fade}}>
			{layers.map((l, i) => (
				<Img key={i} src={staticFile(l.src)} style={{position: 'absolute', left: (l.x ?? 0) + px * l.depth, top: l.y ?? 0, width: l.w ?? 1300, height: l.h, transform: `scale(${(l.scale ?? 1) * (1 + (z - 1) * (0.5 + l.depth))})`, transformOrigin: '50% 60%'}} />
			))}
		</div>
	);
};
/** personagem recortado (PNG transparente) com respiração, balanço e entrada */
export const Boneco: React.FC<{t: number; at: number; until?: number; src: string; x: number; y: number; w: number; flip?: boolean; talk?: boolean}> = ({t, at, until = 1e9, src, x, y, w, flip, talk}) => {
	if (t < at - 0.02 || t > until + 0.4) return null;
	const k = ph(t, at, 0.4), o = ph(t, until, 0.3);
	const br = 1 + Math.sin(t * 2.2) * 0.008, sway = Math.sin(t * 1.1) * 0.6 + (talk ? Math.sin(t * 9) * 0.5 : 0);
	return <Img src={staticFile(src)} style={{position: 'absolute', left: x - w / 2, top: y, width: w, opacity: k * (1 - o), transform: `translateY(${(1 - k) * 40}px) scaleX(${flip ? -1 : 1}) scaleY(${br}) rotate(${sway}deg)`, transformOrigin: '50% 100%', filter: `blur(${(1 - k) * 6}px)`}} />;
};
/** cartão final em arco (título da história + CTA) */
export const ArchCard: React.FC<{t: number; at: number; src?: string; title: string; sub: string; accent: string; children?: React.ReactNode}> = ({t, at, src, title, sub, accent, children}) => {
	if (t < at) return null;
	const k = ph(t, at, 0.5);
	return (
		<div style={{position: 'absolute', inset: 0, background: '#1C1B22', opacity: k, display: 'flex', flexDirection: 'column', alignItems: 'center', paddingTop: 300}}>
			<div style={{width: 560, height: 760, borderRadius: '280px 280px 24px 24px', overflow: 'hidden', border: `6px solid #EDE3D1`, transform: `scale(${lerp(0.9, 1, k)})`}}>{src ? <Img src={staticFile(src)} style={{width: '100%', height: '100%', objectFit: 'cover'}} /> : children}</div>
			<div style={{marginTop: 50, fontFamily: `'XGaramond', serif`, fontWeight: 600, fontSize: 64, color: '#EDE3D1', letterSpacing: '0.06em'}}>{title}</div>
			<div style={{marginTop: 10, fontFamily: `'XGaramond', serif`, fontSize: 32, color: accent, letterSpacing: '0.2em'}}>{sub}</div>
		</div>
	);
};
