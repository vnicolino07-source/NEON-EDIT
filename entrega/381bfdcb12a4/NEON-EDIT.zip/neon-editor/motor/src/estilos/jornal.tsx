/**
 * ESTILO "JORNAL" — papel envelhecido, primeira página que gira e para na tela, manchete serifada pesada,
 * máquina de escrever, carimbo vermelho, recortes.
 * Bom para: casos reais, história, crimes famosos (sem sensacionalismo), "o que aconteceu em 19XX", mistérios.
 * REGRAS: nome do jornal é sempre INVENTADO (padrão "O DIÁRIO"); nunca imite capa real de veículo.
 * Manchete na tela = o fato-chave em poucas palavras, NÃO a frase narrada (uma leitura por vez).
 * Legenda recomendada: KCap kind="papel" font={XFONT.maquina} weight={700} accent={JORNAL.marca} ink={JORNAL.ink}.
 */
import React from 'react';
import {XFONT, ph, easeOut, easeBack, clamp, lerp, alpha, rnd} from './base';

export const JORNAL = {papel: '#E9DFC8', papel2: '#D8CBAE', ink: '#1E1A14', dim: '#7A6E5C', vermelho: '#A3261B', marca: '#F2C94C'} as const;
export type JornalPal = {papel: string; papel2: string; ink: string; dim: string; vermelho: string; marca: string};

const grain = `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='260' height='260'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='3' seed='5'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>")`;

/** mesa escura + papel com manchas e vinheta */
export const JornalBg: React.FC<{t: number; pal?: JornalPal; mesa?: boolean}> = ({t, pal = JORNAL, mesa = false}) => (
	<>
		<div style={{position: 'absolute', inset: 0, background: mesa ? 'radial-gradient(ellipse at 50% 40%, #3B2E22, #17110C 80%)' : `radial-gradient(ellipse 90% 75% at 50% 45%, ${pal.papel}, ${pal.papel2} 85%)`}} />
		{!mesa ? <>
			{[0, 1, 2, 3].map((i) => <div key={i} style={{position: 'absolute', left: rnd(i + 1) * 900 - 100, top: rnd(i + 7) * 1700, width: 200 + rnd(i) * 260, height: 200 + rnd(i) * 260, borderRadius: '50%', border: `10px solid ${alpha('#8B6B3E', 0.08)}`, background: alpha('#8B6B3E', 0.05), filter: 'blur(3px)'}} />)}
			<div style={{position: 'absolute', inset: 0, boxShadow: 'inset 0 0 220px rgba(80,55,25,.45)'}} />
		</> : null}
		<div style={{position: 'absolute', inset: -20, backgroundImage: grain, opacity: 0.16, mixBlendMode: 'multiply', transform: `translate(${(Math.floor(t * 12) % 3) * 3}px, 0)`}} />
	</>
);

/** linhas de texto de coluna (barras cinza — nunca texto falso legível) */
const Colunas: React.FC<{cols: number; lines: number; pal: JornalPal; w: number}> = ({cols, lines, pal, w}) => (
	<div style={{display: 'flex', gap: 22}}>
		{Array.from({length: cols}).map((_, c) => <div key={c} style={{flex: 1, borderLeft: c ? `1.5px solid ${alpha(pal.ink, 0.35)}` : undefined, paddingLeft: c ? 16 : 0}}>{Array.from({length: lines}).map((_, l) => <div key={l} style={{height: 9, marginBottom: 9, width: `${l % 7 === 6 ? 55 : 92 + rnd(c * 40 + l) * 8}%`, background: alpha(pal.ink, 0.42)}} />)}</div>)}
	</div>
);

/** primeira página: gira e para (clássico de cinema). title = fato-chave curto; kicker = chapéu; data = "12 DE MARÇO DE 1987" */
export const PrimeiraPagina: React.FC<{t: number; at: number; until?: number; nome?: string; data: string; kicker?: string; title: string; pal?: JornalPal; foto?: React.ReactNode; spin?: boolean}> = ({t, at, until = 1e9, nome = 'O DIÁRIO', data, kicker, title, pal = JORNAL, foto, spin = true}) => {
	if (t < at - 0.02 || t > until + 0.35) return null;
	const k = ph(t, at, spin ? 0.9 : 0.4, easeOut);
	const o = ph(t, until, 0.3);
	const rot = spin ? (1 - k) * 720 - 3 : -3;
	return (
		<div style={{position: 'absolute', left: 90, top: 250, width: 900, height: 1080, background: pal.papel, padding: '36px 40px', boxShadow: '0 30px 70px rgba(0,0,0,.45)', transform: `rotate(${rot}deg) scale(${lerp(0.05, 1, k) * (1 + o * 0.1)})`, opacity: (1 - o) * clamp(k * 3), filter: o ? `blur(${o * 10}px)` : undefined}}>
			<div style={{textAlign: 'center', fontFamily: XFONT.jornal, fontWeight: 900, fontSize: 96, letterSpacing: '0.02em', color: pal.ink, lineHeight: 1}}>{nome}</div>
			<div style={{display: 'flex', justifyContent: 'space-between', borderTop: `3px solid ${pal.ink}`, borderBottom: `1.5px solid ${pal.ink}`, margin: '14px 0 22px', padding: '6px 0', fontFamily: XFONT.maquina, fontSize: 20, color: pal.ink}}><span>{data}</span><span>EDIÇÃO EXTRA</span></div>
			{kicker ? <div style={{fontFamily: XFONT.maquina, fontWeight: 700, fontSize: 26, letterSpacing: '0.12em', color: pal.vermelho, textAlign: 'center'}}>{kicker}</div> : null}
			<div style={{fontFamily: XFONT.jornal, fontWeight: 900, fontSize: title.length > 26 ? 84 : 108, lineHeight: 0.98, textAlign: 'center', color: pal.ink, margin: '10px 0 24px', textTransform: 'uppercase'}}>{title}</div>
			<div style={{display: 'flex', gap: 24}}>
				<div style={{width: 420, height: 330, background: alpha(pal.ink, 0.12), border: `1.5px solid ${alpha(pal.ink, 0.5)}`, filter: 'grayscale(1) contrast(1.1) sepia(.3)', overflow: 'hidden', position: 'relative'}}>{foto}</div>
				<div style={{flex: 1}}><Colunas cols={2} lines={17} pal={pal} w={360} /></div>
			</div>
			<div style={{marginTop: 22}}><Colunas cols={3} lines={14} pal={pal} w={820} /></div>
		</div>
	);
};

/** texto datilografado, letra por letra, com cursor e leve desalinhamento por letra */
export const Datilo: React.FC<{t: number; at: number; text: string; x?: number; y?: number; w?: number; size?: number; cps?: number; pal?: JornalPal; color?: string; out?: number}> = ({t, at, text, x = 110, y = 600, w = 860, size = 54, cps = 18, pal = JORNAL, color, out = 1e9}) => {
	if (t < at - 0.02 || t > out + 0.3) return null;
	const n = Math.floor((t - at) * cps);
	return (
		<div style={{position: 'absolute', left: x, top: y, width: w, fontFamily: XFONT.maquina, fontWeight: 700, fontSize: size, lineHeight: 1.3, color: color ?? pal.ink, opacity: 1 - ph(t, out, 0.3)}}>
			{text.split('').map((c, i) => <span key={i} style={{opacity: i < n ? 0.82 + rnd(i) * 0.18 : 0, position: 'relative', top: (rnd(i + 3) - 0.5) * 3}}>{c}</span>)}
			{n < text.length ? <span style={{display: 'inline-block', width: size * 0.5, height: size * 0.08, background: color ?? pal.ink, opacity: Math.sin(t * 14) > 0 ? 1 : 0}} /> : null}
		</div>
	);
};

/** carimbo que bate (escala 2 → 1, tremor) */
export const Carimbo: React.FC<{t: number; at: number; text: string; x?: number; y?: number; rot?: number; pal?: JornalPal; size?: number}> = ({t, at, text, x = 540, y = 900, rot = -12, pal = JORNAL, size = 92}) => {
	if (t < at - 0.02) return null;
	const k = ph(t, at, 0.16, easeOut);
	const sh = (1 - clamp((t - at - 0.16) / 0.2)) * (t > at + 0.16 ? 6 : 0);
	return <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${lerp(2.2, 1, k)}) translate(${Math.sin(t * 80) * sh}px,0)`, opacity: clamp(k * 1.4) * 0.88, padding: '10px 28px', border: `8px double ${pal.vermelho}`, borderRadius: 10, fontFamily: XFONT.maquina, fontWeight: 700, fontSize: size, letterSpacing: '0.08em', color: pal.vermelho, mixBlendMode: 'multiply', whiteSpace: 'nowrap'}}>{text}</div>;
};

/** recorte de jornal com borda serrilhada (citação curta, data, número) */
export const Recorte: React.FC<{t: number; at: number; until?: number; text: string; sub?: string; x?: number; y?: number; w?: number; rot?: number; pal?: JornalPal}> = ({t, at, until = 1e9, text, sub, x = 140, y = 520, w = 800, rot = 2, pal = JORNAL}) => {
	if (t < at - 0.02 || t > until + 0.3) return null;
	const k = ph(t, at, 0.4, easeBack);
	const zig = Array.from({length: 41}).map((_, i) => `${(i / 40) * 100}% ${i % 2 ? 0 : 1.6}%`).join(',');
	const zigB = Array.from({length: 41}).map((_, i) => `${100 - (i / 40) * 100}% ${i % 2 ? 100 : 98.4}%`).join(',');
	return (
		<div style={{position: 'absolute', left: x, top: y, width: w, transform: `rotate(${rot}deg) translateY(${(1 - k) * 60}px)`, opacity: clamp(k * 2) * (1 - ph(t, until, 0.3)), background: '#F3EBD8', padding: '44px 44px 40px', clipPath: `polygon(${zig},${zigB})`, boxShadow: '0 14px 30px rgba(0,0,0,.25)'}}>
			<div style={{fontFamily: XFONT.jornal, fontWeight: 900, fontSize: 64, lineHeight: 1.02, color: pal.ink}}>{text}</div>
			{sub ? <div style={{marginTop: 16, fontFamily: XFONT.maquina, fontSize: 26, color: pal.dim}}>{sub}</div> : null}
		</div>
	);
};
