/**
 * ESTILO "INTERFACE" — a história contada por telas: celular genérico, conversa, notificações, busca, janela com cursor.
 * Bom para: golpes, tecnologia, relacionamentos, "história real contada por prints", produtividade.
 * REGRAS: tudo genérico — sem logos, cores ou layout reconhecível de apps reais (nada de verde-WhatsApp, nada de "Google").
 * Conversas são ENCENAÇÕES: deixe claro na narração ou com o selo `Encenacao`.
 * Legenda recomendada: KCap kind="pilula" accent={UI.accent}.
 */
import React from 'react';
import {XFONT, ph, easeBack, easeOut, clamp, lerp, alpha} from './base';

export const UI = {bg: '#DDE3EA', bg2: '#F3F5F8', tela: '#FFFFFF', ink: '#15181D', dim: '#8A93A0', eu: '#5B5CF6', ele: '#E9ECF1', accent: '#5B5CF6', alerta: '#F04438'} as const;
export type UiPal = {bg: string; bg2: string; tela: string; ink: string; dim: string; eu: string; ele: string; accent: string; alerta: string};

export const UiBg: React.FC<{t: number; pal?: UiPal}> = ({t, pal = UI}) => (
	<>
		<div style={{position: 'absolute', inset: 0, background: `linear-gradient(160deg, ${pal.bg2}, ${pal.bg})`}} />
		<div style={{position: 'absolute', left: 540 - 520 + Math.sin(t * 0.4) * 30, top: 300, width: 1040, height: 1040, borderRadius: '50%', background: alpha(pal.accent, 0.08), filter: 'blur(80px)'}} />
	</>
);

/** celular genérico (moldura arredondada, sem marca). Conteúdo em 600×1200 interno. */
export const Phone: React.FC<{t: number; at?: number; x?: number; y?: number; scale?: number; pal?: UiPal; tilt?: number; children?: React.ReactNode}> = ({t, at = 0, x = 540, y = 760, scale = 1, pal = UI, tilt = 0, children}) => {
	const k = ph(t, at, 0.45, easeBack);
	return (
		<div style={{position: 'absolute', left: x - 330, top: y - 640, width: 660, height: 1280, transform: `translateY(${(1 - k) * 300}px) scale(${scale}) rotate(${tilt + Math.sin(t * 0.8) * 0.6}deg)`, opacity: clamp(k * 2), borderRadius: 86, background: '#111317', padding: 30, boxShadow: '0 50px 90px rgba(20,25,35,.35), inset 0 0 0 3px #2A2E36'}}>
			<div style={{position: 'relative', width: 600, height: 1220, borderRadius: 60, overflow: 'hidden', background: pal.tela}}>
				<div style={{position: 'absolute', left: 230, top: 18, width: 140, height: 38, borderRadius: 20, background: '#111317', zIndex: 5}} />
				{children}
			</div>
		</div>
	);
};

/** tela de conversa: bolhas aparecem no tempo, com "digitando…" antes das mensagens do outro lado */
export const ChatScreen: React.FC<{t: number; title: string; msgs: {at: number; who: 'eu' | 'ele'; text: string}[]; pal?: UiPal}> = ({t, title, msgs, pal = UI}) => {
	const shown = msgs.filter((m) => t >= m.at);
	const typing = msgs.find((m) => m.who === 'ele' && t >= m.at - 0.9 && t < m.at);
	const scroll = Math.max(0, shown.length - 6) * 120;
	return (
		<div style={{position: 'absolute', inset: 0, background: pal.tela}}>
			<div style={{position: 'absolute', left: 0, right: 0, top: 0, height: 150, background: pal.bg2, borderBottom: `2px solid ${pal.ele}`, display: 'flex', alignItems: 'flex-end', padding: '0 34px 22px', gap: 18}}>
				<div style={{width: 62, height: 62, borderRadius: 31, background: alpha(pal.accent, 0.25)}} />
				<div style={{fontFamily: XFONT.sans, fontWeight: 700, fontSize: 32, color: pal.ink}}>{title}</div>
			</div>
			<div style={{position: 'absolute', left: 24, right: 24, top: 180, bottom: 120, display: 'flex', flexDirection: 'column', gap: 18, transform: `translateY(${-scroll}px)`}}>
				{shown.map((m, i) => { const k = ph(t, m.at, 0.3, easeBack); return <div key={i} style={{alignSelf: m.who === 'eu' ? 'flex-end' : 'flex-start', maxWidth: 440, padding: '18px 24px', borderRadius: 30, borderBottomRightRadius: m.who === 'eu' ? 8 : 30, borderBottomLeftRadius: m.who === 'eu' ? 30 : 8, background: m.who === 'eu' ? pal.eu : pal.ele, color: m.who === 'eu' ? '#fff' : pal.ink, fontFamily: XFONT.sans, fontWeight: 500, fontSize: 30, lineHeight: 1.28, transform: `scale(${lerp(0.6, 1, k)})`, transformOrigin: m.who === 'eu' ? 'right bottom' : 'left bottom', opacity: clamp(k * 2)}}>{m.text}</div>; })}
				{typing ? <div style={{alignSelf: 'flex-start', padding: '22px 26px', borderRadius: 30, background: pal.ele, display: 'flex', gap: 10}}>{[0, 1, 2].map((d) => <div key={d} style={{width: 14, height: 14, borderRadius: 7, background: pal.dim, transform: `translateY(${Math.sin(t * 10 - d) * 5}px)`}} />)}</div> : null}
			</div>
			<div style={{position: 'absolute', left: 24, right: 24, bottom: 30, height: 74, borderRadius: 37, background: pal.bg2, border: `2px solid ${pal.ele}`}} />
		</div>
	);
};

/** notificação que desce dentro do celular (ou da tela, com x/y) */
export const Notif: React.FC<{t: number; at: number; until?: number; app: string; text: string; y?: number; pal?: UiPal; alerta?: boolean}> = ({t, at, until = 1e9, app, text, y = 80, pal = UI, alerta}) => {
	if (t < at - 0.02 || t > until + 0.35) return null;
	const k = ph(t, at, 0.4, easeBack) * (1 - ph(t, until, 0.3));
	return (
		<div style={{position: 'absolute', left: 20, right: 20, top: y, transform: `translateY(${(1 - k) * -200}px)`, opacity: clamp(k * 2), background: 'rgba(250,251,253,.94)', borderRadius: 34, padding: '22px 26px', boxShadow: '0 16px 40px rgba(0,0,0,.18)', display: 'flex', gap: 20, zIndex: 9}}>
			<div style={{width: 64, height: 64, borderRadius: 16, background: alerta ? pal.alerta : pal.accent, flexShrink: 0}} />
			<div><div style={{fontFamily: XFONT.sans, fontWeight: 700, fontSize: 26, color: pal.ink}}>{app}</div><div style={{fontFamily: XFONT.sans, fontWeight: 500, fontSize: 26, color: '#3A414C', lineHeight: 1.25}}>{text}</div></div>
		</div>
	);
};

/** barra de busca genérica: digita a consulta e mostra resultados-esqueleto */
export const SearchScreen: React.FC<{t: number; at: number; query: string; cps?: number; pal?: UiPal; results?: number}> = ({t, at, query, cps = 14, pal = UI, results = 4}) => {
	const n = Math.floor(clamp((t - at) / (query.length / cps)) * query.length);
	const done = at + query.length / cps + 0.25;
	return (
		<div style={{position: 'absolute', inset: 0, background: pal.tela, padding: '150px 34px'}}>
			<div style={{height: 92, borderRadius: 46, border: `2px solid ${pal.ele}`, boxShadow: '0 6px 20px rgba(0,0,0,.06)', display: 'flex', alignItems: 'center', padding: '0 30px', gap: 18, fontFamily: XFONT.sans, fontSize: 32, color: pal.ink}}>
				<svg width={34} height={34} viewBox="0 0 100 100"><circle cx={42} cy={42} r={28} fill="none" stroke={pal.dim} strokeWidth={10} /><path d="M62 62 L88 88" stroke={pal.dim} strokeWidth={10} strokeLinecap="round" /></svg>
				<span>{query.slice(0, n)}<span style={{opacity: Math.sin(t * 12) > 0 ? 1 : 0, color: pal.accent}}>|</span></span>
			</div>
			{Array.from({length: results}).map((_, i) => { const k = ph(t, done + i * 0.12, 0.3); return <div key={i} style={{marginTop: 46, opacity: k, transform: `translateY(${(1 - k) * 20}px)`}}><div style={{width: 260, height: 18, borderRadius: 9, background: pal.ele}} /><div style={{marginTop: 14, width: 420 - i * 30, height: 28, borderRadius: 10, background: alpha(pal.accent, 0.55)}} /><div style={{marginTop: 14, width: 500, height: 16, borderRadius: 8, background: pal.ele}} /><div style={{marginTop: 10, width: 380, height: 16, borderRadius: 8, background: pal.ele}} /></div>; })}
		</div>
	);
};

/** janela de desktop genérica com título */
export const Janela: React.FC<{t: number; at: number; title: string; x?: number; y?: number; w?: number; h?: number; pal?: UiPal; children?: React.ReactNode}> = ({t, at, title, x = 90, y = 360, w = 900, h = 700, pal = UI, children}) => {
	if (t < at - 0.02) return null;
	const k = ph(t, at, 0.4, easeBack);
	return (
		<div style={{position: 'absolute', left: x, top: y, width: w, height: h, transform: `scale(${lerp(0.8, 1, k)})`, opacity: clamp(k * 2), borderRadius: 22, background: pal.tela, boxShadow: '0 30px 70px rgba(20,25,35,.25)', overflow: 'hidden'}}>
			<div style={{height: 64, background: pal.bg2, display: 'flex', alignItems: 'center', gap: 12, padding: '0 22px', borderBottom: `2px solid ${pal.ele}`}}>{[0, 1, 2].map((i) => <div key={i} style={{width: 18, height: 18, borderRadius: 9, background: pal.ele}} />)}<span style={{marginLeft: 16, fontFamily: XFONT.sans, fontWeight: 600, fontSize: 24, color: pal.dim}}>{title}</span></div>
			<div style={{position: 'relative', height: h - 64}}>{children}</div>
		</div>
	);
};

/** cursor que viaja entre pontos e "clica" (anel) em cada chegada: path = [[t, x, y], ...] */
export const Cursor: React.FC<{t: number; path: [number, number, number][]; pal?: UiPal}> = ({t, path, pal = UI}) => {
	if (t < path[0][0]) return null;
	let i = path.findIndex((p, j) => j === path.length - 1 || t < path[j + 1][0]);
	const a = path[i], b = path[Math.min(i + 1, path.length - 1)];
	const k = b === a ? 1 : easeOut(clamp((t - a[0]) / Math.max(0.01, (b[0] - a[0]) * 0.6)));
	const x = lerp(a[1], b[1], k), y = lerp(a[2], b[2], k);
	const click = clamp((t - a[0] - (b[0] - a[0]) * 0.6) / 0.3);
	return (
		<>
			{click > 0 && click < 1 ? <div style={{position: 'absolute', left: b[1] - 40 * click, top: b[2] - 40 * click, width: 80 * click, height: 80 * click, borderRadius: '50%', border: `4px solid ${pal.accent}`, opacity: 1 - click}} /> : null}
			<svg width={54} height={66} viewBox="0 0 54 66" style={{position: 'absolute', left: x - 6, top: y - 4, filter: 'drop-shadow(0 6px 8px rgba(0,0,0,.3))'}}><path d="M4 4 L4 54 L18 42 L28 62 L36 58 L26 38 L46 38 Z" fill="#fff" stroke="#111" strokeWidth={4} strokeLinejoin="round" /></svg>
		</>
	);
};

/** selo "encenação" para conversas e telas recriadas */
export const Encenacao: React.FC<{t: number; at: number; pal?: UiPal; text?: string}> = ({t, at, pal = UI, text = 'ENCENAÇÃO'}) => <div style={{position: 'absolute', right: 70, top: 210, padding: '8px 16px', borderRadius: 8, border: `2px solid ${pal.dim}`, fontFamily: XFONT.mono, fontSize: 20, letterSpacing: '0.12em', color: pal.dim, opacity: ph(t, at, 0.3)}}>{text}</div>;
