/**
 * ESTILO "LINHA" — traço fino que se desenha sobre fundo grafite, pontos de acento e rótulos mono pequenos.
 * Bom para: mente, psicologia, filosofia, ciência explicada, conceitos abstratos.
 * Tudo procedural (SVG). Cada ícone é desenhado com pathLength=1 (o traço "nasce" em `d` segundos).
 */
import React from 'react';
import {XFONT, ph, easeInOut, clamp, lerp, alpha} from './base';

export const LINHA = {bg: '#141313', bg2: '#1C1A19', line: '#D9D4CC', dim: '#6E6862', accent: '#E8743B', label: '#E8743B'} as const;
export type LinhaPal = {bg: string; bg2: string; line: string; dim: string; accent: string; label: string};

/** biblioteca de ícones em traço (viewBox 0 0 100 100). Pontos de acento em DOTS. */
export const ICONS: Record<string, {d: string[]; dots?: [number, number][]}> = {
	livro: {d: ['M50 28 C38 22 22 22 12 26 V78 C22 74 38 74 50 80 Z', 'M50 28 C62 22 78 22 88 26 V78 C78 74 62 74 50 80', 'M20 38 H42 M20 46 H42 M20 54 H40 M58 38 H80 M58 46 H80 M58 54 H78'], dots: [[50, 52]]},
	olho: {d: ['M8 50 C24 26 76 26 92 50 C76 74 24 74 8 50 Z', 'M50 36 A14 14 0 1 1 49.9 36'], dots: [[50, 50]]},
	cabeca: {d: ['M62 88 V74 C76 72 80 62 78 54 L84 46 C80 44 78 40 78 34 C76 16 60 8 46 10 C28 12 18 26 20 44 C21 56 28 62 30 66 V88'], dots: [[52, 34]]},
	orbita: {d: ['M50 50 m-12 0 a12 12 0 1 0 24 0 a12 12 0 1 0 -24 0', 'M50 50 m-30 0 a30 30 0 1 0 60 0 a30 30 0 1 0 -60 0', 'M50 50 m-44 0 a44 44 0 1 0 88 0 a44 44 0 1 0 -88 0'], dots: [[80, 50], [26, 80], [50, 6]]},
	predio: {d: ['M30 92 V14 H70 V92', 'M14 92 H86', 'M38 24 H46 M54 24 H62 M38 36 H46 M54 36 H62 M38 48 H46 M54 48 H62 M38 60 H46 M54 60 H62', 'M44 92 V76 H56 V92'], dots: [[58, 48]]},
	lupa: {d: ['M42 42 m-26 0 a26 26 0 1 0 52 0 a26 26 0 1 0 -52 0', 'M61 61 L88 88'], dots: [[42, 42]]},
	vela: {d: ['M40 92 V44 H60 V92', 'M50 44 V36', 'M50 34 C44 26 46 18 50 10 C54 18 56 26 50 34 Z'], dots: [[50, 26]]},
	carro: {d: ['M8 66 V56 C8 50 12 48 18 46 L30 34 C34 30 38 28 44 28 H62 C68 28 72 30 76 36 L84 46 C90 48 92 52 92 58 V66 H8', 'M30 34 H76', 'M50 28 V46', 'M28 66 m-8 0 a8 8 0 1 0 16 0 a8 8 0 1 0 -16 0', 'M72 66 m-8 0 a8 8 0 1 0 16 0 a8 8 0 1 0 -16 0'], dots: []},
	lampada: {d: ['M36 62 C26 54 22 44 24 34 C28 18 42 12 50 12 C58 12 72 18 76 34 C78 44 74 54 64 62 V72 H36 Z', 'M38 80 H62 M40 88 H60', 'M44 62 L50 44 L56 62'], dots: [[50, 44]]},
	aviao: {d: ['M8 50 L92 16 L64 86 L48 58 Z', 'M48 58 L92 16'], dots: []},
	venn: {d: ['M38 50 m-26 0 a26 26 0 1 0 52 0 a26 26 0 1 0 -52 0', 'M62 50 m-26 0 a26 26 0 1 0 52 0 a26 26 0 1 0 -52 0'], dots: [[50, 50]]},
	onda: {d: ['M4 50 C12 30 20 30 28 50 C36 70 44 70 52 50 C60 30 68 30 76 50 C84 70 92 70 96 56'], dots: []},
	escada: {d: ['M6 88 H26 V68 H46 V48 H66 V28 H86 V10'], dots: [[46, 48]]},
	pessoa: {d: ['M50 30 m-12 0 a12 12 0 1 0 24 0 a12 12 0 1 0 -24 0', 'M24 90 C24 66 36 52 50 52 C64 52 76 66 76 90'], dots: []},
	cerebro: {d: ['M50 20 C40 10 22 14 20 28 C8 30 6 46 14 52 C8 62 16 76 28 74 C32 86 46 88 50 78 C54 88 68 86 72 74 C84 76 92 62 86 52 C94 46 92 30 80 28 C78 14 60 10 50 20 Z', 'M50 20 V78', 'M30 40 C36 42 38 48 36 54 M70 40 C64 42 62 48 64 54'], dots: [[60, 44]]},
	relogio: {d: ['M50 54 m-36 0 a36 36 0 1 0 72 0 a36 36 0 1 0 -72 0', 'M50 54 V30', 'M50 54 L66 62', 'M42 10 H58'], dots: [[50, 54]]},
	grafico: {d: ['M10 90 V10', 'M10 90 H92', 'M18 76 L38 60 L52 66 L72 38 L88 28'], dots: [[88, 28]]},
	moeda: {d: ['M50 50 m-38 0 a38 38 0 1 0 76 0 a38 38 0 1 0 -76 0', 'M50 50 m-28 0 a28 28 0 1 0 56 0 a28 28 0 1 0 -56 0', 'M58 38 C54 34 42 34 42 42 C42 50 58 48 58 58 C58 66 46 66 42 62 M50 30 V70'], dots: []},
	globo: {d: ['M50 50 m-40 0 a40 40 0 1 0 80 0 a40 40 0 1 0 -80 0', 'M50 10 C34 26 34 74 50 90 C66 74 66 26 50 10', 'M12 38 H88 M12 62 H88'], dots: [[64, 30]]},
	sol: {d: ['M50 50 m-18 0 a18 18 0 1 0 36 0 a18 18 0 1 0 -36 0', 'M50 8 V20 M50 80 V92 M8 50 H20 M80 50 H92 M20 20 L28 28 M72 72 L80 80 M80 20 L72 28 M28 72 L20 80'], dots: [[50, 50]]},
	documento: {d: ['M24 8 H62 L78 24 V92 H24 Z', 'M62 8 V24 H78', 'M34 40 H68 M34 52 H68 M34 64 H60 M34 76 H52'], dots: []},
	coracao: {d: ['M50 84 C20 62 10 46 14 32 C18 16 40 14 50 30 C60 14 82 16 86 32 C90 46 80 62 50 84 Z'], dots: [[50, 46]]},
	balao: {d: ['M14 20 H86 V66 H44 L26 82 V66 H14 Z', 'M28 36 H72 M28 50 H60'], dots: []},
	planeta: {d: ['M50 50 m-26 0 a26 26 0 1 0 52 0 a26 26 0 1 0 -52 0', 'M8 58 C24 74 80 60 92 42 C98 32 76 30 66 32'], dots: [[50, 50]]},
};

/** ícone em traço que se desenha (pathLength) e acende os pontos de acento ao terminar */
export const LineIcon: React.FC<{t: number; name: string; at: number; d?: number; size: number; x: number; y: number; pal?: LinhaPal; stroke?: number; accentPaths?: number[]; label?: string; labelPos?: 'top' | 'bottom'; out?: number}> = ({t, name, at, d = 0.9, size, x, y, pal = LINHA, stroke = 1.3, accentPaths = [], label, labelPos = 'top', out = 1e9}) => {
	const ic = ICONS[name];
	if (!ic || t < at - 0.02) return null;
	const o = ph(t, out, 0.35);
	return (
		<div style={{position: 'absolute', left: x - size / 2, top: y - size / 2, width: size, height: size, opacity: 1 - o, filter: o > 0 ? `blur(${o * 8}px)` : undefined}}>
			<svg width={size} height={size} viewBox="0 0 100 100" style={{overflow: 'visible'}}>
				{ic.d.map((p, i) => { const k = ph(t, at + i * (d / ic.d.length) * 0.6, d, easeInOut); const acc = accentPaths.includes(i); return <path key={i} d={p} pathLength={1} fill="none" stroke={acc ? pal.accent : pal.line} strokeWidth={stroke * (100 / size) * 3.2} strokeLinecap="round" strokeLinejoin="round" strokeDasharray="1 1" strokeDashoffset={1 - k} style={acc ? {filter: `drop-shadow(0 0 4px ${pal.accent})`} : undefined} />; })}
				{(ic.dots ?? []).map(([cx, cy], i) => { const k = ph(t, at + d * 0.8 + i * 0.1, 0.3); return <g key={i} opacity={k}><circle cx={cx} cy={cy} r={2.4 * (1 + 0.3 * Math.sin(t * 4 + i))} fill={pal.accent} /><circle cx={cx} cy={cy} r={6} fill={alpha(pal.accent, 0.25)} /></g>; })}
			</svg>
			{label ? <div style={{position: 'absolute', left: -200, right: -200, [labelPos === 'top' ? 'top' : 'bottom']: -48, textAlign: 'center', fontFamily: XFONT.mono, fontWeight: 500, fontSize: 22, letterSpacing: '0.14em', color: pal.label, opacity: ph(t, at + d * 0.6, 0.3)}}>{label}</div> : null}
		</div>
	);
};
/** linha/curva livre que se desenha (setas, conexões, órbitas) */
export const Trace: React.FC<{t: number; d: string; at: number; dur?: number; color?: string; w?: number; dash?: boolean}> = ({t, d, at, dur = 0.7, color = LINHA.line, w = 3, dash}) => {
	const k = ph(t, at, dur, easeInOut);
	return <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0, overflow: 'visible', pointerEvents: 'none'}}><path d={d} pathLength={1} fill="none" stroke={color} strokeWidth={w} strokeLinecap="round" strokeDasharray={dash ? '0.012 0.012' : '1 1'} strokeDashoffset={dash ? 0 : 1 - k} opacity={dash ? k : 1} /></svg>;
};
/** ponto de acento pulsante que percorre um caminho circular (órbita) */
export const OrbitDot: React.FC<{t: number; cx: number; cy: number; r: number; speed?: number; phase?: number; color?: string; at: number; ry?: number}> = ({t, cx, cy, r, speed = 0.8, phase = 0, color = LINHA.accent, at, ry}) => {
	const k = ph(t, at, 0.3);
	const a = phase + (t - at) * speed;
	return <div style={{position: 'absolute', left: cx + Math.cos(a) * r - 8, top: cy + Math.sin(a) * (ry ?? r) - 8, width: 16, height: 16, borderRadius: 8, background: color, boxShadow: `0 0 18px ${color}`, opacity: k}} />;
};
/** rótulo mono pequeno com traço guia */
export const Tag: React.FC<{t: number; at: number; x: number; y: number; text: string; color?: string; align?: 'left' | 'center' | 'right'}> = ({t, at, x, y, text, color = LINHA.label, align = 'center'}) => {
	const k = ph(t, at, 0.3);
	const n = Math.round(text.length * clamp((t - at) / 0.4));
	return <div style={{position: 'absolute', left: align === 'left' ? x : align === 'right' ? x - 600 : x - 300, width: 600, top: y, textAlign: align, fontFamily: XFONT.mono, fontWeight: 500, fontSize: 22, letterSpacing: '0.14em', color, opacity: k}}>{text.slice(0, n)}</div>;
};
/** fundo grafite com vinheta e leve deriva */
export const LinhaBg: React.FC<{t: number; pal?: LinhaPal}> = ({t, pal = LINHA}) => (
	<>
		<div style={{position: 'absolute', inset: 0, background: `radial-gradient(ellipse 80% 60% at 50% 42%, ${pal.bg2}, ${pal.bg} 75%)`}} />
		<div style={{position: 'absolute', inset: 0, backgroundImage: `radial-gradient(${alpha(pal.line, 0.05)} 1px, transparent 1px)`, backgroundSize: '36px 36px', transform: `translateY(${(t * 6) % 36}px)`, opacity: 0.6}} />
	</>
);
/** grade de quadrados que acendem (contagem/proporção — ex.: "de repente aparece em todo lugar") */
export const SquareGrid: React.FC<{t: number; at: number; cols: number; rows: number; lit: number; cell: number; x: number; y: number; pal?: LinhaPal}> = ({t, at, cols, rows, lit, cell, x, y, pal = LINHA}) => (
	<div style={{position: 'absolute', left: x, top: y, display: 'grid', gridTemplateColumns: `repeat(${cols}, ${cell}px)`, gap: cell * 0.18}}>
		{Array.from({length: cols * rows}).map((_, i) => { const k = ph(t, at + i * 0.01, 0.25); const on = i < lit && t > at + 0.3 + i * 0.03; return <div key={i} style={{width: cell, height: cell, borderRadius: cell * 0.12, border: `2px solid ${on ? pal.accent : alpha(pal.line, 0.35)}`, background: on ? alpha(pal.accent, 0.55) : 'transparent', opacity: k}} />; })}
	</div>
);
export const mixK = (t: number, a: number, b: number) => ph(t, a, 0.3) * (1 - ph(t, b - 0.3, 0.3));
export {lerp};
