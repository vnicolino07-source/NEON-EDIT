/**
 * ESTILO "INFOGRÁFICO" — dados animados: contadores, barras, linha, rosca, grade de pessoas (1 em cada N).
 * Bom para: estatísticas, economia, saúde pública, pesquisas, "o número que ninguém conta".
 * REGRA: todo número na tela precisa estar no fatos.md com fonte. Nada de dado inventado.
 * Legenda recomendada: KCap kind="escuro" accent={INFO.accent}.
 */
import React from 'react';
import {XFONT, ph, easeOut, easeBack, easeInOut, clamp, lerp, alpha} from './base';
import {ICONS} from './linha';

export const INFO = {bg: '#0F1724', bg2: '#162235', ink: '#E6EDF7', dim: '#5B6B82', accent: '#FFB020', a2: '#3DD6C6', a3: '#FF5C7A'} as const;
export type InfoPal = {bg: string; bg2: string; ink: string; dim: string; accent: string; a2: string; a3: string};

export const InfoBg: React.FC<{t: number; pal?: InfoPal}> = ({t, pal = INFO}) => (
	<>
		<div style={{position: 'absolute', inset: 0, background: `linear-gradient(180deg, ${pal.bg2}, ${pal.bg})`}} />
		<div style={{position: 'absolute', inset: 0, backgroundImage: `radial-gradient(${alpha(pal.ink, 0.08)} 1.5px, transparent 1.5px)`, backgroundSize: '40px 40px', backgroundPosition: `0 ${(t * 8) % 40}px`}} />
	</>
);

/** formata número em pt-BR */
export const fmt = (v: number, dec = 0) => v.toLocaleString('pt-BR', {minimumFractionDigits: dec, maximumFractionDigits: dec});

/** número que conta de `from` até `to` (com prefixo/sufixo), e rótulo embaixo */
export const Counter: React.FC<{t: number; at: number; to: number; from?: number; dur?: number; dec?: number; prefix?: string; suffix?: string; label?: string; pal?: InfoPal; size?: number; y?: number; color?: string}> = ({t, at, to, from = 0, dur = 1.2, dec = 0, prefix = '', suffix = '', label, pal = INFO, size = 210, y = 560, color}) => {
	if (t < at - 0.02) return null;
	const k = ph(t, at, dur, easeOut);
	const kin = ph(t, at, 0.3, easeBack);
	return (
		<div style={{position: 'absolute', left: 0, right: 0, top: y, display: 'flex', flexDirection: 'column', alignItems: 'center', transform: `scale(${lerp(0.7, 1, kin)})`, opacity: clamp(kin * 1.5)}}>
			<span style={{fontFamily: XFONT.sans, fontWeight: 800, fontSize: size, lineHeight: 1, letterSpacing: '-0.045em', color: color ?? pal.accent, fontVariantNumeric: 'tabular-nums'}}>{prefix}{fmt(lerp(from, to, k), dec)}{suffix}</span>
			{label ? <span style={{marginTop: 18, fontFamily: XFONT.sans, fontWeight: 500, fontSize: 36, color: pal.ink, opacity: ph(t, at + 0.4, 0.3), textAlign: 'center', maxWidth: 820}}>{label}</span> : null}
		</div>
	);
};

/** barras verticais que crescem uma a uma; `hl` marca a barra de destaque */
export const BarChart: React.FC<{t: number; at: number; data: {label: string; v: number; hl?: boolean; txt?: string}[]; x?: number; y?: number; w?: number; h?: number; pal?: InfoPal; max?: number}> = ({t, at, data, x = 120, y = 420, w = 840, h = 640, pal = INFO, max}) => {
	if (t < at - 0.02) return null;
	const m = max ?? Math.max(...data.map((d) => d.v));
	const bw = (w / data.length) * 0.62;
	return (
		<div style={{position: 'absolute', left: x, top: y, width: w, height: h + 70}}>
			<div style={{position: 'absolute', left: 0, right: 0, top: h, height: 3, background: pal.dim, transform: `scaleX(${ph(t, at, 0.4)})`, transformOrigin: 'left'}} />
			{data.map((d, i) => {
				const k = ph(t, at + 0.2 + i * 0.15, 0.6, easeOut);
				const bh = (d.v / m) * (h - 60) * k;
				const cx = (i + 0.5) * (w / data.length);
				const col = d.hl ? pal.accent : alpha(pal.ink, 0.35);
				return (
					<React.Fragment key={i}>
						<div style={{position: 'absolute', left: cx - bw / 2, top: h - bh, width: bw, height: bh, background: col, borderRadius: '10px 10px 0 0', boxShadow: d.hl ? `0 0 30px ${alpha(pal.accent, 0.4)}` : undefined}} />
						<div style={{position: 'absolute', left: cx - 120, width: 240, top: h - bh - 58, textAlign: 'center', fontFamily: XFONT.sans, fontWeight: 800, fontSize: 40, color: d.hl ? pal.accent : pal.ink, opacity: ph(t, at + 0.5 + i * 0.15, 0.3)}}>{d.txt ?? fmt(d.v * k)}</div>
						<div style={{position: 'absolute', left: cx - 120, width: 240, top: h + 16, textAlign: 'center', fontFamily: XFONT.mono, fontSize: 24, letterSpacing: '0.08em', color: pal.dim, opacity: ph(t, at + 0.2 + i * 0.15, 0.3)}}>{d.label}</div>
					</React.Fragment>
				);
			})}
		</div>
	);
};

/** gráfico de linha que se desenha com ponto na ponta; valores 0..1 */
export const LineChart: React.FC<{t: number; at: number; pts: number[]; labels?: string[]; x?: number; y?: number; w?: number; h?: number; pal?: InfoPal; dur?: number; color?: string}> = ({t, at, pts, labels = [], x = 110, y = 420, w = 860, h = 560, pal = INFO, dur = 1.4, color}) => {
	if (t < at - 0.02) return null;
	const c = color ?? pal.a2;
	const P = pts.map((v, i) => [(i / (pts.length - 1)) * w, h - v * h] as const);
	const d = P.map(([px, py], i) => (i ? 'L' : 'M') + px.toFixed(1) + ' ' + py.toFixed(1)).join(' ');
	const k = ph(t, at, dur, easeInOut);
	const seg = Math.min(P.length - 2, Math.floor(k * (P.length - 1)));
	const f = k * (P.length - 1) - seg;
	const hx = lerp(P[seg][0], P[seg + 1][0], f), hy = lerp(P[seg][1], P[seg + 1][1], f);
	return (
		<svg width={w + 40} height={h + 80} style={{position: 'absolute', left: x - 20, top: y - 20, overflow: 'visible'}}>
			<g transform="translate(20 20)">
				{[0, 0.25, 0.5, 0.75, 1].map((g) => <line key={g} x1={0} x2={w} y1={h - g * h} y2={h - g * h} stroke={alpha(pal.ink, 0.08)} strokeWidth={2} />)}
				<path d={`${d} L${w} ${h} L0 ${h} Z`} fill={alpha(c, 0.12)} style={{clipPath: `inset(0 ${(1 - k) * 100}% 0 0)`}} />
				<path d={d} pathLength={1} fill="none" stroke={c} strokeWidth={7} strokeLinejoin="round" strokeLinecap="round" strokeDasharray="1 1" strokeDashoffset={1 - k} />
				<circle cx={hx} cy={hy} r={14} fill={c} /><circle cx={hx} cy={hy} r={30} fill={alpha(c, 0.25)} />
				{labels.map((l, i) => <text key={i} x={(i / (labels.length - 1)) * w} y={h + 50} textAnchor="middle" fontFamily="XMono" fontSize={24} fill={pal.dim}>{l}</text>)}
			</g>
		</svg>
	);
};

/** rosca/percentual que se completa; texto no centro */
export const Donut: React.FC<{t: number; at: number; pct: number; label?: string; x?: number; y?: number; r?: number; pal?: InfoPal; color?: string}> = ({t, at, pct, label, x = 540, y = 760, r = 250, pal = INFO, color}) => {
	if (t < at - 0.02) return null;
	const k = ph(t, at, 1.1, easeInOut);
	const c = color ?? pal.accent;
	const C = 2 * Math.PI * r;
	return (
		<div style={{position: 'absolute', left: x - r - 30, top: y - r - 30, width: 2 * r + 60, height: 2 * r + 60, opacity: ph(t, at, 0.25)}}>
			<svg width={2 * r + 60} height={2 * r + 60}><g transform={`translate(${r + 30} ${r + 30}) rotate(-90)`}><circle r={r} fill="none" stroke={alpha(pal.ink, 0.1)} strokeWidth={46} /><circle r={r} fill="none" stroke={c} strokeWidth={46} strokeLinecap="round" strokeDasharray={`${C * (pct / 100) * k} ${C}`} /></g></svg>
			<div style={{position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center'}}>
				<span style={{fontFamily: XFONT.sans, fontWeight: 800, fontSize: r * 0.62, color: pal.ink, letterSpacing: '-0.04em'}}>{fmt(pct * k)}%</span>
				{label ? <span style={{fontFamily: XFONT.sans, fontWeight: 500, fontSize: 30, color: pal.dim, maxWidth: r * 1.4, textAlign: 'center'}}>{label}</span> : null}
			</div>
		</div>
	);
};

/** grade de pessoas: `lit` de `n` acendem ("1 em cada 4") */
export const PictoGrid: React.FC<{t: number; at: number; n?: number; cols?: number; lit: number; x?: number; y?: number; cell?: number; pal?: InfoPal; icon?: string}> = ({t, at, n = 40, cols = 8, lit, x, y = 440, cell = 100, pal = INFO, icon = 'pessoa'}) => {
	if (t < at - 0.02) return null;
	const ic = ICONS[icon];
	const left = x ?? (1080 - cols * cell) / 2;
	return (
		<div style={{position: 'absolute', left, top: y, display: 'grid', gridTemplateColumns: `repeat(${cols}, ${cell}px)`}}>
			{Array.from({length: n}).map((_, i) => { const k = ph(t, at + i * 0.012, 0.25, easeBack); const on = i < lit && t > at + 0.6 + i * 0.05; return <svg key={i} width={cell} height={cell} viewBox="0 0 100 100" style={{transform: `scale(${k})`}}>{ic.d.map((p, j) => <path key={j} d={p} fill={on ? pal.accent : 'none'} stroke={on ? pal.accent : alpha(pal.ink, 0.35)} strokeWidth={6} strokeLinecap="round" />)}</svg>; })}
		</div>
	);
};

/** cartão de fonte (rodapé discreto, acima da legenda) — "Fonte: IBGE, 2024" */
export const FonteTag: React.FC<{t: number; at: number; text: string; pal?: InfoPal; y?: number}> = ({t, at, text, pal = INFO, y = 1270}) => <div style={{position: 'absolute', left: 0, right: 0, top: y, textAlign: 'center', fontFamily: XFONT.mono, fontSize: 22, letterSpacing: '0.06em', color: pal.dim, opacity: ph(t, at, 0.3)}}>{text}</div>;
