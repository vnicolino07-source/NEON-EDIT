/**
 * ESTILO "QUADRO" — quadro-negro (ardósia verde) com giz: traço com textura, escrita à mão, sublinhados,
 * círculos e setas feitos "na hora", apagador como transição.
 * Bom para: educação, explicações passo a passo, matemática, história, "aula rápida".
 * Legenda recomendada: KCap kind="suave" font={XFONT.giz} size={64} ink={QUADRO.giz} dim="rgba(237,235,228,.35)".
 */
import React from 'react';
import {XFONT, ph, easeInOut, clamp, alpha, rnd} from './base';
import {ICONS} from './linha';

export const QUADRO = {bg: '#22302A', bg2: '#2C3D35', giz: '#EDEBE4', amarelo: '#F2D36B', rosa: '#F29C9C', azul: '#9CC8F2', moldura: '#6B4A2E'} as const;
export type QuadroPal = {bg: string; bg2: string; giz: string; amarelo: string; rosa: string; azul: string; moldura: string};

/** filtro SVG de giz (borda irregular + falhas). Coloque UM <GizDefs/> por cena. */
export const GizDefs: React.FC = () => (
	<svg width={0} height={0} style={{position: 'absolute'}}>
		<defs>
			<filter id="giz" x="-10%" y="-10%" width="120%" height="120%">
				<feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="3" result="n" />
				<feDisplacementMap in="SourceGraphic" in2="n" scale="3.5" result="d" />
				<feTurbulence type="fractalNoise" baseFrequency="1.6" numOctaves="1" seed="8" result="n2" />
				<feColorMatrix in="n2" type="matrix" values="0 0 0 0 1  0 0 0 0 1  0 0 0 0 1  0 0 0 -1.6 1.25" result="m" />
				<feComposite in="d" in2="m" operator="in" />
			</filter>
		</defs>
	</svg>
);

/** fundo de ardósia com manchas de giz apagado e moldura de madeira opcional */
export const QuadroBg: React.FC<{t: number; pal?: QuadroPal; moldura?: boolean}> = ({t, pal = QUADRO, moldura = false}) => (
	<>
		<div style={{position: 'absolute', inset: 0, background: `radial-gradient(ellipse 90% 70% at 50% 40%, ${pal.bg2}, ${pal.bg} 80%)`}} />
		{Array.from({length: 7}).map((_, i) => <div key={i} style={{position: 'absolute', left: rnd(i) * 900 - 100, top: rnd(i + 9) * 1700, width: 420 + rnd(i + 3) * 300, height: 160 + rnd(i + 5) * 120, borderRadius: '50%', background: alpha(pal.giz, 0.035), filter: 'blur(30px)', transform: `rotate(${rnd(i + 2) * 40 - 20}deg)`}} />)}
		<div style={{position: 'absolute', inset: -20, opacity: 0.08, backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='300' height='300'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.7' numOctaves='3' seed='2'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>")`, mixBlendMode: 'screen'}} />
		{moldura ? <div style={{position: 'absolute', inset: 0, border: `26px solid ${pal.moldura}`, boxShadow: 'inset 0 0 40px rgba(0,0,0,.6)'}} /> : null}
		<div style={{position: 'absolute', left: 0, right: 0, top: 0, height: 1920, background: `linear-gradient(90deg, transparent ${40 + Math.sin(t * 0.3) * 8}%, ${alpha(pal.giz, 0.02)} 50%, transparent 60%)`}} />
	</>
);

/** ícone da biblioteca (ICONS) desenhado a giz */
export const GizIcon: React.FC<{t: number; name: string; at: number; d?: number; size: number; x: number; y: number; color?: string; out?: number}> = ({t, name, at, d = 0.9, size, x, y, color = QUADRO.giz, out = 1e9}) => {
	const ic = ICONS[name];
	if (!ic || t < at - 0.02) return null;
	const o = ph(t, out, 0.3);
	return (
		<svg width={size} height={size} viewBox="0 0 100 100" style={{position: 'absolute', left: x - size / 2, top: y - size / 2, overflow: 'visible', opacity: 1 - o, filter: 'url(#giz)'}}>
			{ic.d.map((p, i) => { const k = ph(t, at + i * (d / ic.d.length) * 0.6, d, easeInOut); return <path key={i} d={p} pathLength={1} fill="none" stroke={color} strokeWidth={(100 / size) * 7} strokeLinecap="round" strokeLinejoin="round" strokeDasharray="1 1" strokeDashoffset={1 - k} />; })}
		</svg>
	);
};

/** texto escrito à mão, letra por letra (fonte de giz) */
export const GizText: React.FC<{t: number; at: number; text: string; x: number; y: number; size?: number; color?: string; cps?: number; align?: 'left' | 'center'; rot?: number; out?: number}> = ({t, at, text, x, y, size = 96, color = QUADRO.giz, cps = 16, align = 'center', rot = -1.5, out = 1e9}) => {
	if (t < at - 0.02) return null;
	const n = Math.floor((t - at) * cps);
	const o = ph(t, out, 0.3);
	return (
		<div style={{position: 'absolute', left: align === 'center' ? x - 500 : x, width: 1000, top: y, textAlign: align, transform: `rotate(${rot}deg)`, fontFamily: XFONT.giz, fontWeight: 700, fontSize: size, lineHeight: 1.05, color, filter: 'url(#giz)', opacity: 1 - o}}>
			{text.split('').map((c, i) => <span key={i} style={{opacity: i < n ? 1 : 0}}>{c}</span>)}
		</div>
	);
};

/** marcações feitas a giz: sublinhado, círculo em volta, seta, X */
export const GizMark: React.FC<{t: number; at: number; kind: 'sublinha' | 'circulo' | 'seta' | 'xis' | 'check'; x: number; y: number; w: number; h?: number; color?: string; dur?: number; rot?: number}> = ({t, at, kind, x, y, w, h = w * 0.5, color = QUADRO.amarelo, dur = 0.45, rot = 0}) => {
	if (t < at - 0.02) return null;
	const k = ph(t, at, dur, easeInOut);
	const P: Record<string, string> = {
		sublinha: `M0 ${h * 0.5} C${w * 0.3} ${h * 0.35} ${w * 0.7} ${h * 0.62} ${w} ${h * 0.45}`,
		circulo: `M${w * 0.55} ${h * 0.04} C${w * 1.05} ${h * 0.02} ${w * 1.04} ${h * 0.98} ${w * 0.5} ${h * 0.98} C${w * -0.04} ${h * 0.98} ${w * -0.03} ${h * 0.04} ${w * 0.6} ${h * 0.1}`,
		seta: `M0 ${h * 0.5} C${w * 0.35} ${h * 0.2} ${w * 0.65} ${h * 0.7} ${w} ${h * 0.5} M${w * 0.86} ${h * 0.3} L${w} ${h * 0.5} L${w * 0.84} ${h * 0.66}`,
		xis: `M0 0 L${w} ${h} M${w} 0 L0 ${h}`,
		check: `M0 ${h * 0.55} L${w * 0.35} ${h} L${w} 0`,
	};
	return <svg width={w} height={h} style={{position: 'absolute', left: x, top: y, overflow: 'visible', transform: `rotate(${rot}deg)`, filter: 'url(#giz)'}}><path d={P[kind]} pathLength={1} fill="none" stroke={color} strokeWidth={9} strokeLinecap="round" strokeLinejoin="round" strokeDasharray="1 1" strokeDashoffset={1 - k} /></svg>;
};

/** transição: apagador passa em zigue-zague e limpa a lousa (use no fim de uma cena, dura ~0,6 s) */
export const Apagador: React.FC<{t: number; at: number; pal?: QuadroPal; dur?: number}> = ({t, at, pal = QUADRO, dur = 0.6}) => {
	if (t < at || t > at + dur + 0.2) return null;
	const k = clamp((t - at) / dur);
	const rows = 5;
	const row = Math.min(rows - 1, Math.floor(k * rows));
	const kx = (k * rows) % 1;
	const ex = row % 2 === 0 ? kx : 1 - kx;
	return (
		<div style={{position: 'absolute', inset: 0}}>
			{Array.from({length: rows}).map((_, i) => { const done = i < row ? 1 : i === row ? kx : 0; const left = i % 2 === 0 ? 0 : (1 - done) * 1080; return <div key={i} style={{position: 'absolute', top: i * (1920 / rows) - 20, height: 1920 / rows + 40, left, width: done * 1080, background: pal.bg, filter: 'blur(10px)', opacity: 0.97}} />; })}
			<div style={{position: 'absolute', left: ex * 1080 - 130, top: row * (1920 / rows) + 120, width: 260, height: 110, borderRadius: 14, background: '#C9B48F', boxShadow: '0 10px 30px rgba(0,0,0,.5)', borderBottom: '26px solid #3A3A3A', transform: 'rotate(-8deg)'}} />
		</div>
	);
};
