/**
 * ESTILO "COLAGEM" — papel kraft/creme, fotos de arquivo coladas com fita, documentos datilografados com tarjas,
 * tiras de papel rasgado com títulos, círculos feitos à mão, recortes de cor. Tipografia serifada.
 * Bom para: história, biografias, comportamento, "lições de gênios", livros, investigações.
 * Fotos: SEMPRE da pessoa/licenciadas/domínio público (em public/<projeto>/). Sem foto → card ilustrado (Silhueta).
 */
import React from 'react';
import {Img, staticFile} from 'remotion';
import {XFONT, ph, easeBack, easeInOut, clamp, lerp, rnd} from './base';

export type ColagemPal = {paper: string; paper2: string; kraft: string; ink: string; accent: string; green: string; black: string};
export const COLAGEM: ColagemPal = {paper: '#EFE6D6', paper2: '#E3D6BF', kraft: '#C9A57A', ink: '#2B2118', accent: '#E58C6E', green: '#2F6B4F', black: '#1B1714'};

/** fundo de papel com fibras/manchas, levemente animado */
export const PaperBg: React.FC<{t: number; pal?: ColagemPal; dark?: boolean}> = ({t, pal = COLAGEM, dark}) => (
	<>
		<div style={{position: 'absolute', inset: 0, background: dark ? `radial-gradient(ellipse at 50% 40%, #3A3128, ${pal.black} 75%)` : `radial-gradient(ellipse at 45% 35%, ${pal.paper}, ${pal.paper2} 80%)`}} />
		<div style={{position: 'absolute', inset: 0, opacity: dark ? 0.12 : 0.35, backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='600'><filter id='p'><feTurbulence type='fractalNoise' baseFrequency='0.012 0.03' numOctaves='4' seed='3'/><feColorMatrix values='0 0 0 0 0.45 0 0 0 0 0.35 0 0 0 0 0.25 0 0 0 0.35 0'/></filter><rect width='100%' height='100%' filter='url(%23p)'/></svg>")`, transform: `translate(${Math.sin(t * 0.2) * 6}px, ${Math.cos(t * 0.17) * 6}px)`}} />
	</>
);
/** pedaço de fita adesiva */
export const Tape: React.FC<{x: number; y: number; w?: number; rot?: number; color?: string}> = ({x, y, w = 150, rot = -8, color = 'rgba(235,225,200,.75)'}) => <div style={{position: 'absolute', left: x, top: y, width: w, height: 44, background: color, transform: `rotate(${rot}deg)`, boxShadow: '0 2px 6px rgba(0,0,0,.15)', clipPath: 'polygon(2% 0, 98% 6%, 100% 50%, 97% 100%, 3% 94%, 0 52%)', zIndex: 3}} />;
/** borda rasgada (clip-path determinístico) */
const torn = (seed: number, n = 22, amp = 2.2) => { const pts: string[] = []; for (let i = 0; i <= n; i++) pts.push(`${(i / n) * 100}% ${rnd(seed + i) * amp}%`); for (let i = n; i >= 0; i--) pts.push(`${(i / n) * 100}% ${100 - rnd(seed + 40 + i) * amp}%`); return `polygon(${pts.join(',')})`; };

/** foto colada em papel kraft com fita e legenda; Ken Burns lento */
export const TapedPhoto: React.FC<{t: number; at: number; until?: number; src?: string; w?: number; h?: number; x?: number; y?: number; rot?: number; caption?: string; pal?: ColagemPal; children?: React.ReactNode; bw?: boolean}> = ({t, at, until = 1e9, src, w = 640, h = 720, x = 540, y = 760, rot = -2, caption, pal = COLAGEM, children, bw = true}) => {
	if (t < at - 0.02 || t > until + 0.4) return null;
	const k = ph(t, at, 0.45, easeBack), o = ph(t, until, 0.35);
	const kb = 1.04 + (t - at) * 0.012;
	return (
		<div style={{position: 'absolute', left: x - w / 2 - 40, top: y - h / 2 - 40, width: w + 80, height: h + 120, transform: `rotate(${rot + (1 - k) * 6}deg) scale(${lerp(0.85, 1, k)}) translateY(${o * -40}px)`, opacity: clamp(k * 1.5) * (1 - o), filter: `blur(${(1 - clamp(k)) * 10 + o * 10}px)`}}>
			<div style={{position: 'absolute', inset: 0, background: pal.kraft, clipPath: torn(at * 10), boxShadow: '0 20px 50px rgba(0,0,0,.25)'}} />
			<div style={{position: 'absolute', left: 40, top: 40, width: w, height: h, overflow: 'hidden', background: '#ddd', border: '10px solid #F7F3EA', boxSizing: 'border-box'}}>
				{src ? <Img src={staticFile(src)} style={{width: '100%', height: '100%', objectFit: 'cover', transform: `scale(${kb})`, filter: bw ? 'grayscale(1) contrast(1.1) sepia(.15)' : 'sepia(.12)'}} /> : children}
			</div>
			<Tape x={w / 2 - 35} y={14} rot={-4} />
			{caption ? <div style={{position: 'absolute', left: 0, right: 0, top: h + 52, display: 'flex', justifyContent: 'center'}}><span style={{background: pal.accent, padding: '4px 16px', fontFamily: XFONT.serif, fontSize: 30, color: pal.ink, transform: 'rotate(-1deg)'}}>{caption}</span></div> : null}
		</div>
	);
};
/** documento datilografado com linhas tarjadas; círculo à mão em `circle` (índice da linha) */
export const RedactedDoc: React.FC<{t: number; at: number; until?: number; title: string; lines?: number; circle?: number; circleAt?: number; x?: number; y?: number; rot?: number; pal?: ColagemPal}> = ({t, at, until = 1e9, title, lines = 9, circle, circleAt, x = 540, y = 740, rot = 1.5, pal = COLAGEM}) => {
	if (t < at - 0.02 || t > until + 0.4) return null;
	const k = ph(t, at, 0.4, easeBack), o = ph(t, until, 0.35);
	const typed = Math.round(title.length * clamp((t - at - 0.2) / 0.8));
	return (
		<div style={{position: 'absolute', left: x - 300, top: y - 380, width: 600, height: 760, transform: `rotate(${rot}deg) scale(${lerp(0.88, 1, k)})`, opacity: clamp(k * 1.5) * (1 - o), filter: `blur(${(1 - clamp(k)) * 8 + o * 10}px)`}}>
			<div style={{position: 'absolute', inset: 0, background: '#F8F5EE', boxShadow: '0 18px 40px rgba(0,0,0,.22)', padding: '60px 54px'}}>
				<div style={{fontFamily: XFONT.mono, fontSize: 28, color: pal.ink, lineHeight: 1.35, minHeight: 80}}>{title.slice(0, typed)}<span style={{opacity: typed < title.length && Math.sin(t * 14) > 0 ? 1 : 0}}>▍</span></div>
				<div style={{marginTop: 26, display: 'flex', flexDirection: 'column', gap: 18}}>
					{Array.from({length: lines}).map((_, i) => { const lk = ph(t, at + 0.5 + i * 0.07, 0.2); const segs = [0.2 + rnd(i) * 0.25, 0.15 + rnd(i + 5) * 0.3, 0.1 + rnd(i + 9) * 0.2]; return <div key={i} style={{display: 'flex', gap: 10, opacity: lk, position: 'relative'}}>{segs.map((s, j) => <div key={j} style={{height: 22, width: `${s * 100}%`, background: (i + j) % 3 === 1 ? pal.black : '#B8B0A2', borderRadius: 2}} />)}
						{circle === i ? <svg width={300} height={110} viewBox="0 0 300 110" style={{position: 'absolute', left: 40, top: -44, overflow: 'visible'}}><path d="M20 60 C20 20 120 8 200 14 C270 20 290 50 270 78 C240 104 90 104 40 86 C10 74 14 46 40 34" pathLength={1} fill="none" stroke={pal.accent} strokeWidth={6} strokeLinecap="round" strokeDasharray="1 1" strokeDashoffset={1 - ph(t, circleAt ?? at + 1, 0.6, easeInOut)} /></svg> : null}
					</div>; })}
				</div>
				<svg width={120} height={30} viewBox="0 0 120 30" style={{position: 'absolute', right: 70, bottom: 60}}><path d="M4 20 C14 4 24 30 34 14 C44 0 54 28 64 14 C74 2 84 26 94 12 C104 2 110 20 116 16" fill="none" stroke={pal.ink} strokeWidth={2.5} opacity={0.6} /></svg>
			</div>
			<Tape x={230} y={-18} rot={3} />
		</div>
	);
};
/** tira de papel rasgado com texto (título/citação). serif grande */
export const TornStrip: React.FC<{t: number; at: number; until?: number; text: string; y?: number; size?: number; color?: string; pal?: ColagemPal; rot?: number; italic?: boolean}> = ({t, at, until = 1e9, text, y = 760, size = 64, color, pal = COLAGEM, rot = -1.5, italic}) => {
	if (t < at - 0.02 || t > until + 0.4) return null;
	const k = ph(t, at, 0.35), o = ph(t, until, 0.3);
	return (
		<div style={{position: 'absolute', left: 60, right: 60, top: y, display: 'flex', justifyContent: 'center', transform: `rotate(${rot}deg) translateX(${(1 - k) * -60}px)`, opacity: k * (1 - o)}}>
			<div style={{position: 'relative', padding: '26px 60px'}}>
				<div style={{position: 'absolute', inset: 0, background: color ?? pal.kraft, clipPath: torn(at * 7 + 3, 26, 9), opacity: 0.92}} />
				<span style={{position: 'relative', fontFamily: XFONT.serif, fontStyle: italic ? 'italic' : 'normal', fontWeight: 500, fontSize: size, color: pal.ink}}>{text}</span>
			</div>
		</div>
	);
};
/** recortes decorativos (faixas de cor, papel de jornal) que entram pelas bordas */
export const Scraps: React.FC<{t: number; at: number; until?: number; seed?: number; pal?: ColagemPal}> = ({t, at, until = 1e9, seed = 1, pal = COLAGEM}) => {
	const k = ph(t, at, 0.5), o = ph(t, until, 0.4);
	return <>{[0, 1, 2].map((i) => { const left = rnd(seed + i) > 0.5; return <div key={i} style={{position: 'absolute', [left ? 'left' : 'right']: lerp(-420, -120, k) - o * 200, top: 250 + i * 300 + rnd(seed + i + 3) * 80, width: 380, height: 150 + rnd(seed + i + 7) * 120, background: i === 0 ? pal.green : i === 1 ? '#E9E1D2' : pal.black, opacity: i === 1 ? 0.7 : 0.9, transform: `rotate(${(rnd(seed + i + 11) - 0.5) * 16}deg)`, clipPath: torn(seed * 13 + i, 16, 6), backgroundImage: i === 1 ? 'repeating-linear-gradient(0deg, transparent 0 14px, rgba(0,0,0,.18) 14px 16px)' : undefined}} />; })}</>;
};
/** card "silhueta" quando não há foto liberada: perfil desenhado + rótulo */
export const Silhueta: React.FC<{label?: string; pal?: ColagemPal}> = ({label, pal = COLAGEM}) => (
	<div style={{width: '100%', height: '100%', background: `linear-gradient(160deg, #CFC4B0, #9E917B)`, display: 'flex', alignItems: 'flex-end', justifyContent: 'center', position: 'relative'}}>
		<svg width="70%" height="80%" viewBox="0 0 100 100"><path d="M30 100 V86 C14 82 10 70 18 60 C14 46 20 26 40 20 C60 14 78 26 78 44 L84 52 L78 56 C80 64 76 70 70 72 V100 Z" fill={pal.black} opacity={0.82} /></svg>
		{label ? <div style={{position: 'absolute', top: 24, left: 0, right: 0, textAlign: 'center', fontFamily: XFONT.mono, fontSize: 22, color: pal.ink, letterSpacing: '0.1em'}}>{label}</div> : null}
	</div>
);
