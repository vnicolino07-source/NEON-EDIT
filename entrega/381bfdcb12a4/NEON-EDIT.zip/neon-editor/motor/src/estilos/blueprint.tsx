/**
 * ESTILO "BLUEPRINT" — planta técnica: fundo azul, grade, traço branco que se desenha, cotas com medidas,
 * chamadas com linha guia, engrenagens girando.
 * Bom para: engenharia, "como funciona", invenções, arquitetura, produto por dentro.
 * Legenda recomendada: KCap kind="suave" font={XFONT.mono} ink={BP.line} dim="rgba(220,235,255,.4)" accent={BP.accent}.
 */
import React from 'react';
import {XFONT, ph, easeInOut, clamp, alpha} from './base';
import {ICONS} from './linha';

export const BP = {bg: '#0D3B6E', bg2: '#11497F', line: '#DCEBFF', dim: 'rgba(220,235,255,.22)', accent: '#FFD166'} as const;
export type BpPal = {bg: string; bg2: string; line: string; dim: string; accent: string};

export const BlueprintBg: React.FC<{t: number; pal?: BpPal; carimbo?: string}> = ({t, pal = BP, carimbo}) => (
	<>
		<div style={{position: 'absolute', inset: 0, background: `radial-gradient(ellipse 90% 70% at 50% 40%, ${pal.bg2}, ${pal.bg} 85%)`}} />
		<div style={{position: 'absolute', inset: 0, backgroundImage: `linear-gradient(${pal.dim} 1px, transparent 1px), linear-gradient(90deg, ${pal.dim} 1px, transparent 1px)`, backgroundSize: '120px 120px', opacity: 0.9}} />
		<div style={{position: 'absolute', inset: 0, backgroundImage: `linear-gradient(${alpha(pal.line, 0.07)} 1px, transparent 1px), linear-gradient(90deg, ${alpha(pal.line, 0.07)} 1px, transparent 1px)`, backgroundSize: '24px 24px'}} />
		<div style={{position: 'absolute', inset: 40, border: `2px solid ${alpha(pal.line, 0.5)}`}} />
		{carimbo ? <div style={{position: 'absolute', right: 40, bottom: 40, width: 360, padding: '12px 18px', borderTop: `2px solid ${alpha(pal.line, 0.5)}`, borderLeft: `2px solid ${alpha(pal.line, 0.5)}`, fontFamily: XFONT.mono, fontSize: 20, letterSpacing: '0.1em', color: alpha(pal.line, 0.75)}}>{carimbo}<br />ESC 1:{(10 + Math.floor(t)) % 50 + 10}</div> : null}
	</>
);

/** ícone da biblioteca em traço técnico, com linhas de construção tracejadas atrás */
export const BpIcon: React.FC<{t: number; name: string; at: number; d?: number; size: number; x: number; y: number; pal?: BpPal; out?: number}> = ({t, name, at, d = 1.1, size, x, y, pal = BP, out = 1e9}) => {
	const ic = ICONS[name];
	if (!ic || t < at - 0.02) return null;
	const kc = ph(t, at, 0.4);
	const o = ph(t, out, 0.3);
	return (
		<svg width={size} height={size} viewBox="0 0 100 100" style={{position: 'absolute', left: x - size / 2, top: y - size / 2, overflow: 'visible', opacity: 1 - o}}>
			<g stroke={alpha(pal.line, 0.35)} strokeWidth={0.4} strokeDasharray="2 2" opacity={kc}>
				<line x1={-20} x2={120} y1={50} y2={50} /><line y1={-20} y2={120} x1={50} x2={50} /><circle cx={50} cy={50} r={48} fill="none" />
			</g>
			{ic.d.map((p, i) => { const k = ph(t, at + 0.2 + i * (d / ic.d.length) * 0.6, d, easeInOut); return <path key={i} d={p} pathLength={1} fill="none" stroke={pal.line} strokeWidth={(100 / size) * 3.4} strokeLinecap="square" strokeLinejoin="miter" strokeDasharray="1 1" strokeDashoffset={1 - k} />; })}
		</svg>
	);
};

/** cota: linha com setas nas pontas, linhas de chamada e medida no meio */
export const Cota: React.FC<{t: number; at: number; x1: number; y1: number; x2: number; y2: number; label: string; pal?: BpPal; off?: number}> = ({t, at, x1, y1, x2, y2, label, pal = BP, off = 0}) => {
	if (t < at - 0.02) return null;
	const k = ph(t, at, 0.5, easeInOut);
	const ang = Math.atan2(y2 - y1, x2 - x1);
	const nx = -Math.sin(ang) * off, ny = Math.cos(ang) * off;
	const ax = x1 + nx, ay = y1 + ny, bx = x2 + nx, by = y2 + ny;
	const mx = (ax + bx) / 2, my = (ay + by) / 2;
	const ar = (px: number, py: number, dir: number) => { const a = ang + (dir > 0 ? 0 : Math.PI); return `M${px} ${py} L${px - Math.cos(a - 0.4) * 18} ${py - Math.sin(a - 0.4) * 18} M${px} ${py} L${px - Math.cos(a + 0.4) * 18} ${py - Math.sin(a + 0.4) * 18}`; };
	return (
		<svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0, overflow: 'visible'}}>
			<g stroke={pal.accent} strokeWidth={2.5} fill="none" opacity={clamp(k * 2)}>
				{off ? <><line x1={x1} y1={y1} x2={ax + nx * 0.15} y2={ay + ny * 0.15} strokeDasharray="4 4" /><line x1={x2} y1={y2} x2={bx + nx * 0.15} y2={by + ny * 0.15} strokeDasharray="4 4" /></> : null}
				<line x1={mx - (mx - ax) * k} y1={my - (my - ay) * k} x2={mx + (bx - mx) * k} y2={my + (by - my) * k} />
				{k > 0.95 ? <><path d={ar(ax, ay, -1)} /><path d={ar(bx, by, 1)} /></> : null}
			</g>
			<g transform={`translate(${mx} ${my}) rotate(${(Math.abs(ang) > Math.PI / 2 ? ang + Math.PI : ang) * 57.3})`} opacity={ph(t, at + 0.35, 0.25)}>
				<rect x={-label.length * 9.5 - 12} y={-22} width={label.length * 19 + 24} height={44} fill={pal.bg} />
				<text textAnchor="middle" dominantBaseline="central" fontFamily="XMono" fontSize={30} fill={pal.accent}>{label}</text>
			</g>
		</svg>
	);
};

/** chamada: ponto no objeto → linha em cotovelo → rótulo */
export const Chamada: React.FC<{t: number; at: number; x: number; y: number; tx: number; ty: number; text: string; pal?: BpPal}> = ({t, at, x, y, tx, ty, text, pal = BP}) => {
	if (t < at - 0.02) return null;
	const k = ph(t, at, 0.45, easeInOut);
	const right = tx >= x;
	return (
		<>
			<svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0, overflow: 'visible'}}>
				<circle cx={x} cy={y} r={9 * clamp(k * 3)} fill={pal.accent} />
				<path d={`M${x} ${y} L${tx} ${ty} L${tx + (right ? 60 : -60)} ${ty}`} pathLength={1} fill="none" stroke={pal.accent} strokeWidth={2.5} strokeDasharray="1 1" strokeDashoffset={1 - k} />
			</svg>
			<div style={{position: 'absolute', top: ty - 22, left: right ? tx + 74 : tx - 74 - 500, width: 500, textAlign: right ? 'left' : 'right', fontFamily: XFONT.mono, fontWeight: 500, fontSize: 28, letterSpacing: '0.08em', color: pal.line, opacity: ph(t, at + 0.35, 0.25)}}>{text}</div>
		</>
	);
};

/** engrenagem em contorno, girando (use pares com speed oposta e dentes proporcionais) */
export const Engrenagem: React.FC<{t: number; at: number; x: number; y: number; r: number; teeth?: number; speed?: number; pal?: BpPal; color?: string}> = ({t, at, x, y, r, teeth = 12, speed = 0.6, pal = BP, color}) => {
	if (t < at - 0.02) return null;
	const k = ph(t, at, 0.8, easeInOut);
	const pts: string[] = [];
	for (let i = 0; i < teeth * 4; i++) { const a = (i / (teeth * 4)) * Math.PI * 2; const rr = i % 4 < 2 ? r : r * 0.84; pts.push(`${Math.cos(a) * rr} ${Math.sin(a) * rr}`); }
	return (
		<svg width={r * 2 + 20} height={r * 2 + 20} style={{position: 'absolute', left: x - r - 10, top: y - r - 10, overflow: 'visible'}}>
			<g transform={`translate(${r + 10} ${r + 10}) rotate(${(t - at) * speed * 57.3})`} fill="none" stroke={color ?? pal.line} strokeWidth={3}>
				<path d={'M' + pts.join(' L') + ' Z'} pathLength={1} strokeDasharray="1 1" strokeDashoffset={1 - k} />
				<circle r={r * 0.3} opacity={k} /><circle r={r * 0.6} opacity={k * 0.4} strokeDasharray="6 6" />
			</g>
		</svg>
	);
};
