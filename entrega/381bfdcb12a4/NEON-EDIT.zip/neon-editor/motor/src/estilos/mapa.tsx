/**
 * ESTILO "MAPA" — mapa-múndi vetorial (Natural Earth 1:110m, domínio público) com câmera que viaja e dá zoom,
 * países que acendem, pinos com rótulo e rotas em arco com ponto viajando.
 * Bom para: história, geopolítica, guerras (sem violência gráfica), viagens, comércio, migração de animais, "onde fica".
 * Nomes de países: em inglês, como em dados/mundo.json (ex.: 'Brazil', 'United States of America', 'Japan').
 * Legenda recomendada: KCap kind="escuro" accent={MAPA.hl}.
 */
import React from 'react';
import {XFONT, ph, easeInOut, easeBack, clamp, lerp, alpha} from './base';
import MUNDO from './dados/mundo.json';

const M = MUNDO as Record<string, {d: string; c: [number, number]}>;
export const PAISES = Object.keys(M);
export const MAPA = {bg: '#0A1220', mar: '#0E1A2E', terra: '#22324A', borda: '#34486A', hl: '#FF6B3D', rota: '#FFD166', ink: '#E8EEF7'} as const;
export type MapaPal = {bg: string; mar: string; terra: string; borda: string; hl: string; rota: string; ink: string};

/** posição (espaço do mapa 1000×500) de um país ou [lon, lat] */
export const pos = (p: string | [number, number]): [number, number] => {
	if (typeof p === 'string') { const c = M[p]; if (!c) throw new Error(`país "${p}" não está em mundo.json`); return c.c; }
	return [((p[0] + 180) / 360) * 1000, ((90 - p[1]) / 180) * 500];
};

export type Cam = {at: number; foco: string | [number, number]; zoom: number};
/** câmera: interpola foco e zoom entre chaves (easeInOut, 1,2 s) */
const camAt = (t: number, cams: Cam[]) => {
	let i = 0;
	while (i < cams.length - 1 && t >= cams[i + 1].at) i++;
	const a = cams[i], b = cams[Math.min(i + 1, cams.length - 1)];
	const pa = pos(a.foco);
	if (i === cams.length - 1 || t < a.at) return {x: pa[0], y: pa[1], z: a.zoom};
	const pb = pos(b.foco);
	const k = ph(t, b.at - 1.2, 1.2, easeInOut);
	const zMid = Math.min(a.zoom, b.zoom) * (Math.hypot(pb[0] - pa[0], pb[1] - pa[1]) > 150 ? 0.7 : 1);
	const z = k < 0.5 ? lerp(a.zoom, zMid, k * 2) : lerp(zMid, b.zoom, (k - 0.5) * 2);
	return {x: lerp(pa[0], pb[0], k), y: lerp(pa[1], pb[1], k), z};
};

type Hl = {at: number; pais: string; cor?: string; ate?: number};
type Pino = {at: number; onde: string | [number, number]; label?: string; ate?: number};
type Rota = {at: number; de: string | [number, number]; para: string | [number, number]; dur?: number; ate?: number};

/**
 * Mapa com câmera. cy = centro vertical da área do mapa na tela (deixe a legenda livre embaixo).
 * escala base: zoom 1 = mundo inteiro com 1000 unidades → 1000 px de largura.
 */
export const WorldMap: React.FC<{t: number; cams: Cam[]; hl?: Hl[]; pinos?: Pino[]; rotas?: Rota[]; pal?: MapaPal; cy?: number; antartida?: boolean}> = ({t, cams, hl = [], pinos = [], rotas = [], pal = MAPA, cy = 760, antartida = false}) => {
	const c = camAt(t, cams);
	const S = c.z * 1.0;
	const tr = `translate(${540 - c.x * S} ${cy - c.y * S}) scale(${S})`;
	const sw = 0.8 / S;
	return (
		<>
			<div style={{position: 'absolute', inset: 0, background: `radial-gradient(ellipse at 50% 40%, ${pal.mar}, ${pal.bg} 80%)`}} />
			<svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0}}>
				<g transform={tr}>
					{[-60, -30, 0, 30, 60].map((lat) => { const y = ((90 - lat) / 180) * 500; return <line key={lat} x1={0} x2={1000} y1={y} y2={y} stroke={alpha(pal.ink, 0.05)} strokeWidth={sw} />; })}
					{[-120, -60, 0, 60, 120].map((lon) => { const x = ((lon + 180) / 360) * 1000; return <line key={lon} y1={0} y2={500} x1={x} x2={x} stroke={alpha(pal.ink, 0.05)} strokeWidth={sw} />; })}
					{PAISES.filter((p) => antartida || p !== 'Antarctica').map((p) => {
						const h = hl.find((x) => x.pais === p && t >= x.at && (x.ate === undefined || t < x.ate + 0.4));
						const k = h ? ph(t, h.at, 0.5) * (h.ate !== undefined ? 1 - ph(t, h.ate, 0.4) : 1) : 0;
						const col = h?.cor ?? pal.hl;
						return <path key={p} d={M[p].d} fill={k > 0 ? mix(pal.terra, col, k) : pal.terra} stroke={k > 0 ? col : pal.borda} strokeWidth={sw * (1 + k)} strokeLinejoin="round" style={k > 0.5 ? {filter: `drop-shadow(0 0 ${3 / S}px ${col})`} : undefined} />;
					})}
					{rotas.map((r, i) => {
						if (t < r.at || (r.ate !== undefined && t > r.ate + 0.4)) return null;
						const [x1, y1] = pos(r.de), [x2, y2] = pos(r.para);
						const dist = Math.hypot(x2 - x1, y2 - y1);
						const mx = (x1 + x2) / 2, my = (y1 + y2) / 2 - dist * 0.28;
						const k = ph(t, r.at, r.dur ?? 1.4, easeInOut);
						const o = r.ate !== undefined ? 1 - ph(t, r.ate, 0.4) : 1;
						const bx = (1 - k) * (1 - k) * x1 + 2 * (1 - k) * k * mx + k * k * x2, by = (1 - k) * (1 - k) * y1 + 2 * (1 - k) * k * my + k * k * y2;
						return <g key={i} opacity={o}><path d={`M${x1} ${y1} Q${mx} ${my} ${x2} ${y2}`} pathLength={1} fill="none" stroke={pal.rota} strokeWidth={2.2 / S} strokeDasharray="1 1" strokeDashoffset={1 - k} strokeLinecap="round" /><circle cx={bx} cy={by} r={5 / S} fill={pal.rota} /><circle cx={bx} cy={by} r={12 / S} fill={alpha(pal.rota, 0.3)} /></g>;
					})}
				</g>
			</svg>
			{pinos.map((p, i) => {
				if (t < p.at - 0.02 || (p.ate !== undefined && t > p.ate + 0.3)) return null;
				const [mx, my] = pos(p.onde);
				const sx = 540 + (mx - c.x) * S, sy = cy + (my - c.y) * S;
				const k = ph(t, p.at, 0.4, easeBack) * (p.ate !== undefined ? 1 - ph(t, p.ate, 0.3) : 1);
				return (
					<div key={i} style={{position: 'absolute', left: sx, top: sy, opacity: clamp(k * 2)}}>
						<div style={{position: 'absolute', left: -40 * k, top: -40 * k, width: 80 * k, height: 80 * k, borderRadius: '50%', border: `3px solid ${pal.hl}`, opacity: 1 - ((t - p.at) % 1.2) / 1.2, transform: `scale(${1 + ((t - p.at) % 1.2)})`}} />
						<svg width={56} height={76} viewBox="0 0 56 76" style={{position: 'absolute', left: -28, top: -74, transform: `translateY(${(1 - k) * -60}px)`}}><path d="M28 74 C28 74 4 44 4 28 A24 24 0 1 1 52 28 C52 44 28 74 28 74 Z" fill={pal.hl} /><circle cx={28} cy={28} r={9} fill={pal.bg} /></svg>
						{p.label ? <div style={{position: 'absolute', left: -300, width: 600, top: 18, textAlign: 'center', fontFamily: XFONT.sans, fontWeight: 800, fontSize: 40, color: pal.ink, textShadow: `0 3px 12px ${pal.bg}`}}>{p.label}</div> : null}
					</div>
				);
			})}
		</>
	);
};

const mix = (a: string, b: string, k: number) => {
	const p = (h: string) => { const n = parseInt(h.replace('#', ''), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
	const A = p(a), B = p(b);
	return `rgb(${A.map((v, i) => Math.round(lerp(v, B[i], k))).join(',')})`;
};
