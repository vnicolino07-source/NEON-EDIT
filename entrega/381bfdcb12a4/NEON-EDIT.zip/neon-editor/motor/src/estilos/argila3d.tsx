/**
 * ESTILO "ARGILA 3D" — um objeto 3D de "massinha" (cantos arredondados, luz de estúdio macia) por ideia,
 * no centro, entrando com pop e foco; números grandes e títulos curtos em 2D por cima.
 * Bom para: notícias, política, economia, dinheiro, tecnologia do dia a dia, "como funciona".
 * Objetos procedurais (sem arquivos): calendario, documento, moeda, barras, celular, pino, relogio,
 * pizza, lupa, balao, carimbo, predio. Cada "tomada" = {obj, at, ate, args}.
 */
import React, {useCallback} from 'react';
import * as THREE from 'three';
import {RoundedBoxGeometry} from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import {ThreeLayer, ThreeCtx} from '../components/three/ThreeLayer';
import {clamp, easeBack, easeOut, lerp} from './base';

export type ArgilaPal = {accent: string; clay: string; dark: string; bg: string; bg2: string; floor: string};
export const ARGILA: ArgilaPal = {accent: '#2F7BFF', clay: '#F1EEE8', dark: '#2A2D34', bg: '#0E1016', bg2: '#1A1E28', floor: '#151820'};
export type Shot = {obj: string; at: number; ate: number; args?: Record<string, unknown>; x?: number; y?: number; s?: number};

const C = (h: string) => new THREE.Color(h);
const clay = (h: string, extra: Partial<THREE.MeshStandardMaterialParameters> = {}) => new THREE.MeshStandardMaterial({color: C(h), roughness: 0.62, metalness: 0.02, ...extra});
const rbox = (w: number, h: number, d: number, r: number, m: THREE.Material) => { const o = new THREE.Mesh(new RoundedBoxGeometry(w, h, d, 4, r), m); o.castShadow = true; o.receiveShadow = true; return o; };
const cyl = (rt: number, rb: number, h: number, m: THREE.Material, seg = 48) => { const o = new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, seg), m); o.castShadow = true; o.receiveShadow = true; return o; };
const texFrom = (w: number, h: number, draw: (g: CanvasRenderingContext2D) => void) => { const c = document.createElement('canvas'); c.width = w; c.height = h; const g = c.getContext('2d')!; draw(g); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return t; };
const plane = (w: number, h: number, tex: THREE.Texture) => new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshStandardMaterial({map: tex, roughness: 0.8, transparent: true}));

type Built = {g: THREE.Group; tick?: (t: number, local: number) => void};
const FACT: Record<string, (p: ArgilaPal, a: Record<string, unknown>) => Built> = {
	calendario: (p, a) => {
		const g = new THREE.Group();
		g.add(rbox(1.8, 1.9, 0.28, 0.12, clay(p.clay)));
		const top = rbox(1.8, 0.5, 0.32, 0.12, clay(p.accent)); top.position.y = 0.72; g.add(top);
		[-0.45, 0.45].forEach((x) => { const r = cyl(0.07, 0.07, 0.4, clay(p.dark)); r.position.set(x, 0.98, 0); g.add(r); });
		const day = String(a.dia ?? '');
		const t = texFrom(512, 512, (c) => { c.fillStyle = '#0000'; c.clearRect(0, 0, 512, 512); if (day) { c.fillStyle = p.dark; c.font = '800 250px XInter, sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(day, 256, 280); } else { c.fillStyle = p.dark; for (let r = 0; r < 4; r++) for (let k = 0; k < 6; k++) { const hi = (a.marca as number | undefined) === r * 6 + k; c.fillStyle = hi ? p.accent : '#B9B4AC'; c.beginPath(); c.roundRect(48 + k * 72, 120 + r * 92, 52, 60, 10); c.fill(); } } });
		const pl = plane(1.6, 1.6, t); pl.position.set(0, -0.17, 0.15); g.add(pl);
		return {g};
	},
	documento: (p, a) => {
		const g = new THREE.Group();
		const sheet = rbox(1.5, 2.0, 0.06, 0.03, clay('#FFFFFF')); g.add(sheet);
		const t = texFrom(384, 512, (c) => { c.clearRect(0, 0, 384, 512); c.fillStyle = '#9A958D'; for (let i = 0; i < 9; i++) { c.beginPath(); c.roundRect(48, 90 + i * 38, i % 3 === 2 ? 180 : 288, 12, 6); c.fill(); } c.fillStyle = p.accent; c.beginPath(); c.roundRect(48, 90 + 3 * 38, 220, 12, 6); c.fill(); if (a.carimbo) { c.strokeStyle = p.accent; c.lineWidth = 8; c.beginPath(); c.arc(280, 440, 46, 0, 6.3); c.stroke(); } });
		const pl = plane(1.5, 2.0, t); pl.position.z = 0.04; g.add(pl);
		const clip = rbox(0.5, 0.18, 0.12, 0.05, clay(p.dark)); clip.position.set(0, 1.0, 0.05); g.add(clip);
		return {g};
	},
	moeda: (p, a) => {
		const g = new THREE.Group();
		const c = cyl(1, 1, 0.24, clay(p.accent, {metalness: 0.25, roughness: 0.4})); c.rotation.x = Math.PI / 2; g.add(c);
		const t = texFrom(512, 512, (x) => { x.clearRect(0, 0, 512, 512); x.strokeStyle = 'rgba(255,255,255,.55)'; x.lineWidth = 14; x.beginPath(); x.arc(256, 256, 200, 0, 6.3); x.stroke(); x.fillStyle = '#FFFFFF'; x.font = '800 260px XInter, sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText(String(a.simbolo ?? '$'), 256, 270); });
		const f = plane(1.9, 1.9, t); f.position.z = 0.13; g.add(f);
		return {g, tick: (t) => { g.rotation.y = Math.sin(t * 1.4) * 0.5; }};
	},
	barras: (p, a) => {
		const g = new THREE.Group();
		const vals = (a.valores as number[]) ?? [0.4, 0.6, 1];
		const hl = (a.destaque as number) ?? vals.length - 1;
		const bars: THREE.Mesh[] = [];
		vals.forEach((v, i) => { const b = rbox(0.5, 1, 0.5, 0.08, clay(i === hl ? p.accent : p.clay)); b.position.x = (i - (vals.length - 1) / 2) * 0.68; g.add(b); bars.push(b); });
		const base = rbox(vals.length * 0.68 + 0.3, 0.1, 0.8, 0.04, clay(p.dark)); base.position.y = -0.05; g.add(base);
		return {g, tick: (_t, l) => bars.forEach((b, i) => { const h = Math.max(0.02, vals[i] * 1.9 * easeOut(clamp((l - 0.15 - i * 0.12) / 0.5))); b.scale.y = h; b.position.y = h / 2; })};
	},
	celular: (p, a) => {
		const g = new THREE.Group();
		g.add(rbox(1.15, 2.2, 0.16, 0.16, clay(p.accent)));
		const t = texFrom(256, 512, (c) => { c.fillStyle = '#EDEAE4'; c.beginPath(); c.roundRect(0, 0, 256, 512, 26); c.fill(); c.fillStyle = p.accent; c.beginPath(); c.roundRect(28, 60, 200, 120, 14); c.fill(); c.fillStyle = '#B9B4AC'; for (let i = 0; i < 4; i++) { c.beginPath(); c.roundRect(28, 210 + i * 46, i % 2 ? 140 : 200, 22, 11); c.fill(); } if (a.texto) { c.fillStyle = '#FFF'; c.font = '700 44px XInter'; c.textAlign = 'center'; c.fillText(String(a.texto), 128, 132); } });
		const s = plane(1.0, 2.0, t); s.position.z = 0.085; g.add(s);
		return {g};
	},
	pino: (p) => {
		const g = new THREE.Group();
		const head = new THREE.Mesh(new THREE.SphereGeometry(0.62, 48, 32), clay(p.accent)); head.position.y = 0.6; head.castShadow = true; g.add(head);
		const cone = cyl(0.42, 0.02, 1.1, clay(p.accent)); cone.position.y = -0.15; g.add(cone);
		const hole = new THREE.Mesh(new THREE.SphereGeometry(0.24, 32, 16), clay(p.clay)); hole.position.set(0, 0.62, 0.48); hole.scale.z = 0.4; g.add(hole);
		return {g, tick: (t) => { g.position.y = Math.abs(Math.sin(t * 3)) * 0.12; }};
	},
	relogio: (p) => {
		const g = new THREE.Group();
		const body = cyl(1.05, 1.05, 0.3, clay(p.accent)); body.rotation.x = Math.PI / 2; g.add(body);
		const face = cyl(0.9, 0.9, 0.32, clay(p.clay)); face.rotation.x = Math.PI / 2; g.add(face);
		const h1 = rbox(0.09, 0.5, 0.06, 0.03, clay(p.dark)); h1.geometry.translate(0, 0.25, 0); h1.position.z = 0.2; g.add(h1);
		const h2 = rbox(0.06, 0.72, 0.06, 0.03, clay(p.accent)); h2.geometry.translate(0, 0.36, 0); h2.position.z = 0.23; g.add(h2);
		for (let i = 0; i < 12; i++) { const m = rbox(0.06, 0.14, 0.04, 0.02, clay(p.dark)); const an = (i / 12) * Math.PI * 2; m.position.set(Math.sin(an) * 0.74, Math.cos(an) * 0.74, 0.18); m.rotation.z = -an; g.add(m); }
		return {g, tick: (t) => { h2.rotation.z = -t * 3; h1.rotation.z = -t * 0.25; }};
	},
	pizza: (p, a) => {
		const g = new THREE.Group();
		const parts = (a.partes as number[]) ?? [0.55, 0.3, 0.15];
		let ang = 0;
		parts.forEach((v, i) => { const th = v * Math.PI * 2; const m = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.1, 0.32, 48, 1, false, ang, th - 0.02), clay(i === 0 ? p.accent : i === 1 ? p.clay : p.dark)); m.castShadow = true; const mid = ang + th / 2; if (i === 0) m.position.set(Math.sin(mid) * 0.12, 0, Math.cos(mid) * 0.12); g.add(m); ang += th; });
		g.rotation.x = 0.9;
		return {g, tick: (t) => { g.rotation.z = Math.sin(t * 0.6) * 0.2; }};
	},
	lupa: (p) => {
		const g = new THREE.Group();
		const ring = new THREE.Mesh(new THREE.TorusGeometry(0.75, 0.16, 24, 64), clay(p.accent)); ring.castShadow = true; g.add(ring);
		const glass = new THREE.Mesh(new THREE.CircleGeometry(0.72, 48), new THREE.MeshStandardMaterial({color: C('#CFE3FF'), transparent: true, opacity: 0.35, roughness: 0.1})); g.add(glass);
		const handle = rbox(0.26, 1.1, 0.26, 0.1, clay(p.clay)); handle.position.set(0.82, -0.82, 0); handle.rotation.z = 0.78; g.add(handle);
		return {g, tick: (t) => { g.rotation.z = Math.sin(t * 2) * 0.15; }};
	},
	balao: (p, a) => {
		const g = new THREE.Group();
		g.add(rbox(1.9, 1.3, 0.3, 0.3, clay(p.accent)));
		const tail = cyl(0.01, 0.28, 0.5, clay(p.accent), 4); tail.rotation.z = 2.6; tail.position.set(-0.55, -0.72, 0); g.add(tail);
		const dots = Number(a.pontos ?? 3);
		const ms: THREE.Mesh[] = [];
		for (let i = 0; i < dots; i++) { const d = new THREE.Mesh(new THREE.SphereGeometry(0.14, 24, 16), clay(p.clay)); d.position.set((i - (dots - 1) / 2) * 0.45, 0, 0.18); g.add(d); ms.push(d); }
		return {g, tick: (t) => ms.forEach((d, i) => { d.position.y = Math.max(0, Math.sin(t * 6 - i * 0.8)) * 0.15; })};
	},
	carimbo: (p) => {
		const g = new THREE.Group();
		const base = rbox(1.2, 0.3, 1.2, 0.08, clay(p.dark)); g.add(base);
		const neck = cyl(0.18, 0.24, 0.7, clay(p.clay)); neck.position.y = 0.5; g.add(neck);
		const knob = new THREE.Mesh(new THREE.SphereGeometry(0.42, 32, 24), clay(p.accent)); knob.position.y = 1.05; knob.castShadow = true; g.add(knob);
		return {g, tick: (_t, l) => { const k = l < 0.6 ? 0 : Math.max(0, Math.sin((l - 0.6) * 6)); g.position.y = (1 - Math.min(1, k * 3)) * 0.0 + Math.max(0, 0.6 - l) * 2; }};
	},
	predio: (p) => {
		const g = new THREE.Group();
		const body = rbox(1.3, 2.4, 1.0, 0.08, clay(p.clay)); body.position.y = 1.2; g.add(body);
		for (let r = 0; r < 5; r++) for (let k = 0; k < 3; k++) { const w = rbox(0.24, 0.24, 0.05, 0.04, clay((r + k) % 4 === 0 ? p.accent : p.dark)); w.position.set((k - 1) * 0.36, 0.45 + r * 0.42, 0.51); g.add(w); }
		const roof = rbox(1.45, 0.14, 1.15, 0.05, clay(p.accent)); roof.position.y = 2.45; g.add(roof);
		g.position.y = -1.2;
		return {g};
	},
};
export const ARGILA_OBJS = Object.keys(FACT);

type St = {items: {shot: Shot; b: Built}[]; floor: THREE.Mesh};
/** palco 3D: um objeto por vez (ou mais, com x/y), entrando com pop, girando de leve e flutuando */
export const ArgilaStage: React.FC<{t: number; shots: Shot[]; pal?: ArgilaPal; camY?: number}> = ({t, shots, pal = ARGILA, camY = 0.4}) => {
	const init = useCallback(({scene, camera}: Omit<ThreeCtx<St>, 'state'>): St => {
		camera.fov = 30; camera.position.set(0, camY + 0.2, 11.5); camera.lookAt(0, camY - 0.75, 0); camera.updateProjectionMatrix();
		scene.add(new THREE.HemisphereLight(0xffffff, C(pal.bg2), 1.1));
		const key = new THREE.DirectionalLight(0xffffff, 2.2); key.position.set(3, 6, 6); key.castShadow = true; key.shadow.mapSize.set(1024, 1024); key.shadow.camera.left = -5; key.shadow.camera.right = 5; key.shadow.camera.top = 5; key.shadow.camera.bottom = -5; key.shadow.radius = 8; scene.add(key);
		const rim = new THREE.DirectionalLight(C(pal.accent), 1.2); rim.position.set(-5, 3, -4); scene.add(rim);
		const floor = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), new THREE.ShadowMaterial({opacity: 0.35})); floor.rotation.x = -Math.PI / 2; floor.position.y = -1.35; floor.receiveShadow = true; scene.add(floor);
		const items = shots.map((shot) => { const f = FACT[shot.obj]; if (!f) throw new Error('objeto 3D desconhecido: ' + shot.obj); const b = f(pal, shot.args ?? {}); b.g.visible = false; scene.add(b.g); return {shot, b}; });
		return {items, floor};
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);
	const update = useCallback(({state}: ThreeCtx<St>, tt: number) => {
		state.items.forEach(({shot, b}) => {
			const vis = tt >= shot.at - 0.02 && tt < shot.ate + 0.3;
			b.g.visible = vis;
			if (!vis) return;
			const l = tt - shot.at;
			const kin = easeBack(clamp(l / 0.45));
			const kout = clamp((tt - shot.ate) / 0.28);
			const s = (shot.s ?? 1) * lerp(0.2, 1, kin) * (1 - 0.6 * kout);
			b.g.scale.setScalar(Math.max(0.001, s));
			const base = b.g.userData.baseY ?? (b.g.userData.baseY = b.g.position.y);
			b.g.position.set(shot.x ?? 0, base + (shot.y ?? 0) + Math.sin(tt * 1.6) * 0.06 + (1 - kin) * -0.6, 0);
			b.g.rotation.y = (b.g.userData.ry0 ?? 0) + Math.sin(tt * 0.7 + shot.at) * 0.35 + (1 - kin) * 1.2;
			b.tick?.(tt, l);
		});
	}, []);
	return <ThreeLayer t={t} init={init} update={update} shadows />;
};
/** cenário de fundo do palco (estúdio escuro com chão e brilho atrás) */
export const ArgilaBg: React.FC<{t: number; pal?: ArgilaPal; kind?: 'estudio' | 'cidade'}> = ({t, pal = ARGILA, kind = 'estudio'}) => (
	<>
		<div style={{position: 'absolute', inset: 0, background: `linear-gradient(${pal.bg2}, ${pal.bg} 62%, ${pal.floor} 62.2%, ${pal.bg} 100%)`}} />
		<div style={{position: 'absolute', left: -200, right: -200, top: 380, height: 900, background: `radial-gradient(ellipse at 50% 50%, ${pal.accent}22, transparent 60%)`, transform: `translateX(${Math.sin(t * 0.3) * 20}px)`}} />
		{kind === 'cidade' ? <div style={{position: 'absolute', left: -40, right: -40, top: 700, height: 500, display: 'flex', alignItems: 'flex-end', gap: 14, opacity: 0.55, transform: `translateX(${-t * 6}px)`}}>{Array.from({length: 14}).map((_, i) => <div key={i} style={{width: 90 + ((i * 37) % 60), height: 220 + ((i * 53) % 260), background: i % 3 ? pal.bg2 : pal.dark, borderRadius: '8px 8px 0 0', backgroundImage: `linear-gradient(90deg, transparent 40%, ${pal.accent}33 40%, ${pal.accent}33 55%, transparent 55%)`, backgroundSize: '30px 40px'}} />)}</div> : null}
		<div style={{position: 'absolute', left: 0, right: 0, top: 1188, height: 3, background: `linear-gradient(90deg, transparent, ${pal.accent}55, transparent)`}} />
	</>
);
