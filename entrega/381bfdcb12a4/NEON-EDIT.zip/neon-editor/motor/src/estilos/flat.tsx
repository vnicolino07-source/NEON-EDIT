/**
 * ESTILO "FLAT" — minimalista chapado: formas geométricas sólidas, cores vibrantes, bonequinho simples,
 * transições de círculo que cobre a tela. O mais versátil (serve para quase tudo e qualquer marca).
 * Bom para: dicas, listas, finanças pessoais, saúde/hábitos, produto, institucional leve.
 * Legenda recomendada: KCap kind="pilula" accent={FLAT.c4}  (ou kind="escuro" ink={FLAT.ink} se o fundo for claro).
 */
import React from 'react';
import {XFONT, ph, easeBack, easeInOut, clamp, lerp, rnd} from './base';
import {ICONS} from './linha';

export const FLAT = {bg: '#FFF4E4', ink: '#1D1D1F', c1: '#FF5A5F', c2: '#3D5AFE', c3: '#00B894', c4: '#FFC145', pele: '#F2B48C'} as const;
export type FlatPal = {bg: string; ink: string; c1: string; c2: string; c3: string; c4: string; pele: string};

/** fundo liso com formas grandes desfocadas que flutuam devagar */
export const FlatBg: React.FC<{t: number; pal?: FlatPal; cor?: string}> = ({t, pal = FLAT, cor}) => (
	<>
		<div style={{position: 'absolute', inset: 0, background: cor ?? pal.bg}} />
		{[pal.c1, pal.c2, pal.c3, pal.c4].map((c, i) => <div key={i} style={{position: 'absolute', left: rnd(i + 2) * 900 - 150 + Math.sin(t * 0.5 + i) * 20, top: rnd(i + 9) * 1500 + Math.cos(t * 0.4 + i) * 20, width: 260 + i * 40, height: 260 + i * 40, borderRadius: i % 2 ? '50%' : 60, background: c, opacity: 0.12, transform: `rotate(${t * 6 + i * 30}deg)`}} />)}
	</>
);

type Kind = 'circulo' | 'quadrado' | 'triangulo' | 'pilula' | 'anel' | 'estrela';
/** forma que entra com pop e flutua; use várias para compor cenas */
export const Forma: React.FC<{t: number; at: number; kind: Kind; x: number; y: number; size: number; color: string; rot?: number; until?: number; float?: number}> = ({t, at, kind, x, y, size, color, rot = 0, until = 1e9, float = 8}) => {
	if (t < at - 0.02 || t > until + 0.3) return null;
	const k = ph(t, at, 0.4, easeBack) * (1 - ph(t, until, 0.25));
	const fy = Math.sin(t * 1.6 + x * 0.01) * float;
	const common: React.CSSProperties = {position: 'absolute', left: x - size / 2, top: y - size / 2 + fy, width: size, height: size, transform: `scale(${k}) rotate(${rot + (1 - k) * -40}deg)`};
	if (kind === 'circulo') return <div style={{...common, borderRadius: '50%', background: color}} />;
	if (kind === 'anel') return <div style={{...common, borderRadius: '50%', border: `${size * 0.16}px solid ${color}`}} />;
	if (kind === 'quadrado') return <div style={{...common, borderRadius: size * 0.16, background: color}} />;
	if (kind === 'pilula') return <div style={{...common, height: size * 0.42, top: y - size * 0.21 + fy, borderRadius: size, background: color}} />;
	const d = kind === 'triangulo' ? 'M50 6 L96 90 L4 90 Z' : 'M50 4 L62 36 L96 38 L69 59 L79 94 L50 74 L21 94 L31 59 L4 38 L38 36 Z';
	return <svg viewBox="0 0 100 100" style={common}><path d={d} fill={color} strokeLinejoin="round" stroke={color} strokeWidth={6} /></svg>;
};

/** bonequinho flat (cabeça + corpo arredondado + braços). acao: 'acena' | 'pensa' | 'comemora' | 'parado' */
export const Boneco: React.FC<{t: number; at: number; x: number; y: number; h?: number; cor: string; pal?: FlatPal; acao?: 'acena' | 'pensa' | 'comemora' | 'parado'; until?: number}> = ({t, at, x, y, h = 520, cor, pal = FLAT, acao = 'parado', until = 1e9}) => {
	if (t < at - 0.02 || t > until + 0.3) return null;
	const k = ph(t, at, 0.45, easeBack) * (1 - ph(t, until, 0.25));
	const s = h / 520;
	const wave = acao === 'acena' ? Math.sin(t * 8) * 20 : 0;
	const bob = Math.sin(t * 3) * 4;
	return (
		<svg width={360 * s} height={h} viewBox="0 0 360 520" style={{position: 'absolute', left: x - 180 * s, top: y - h, transform: `translateY(${(1 - k) * 80}px)`, opacity: clamp(k * 2), overflow: 'visible'}}>
			<g transform={`translate(0 ${bob})`}>
				<path d="M110 520 V330 C110 260 140 230 180 230 C220 230 250 260 250 330 V520 Z" fill={cor} />
				<g transform={`rotate(${acao === 'acena' ? -150 + wave : acao === 'comemora' ? -160 : acao === 'pensa' ? -120 : 10} 240 270)`}><rect x={232} y={262} width={26} height={150} rx={13} fill={cor} /><circle cx={245} cy={412} r={18} fill={pal.pele} /></g>
				<g transform={`rotate(${acao === 'comemora' ? 160 : -10} 120 270)`}><rect x={102} y={262} width={26} height={150} rx={13} fill={cor} /><circle cx={115} cy={412} r={18} fill={pal.pele} /></g>
				<circle cx={180} cy={160} r={68} fill={pal.pele} />
				<path d="M112 150 C112 96 150 82 182 84 C222 86 250 110 248 150 C230 128 196 120 160 124 C140 126 124 136 112 150 Z" fill={pal.ink} />
				<circle cx={158} cy={168} r={7} fill={pal.ink} /><circle cx={204} cy={168} r={7} fill={pal.ink} />
				<path d={acao === 'pensa' ? 'M166 198 H196' : 'M162 194 C172 206 192 206 200 194'} stroke={pal.ink} strokeWidth={6} fill="none" strokeLinecap="round" />
				{acao === 'pensa' ? <g opacity={ph(t, at + 0.4, 0.3)}><circle cx={290} cy={70} r={12} fill="#fff" /><circle cx={320} cy={30} r={20} fill="#fff" /></g> : null}
			</g>
		</svg>
	);
};

/** ícone da biblioteca em traço grosso arredondado dentro de um círculo colorido */
export const FlatIcon: React.FC<{t: number; at: number; name: string; x: number; y: number; size?: number; bg: string; ink?: string; until?: number}> = ({t, at, name, x, y, size = 260, bg, ink = '#FFFFFF', until = 1e9}) => {
	const ic = ICONS[name];
	if (!ic || t < at - 0.02 || t > until + 0.3) return null;
	const k = ph(t, at, 0.4, easeBack) * (1 - ph(t, until, 0.25));
	const kd = ph(t, at + 0.15, 0.6, easeInOut);
	return (
		<div style={{position: 'absolute', left: x - size / 2, top: y - size / 2, width: size, height: size, borderRadius: '50%', background: bg, transform: `scale(${k})`, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 18px 0 rgba(0,0,0,.08)'}}>
			<svg width={size * 0.58} height={size * 0.58} viewBox="0 0 100 100">{ic.d.map((p, i) => <path key={i} d={p} pathLength={1} fill="none" stroke={ink} strokeWidth={8} strokeLinecap="round" strokeLinejoin="round" strokeDasharray="1 1" strokeDashoffset={1 - kd} />)}</svg>
		</div>
	);
};

/** item de lista numerado (para "3 dicas", "5 sinais"…) — texto CURTO, a narração explica */
export const ListaItem: React.FC<{t: number; at: number; n: number; text: string; y: number; cor: string; pal?: FlatPal; until?: number}> = ({t, at, n, text, y, cor, pal = FLAT, until = 1e9}) => {
	if (t < at - 0.02 || t > until + 0.3) return null;
	const k = ph(t, at, 0.4, easeBack) * (1 - ph(t, until, 0.25));
	return (
		<div style={{position: 'absolute', left: 110, right: 110, top: y, display: 'flex', alignItems: 'center', gap: 28, transform: `translateX(${(1 - k) * -120}px)`, opacity: clamp(k * 2)}}>
			<div style={{width: 110, height: 110, borderRadius: 30, background: cor, color: '#fff', fontFamily: XFONT.sans, fontWeight: 800, fontSize: 64, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0}}>{n}</div>
			<div style={{fontFamily: XFONT.sans, fontWeight: 800, fontSize: 54, lineHeight: 1.05, color: pal.ink, letterSpacing: '-0.02em'}}>{text}</div>
		</div>
	);
};

/** transição: círculo de cor cresce a partir de (x,y) e cobre a tela; depois some revelando a próxima cena */
export const Cobertura: React.FC<{t: number; at: number; cor: string; x?: number; y?: number; dur?: number}> = ({t, at, cor, x = 540, y = 960, dur = 0.5}) => {
	if (t < at || t > at + dur * 2) return null;
	const a = ph(t, at, dur, easeInOut), b = ph(t, at + dur, dur, easeInOut);
	const R = 2300;
	return <div style={{position: 'absolute', inset: 0, background: cor, clipPath: b > 0 ? `circle(${(1 - b) * R}px at ${1080 - x}px ${1920 - y}px)` : `circle(${a * R}px at ${x}px ${y}px)`}} />;
};
export {lerp};
