/**
 * ESTILOS EXPLICATIVOS — base comum (vídeos feitos a partir de um TEMA, sem gravação da pessoa).
 * Legenda karaokê, entrada com foco (blur → nítido), número grande, rótulos e transições.
 * Guia: references/20-videos-por-tema.md e references/21-estilos-explicativos.md
 */
import React from 'react';
import {continueRender, delayRender, staticFile} from 'remotion';
import {WORDS, FPS, TOTAL_FRAMES} from '../engine/timing';

export const clamp = (x: number) => Math.max(0, Math.min(1, x));
export const lerp = (a: number, b: number, k: number) => a + (b - a) * k;
export const rnd = (i: number) => { const x = Math.sin(i * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };
export const nrm = (s: string) => s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]/g, '');
export const easeOut = (x: number) => 1 - Math.pow(1 - clamp(x), 3);
export const easeInOut = (x: number) => { const k = clamp(x); return k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2; };
/** entrada com leve passada do ponto (pop) */
export const easeBack = (x: number) => { const k = clamp(x); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(k - 1, 3) + c1 * Math.pow(k - 1, 2); };
export const ph = (t: number, at: number, d: number, e: (x: number) => number = easeOut) => e(clamp((t - at) / d));
export const END = TOTAL_FRAMES / FPS;
export const alpha = (hex: string, a: number) => { const h = hex.replace('#', ''); const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16); return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`; };
/** tempo (s) da palavra mais próxima de `near` */
export const N = (w: string, near: number) => {
	let best = -1, bd = 1e9;
	WORDS.forEach((x, i) => { if (nrm(x.w) === nrm(w) && Math.abs(x.start - near) < bd) { bd = Math.abs(x.start - near); best = i; } });
	if (best < 0 || bd > 1.5) throw new Error(`palavra ${w} perto de ${near} não encontrada`);
	return WORDS[best].start;
};

// ---------------- fontes ----------------
export const XFONT = {
	sans: `'XInter', 'Inter', ui-sans-serif, system-ui, sans-serif`,
	serif: `'XGaramond', 'EB Garamond', Georgia, serif`,
	mono: `'XMono', ui-monospace, Menlo, monospace`,
	giz: `'XGiz', 'Caveat', cursive`,
	impacto: `'XAnton', 'Anton', Impact, sans-serif`,
	maquina: `'XMaquina', 'Courier Prime', 'Courier New', monospace`,
	retro: `'XRetro', 'Orbitron', sans-serif`,
	jornal: `'XJornal', 'Playfair Display', Georgia, serif`,
} as const;
let fontsDone = false;
export const ensureXFonts = () => {
	if (fontsDone || typeof document === 'undefined') return;
	fontsDone = true;
	const f = (fam: string, file: string, w: number, st = 'normal') => `@font-face{font-family:'${fam}';src:url('${staticFile('fonts/' + file)}') format('${file.endsWith('ttf') ? 'truetype' : 'woff2'}');font-weight:${w};font-style:${st};font-display:block;}`;
	const css = [400, 500, 600, 700, 800].map((w) => f('XInter', `Inter-${w}.woff2`, w)).join('') + [400, 500, 600, 700].map((w) => f('XGaramond', `EBGaramond-${w}.woff2`, w)).join('') + f('XGaramond', 'EBGaramond-400-italic.woff2', 400, 'italic') + f('XMono', 'JetBrainsMono-400.ttf', 400) + f('XMono', 'JetBrainsMono-500.ttf', 500) + f('XMono', 'JetBrainsMono-500.ttf', 700)
		+ f('XGiz', 'Caveat-400.woff2', 400) + f('XGiz', 'Caveat-700.woff2', 700) + f('XAnton', 'Anton-400.woff2', 400) + f('XAnton', 'Anton-400.woff2', 800)
		+ f('XMaquina', 'CourierPrime-400.woff2', 400) + f('XMaquina', 'CourierPrime-700.woff2', 700) + f('XRetro', 'Orbitron-700.woff2', 700) + f('XRetro', 'Orbitron-900.woff2', 900)
		+ f('XJornal', 'PlayfairDisplay-700.woff2', 700) + f('XJornal', 'PlayfairDisplay-900.woff2', 900);
	const st = document.createElement('style');
	st.textContent = css;
	document.head.appendChild(st);
	const h = delayRender('xfonts');
	Promise.all(['400 20px XInter', '700 20px XInter', '800 20px XInter', '400 20px XGaramond', '600 20px XGaramond', 'italic 400 20px XGaramond', '400 20px XMono', '700 20px XGiz', '400 20px XAnton', '400 20px XMaquina', '700 20px XMaquina', '900 20px XRetro', '900 20px XJornal', '700 20px XJornal'].map((x) => document.fonts.load(x))).then(() => continueRender(h), () => continueRender(h));
};

// ---------------- legenda karaokê ----------------
export type CapStyle = 'escuro' | 'papel' | 'pilula' | 'suave';
export type Chunk = {i0: number; i1: number; start: number; end: number};
/** agrupa as palavras faladas em blocos curtos (até `max` palavras / 1,8 s, quebra em pontuação e pausas) */
export const chunkWords = (max = 4): Chunk[] => {
	const out: Chunk[] = [];
	let s = 0;
	for (let i = 0; i < WORDS.length; i++) {
		const w = WORDS[i], nx = WORDS[i + 1];
		const n = i - s + 1;
		const dur = w.end - WORDS[s].start;
		const punct = /[.,!?;:]$/.test(w.w);
		const gap = nx ? nx.start - w.end : 9;
		if (!nx || punct || gap > 0.35 || n >= max || dur > 1.8) { out.push({i0: s, i1: i, start: WORDS[s].start, end: w.end}); s = i + 1; }
	}
	return out;
};
const CHUNKS_CACHE: Record<number, Chunk[]> = {};
export const KCap: React.FC<{t: number; kind: CapStyle; hl?: Set<string>; accent: string; off?: boolean; y?: number; max?: number; size?: number; ink?: string; font?: string; weight?: number; glow?: string; dim?: string}> = ({t, kind, hl = new Set(), accent, off, y = 1400, max = 4, size, ink, font, weight, glow, dim: dimCol}) => {
	const chunks = (CHUNKS_CACHE[max] ||= chunkWords(max));
	const c = chunks.find((ch, i) => { const nx = chunks[i + 1]; const until = nx ? Math.min(nx.start - 0.02, ch.end + 0.6) : ch.end + 1; return t >= ch.start - 0.05 && t < until; });
	if (!c || off) return null;
	const words = WORDS.slice(c.i0, c.i1 + 1);
	const fs = size ?? (kind === 'papel' ? 58 : 54);
	const base: React.CSSProperties = kind === 'papel' ? {fontFamily: font ?? XFONT.serif, fontWeight: weight ?? 500, color: ink ?? '#2B2118'} : {fontFamily: font ?? XFONT.sans, fontWeight: weight ?? (kind === 'suave' ? 500 : 700), color: ink ?? '#FFFFFF'};
	const k = ph(t, c.start - 0.05, 0.12);
	return (
		<div style={{position: 'absolute', left: 60, right: 60, top: y, transform: `translateY(-50%) translateY(${(1 - k) * 10}px)`, opacity: k * (1 - ph(t, END - 0.25, 0.25)), display: 'flex', justifyContent: 'center'}}>
			<div style={{display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: `0 ${fs * 0.26}px`, padding: kind === 'pilula' ? '10px 22px' : 0, borderRadius: 14, background: kind === 'pilula' ? 'rgba(10,10,12,.82)' : undefined, maxWidth: 900}}>
				{words.map((w, j) => {
					const said = t >= w.start - 0.03;
					const active = said && t < w.end + 0.05;
					const key = hl.has(nrm(w.w));
					const dim = kind === 'suave' ? 0.38 : kind === 'papel' ? 0.0 : 0.0;
					const op = said ? 1 : dim;
					const col = key && said ? (kind === 'papel' ? '#2B2118' : accent) : kind === 'suave' ? (active ? (ink ?? '#FFFFFF') : (dimCol ?? '#9A9A9A')) : base.color;
					return (
						<span key={j} style={{...base, fontSize: fs, lineHeight: 1.18, opacity: op, color: col, fontWeight: kind === 'suave' && !weight ? (active || key ? 700 : 500) : base.fontWeight, position: 'relative', textShadow: glow && said ? `0 0 18px ${glow}, 0 0 4px ${glow}` : kind === 'escuro' || kind === 'suave' ? '0 3px 14px rgba(0,0,0,.55)' : undefined}}>
							{key && said && kind === 'papel' ? <span style={{position: 'absolute', left: -6, right: -6, top: '14%', bottom: '8%', background: accent, opacity: 0.85, transform: 'rotate(-1.5deg)', zIndex: -1, borderRadius: 3}} /> : null}
							<span style={{position: 'relative'}}>{w.w}</span>
						</span>
					);
				})}
			</div>
		</div>
	);
};

// ---------------- entradas e blocos ----------------
/** entra com foco (blur → nítido) e pop; sai com blur */
export const Pop: React.FC<{t: number; at: number; until?: number; d?: number; blur?: number; children: React.ReactNode; style?: React.CSSProperties; from?: number}> = ({t, at, until = 1e9, d = 0.35, blur = 18, children, style, from = 0.55}) => {
	if (t < at - 0.01 || t > until + 0.3) return null;
	const k = ph(t, at, d, easeBack);
	const kb = ph(t, at, d * 0.9);
	const o = ph(t, until, 0.25);
	return <div style={{position: 'absolute', inset: 0, opacity: clamp(kb * 1.4) * (1 - o), transform: `scale(${lerp(from, 1, k) * (1 + 0.04 * o)})`, filter: `blur(${(1 - kb) * blur + o * blur}px)`, ...style}}>{children}</div>;
};
/** número grande com legenda pequena (dados ditos na narração) */
export const BigStat: React.FC<{t: number; at: number; value: string; label?: string; color: string; sub?: string; size?: number; font?: string; y?: number}> = ({t, at, value, label, color, sub = '#D9D9D9', size = 200, font = XFONT.sans, y = 520}) => {
	const k = ph(t, at, 0.4, easeBack);
	return (
		<div style={{position: 'absolute', left: 0, right: 0, top: y, display: 'flex', flexDirection: 'column', alignItems: 'center', opacity: clamp(k * 1.5), transform: `scale(${lerp(0.6, 1, k)})`, filter: `blur(${(1 - clamp(k)) * 12}px)`}}>
			<span style={{fontFamily: font, fontWeight: 800, fontSize: size, color, letterSpacing: '-0.04em', lineHeight: 1}}>{value}</span>
			{label ? <span style={{marginTop: 14, fontFamily: XFONT.sans, fontWeight: 500, fontSize: 32, color: sub}}>{label}</span> : null}
		</div>
	);
};
/** título curto no topo, escrito palavra a palavra (gancho / tópico) */
export const TopTitle: React.FC<{t: number; at: number; text: string; color: string; accent: string; hl?: string[]; until?: number; y?: number; font?: string; size?: number}> = ({t, at, text, color, accent, hl = [], until = 1e9, y = 300, font = XFONT.sans, size = 64}) => {
	if (t < at || t > until + 0.3) return null;
	const ws = text.split(' ');
	const o = ph(t, until, 0.25);
	return (
		<div style={{position: 'absolute', left: 70, right: 70, top: y, display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: `0 ${size * 0.25}px`, opacity: 1 - o, filter: `blur(${o * 10}px)`}}>
			{ws.map((w, i) => { const k = ph(t, at + i * 0.09, 0.2); return <span key={i} style={{fontFamily: font, fontWeight: 800, fontSize: size, lineHeight: 1.08, color: hl.includes(nrm(w)) ? accent : color, opacity: k, transform: `translateY(${(1 - k) * 14}px)`, letterSpacing: '-0.02em'}}>{w}</span>; })}
		</div>
	);
};
/** perfil/assinatura pequena no topo (da própria pessoa — nunca de outro criador) */
export const Handle: React.FC<{text: string; color: string}> = ({text, color}) => <div style={{position: 'absolute', left: 0, right: 0, top: 96, textAlign: 'center', fontFamily: XFONT.sans, fontWeight: 600, fontSize: 22, color, opacity: 0.75, letterSpacing: '0.02em'}}>{text}</div>;
/** grão de filme leve, determinístico */
export const Grain: React.FC<{t: number; o?: number}> = ({t, o = 0.06}) => <div style={{position: 'absolute', inset: -20, opacity: o, backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='220' height='220'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' seed='${Math.floor(t * 12) % 7}'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>")`, mixBlendMode: 'overlay', pointerEvents: 'none'}} />;
/** cenas: intervalo [início, fim) com entrada/saída por foco */
export const on = (t: number, a: number, b: number) => t >= a - 0.02 && t < b + 0.3;
export const sceneK = (t: number, a: number, b: number) => ph(t, a - 0.05, 0.3) * (1 - ph(t, b - 0.05, 0.3));
