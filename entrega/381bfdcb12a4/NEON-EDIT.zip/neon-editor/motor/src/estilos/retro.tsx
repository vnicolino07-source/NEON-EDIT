/**
 * ESTILO "RETRÔ" — anos 80 / synthwave / VHS: céu degradê, sol listrado, grade em perspectiva correndo,
 * texto cromado com brilho neon, camada de fita VHS (scanlines, faixa de tracking, aberração de cor).
 * Bom para: nostalgia, games, música, cultura pop, "como era antes", tecnologia antiga.
 * Legenda recomendada: KCap kind="suave" font={XFONT.retro} weight={700} size={44} ink="#FFFFFF" glow={RETRO.rosa} accent={RETRO.ciano}.
 */
import React from 'react';
import {XFONT, ph, easeBack, clamp, lerp, rnd} from './base';

export const RETRO = {ceu1: '#0A0418', ceu2: '#2B0B4A', ceu3: '#7A1E6C', rosa: '#FF3EA5', ciano: '#2DE2E6', amarelo: '#FFD319', roxo: '#7A2BF5'} as const;
export type RetroPal = {ceu1: string; ceu2: string; ceu3: string; rosa: string; ciano: string; amarelo: string; roxo: string};

/** cenário: estrelas, sol listrado, montanhas em linha e chão de grade em perspectiva. horizon = y do horizonte */
export const RetroBg: React.FC<{t: number; pal?: RetroPal; horizon?: number; sol?: boolean; speed?: number}> = ({t, pal = RETRO, horizon = 1060, sol = true, speed = 1}) => {
	const H = 1920 - horizon;
	const rows = 14;
	const off = (t * speed * 0.9) % 1;
	return (
		<>
			<div style={{position: 'absolute', inset: 0, background: `linear-gradient(180deg, ${pal.ceu1} 0%, ${pal.ceu2} ${(horizon / 1920) * 70}%, ${pal.ceu3} ${(horizon / 1920) * 100}%, ${pal.ceu1} ${(horizon / 1920) * 100}%)`}} />
			{Array.from({length: 70}).map((_, i) => <div key={i} style={{position: 'absolute', left: rnd(i) * 1080, top: rnd(i + 50) * (horizon - 200), width: 3, height: 3, borderRadius: 2, background: '#fff', opacity: 0.3 + 0.5 * Math.abs(Math.sin(t * 2 + i))}} />)}
			{sol ? <div style={{position: 'absolute', left: 540 - 300, top: horizon - 420, width: 600, height: 600, borderRadius: '50%', background: `linear-gradient(180deg, ${pal.amarelo}, ${pal.rosa} 75%)`, boxShadow: `0 0 120px ${pal.rosa}`, WebkitMaskImage: `repeating-linear-gradient(180deg, #000 0 ${300}px, #000 300px 330px, transparent 330px 344px, #000 344px 370px, transparent 370px 390px, #000 390px 410px, transparent 410px 434px)`, clipPath: `inset(0 0 ${600 - 420}px 0)`}} /> : null}
			<svg width={1080} height={200} style={{position: 'absolute', left: 0, top: horizon - 160}}><path d="M0 200 L120 90 L220 150 L360 40 L470 140 L560 100 L700 170 L820 60 L940 130 L1080 80 L1080 200 Z" fill={pal.ceu1} stroke={pal.ciano} strokeWidth={2.5} opacity={0.9} /></svg>
			<svg width={1080} height={H} style={{position: 'absolute', left: 0, top: horizon}}>
				<rect width={1080} height={H} fill={pal.ceu1} />
				{Array.from({length: 23}).map((_, i) => { const x = (i - 11) * 110; return <line key={i} x1={540 + x * 0.08} y1={0} x2={540 + x * 3.2} y2={H} stroke={pal.rosa} strokeWidth={2.5} opacity={0.85} />; })}
				{Array.from({length: rows}).map((_, i) => { const z = (i + 1 - off) / rows; const y = Math.pow(z, 2.4) * H; return <line key={i} x1={0} x2={1080} y1={y} y2={y} stroke={pal.rosa} strokeWidth={1 + z * 3} opacity={0.3 + z * 0.7} />; })}
				<rect width={1080} height={60} fill={`url(#rfade)`} />
				<defs><linearGradient id="rfade" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={pal.ceu3} stopOpacity={0.9} /><stop offset="1" stopColor={pal.ceu1} stopOpacity={0} /></linearGradient></defs>
			</svg>
		</>
	);
};

/** texto cromado com contorno neon; entra com pop e brilho piscando como letreiro */
export const ChromeText: React.FC<{t: number; at: number; until?: number; text: string; size?: number; y?: number; pal?: RetroPal; sub?: string}> = ({t, at, until = 1e9, text, size = 150, y = 560, pal = RETRO, sub}) => {
	if (t < at - 0.02 || t > until + 0.3) return null;
	const k = ph(t, at, 0.35, easeBack);
	const o = ph(t, until, 0.25);
	const flick = t - at < 0.5 ? (Math.sin((t - at) * 70) > -0.2 ? 1 : 0.35) : 1;
	return (
		<div style={{position: 'absolute', left: 0, right: 0, top: y, textAlign: 'center', transform: `translateY(-50%) scale(${lerp(0.6, 1, k)}) skewX(-8deg)`, opacity: clamp(k * 2) * (1 - o)}}>
			<div style={{fontFamily: XFONT.retro, fontWeight: 900, fontSize: size, lineHeight: 1, letterSpacing: '0.02em', background: 'linear-gradient(180deg, #FFFFFF 0%, #BFE9FF 38%, #2A3A7A 52%, #FFFFFF 58%, #8FD8FF 100%)', WebkitBackgroundClip: 'text', color: 'transparent', WebkitTextStroke: `2px ${pal.rosa}`, filter: `drop-shadow(0 0 ${14 * flick}px ${pal.rosa}) drop-shadow(0 6px 0 ${pal.roxo})`}}>{text}</div>
			{sub ? <div style={{marginTop: 18, fontFamily: XFONT.retro, fontWeight: 700, fontSize: size * 0.28, letterSpacing: '0.3em', color: pal.ciano, textShadow: `0 0 14px ${pal.ciano}`}}>{sub}</div> : null}
		</div>
	);
};

/** camada VHS por cima de tudo: scanlines, faixa de tracking, ruído e OSD ("PLAY ▶ 00:12") no canto superior */
export const VHS: React.FC<{t: number; osd?: boolean; forte?: number}> = ({t, osd = true, forte = 1}) => {
	const band = ((t * 0.37) % 1.4) * 1920 - 200;
	const s = Math.floor(t);
	return (
		<>
			<div style={{position: 'absolute', inset: 0, backgroundImage: 'repeating-linear-gradient(0deg, rgba(0,0,0,.28) 0 2px, transparent 2px 5px)', opacity: 0.6 * forte, pointerEvents: 'none'}} />
			<div style={{position: 'absolute', left: 0, right: 0, top: band, height: 70, background: 'linear-gradient(180deg, transparent, rgba(255,255,255,.08), transparent)', backdropFilter: 'blur(1.5px)', transform: `translateX(${Math.sin(t * 40) * 6 * forte}px)`, pointerEvents: 'none'}} />
			<div style={{position: 'absolute', inset: 0, boxShadow: 'inset 0 0 220px rgba(0,0,0,.75)', pointerEvents: 'none'}} />
			{osd ? <div style={{position: 'absolute', left: 80, top: 150, fontFamily: XFONT.mono, fontSize: 34, color: '#fff', textShadow: '2px 0 #ff2a6d, -2px 0 #05d9e8', opacity: 0.85}}>PLAY ▶<br /><span style={{fontSize: 26}}>{`00:${String(s).padStart(2, '0')}`}</span></div> : null}
		</>
	);
};

/** glitch: separa RGB e desloca faixas por ~0,25 s a partir de cada `at` */
export const Glitch: React.FC<{t: number; at: number[]; children: React.ReactNode}> = ({t, at, children}) => {
	const g = at.reduce((m, a) => Math.max(m, t >= a && t < a + 0.25 ? 1 - (t - a) / 0.25 : 0), 0);
	if (g <= 0) return <>{children}</>;
	const dx = 14 * g;
	return (
		<div style={{position: 'absolute', inset: 0}}>
			<div style={{position: 'absolute', inset: 0, transform: `translateX(${-dx}px)`, mixBlendMode: 'screen', filter: 'drop-shadow(0 0 0 #f0f) sepia(1) hue-rotate(-50deg) saturate(6)', opacity: 0.7}}>{children}</div>
			<div style={{position: 'absolute', inset: 0, transform: `translateX(${dx}px)`, mixBlendMode: 'screen', filter: 'sepia(1) hue-rotate(140deg) saturate(6)', opacity: 0.7}}>{children}</div>
			<div style={{position: 'absolute', inset: 0, clipPath: `inset(${(rnd(Math.floor(t * 30)) * 80).toFixed(0)}% 0 ${(rnd(Math.floor(t * 30) + 1) * 15).toFixed(0)}% 0)`, transform: `translateX(${Math.sin(t * 90) * 30 * g}px)`}}>{children}</div>
		</div>
	);
};
