// Voz + trilha com ducking + efeitos (mesma curva usada em harness/mix.py na renderização local).
import React from 'react';
import {Audio, Sequence, staticFile} from 'remotion';
import env from '../data/voice_env.json';

const ENV = env as number[];
export type Sfx = {at: number; name: string; vol: number};
export const musicVolume = (f: number, total: number) => {
	let v = 0;
	for (let k = -6; k <= 6; k++) v = Math.max(v, ENV[f + k] ?? 0);
	return (0.16 - 0.1 * Math.min(1, v * 4)) * Math.min(1, f / 20) * Math.min(1, (total - f) / 30);
};
export const SoundTrack: React.FC<{sfx: Sfx[]; total: number; fps?: number}> = ({sfx, total, fps = 30}) => (
	<>
		<Audio src={staticFile('audio/voice.wav')} />
		<Audio src={staticFile('audio/music.wav')} volume={(f) => musicVolume(f, total)} />
		{sfx.map((s, i) => (
			<Sequence key={i} from={Math.max(0, Math.round(s.at * fps))} durationInFrames={60} layout="none">
				<Audio src={staticFile(`sfx/${s.name}.wav`)} volume={s.vol} />
			</Sequence>
		))}
	</>
);
