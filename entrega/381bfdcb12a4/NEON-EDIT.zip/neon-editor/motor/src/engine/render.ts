import {continueRender, delayRender} from 'remotion';
declare global {
	interface Window {
		__pending?: number;
	}
}
/** segura a renderização até um recurso assíncrono terminar (Remotion delayRender + contador do renderizador local) */
export const holdRender = (label: string) => {
	if (typeof window !== 'undefined') window.__pending = (window.__pending ?? 0) + 1;
	const h = delayRender(label);
	return () => {
		if (typeof window !== 'undefined') window.__pending = (window.__pending ?? 1) - 1;
		continueRender(h);
	};
};
