import words from '../data/words.json';
import edl from '../data/edl.json';
import {Easing, interpolate} from 'remotion';

export const FPS = 30;
export const W = 1080;
export const H = 1920;

export type Word = {w: string; start: number; end: number; src: number};
export const WORDS = words as Word[];
export const EDL = edl as {
	segments: {src_start: number; src_end: number; dst_start: number; frames: number; dst_frame: number; label: string}[];
	duration: number;
};
export const TOTAL_FRAMES = EDL.segments.reduce((a, s) => a + s.frames, 0);

/** frames de cada corte (início de segmento) na timeline editada */
export const CUTS = EDL.segments.slice(1).map((s) => s.dst_frame);

const norm = (s: string) =>
	s
		.toLowerCase()
		.normalize('NFD')
		.replace(/[̀-ͯ]/g, '')
		.replace(/[^a-z0-9]/g, '');

/** índice da n-ésima ocorrência (1-based) de uma palavra falada */
export const wi = (text: string, n = 1): number => {
	let c = 0;
	for (let i = 0; i < WORDS.length; i++) {
		if (norm(WORDS[i].w) === norm(text)) {
			c++;
			if (c === n) return i;
		}
	}
	throw new Error(`Palavra não encontrada: ${text} #${n}`);
};
/** segundo (timeline editada) em que a n-ésima ocorrência de uma palavra começa */
export const T = (text: string, n = 1) => WORDS[wi(text, n)].start;
export const TE = (text: string, n = 1) => WORDS[wi(text, n)].end;
export const fr = (sec: number) => Math.round(sec * FPS);

export const ease = Easing.bezier(0.22, 1, 0.36, 1); // easeOutQuint-ish
export const easeInOut = Easing.bezier(0.65, 0, 0.35, 1);
export const easeIn = Easing.bezier(0.55, 0, 1, 0.45);

/** 0→1 entre dois tempos (segundos) com easing */
export const prog = (t: number, a: number, b: number, e = ease) =>
	interpolate(t, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: e});

/** janela: sobe em [a, a+inD], desce em [b-outD, b] */
export const win = (t: number, a: number, b: number, inD = 0.3, outD = 0.3) =>
	Math.min(prog(t, a, a + inD), 1 - prog(t, b - outD, b, easeIn));

/** mola determinística (overshoot) */
export const spring01 = (t: number, a: number, dur = 0.55, bounce = 0.35) => {
	if (t <= a) return 0;
	const x = Math.min(1, (t - a) / dur);
	const s = 1 - Math.exp(-6 * x) * Math.cos(x * Math.PI * (1.5 + bounce * 2));
	return x >= 1 ? 1 : s;
};

/** gerador pseudo-aleatório determinístico */
export const rand = (seed: number) => {
	const x = Math.sin(seed * 127.1 + 311.7) * 43758.5453;
	return x - Math.floor(x);
};
