// Monta blocos de legenda a partir de frases escritas à mão e das palavras com tempo (verifica a sincronia).
import {WORDS} from './timing';

const norm = (s: string) => s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]/g, '');
export type Tok = {text: string; hl: boolean; start: number; end: number};
export type Block = {toks: Tok[]; hidden: boolean; start: number; end: number};

/**
 * BLOCKS: uma string por bloco, na ordem da fala. *palavra* = destaque neon. "!" no início = bloco não exibido
 * (a frase já aparece como gráfico). Lança erro se o texto não bater com a transcrição.
 */
export const buildBlocks = (BLOCKS: string[]): Block[] => {
	let wi = 0;
	const out = BLOCKS.map((b) => {
		const hidden = b.startsWith('!');
		const toks = b.replace(/^!/, '').split(' ').map((r) => {
			const text = r.replace(/\*/g, '');
			const w = WORDS[wi];
			if (!w || norm(w.w) !== norm(text)) throw new Error(`Legenda fora de sincronia: "${text}" ≠ "${w?.w}" (#${wi})`);
			wi++;
			return {text, hl: r.startsWith('*'), start: w.start, end: w.end};
		});
		return {toks, hidden, start: toks[0].start, end: toks[toks.length - 1].end};
	});
	if (wi !== WORDS.length) throw new Error(`Legendas cobrem ${wi} de ${WORDS.length} palavras`);
	return out;
};
export const blockAt = (blocks: Block[], t: number) =>
	blocks.find((b, i) => {
		const next = blocks[i + 1];
		const until = next ? Math.min(next.start - 0.02, b.end + 0.7) : b.end + 1.2;
		return t >= b.start - 0.06 && t < until;
	});
