// Camada do apresentador em 1080×1920: quadro da timeline final, elementos "atrás" e recorte por máscara por cima.
import React from 'react';
import {AbsoluteFill, Img, staticFile} from 'remotion';

export const frameSrc = (f: number) => staticFile(`frames/f_${String(f).padStart(5, '0')}.jpg`);
export const fgSrc = (f: number) => staticFile(`fg/fg_${String(f).padStart(5, '0')}.webp`);

/** fgRanges: intervalos de quadros com recorte gerado E validado (tools/make_mattes2.py) */
export const Plate: React.FC<{frame: number; behind?: React.ReactNode; fgRanges?: [number, number][]; filter?: string}> = ({frame, behind, fgRanges = [], filter}) => {
	const cut = behind && fgRanges.some(([a, b]) => frame >= a && frame <= b);
	return (
		<AbsoluteFill style={{width: 1080, height: 1920}}>
			<Img src={frameSrc(frame)} style={{width: 1080, height: 1920, filter}} />
			{behind ? <AbsoluteFill>{behind}</AbsoluteFill> : null}
			{cut ? <Img src={fgSrc(frame)} style={{position: 'absolute', inset: 0, width: 1080, height: 1920, filter}} /> : null}
		</AbsoluteFill>
	);
};
