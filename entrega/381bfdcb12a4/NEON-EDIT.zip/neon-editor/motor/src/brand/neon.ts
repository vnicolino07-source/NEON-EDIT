/**
 * TOKENS DA MARCA ATIVA. Os valores de cor e fonte vêm de `marca.json` (escrito por `pipeline/neon.py marca usar <id>`
 * a partir de `config/marcas/<id>.json`). Os nomes exportados (COLOR.lime, COLOR.ink...) são históricos: "lime" = acento
 * da marca, "ink" = fundo. Assim todos os componentes aprovados funcionam com qualquer marca sem serem reescritos.
 *
 * Regra: TODO componente lê cores, fontes, raios e movimento daqui. Não use valores soltos nos componentes.
 * [exato]   = valor da Biblioteca Neon original (referência de proporção e movimento)
 * [escala]  = valor da biblioteca × SCALE (a biblioteca desenha em 270 px de largura; o vídeo tem 1080 px)
 * [derivado]= decisão técnica, ajustável
 */
import marca from './marca.json';

type Fonte = {familia: string; variavel: string; pesos?: string; arquivo_3d?: string};
type Marca = {id: string; nome: string; cores: Record<string, string>; fontes: {titulo: Fonte; mono: Fonte}; logo?: string | null};
export const MARCA = marca as unknown as Marca;
const C = MARCA.cores;
const rgb = (hex: string) => [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16));
/** cor da marca com transparência: rgba(acento, a) */
export const alpha = (hex: string, a: number) => `rgba(${rgb(hex).join(',')},${a})`;
const mix = (h1: string, h2: string, k: number) => '#' + rgb(h1).map((v, i) => Math.round(v * (1 - k) + rgb(h2)[i] * k).toString(16).padStart(2, '0')).join('');

export const SCALE = 4; // [derivado] 270 px (quadro da prévia) → 1080 px (vídeo)

export const COLOR = {
	ink: C.fundo, // fundo
	panel: C.superficie, // card
	panel2: C.superficie2 ?? mix(C.superficie, C.texto, 0.05), // card secundário / "antes"
	panel3: mix(C.superficie2 ?? C.superficie, C.fundo, 0.25), // listra escura do placeholder de imagem
	line: C.borda, // bordas e trilhos
	cam: C.area_video ?? mix(C.fundo, C.superficie, 0.8), // fundo da área do vídeo
	lime: C.acento, // ACENTO ÚNICO da marca
	limeDim: C.acento_escuro ?? mix(C.acento, C.fundo, 0.4),
	limeOnDark: C.texto_sobre_acento_escuro ?? mix(C.acento, C.fundo, 0.7),
	text: C.texto,
	mute: C.texto_secundario,
	warn: C.alerta, // risco / alerta (só para negativo)
	limeGlow: alpha(C.acento, 0.5), // pulso do botão
	limeSoft: alpha(C.acento, 0.12), // fundo do selo delta
	limeWin: alpha(C.acento, 0.22), // barra vencedora da enquete
	scanGlow: alpha(C.acento, 0.18), // varredura da imagem
	captionShadow: 'rgba(0,0,0,0.6)', // sombra da legenda
	white: '#FFFFFF',
} as const;

export const FONT = {
	display: `'${MARCA.fontes.titulo.familia}', ui-sans-serif, system-ui, sans-serif`, // títulos, cards, legendas (400/500/700)
	mono: `'${MARCA.fontes.mono.familia}', ui-monospace, Menlo, monospace`, // rótulos e números (400/500)
} as const;
/** arquivos de fonte (em motor/public) usados pelo CSS e pelo Three.js */
export const FONT_FILES = {
	display: MARCA.fontes.titulo.variavel,
	displayWeights: MARCA.fontes.titulo.pesos ?? '300 700',
	mono: MARCA.fontes.mono.variavel,
	monoWeights: MARCA.fontes.mono.pesos ?? '100 800',
	display3d: MARCA.fontes.titulo.arquivo_3d ?? MARCA.fontes.titulo.variavel,
	displayFamily: MARCA.fontes.titulo.familia,
	monoFamily: MARCA.fontes.mono.familia,
} as const;

/** tamanhos tipográficos [escala] (valor da biblioteca × 4) */
export const TYPE = {
	caption: 19 * SCALE, // 76 px — legenda 700
	label: 10 * SCALE, // 40 px — rótulo mono uppercase, letter-spacing .1em
	body: 15 * SCALE, // 60 px — linha de checklist
	bodySm: 13 * SCALE, // 52 px
	title: 18 * SCALE, // 72 px — título de card (700)
	big: 56 * SCALE, // 224 px — número do contador (700, tabular, -0.03em)
	quote: 30 * SCALE, // 120 px — frase de impacto (700, -0.02em, lh 1.05)
	cta: 40 * SCALE, // 160 px — palavra da chamada final
	value: 22 * SCALE, // 88 px — valores do antes/depois
} as const;

export const RADIUS = {
	frame: 26 * SCALE, // [escala] moldura 9:16 da prévia
	card: 14 * SCALE, // 56 px
	cam: 14 * SCALE, // 56 px — área do apresentador
	toast: 14 * SCALE,
	icon: 10 * SCALE, // 40 px
	box: 5 * SCALE, // 20 px — checkbox
	bar: 4 * SCALE, // 16 px
	mark: 4 * SCALE, // marca-texto da frase
	hl: 5 * SCALE, // 20 px — destaque da legenda
	pill: 999,
} as const;

export const SPACE = {
	framePadY: 16 * SCALE, // 64 px [escala]
	framePadX: 14 * SCALE, // 56 px
	gap: 12 * SCALE, // 48 px
	cardPad: 12 * SCALE, // 48 px
	slotMinHeight: 0.38, // [exato] área do card ocupa ≥ 38% da altura
	captionBottom: 0.16, // [exato] legenda a 16% da base da área do vídeo
	border: 1 * SCALE, // 4 px [escala] — borda 1 px na prévia
} as const;

/** a biblioteca NÃO define sombras: cards são planos com borda de 1 px (#2A2D38). */
export const SHADOW = {
	none: 'none',
	caption: `0 ${2 * SCALE}px ${10 * SCALE}px ${COLOR.captionShadow}`, // [escala] text-shadow da legenda
} as const;

/** curvas [exato] */
export const EASE = {
	brand: [0.2, 0.9, 0.25, 1.15] as const, // --ease (entrada com leve overshoot)
	standard: [0.4, 0, 0.2, 1] as const, // barras de progresso, enquete
	inOut: [0.42, 0, 0.58, 1] as const, // ease-in-out (varredura)
	css: [0.25, 0.1, 0.25, 1] as const, // "ease" do CSS (checklist, risco)
};

/** comportamentos de animação [exato], em segundos */
export const MOTION = {
	pop: {dur: 0.55, fromY: 14 * SCALE, fromScale: 0.94, ease: EASE.brand}, // entrada padrão "sobe + escala"
	cascadeStep: 0.3, // elementos em cascata (.25 .55 .85 1.15)
	cascadeFirst: 0.25,
	check: {first: 0.6, step: 0.5, fill: 0.3, draw: 0.35},
	strike: {dur: 0.4, delay: 0.7},
	grow: {dur: 2.2, delay: 0.3, ease: EASE.standard},
	drop: {dur: 0.6, fromY: -30 * SCALE, secondDelay: 0.7, ease: EASE.brand},
	rise: {dur: 0.6, stagger: 0.12, ease: EASE.brand},
	mark: {dur: 0.45, delay: 0.6, inkAt: 0.8},
	scan: {dur: 1.6, delay: 0.3, ease: EASE.inOut},
	poll: {dur: 0.9, delay: 0.5, ease: EASE.standard},
	pulse: {period: 1.6, start: 1.6, spread: 8 * SCALE},
	type: {start: 0.4, perChar: 0.055}, // digitação
	count: {start: 0.3, dur: 1.2}, // contador easeOutCubic
	caption: {perBlock: 0.9}, // na prévia; no vídeo a legenda segue as palavras reais
	blink: 1.0, // cursor
} as const;

/** regras de legenda [exato] */
export const CAPTION = {
	wordsPerBlock: [2, 3] as const,
	weight: 700,
	highlight: 'bg-neon', // palavra-chave com fundo neon e texto ink
} as const;
