import React from 'react';
import {Composition} from 'remotion';
import {Vitrine, VITRINE_FRAMES} from './library/Vitrine';
import {Video as Modelo} from './videos/_modelo/Video';
import {Video as Demonstracao} from './videos/demonstracao/Video';
import {Video as Adaptativo, ADAPTATIVO_FRAMES} from './videos/adaptativo/Video';
import {TOTAL_FRAMES} from './engine/timing';

// Cada vídeo novo ganha uma <Composition id="<id>"> apontando para src/videos/<id>/Video.tsx.
// Todas usam os dados ligados em src/data (um projeto por vez: `neon.py vincular`).
export const RemotionRoot: React.FC = () => (
	<>
		<Composition id="Vitrine" component={Vitrine} durationInFrames={VITRINE_FRAMES} fps={30} width={1080} height={1920} />
		<Composition id="Demonstracao" component={Demonstracao} durationInFrames={TOTAL_FRAMES} fps={30} width={1080} height={1920} defaultProps={{withAudio: true}} />
		<Composition id="DirecaoAdaptativa" component={Adaptativo} durationInFrames={ADAPTATIVO_FRAMES} fps={30} width={1080} height={1920} />
		<Composition id="VideoModelo" component={Modelo} durationInFrames={TOTAL_FRAMES} fps={30} width={1080} height={1920} defaultProps={{withAudio: true}} />
	</>
);
