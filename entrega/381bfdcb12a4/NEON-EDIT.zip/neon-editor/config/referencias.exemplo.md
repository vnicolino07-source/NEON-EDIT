# Referências da pessoa

Uma ficha por vídeo de referência. Preencha só com o que você realmente assistiu (tempos exatos).
Copie TÉCNICAS (ritmo, tipo de gancho, transição, composição). Não copie marca, paleta, fontes, personagens ou textos.

## R01 · <arquivo ou link> (<duração>)
- Assunto:
- Gancho (0–3 s): o que acontece e em que segundo
- Ritmo: eventos por segundo, palavras por segundo
- Técnicas a usar (com tempos):
- O que NÃO copiar:
