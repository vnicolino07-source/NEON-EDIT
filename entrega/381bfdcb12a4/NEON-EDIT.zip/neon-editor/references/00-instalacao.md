# 00 · Instalação e verificação do ambiente

## Princípios

- **Nunca instale nem baixe nada sem a pessoa autorizar** a lista exata do que será instalado, de onde vem e quanto ocupa.
- Use só fontes oficiais: nodejs.org, ffmpeg.org (ou o gerenciador de pacotes do sistema), python.org, npmjs.com (pacotes
  do Remotion e do Three.js), PyPI (numpy, scipy, onnxruntime, opencv) e as releases oficiais no GitHub de
  `k2-fsa/sherpa-onnx` e `danielgatis/rembg`.
- Não peça para desativar antivírus, firewall ou outras proteções. Não guarde senhas ou tokens em nenhum arquivo do kit.
- Se o ambiente não permitir executar comandos, **diga isso**. A instalação só é automática onde há um shell.

## Onde o editor funciona

| Modalidade do Claude | Situação |
|---|---|
| **Claude Code** (terminal ou app) na máquina da pessoa | Suportado. Tem shell e arquivos locais. Caminho principal previsto. |
| **App desktop do Claude ligado ao computador** (pasta conectada + shell no computador) | Suportado quando houver ferramenta de shell no computador. Sem shell, só dá para ler e escrever arquivos: a edição precisa de outro ambiente. |
| **Ambiente na nuvem do Claude** (sessão com Linux temporário) | Funcionou no desenvolvimento, com ressalvas: o npm e o PyPI podem estar bloqueados (o kit tem o caminho alternativo descrito em `10-renderizacao.md`), o ambiente é apagado no fim da sessão e a CPU é limitada (≈ 0,5–1,5 s por quadro em 1080×1920). |
| **Chat sem execução de código** | Não suportado: dá para planejar a edição, não para produzi-la. |

## Dependências reais

| Ferramenta | Versão usada nos vídeos aprovados | Para quê | Obrigatória |
|---|---|---|---|
| Node.js | 22 (mínimo 18) | Remotion, Three.js, renderizador | sim |
| Remotion (`remotion`, `@remotion/cli`, `@remotion/player`) | 4.0.539 | composição e render | sim |
| Three.js | 0.170.0 (r170) | 3D real (TextGeometry, TTFLoader) | sim |
| React / React DOM | 19.2 | componentes | sim |
| ffmpeg com **librubberband** | 6.1 | extração, aceleração com tom preservado, filtros de voz, loudnorm | sim |
| Python | 3.10+ (desenvolvido em 3.12) | pipeline | sim |
| numpy, scipy | 2.x / 1.x | áudio, EDL, mixagem | sim |
| onnxruntime | 1.18+ | recorte (u2net) | só para elementos atrás da pessoa |
| opencv-contrib-python-headless | 4.x/5.x **com ximgproc** | filtro guiado do recorte, webp | só para recortes |
| sherpa-onnx | 1.13.8 (binário estático) ou pacote Python | transcrição | sim |
| Modelo `sherpa-onnx-nemo-parakeet-tdt-0.6b-v3-int8` | release `asr-models` | transcrição com tempo por palavra (PT e outras 24 línguas) | sim |
| `u2net_human_seg.onnx` | release `v0.0.0` de rembg | máscara do apresentador | só para recortes |
| Chromium | o que o Remotion baixa, ou o do Playwright | render headless com WebGL | sim |
| esbuild + playwright | 0.28 / 1.63 | renderizador local alternativo (`motor/harness`) | só se o `npx remotion render` não funcionar |

Downloads dos modelos (verifique o SHA-256 depois de baixar; `instalador/baixar_modelos.py` faz isso):

| Arquivo | URL | SHA-256 do arquivo usado no projeto |
|---|---|---|
| Parakeet TDT v3 int8 (`.tar.bz2`, ~640 MB) | `https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-nemo-parakeet-tdt-0.6b-v3-int8.tar.bz2` | `5793d0fd397c5778d2cf2126994d58e9d56b1be7c04d13c7a15bb1b4eafb16bf` |
| sherpa-onnx Linux x64 estático | `https://github.com/k2-fsa/sherpa-onnx/releases/download/v1.13.8/sherpa-onnx-v1.13.8-linux-x64-static.tar.bz2` | `d265986f7b990026e45bca573415575140106a2c663014924037d8f2c2e297cc` |
| u2net_human_seg (~168 MB) | `https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2net_human_seg.onnx` | `01eb6a29a5c4d8edb30b56adad9bb3a2a0535338e480724a213e0acfd2d1c73c` |

No Windows e no macOS, use o pacote Python `sherpa-onnx` (`pip install sherpa-onnx`), que roda o mesmo modelo. O
`pipeline/neon.py` usa esse pacote automaticamente quando `asr_bin` está vazio. **Esse caminho ainda não foi testado**
(ver `references/17-pendencias-e-limitacoes.md`).

## Procedimento

1. **Verificar:** `python instalador/verificar_ambiente.py` (Windows: `py instalador\verificar_ambiente.py`).
   Se não houver Python, use `instalador/verificar_ambiente.sh` (macOS/Linux) ou `instalador/verificar_ambiente.ps1` (Windows).
   O resultado lista o que está pronto, o que falta, a versão encontrada e o comando sugerido para cada item.
2. **Mostrar à pessoa** a lista do que falta, com tamanho aproximado e origem. Perguntar se pode instalar.
3. **Instalar com autorização:** `python instalador/instalar.py` mostra cada comando e pede confirmação item por item
   (`--sim` só se a pessoa autorizou tudo explicitamente). Ferramentas de sistema (Node, ffmpeg, Python) são instaladas
   pelo gerenciador do sistema (winget, Homebrew, apt). Se não houver gerenciador, explique o download manual no site oficial.
4. **Modelos:** `python instalador/baixar_modelos.py --destino <pasta>` baixa, confere o SHA-256, descompacta e grava
   `config/ferramentas.json` com os caminhos.
5. **Pacotes do motor:** `cd motor && npm install` (usa o `package.json` com versões fixas).
6. **Verificar de novo** e rodar o teste rápido: `python qa/teste_rapido.py` (gera a demonstração, renderiza alguns quadros,
   confere fontes e cores da marca ativa). Só diga que o ambiente está pronto se esse teste passar.

## `config/ferramentas.json`

```json
{
  "asr_bin": "C:/neon-editor/modelos/sherpa-onnx/bin/sherpa-onnx-offline.exe",
  "asr_model": "C:/neon-editor/modelos/sherpa-onnx-nemo-parakeet-tdt-0.6b-v3-int8",
  "u2net": "C:/neon-editor/modelos/u2net_human_seg.onnx",
  "threads": 4
}
```

`asr_bin` vazio → o pacote Python `sherpa_onnx` é usado. Variáveis de ambiente `NEON_ASR_BIN`, `NEON_ASR_MODEL` e
`NEON_U2NET` têm prioridade sobre o arquivo.
