# 09 · Identidade visual (marca)

## Como a marca chega aos componentes

`config/marcas/<id>.json` → `neon.py marca usar <id> --motor motor` copia para `motor/src/brand/marca.json` →
`motor/src/brand/neon.ts` transforma em tokens (`COLOR`, `FONT`, `FONT_FILES`, `alpha()`) → todos os componentes leem
só os tokens. **Nenhuma cor ou fonte é escrita à mão em componente.** Trocar de marca = trocar o JSON e recompilar.

Os nomes dos tokens são históricos e independem da marca: `COLOR.lime` é o **acento**, `COLOR.ink` é o **fundo**,
`COLOR.panel` a superfície, `COLOR.line` a borda, `COLOR.warn` o alerta, `COLOR.text`/`mute` os textos.

## O que é fixo (dá unidade à marca)

- Um único acento. Vermelho/alerta só para riscar, apagar ou marcar algo negativo.
- Fonte de título (cards, legendas, números grandes) e fonte mono (rótulos em maiúsculas com `letter-spacing` 0,1em,
  cor secundária).
- Cards planos: superfície + borda de 4 px (1 px na escala da biblioteca), raio 56 px, padding 48 px. Sem sombra nos
  cards (a biblioteca de referência não usa); sombra só sob textos que ficam sobre a imagem real.
- Legenda no estilo de `05-legendas.md`.
- Proporções da biblioteca de referência (quadro de 270 px × 4 = 1080 px): rótulo 40 px, corpo 60 px, título 72 px,
  frase de impacto 120 px, número 224 px, palavra de CTA 160 px.

## O que varia (dá vida a cada vídeo)

Objetos, layouts, animações, composições, transições, efeitos sonoros, tipo de gancho e de CTA.

## Cores naturais da imagem

A identidade vale para os **elementos gráficos**. Não aplique filtros de cor, LUT ou tinta da marca sobre o vídeo da
pessoa nem sobre imagens reais. (Decisão do cliente original: "preserve as cores naturais da minha imagem".)

## Marcas incluídas

| id | Uso |
|---|---|
| `padrao` | marca neutra de fábrica do kit (escura, acento azul) |
| `exemplo-aurora` | marca fictícia de teste (acento laranja) usada no teste de portabilidade |

A identidade "Neon" do cliente original não é distribuída com o kit.

## Logo

Se `logo` estiver definido, use-o pequeno (altura ≤ 72 px) no card do CTA ou num canto da tela final, nunca sobre o
rosto e nunca no gancho. Formatos: PNG transparente ou SVG.

## Testes

- `python qa/qa_marca.py config/marcas/<id>.json`: formato das cores, contraste mínimo, arquivos de fonte presentes.
- `python qa/teste_rapido.py --marca <id>`: renderiza a vitrine e a demonstração; `qa_layout.mjs` confirma que todo
  texto usa as fontes da marca e que as cores dos elementos pertencem à paleta.
