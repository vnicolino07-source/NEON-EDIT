# 20 · Vídeo a partir de um TEMA (explicativo / curiosidades, sem gravação da pessoa)

Use este guia quando a pessoa mandar **só um assunto** ("faz um vídeo sobre por que o céu é azul",
"um vídeo sobre a polêmica X", "um sobre a história de Y") e esperar o vídeo pronto: pesquisa, roteiro, narração,
visual animado, legenda, trilha e prévia. Não existe bruto: **tudo o que aparece na tela é criado aqui.**
O visual vem de `references/21-estilos-explicativos.md` e dos componentes em `motor/src/estilos/`.

O que importa no resultado: o espectador **entende algo que não sabia** em 45–110 s, sem perder o fio. Cada frase tem
uma imagem que a mostra, os dados têm fonte, e o fim fecha a ideia aberta no gancho.

---

## O fluxo (siga na ordem)

### 0 · Entender o pedido (perguntar o mínimo)
Pergunte **só** se faltar algo que muda o vídeo e não dá para supor. Padrões quando a pessoa não disser:

| Item | Padrão |
|---|---|
| Duração | 55–80 s (120–220 palavras) |
| Estilo visual | escolhido pela matriz do guia 21 |
| Voz | a voz configurada da pessoa (ElevenLabs, **1 take**) |
| Perfil no topo | `config/perfil.json` → `arroba` (se não houver, sem perfil) |
| Palavra do CTA | `config/perfil.json` → `cta_palavra` (se não houver, "segue o perfil") |

### 1 · Pesquisa (obrigatória, antes de escrever)
- Pesquise na web: **pelo menos 2 fontes confiáveis** por fato central (órgão oficial, veículo grande, artigo, livro, enciclopédia).
  Use a data de hoje nas buscas: o assunto pode ter mudado.
- Monte a **ficha de fatos** em `projetos/<id>/fatos.md`: fato → número/data exata → fonte (título + link).
  Só entra no roteiro o que está na ficha.
- Números: dê o valor **como a fonte dá**. Arredondar é aceitável ("quase 15 bilhões"), inventar não. Use "segundo o X" antes
  de dados disputados ou de projeções.
- Política e temas contestados:
  - mostre o fato e a **resposta do outro lado** ("o governo diz que…");
  - sem adjetivos de juízo ("absurdo", "vergonha");
  - não insinue o que a fonte não diz.
- Saúde, dinheiro e religião:
  - nada de promessa ou garantia;
  - diga "estudos sugerem" quando for o caso;
  - crença é apresentada como crença ("na tradição X…").
- Se não achar fonte firme para um ponto, **corte o ponto** e avise no relatório.

### 2 · Ângulo e gancho
Escolha **um** ângulo (a pergunta que o vídeo responde) e escreva o gancho na primeira frase (≤ 3 s, ≤ 14 palavras).
Os ganchos que funcionam no gênero:

| Tipo | Forma | Exemplo (modelo, não copiar) |
|---|---|---|
| Fato absurdo | cena concreta e estranha | "Um homem andou com 99 celulares num carrinho e o mapa mostrou engarrafamento." |
| Contradição | "disse X… mas o papel diz Y" | "Prometeu nunca cortar gastos. O próprio plano dele pede cortes." |
| Pergunta ingênua | pergunta que todo mundo já fez | "Por que o governo não imprime dinheiro e acaba com a pobreza?" |
| Promessa de lição | regra/segredo que se pode usar | "Existe uma regra que quase todo gênio seguiu." |
| Personagem + descoberta | "Esse homem descobriu…" | "Esse cientista mostrou que a cadeira onde você está sentado é quase vazia." |
| Observação do cotidiano | "Já reparou que…?" | "Já reparou que, depois que você aprende uma palavra, ela aparece em todo lugar?" |
| Número chocante | dado + contexto mínimo | "Uma moeda que não existe subiu 2.900% em uma hora." (só com fonte) |

### 3 · Roteiro (esqueleto do gênero)
1. **Gancho** — 1 frase.
2. **Contexto** — quem, quando, onde (data e lugar concretos). 1–2 frases.
3. **Desenvolvimento** — 3 a 5 "batidas". Cada batida é uma ideia, cabe em 1–2 frases e tem uma imagem.
   Use "pensa comigo", "repara", "agora imagina" para conduzir.
4. **Virada / como funciona** — a explicação ou o detalhe que muda a leitura do caso.
5. **Ressalva honesta** — "mas atenção: …" (o limite da ideia, o outro lado, o que não se sabe).
6. **Fecho** — 1 frase que **espelha o gancho** ("na campanha era X; no papel, Y").
7. **Pergunta ao público** — opinião ou experiência ("você teria caído nessa?").
8. **CTA** — salvar/compartilhar/seguir + a palavra-chave da pessoa. **Nunca** o bordão ou o @ de outro criador.

Regras de escrita:
- **Frases e ritmo:**
  - frases de 6 a 14 palavras, voz ativa, presente;
  - 1 ideia por frase;
  - **ritmo do gênero: 2,6–3,0 palavras/s** (mais lento que os anúncios, que usam 1,15×).
- **Clareza:**
  - jargão sempre traduzido ("traduzindo do economês: corte");
  - números falados como gente fala ("quase quinze bilhões");
  - comparações físicas para escala (100 pães numa cidade, um carrinho com 99 celulares).
- **Formato do arquivo:** salve em `roteiro.txt` (texto falado) e `roteiro_tts.txt`. O `roteiro_tts.txt` leva as pronúncias:
  - siglas por extenso ("Gê Tê Á seis");
  - números com unidade escrita;
  - nomes estrangeiros como se fala.

### 4 · Estilo visual
- Escolha o estilo pela matriz do guia 21 (assunto → estilo) e **varie** em relação ao último vídeo da pessoa.
- Escolha a paleta (padrão do estilo ou a da marca) e anote numa frase a **linguagem visual** do vídeo
  ("traço que se desenha sobre grafite, órbitas laranja para a mente").

### 5 · Roteiro visual (storyboard)
Para cada frase: o que aparece, quando e com que componente. Regras do gênero:

| A frase tem… | Mostre | Componente |
|---|---|---|
| Número, valor, % | número enorme + rótulo curto, depois o objeto | `BigStat` + objeto (barras, moeda, pizza) |
| Data | calendário / número do ano | `calendario` (3D) · `textPts('1905')` · `TopTitle` |
| Documento, lei, relatório | papel/documento com linha destacada | `documento` (3D) · `RedactedDoc` |
| Pessoa real | foto liberada → `TapedPhoto`; sem foto → silhueta/ícone (nunca rosto gerado por IA) | `TapedPhoto`/`Silhueta`/`pessoa` |
| Comparação | lado a lado, barras, Venn | `barras` · `venn` · dois ícones |
| Processo / causa | setas, órbitas, etapas que se desenham | `Trace`, `OrbitDot`, `LineIcon` |
| Lugar | cenário (cidade, prédio, mapa) | `ArgilaBg kind="cidade"`, `predio`, `pino` |
| Pergunta ao público | balão de fala / ponto de interrogação | `balao` (3D) · `balao` (linha) |
| Ideia abstrata | metáfora física (rádio/frequência, lupa, olho) | `onda`, `lupa`, `olho`, `DotField` |

Ritmo:
- **Troca de imagem:** algo novo a cada **2–3 s**. Pode ser outro objeto, um número que entra, uma linha que se desenha ou um zoom.
- **Mudança de cena:** fundo ou plano novo a cada **4–10 s**.
- **Regra dos 2 s:** nada fica parado por mais de 2 s (QA "Regra dos 2 s").
- **Leitura:** uma leitura por vez. Título grande na tela que repete a fala → legenda some naquele trecho (`CAP_OFF`).

### 6 · Narração
- Gere com ElevenLabs a partir de `roteiro_tts.txt`: **1 take**, `eleven_v4`, a voz da pessoa. Tag `[excited]` só no gancho, se couber.
- Prepare o áudio com o `prep.sh` padrão, mas com **velocidade 1.0–1.05** (não 1.15). O gênero pede respiro.
- Confira a transcrição e corrija os tokens errados no `words.json`, sempre conferindo pelo áudio.

### 7 · Trilha e sons
- **Trilha contínua por baixo:** cama de música do início ao fim, sem silêncio, 12–14 dB abaixo da voz; total −14 LUFS.
  Mood por estilo no guia 21.
- **SFX discretos:**
  - whoosh/foco nas trocas de cena;
  - pop nos números e objetos;
  - tique na escrita/digitação;
  - nunca mais alto que a voz.

### 8 · Montagem no motor
- Pasta `src/videos/<id>/Video.tsx`. Componentes:
  - `estilos/base.tsx`: legenda `KCap`, `Pop`, `BigStat`, `TopTitle`, `Handle`, `Grain`;
  - mais o módulo do estilo escolhido.
- **Legenda:**
  - `KCap` com o tipo do estilo (`suave`, `escuro`, `pilula` ou `papel`);
  - 3–4 palavras por bloco, y = 1400;
  - 1 palavra-chave destacada por bloco.
- **Exports:** `SFX` e `VISUAL_EVENTS` (QA de ritmo), como nos outros vídeos.
- **Abertura e fechamento:**
  - os 1–2 primeiros segundos têm o gancho visual mais forte do vídeo;
  - o último quadro fecha com o CTA da pessoa.

### 9 · QA, prévia e entrega
- `audit_ritmo` → stills → `qa_layout` → prévia completa com áudio → `qa_tudo`.
- Entregue a prévia com:
  - a lista de **fontes** (da ficha de fatos);
  - qualquer ponto cortado por falta de fonte;
  - a legenda sugerida para o post (2–3 linhas, sem hashtag em excesso).
- Final em 1080×1920 só após aprovação.

---

## O que nunca fazer
- **Conteúdo:**
  - inventar fato, número, citação, data ou resultado;
  - transformar opinião em fato.
- **Imagens de pessoas e marcas:**
  - gerar **foto realista** de pessoa real;
  - baixar foto de pessoa pública da internet para colocar no vídeo;
  - fotos de pessoas só se a pessoa fornecer (com direito de uso) ou se forem de domínio público baixadas por ela;
  - copiar marca, @, bordão, vinheta, personagem ou layout reconhecível de outro criador (modelar o estilo, sim; copiar, não).
- **Forma:** deixar o vídeo sem fecho (a pergunta do gancho precisa ser respondida).
