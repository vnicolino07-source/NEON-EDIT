# 17 · Pendências e limitações (o que impede a venda hoje)

Atualizado em 29/10/2026. Nada aqui foi omitido para parecer pronto.

## Bloqueiam a distribuição comercial

1. **Teste de portabilidade não executado.** O kit só foi executado no ambiente de desenvolvimento (Linux na nuvem,
   sem npm). Falta rodar `testes-portabilidade/PROCEDIMENTO.md` em Windows e macOS limpos, com outra conta do Claude.
2. **Render oficial do Remotion (`npx remotion render`) nunca executado.** O `package.json`, o `remotion.config.ts` e o
   `Root.tsx` estão prontos, mas o npm estava bloqueado. Os vídeos aprovados saíram pelo renderizador local
   (`motor/harness`), que foi testado. Riscos: diferenças de comportamento do `<Audio>`/volume por quadro e do WebGL
   no Chrome do Remotion.
3. **`npm install` com as versões fixadas nunca executado.** Em especial `esbuild@0.25.0` e `playwright@1.55.0` (o
   desenvolvimento usou 0.28.2 e 1.63.0 já instalados) e `react@19.2.0` (o desenvolvimento usou 19.2.8).
4. **Transcrição no Windows/macOS não testada.** O caminho previsto é o pacote Python `sherpa-onnx` (o código existe em
   `neon.py`, função `sherpa`), mas o PyPI estava bloqueado. Só o binário Linux foi testado.
5. **Instalador nunca executado de ponta a ponta** (`instalar.py`, `baixar_modelos.py`). Os SHA-256 são dos arquivos
   realmente usados, mas os downloads não foram refeitos pelo script. Os comandos de `winget`/`brew` não foram testados.
   `verificar_ambiente.ps1` não foi executado (não havia Windows).
6. **Licenças:** definir a licença comercial do kit; conferir a licença do Remotion para compradores empresas e a
   atribuição exigida pelo modelo Parakeet (CC-BY-4.0); ver `LICENCAS.md`.
7. **Decisão sobre exemplos com a fala do titular** em `references/14` e `16` (autorizar ou anonimizar).

8. **Nenhuma edição inédita completa foi feita com o kit** (vídeo diferente do v002, do bruto à prévia, numa sessão sem
   histórico). É o próximo teste obrigatório; ver `testes-portabilidade/PROCEDIMENTO.md`.
9. **Direção adaptativa:** o analisador (`neon.py mapa`) e os 11 componentes de `components/adaptativo/` foram testados
   na vitrine `DirecaoAdaptativa` e no v002, mas nunca num vídeo aprovado por cliente.
10. **Autorização de uso de imagem do titular por escrito** para o v002 incluído como exemplo (recomendação).

## Limitações conhecidas (não bloqueiam, mas o comprador precisa saber)

- **Velocidade de render:** sem GPU, ~0,5–1,5 s por quadro. Um vídeo de 50 s leva de 10 a 40 min.
- **Só 9:16 1080×1920 foi comprovado.** Outros formatos não foram implementados.
- **Tema claro** é tecnicamente possível (tokens), mas nenhum componente foi aprovado em tema claro.
- **Estilos "cinematográfico" e "personalizado"** são propostas, sem teste (`config/estilos.json`).
- **Componentes do A1** (EditComposition, ThumbCard, ProntoFlow, Features com onda real, títulos com raios, etc.) não
  foram migrados para os tokens e não estão no kit.
- **Alguns componentes aprovados têm textos fixos do vídeo de origem** (StepTrack: "edita pra mim", "lendo
  GUIA_DE_EDICAO...", "/videos"; TemplateCard; ReferenceScan; PostPanel "Postar/postado"). Funcionam, mas precisam
  virar parâmetros quando o contexto for outro (ver `references/13-componentes.md`).
- **Defeito menor encontrado no v002 aprovado** pelo novo verificador de layout: no CTA, o campo de comentário é 96 px
  mais largo que o card que o contém (passa da borda direita do card, não da tela). O vídeo aprovado não foi alterado; a
  demonstração do kit já usa a largura certa e o `qa_layout.mjs` passa a acusar isso.
- **Detector de palavra-fantasma** é heurístico (palavra > 0,9 s, < 30% no trecho mantido, sem fala nesse pedaço):
  pegou o caso real do v002 sem falsos positivos no v002, mas não foi validado em outros vídeos.
- **`qa_movimento.py`** subestima animações pequenas (informativo).
- **Recorte (u2net)** pode falhar com cabelo muito fino, fundo da mesma cor da roupa ou várias pessoas; o guia manda
  conferir a folha magenta e cair para layouts sem elemento atrás quando falhar.
- **A ponte de arquivos do app desktop** recusa arquivos acima de 30 MB por envio.

## Testado no desenvolvimento (com evidência)

| O quê | Resultado |
|---|---|
| Pipeline do kit no bruto do v002 | EDL, palavras, 1568 quadros e máscaras idênticos aos aprovados |
| Voz pelo pipeline do kit | idêntica (correlação 1,0), 6 ms mais adiantada (atraso medido 26 ms em vez dos 20 ms fixos) |
| Motor do kit + marca Neon + direção do v002 | 19/20 quadros idênticos pixel a pixel |
| Troca de marca (exemplo-aurora) | demonstração renderizada; `qa_layout` sem falhas |
| `qa_layout.mjs` | detecta os 3 erros reais do v002 (Times, texto estourando, card vazando) e o campo maior que o card |
| `qa_latencia.py` | atraso real 28,1 ms × medido 28 ms |
| `qa/teste_rapido.py` em cópia limpa do kit (modo sem npm, `NEON_VENDOR`) | todas as etapas OK (demonstração, marca, compilação, quadros, layout, ritmo, vídeo de 3 s com áudio, arquivo) |
| QA completo do v002 final | sem falhas |
| Vitrine `DirecaoAdaptativa` (11 componentes novos) | renderizada; `qa_layout` sem falhas em 30 quadros; `qa_ritmo` OK (maior intervalo 1,6 s) |
| `neon.py mapa` no v002 | detectou os 3 pedidos literais e o CTA; assunto provável criatividade + tecnologia |
