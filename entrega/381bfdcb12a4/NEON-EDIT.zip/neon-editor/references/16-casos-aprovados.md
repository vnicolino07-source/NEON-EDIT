# 16 · Casos aprovados (padrão de qualidade)

Dois vídeos editados com este motor foram aprovados pelo cliente que originou o kit. Eles definem o nível esperado.
Os arquivos de vídeo não acompanham o kit (são do cliente); os números e a estrutura estão aqui.

## A1 — "edita pra mim esse vídeo" (28/10/2026)

- Bruto 2 min 01 s (576×1024, rotação 90°) → **59,2 s** a **1,15×**; 3,68 palavras/s; **70 eventos visuais**
  (1 a cada 0,85 s; maior intervalo 1,89 s); voz −14,5 LUFS.
- A 1ª versão (sem aceleração, 70,9 s) foi recusada. Correções que viraram regra:
  1. Abertura só com legenda → **impacto no quadro 1 e ≥ 3 transformações nos primeiros ~4 s**.
  2. Conectivo repetido ("e pedi assim") → **cortar repetições pela fala real**.
  3. 17–20 s sem progressão → **cada frase-chave ganha uma etapa visual**.
  4. Intervalos parados → **regra dos 2 s**.
  5. Resíduos nas emendas → margens 0,05/0,08 s, pausas > 0,30 s viram 0,14 s, microfade 4 ms.
  6. Ritmo lento → **1,15× depois dos cortes**, tom preservado, compensação de 20 ms.
  7. Prévia completa com áudio antes do final, sempre.
- A aparência do A1 (cards claros) foi substituída depois pela identidade escura de um acento; dele vêm ritmo, cortes,
  velocidade e densidade.

## v002 — "o Claude acabou de matar os editores de vídeo" (29/10/2026)

- Bruto 96,3 s → **52,3 s** a 1,15×; 229 palavras (4,4 palavras/s); **50 eventos** (1 a cada 1,05 s; maior intervalo
  1,81 s); 38 efeitos sonoros; final −14,4 LUFS / −1,0 dBTP. **Aprovado na primeira prévia**, sem pedidos de correção.
- Removidos: 1ª tomada de "Eu gravo… com a"; falso começo "Se eu quiser que a minha"; "E cara, se você quiser";
  "que é que eu te envio?" (redundante); 1ª tentativa de "Comenta aí IA aqui no"; uma palavra-fantasma da tomada descartada.
- Inferidos e confirmados com a aprovação: "IA" (palavra do CTA, por formantes) e "reels" (o reconhecimento ouviu "views").

### Direção completa do v002

| Tempo (s) | Fala | Efeito | Layout |
|---|---|---|---|
| 0–2,4 | "O Claude acabou de matar os editores de vídeo" | "EDITORES / DE VÍDEO" 3D (segunda linha no acento) visível no quadro 1, atrás da cabeça com recorte; risco vermelho em "matar"; letras tremem e explodem em "editores"; reenquadramento depois | tela cheia, zoom 1,16 → 1,06 |
| 2,4–5,3 | "Esse vídeo aqui foi editado com um só prompt que eu mandei para o Claude" | card "1 · só um prompt" acima da cabeça; avião de papel sai em "mandei" | tela cheia |
| 5,3–9,9 | "edita com toda a minha identidade visual e todos os efeitos que eu gosto" | card "minha identidade visual": cores em "identidade", fontes em "visual", chips de efeitos em "efeitos" | dividido |
| 9,9–12,6 | "E o passo a passo… é simples" | "o passo a passo / é *simples*" com marca-texto que preenche em "simples" | tela cheia |
| 12,6–20,6 | "Eu gravo… celular. Pego, jogo pra uma pasta e mando o Claude editar… do jeito que eu gosto" | trilha de 3 etapas: celular gravando com o quadro ao vivo → quadro caindo na pasta "/videos" → balão "edita pra mim" + "lendo o guia de edição" + "✓ do jeito que eu gosto" | dividido |
| 20,7–25,0 | "deixa o vídeo pronto para eu postar nos meus reels e ganhar visualizações" | o apresentador vira um celular; botão "Postar" → "✓ postado"; ícone de olho e curva subindo (sem números) | celular |
| 25,2–27,1 | "Ele faz tudo o que eu quiser nesse vídeo aqui" | alças de seleção de editor no quadro inteiro | tela cheia |
| 27,2–30,6 | "um texto gigante atrás da minha cabeça… vai colocar" | "TEXTO / GIGANTE" cai atrás da cabeça com recorte, trava em "colocar" | tela cheia, zoom em "cabeça" |
| 30,7–34,3 | "que ele corte essa tela no meio" | laser atravessa em "corte"; metades se afastam em "meio"; voltam em "isso" | tela cheia |
| 34,4–41,2 | "minha tela fique pra baixo e a tela dele dá a explicação… fica em cima" | o vídeo desce em "baixo"; a área de cima transcreve a fala ao vivo; seta para cima em "cima" | dividido |
| 41,2–44,6 | "Tudo com um só prompt de acordo com o modelo de vídeo" | "1 prompt" enviado; wireframe do modelo (card no topo, vídeo embaixo, legenda) | dividido |
| 44,7–48,3 | "mandar uma referência… entendeu o estilo" | card "referência enviada" escaneado; chips ritmo, cortes, legendas, cores | dividido |
| 48,4–49,3 | "Gostou dessa ferramenta?" | "gostou?" grande no acento | tela cheia |
| 49,4–52,3 | "Comenta aí IA aqui nos comentários… lá no seu direct" | card com campo digitando "IA" e enviando; notificação "Direct" | tela cheia |

O código dessa direção é o modelo seguido por `motor/src/videos/demonstracao/Video.tsx`.

## O que fez esses vídeos serem aprovados

- Efeitos **literais**: o que a pessoa diz acontece na tela no mesmo instante.
- Gancho no quadro 1 com ação física (risco + explosão).
- Ritmo constante (evento a cada ~1 s) sem acumular elementos.
- Legenda fiel ao áudio, curta, com uma palavra destacada.
- Identidade consistente em tudo que é gráfico, imagem real intocada.
- Áudio limpo: voz acima de tudo, efeitos curtos e discretos.
