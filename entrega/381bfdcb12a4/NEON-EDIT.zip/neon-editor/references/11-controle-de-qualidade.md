# 11 · Controle de qualidade

Nenhuma prévia sai sem passar por aqui. O QA automático pega erros objetivos; a revisão visual pega o resto. Os dois são
obrigatórios.

## 1. Automático

```bash
python qa/qa_tudo.py --proj projetos/<id> --meta motor/out/meta.json --video <previa ou final>.mp4 --tipo previa
```

| Verificação | Script | Falha quando |
|---|---|---|
| Legendas × voz | `qa_legendas.py` | palavra em silêncio na voz final (fantasma ou fora de sincronia), sobreposta, fora do vídeo |
| Texto da legenda × transcrição | `buildBlocks` (na compilação) | qualquer palavra trocada, pulada ou fora de ordem |
| Regra dos 2 s | `qa_ritmo.py` | intervalo > 2 s entre eventos declarados |
| Layout | `qa_layout.mjs` | texto fora da fonte da marca (ex.: Times), fonte não carregada, texto saindo da tela ou cortado por um contêiner, erro de JavaScript; avisa cor fora da paleta |
| Arquivo | `qa_render.py` | resolução, codec, fps, pix_fmt, duração ≠ composição, áudio ausente, quadros pretos; avisa congelamento > 2,5 s e falta de faststart |
| Áudio | `qa_audio.py` | loudness fora de −14 ± 1 LU, pico > −0,9 dBTP, clipping, estalo nas emendas |
| Movimento medido | `qa_movimento.py` | informativo: subestima animações pequenas; confira os trechos que ele apontar |
| Marca | `qa_marca.py` | cor inválida, contraste insuficiente, fonte/logo ausente |
| Atraso da voz | `qa_latencia.py` | a medição automática do atraso diverge mais de 4 ms do atraso real (rodar uma vez por instalação) |
| Instalação completa | `teste_rapido.py` | qualquer etapa da demonstração falha, ou falta ferramenta para vídeos reais |

O relatório fica em `projetos/<id>/qa/relatorio_<arquivo>.md` com a folha de contato ao lado.

## 2. Revisão visual (você olha)

Abra a folha de contato (1 quadro/s) e os quadros de teste de cada cena. Confira:

- **Abertura:** o quadro 1 já tem impacto ligado à primeira frase?
- **Rosto:** nada cobre olhos e boca; a legenda fica abaixo da boca.
- **Recortes:** borda de cabelo, mãos e microfone limpa (sem halo, sem pedaço do fundo) nos quadros com elemento atrás.
- **Hierarquia:** um foco por vez; nenhum card pequeno ilegível sobre a imagem (rótulo sempre dentro de card).
- **Identidade:** só cores e fontes da marca nos gráficos; imagem da pessoa sem filtro.
- **Coerência:** cada efeito corresponde ao que está sendo dito naquele instante.
- **Números e nomes:** tudo que aparece escrito foi dito (ou confirmado).
- **Fim:** o CTA aparece com a palavra certa e há respiro no final (sem corte seco na última sílaba).

## 3. Escuta

Ouça a prévia inteira uma vez (ou pelo menos: início, cada emenda com `inicio_exato`/`fim_exato`, o CTA):
emendas sem estalo nem palavra cortada; voz sempre acima da trilha; nenhum efeito tapando palavra importante;
sincronia labial (atraso residual 0 ms medido em `neon.py voz`).

## 4. Critérios de "pronto para enviar"

Todos os automáticos OK (o movimento medido é informativo) + revisão visual sem pendências + escuta ok. Se algo ficou de
fora por limitação, diga no relatório da prévia.
