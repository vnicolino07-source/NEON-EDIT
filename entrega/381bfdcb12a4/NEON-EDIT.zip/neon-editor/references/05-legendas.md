# 05 · Legendas

## Estilo (identidade)

- Blocos de **2–3 palavras** (4 só quando separar quebraria o sentido). Cada palavra aparece **quando é falada**.
- Fonte de título da marca, peso 700, cor `texto`, sombra `0 8px 40px rgba(0,0,0,.6)`.
- **Palavra-chave** com fundo do acento e texto na cor do fundo (raio 20 px, padding 0 24 px). No máximo **1 por bloco**
  e não em todos os blocos (média do v002: 1 a cada 2–3 blocos). Destaque substantivos e verbos que carregam a ideia
  ("matar", "identidade", "pasta", "pronto", "meio", "direct"), nunca artigos.
- Tamanho: 76 px em tela cheia; 64 px no layout dividido (área do vídeo menor).

## Posição e áreas seguras

| Layout | Posição vertical (centro do bloco) |
|---|---|
| Tela cheia | y ≈ 1470 (sobre o peito, abaixo da boca) |
| Dividido (card no topo) | 84% da altura da área do vídeo |
| "Celular" | y ≈ 1520 (abaixo do aparelho) |

- `captionY(weights)` em `PresenterStage.tsx` interpola a posição durante as transições de layout.
- Margem lateral mínima 56 px. A interface do Instagram/TikTok cobre ~250 px embaixo e ~120 px à direita: nada
  essencial abaixo de y = 1680 ou colado na borda direita.
- A legenda nunca cobre a boca. Se um gráfico ocupar a posição da legenda, mova a legenda ou oculte o bloco.

## Construção

```ts
const BLOCKS = [
  'O Claude acabou de *matar*',     // *palavra* = destaque
  '!os editores de vídeo',          // ! = bloco existe para a sincronia, mas não aparece (o 3D já escreve isso)
  'Esse vídeo aqui', ...
];
const blocks = buildBlocks(BLOCKS); // lança erro se o texto não bater palavra por palavra com words.json
```

- **Cubra todas as palavras** de `words.json`, em ordem. `buildBlocks` recusa blocos que pulem ou troquem palavras: é a
  garantia de que a legenda é fiel ao áudio.
- Oculte com `!` o bloco cuja frase já está na tela como gráfico (título 3D, prompt digitado, texto gigante, CTA). Duas
  cópias do mesmo texto competem pela leitura.
- Pontuação: só "?" em perguntas. Sem ponto final.
- O bloco fica na tela até 0,7 s depois da última palavra ou até o próximo bloco começar (`blockAt`).

## Erros que já aconteceram

| Problema | Causa | Solução | Como testar |
|---|---|---|---|
| Legenda em fonte serifada (Times) | O elemento não herdava a família da marca (sem `fontFamily` no contêiner raiz). | O `AbsoluteFill` raiz de toda composição define `fontFamily: FONT.display, color: COLOR.text`. | `qa/qa_layout.mjs` lê a fonte calculada de cada texto e falha se não for da marca. |
| Palavra que não foi dita aparecendo | Sobra de tomada descartada no `words.json`. | `correcoes.json` → `remover`. | `neon.py palavras` avisa; `qa_legendas.py` confere energia. |
| Legenda duplicando o gráfico | Frase já escrita na tela. | Bloco com `!`. | Folha de quadros. |

## Validação

1. A compilação passa (buildBlocks).
2. `python qa/qa_legendas.py --proj P`.
3. Folha de quadros: legenda dentro da área segura, sem cobrir a boca, contraste ok sobre o fundo real.
