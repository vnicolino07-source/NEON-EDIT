# 02 · Análise do vídeo bruto

Antes de cortar qualquer coisa, entenda o vídeo como um editor sênior: o que a pessoa promete, como prova e o que pede.

## 1. Ficha técnica (`neon.py preparar`)

Leia `data/bruto.json`: duração, resolução exibida (a rotação já é considerada), fps, áudio. Avise se:
- não for 9:16 (os quadros serão ampliados e cortados no centro; confira se a cabeça não fica cortada);
- o áudio tiver ruído alto, clipping, música de fundo gravada junto (o corte por energia fica impreciso), ou duas vozes;
- o fps for variável (normal em celular; o pipeline reamostra para 30 fps).

## 2. Transcrição completa (`neon.py transcrever` → `neon.py texto`)

Leia o texto inteiro, com as pausas. Monte, por escrito no seu raciocínio ou num arquivo `projetos/<id>/analise.md`:

| Item | Pergunta |
|---|---|
| Assunto | Sobre o que é, em uma frase? |
| Promessa / gancho | Qual é a frase mais forte dos primeiros 3 s? Se o gancho real estiver mais à frente, ele pode abrir o vídeo? (Só mover frases se o sentido continuar verdadeiro.) |
| Estrutura | gancho → contexto → passos/prova → resultado → CTA. Marque o início e o fim de cada parte em segundos. |
| Momentos-chave | frases com imagem forte ("texto gigante atrás da minha cabeça", "corta a tela no meio"), números ditos, nomes de ferramentas, comparações, listas, perguntas. |
| Repetições | a mesma frase dita duas vezes: fica a tentativa **completa e mais fluente** (normalmente a última). |
| Falsos começos | frase iniciada e abandonada ("Se eu quiser que a minha… Se eu quiser que a minha tela"). Remover o trecho abandonado. |
| Erros de fala | troca de palavra corrigida em seguida, gaguejo, "é… é". Remover se o corte ficar natural. |
| Muletas | "tá bom?", "né", "cara" no fim de frase: mantenha se fizerem parte do jeito de falar e não arrastarem o ritmo; corte se forem só enchimento. |
| Descartáveis | silêncios, conversa fora do roteiro, pedidos de desculpa, "deixa eu ver", ruídos. |
| CTA | a palavra-chave pedida ("comenta X"). Se for incerta, verifique pelo áudio (`03`) e confirme com a pessoa. |
| Incertezas | toda palavra que o reconhecimento pode ter errado (nomes de produtos, estrangeirismos, siglas). |

## 3. Oportunidades visuais (alimentam o mapa de edição, `14-direcao-criativa.md`)

Para cada frase, pergunte "**o que aparece na tela que prova ou demonstra isso?**":
- **Pedido literal** ("palavra explodindo", "texto atrás de mim", "tela no meio") → execute exatamente esse efeito, no
  momento da fala. É o que mais impressiona quem assiste.
- **Ação descrita** ("eu gravo", "jogo numa pasta", "mando pro Claude") → demonstração em etapas sincronizadas.
- **Resultado** ("fica pronto", "ganhar visualizações") → transformação de estado (botão "postar" → "postado"), sem
  inventar números.
- **Conceito** ("identidade visual", "estilo") → mostrar os elementos concretos (cores, fontes, chips).
- **Número dito** → contador ou comparação, com o valor exato falado.
- **Pergunta ao público / CTA** → interface de comentário, enquete com opções faladas.

Bons momentos para 3D: palavra-âncora do gancho, objeto concreto citado (dinheiro, relógio, arquivo), algo "atrás" da
pessoa, um impacto que pede volume e luz. 3D só agrega quando o volume ou o movimento físico comunicam algo
(`07-animacoes-3d.md`).

## 4. Enquadramento

Olhe 5–6 quadros espalhados: onde está o rosto (o padrão do motor é x=540, y≈760 em 1080×1920; ajuste `face`), se as
mãos e o microfone entram no quadro (importante para recortes), se há área livre acima da cabeça (texto atrás) e nas
laterais. Anote a cor dominante do fundo real: os gráficos usam a marca, mas precisam de contraste contra esse fundo.
