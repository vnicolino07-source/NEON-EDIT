# 14 · Direção criativa: como escolher os efeitos

## Diretriz

**Identidade visual consistente, liberdade para criar, variedade entre vídeos.** A biblioteca é um acervo, não um
catálogo fechado. Para cada momento da fala, decida conscientemente entre **reutilizar**, **adaptar** ou **criar**.
O critério é sempre o mesmo: o que faz quem assiste **entender e sentir** essa frase mais rápido?

## Mapa de edição (faça antes de escrever código)

Uma linha por frase ou ideia:

| Tempo | Fala | Função | Efeito que demonstra | Componente | Layout | Som |
|---|---|---|---|---|---|---|
| 0–2,4 | "o Claude acabou de matar os editores de vídeo" | gancho | "EDITORES DE VÍDEO" 3D já na tela; risco vermelho em "matar"; explode em "editores" | ShatterText3D (novo) | tela cheia, zoom 1,16 | impact, laser, shatter |
| 2,4–5,3 | "esse vídeo foi editado com um só prompt que eu mandei" | prova | "1 prompt" sobre a cabeça; enviado em "mandei" | OnePrompt (novo) | tela cheia | pop, whoosh |
| 5,3–9,9 | "edita com toda a minha identidade visual… efeitos" | conceito | cores em "identidade", fontes em "visual", efeitos em "efeitos" | IdentityCard (novo) | dividido | whoosh, click, pop |
| … | | | | | | |
| 49,4–52,3 | "comenta aí IA… te envio no direct" | CTA | campo digitando "IA" e enviando; notificação "Direct" | NeonPrompt + NeonToasts | tela cheia, card no topo | pop, type, click, pop |

(Mapa resumido do v002; a direção inteira está em `16-casos-aprovados.md`.)

Depois de montar o mapa, confira: algum trecho > 2 s sem evento? Dois elementos competindo? Algum efeito sem ligação
com a fala? A estrutura é diferente do vídeo anterior?

## Prioridades

1. **Pedido literal na fala → execute exatamente.** "Palavra explodindo", "texto atrás de mim", "corta a tela no meio",
   "tela pra baixo e explicação em cima": o efeito acontece no momento da frase e faz o que a frase diz. É o que mais
   surpreende e convence.
2. **Ação descrita → demonstração em etapas** sincronizadas com cada verbo (grava → pasta → manda).
3. **Resultado → transformação de estado** (botão vira "postado"), nunca número inventado.
4. **Conceito abstrato → seus elementos concretos** (identidade = cores + fontes + efeitos reais da marca).
5. **Frase de impacto sem ação → tipografia** (palavra-chave grande, 3D, marca-texto) ou reenquadramento.
6. **Transição de assunto → troca de layout** no corte.

## Repertório de técnicas (observado em referências do gênero; adapte à marca, nunca copie marca ou paleta de terceiros)

- **Ganchos:** título enorme atrás do apresentador com oclusão real; pergunta na tela respondida em seguida;
  demonstração imediata (arquivo entrando, cronômetro); prova "este vídeo" (miniatura do próprio vídeo); palavra 3D
  que sofre uma ação (riscada, explodida).
- **Destaque de palavra:** palavra-chave na cor do acento dentro do título; tipografia empilhada em crescendo.
- **Interface:** prompt digitado e enviado; arquivo arrastado para o chat; anotações à mão sobre a interface (ideia).
- **Processo:** forma de onda com pausas cortadas; fluxo A → B → C com ícones; quadro branco como mapa (ideia).
- **Comparação:** valor antigo riscado + novo aceso; balança (ideia).
- **Lista:** checklist que marca na palavra; etapas numeradas.
- **Número/tempo:** contador que para no número dito; relógio 3D; barra de duração caindo.
- **Metáfora 3D:** objetos caindo (dinheiro, arquivos); texto 3D; planta isométrica; ímã com partículas (ideia).
- **Profundidade:** texto ou objeto atrás da pessoa (com recorte validado); troca do fundo inteiro (ideia; exige recorte
  em todo o trecho).
- **Transições:** troca de layout no corte; tela cortada; apresentador que vira um aparelho; flash de luz (ideia);
  recuo de câmera revelando o mapa (ideia).
- **CTA:** campo de comentário com a palavra falada digitada + envio; notificação de DM respondida.

Padrões comuns aos bons vídeos do gênero: começam a falar no quadro 1 com um gráfico ligado à frase; um elemento por vez;
a animação acontece na palavra; a marca fica fixa e o que varia é o objeto ou a metáfora; o CTA é a palavra falada (se o
áudio não deixar claro, "comente aqui embaixo", sem inventar a palavra).

## Variedade entre vídeos

Registre no histórico a estrutura de cada vídeo (gancho, sequência de layouts, objetos, CTA). No vídeo seguinte, mude
pelo menos o tipo de gancho, a sequência de layouts e o objeto principal. Componentes podem se repetir; a direção não.

## Quando criar algo novo

Crie quando nenhum componente existente demonstrar a frase tão bem quanto um novo, e quando der para fazer com
qualidade no tempo disponível (teste em quadros antes). Siga as regras de criação em `06-motion-graphics.md`. Não peça
autorização para cada ideia: a prévia é o momento de aprovação.
