# 21 · Estilos visuais para vídeos explicativos (a partir de tema)

Catorze linguagens visuais. As 5 primeiras (1–5) foram destiladas de vídeos explicativos de alto desempenho (análise de 9
referências do gênero "curiosidades", 13,5 min no total); as 9 seguintes (6–14) são estilos clássicos de motion design
construídos no motor com as mesmas medidas. Estilo que a pessoa DESCREVE e não está aqui → `references/22-estilo-sob-medida.md`.
Medidas comuns a todas:

| Medida | Valor observado |
|---|---|
| Duração | 59–119 s (mediana ~99 s) |
| Ritmo da fala | 2,5–3,0 palavras/s |
| Troca de imagem | a cada 2–3 s (objeto/elemento novo); cena nova a cada 4–10 s |
| Loudness | −14 LUFS, **música contínua** por baixo (nenhum silêncio) |
| Legenda | karaokê, 2–5 palavras por bloco, ~72% da altura (nosso y = 1400), palavra-chave em cor de destaque |
| Perfil | @ pequeno centralizado no topo |
| Estrutura | gancho → contexto → 3–5 batidas → virada → ressalva → fecho espelhando o gancho → pergunta → CTA |
| Transição padrão | foco: blur → nítido com pop (escala 0,55 → 1 com passada); saída com blur |

Status (siga `config/estilos.json`; nunca apresente "proposto" como pronto):
- **parcial:** os componentes renderizam e passam no layout, mas ainda não há vídeo aprovado pelo cliente;
- **proposto:** depende de ativos ainda não gerados.

---

## Qual estilo para qual tema

| Tema | 1ª opção | 2ª opção |
|---|---|---|
| Notícia, política, economia, governo, "a conta não fecha" | **Argila 3D** (estúdio escuro) | Colagem (documentos) |
| "Como funciona" (apps, mapas, cripto, tecnologia do dia a dia) | **Argila 3D** (cidade/estúdio) | Linha |
| Economia explicada com exemplo (inflação, juros) | **Argila 3D** (cenário de mercado/banco) | Linha |
| História, biografias, "lições de gênios", livros | **Colagem** | Partículas (retratos) |
| Física, universo, ciência "a realidade não é o que parece" | **Partículas** | Linha |
| Mente, psicologia, filosofia, espiritualidade, hábitos | **Linha** | Partículas |
| Histórias com personagens (bíblicas, fábulas, históricas narradas) | **Ilustrado** | Colagem |
| Aula rápida, matemática, "explicando do zero", passo a passo | **Quadro** | Flat |
| Frase de impacto, motivacional, opinião, manifesto, gancho forte | **Kinetic** | Retrô |
| Estatística, pesquisa, economia em números, "o número que ninguém conta" | **Infográfico** | Argila 3D |
| Golpe, tecnologia, relacionamento, "história contada por prints" | **Interface** | Flat |
| Caso real, crime famoso, mistério, "o que aconteceu em 19XX" | **Jornal** | Colagem |
| "Como funciona por dentro", invenção, engenharia, arquitetura | **Blueprint** | Linha |
| Nostalgia, games, música, cultura pop, tecnologia antiga | **Retrô** | Kinetic |
| Dicas, listas, hábitos, finanças pessoais, produto, institucional leve | **Flat** | Infográfico |
| Geopolítica, guerras, viagens, comércio, "onde fica", rotas | **Mapa** | Jornal |

Não repita o mesmo estilo + paleta em vídeos seguidos da mesma pessoa. Alterne o estilo ou, no mínimo, a paleta e o cenário.

---

## 1. ARGILA 3D — `motor/src/estilos/argila3d.tsx` · status: parcial
**Visual:** um objeto 3D "de massinha" por ideia, no centro, sobre palco escuro, com sombra macia e luz de estúdio
(chave + recorte colorido). Números enormes em 2D por cima, títulos curtos no topo.

- **Paleta padrão:** fundo azul-noite `#0E1016` → `#1A1E28`, argila off-white `#F1EEE8`, destaque `#2F7BFF`.
  Troque o destaque pela cor da marca. Evite repetir o laranja das referências.
- **Tipografia:** Inter 800 nos números e títulos; legenda `KCap kind="escuro"` (Inter 700 branca, destaque na cor).
- **Objetos prontos:** `calendario{dia}`, `documento{carimbo}`, `moeda{simbolo}`, `barras{valores,destaque}`, `celular{texto}`,
  `pino`, `relogio`, `pizza{partes}`, `lupa`, `balao{pontos}`, `carimbo`, `predio`.
  Criar novos segue o mesmo molde: `RoundedBoxGeometry` + `clay()`.
- **Cenários:** `ArgilaBg kind="estudio" | "cidade"`. A criar quando precisar: mercado, banco, tribunal, sala.
- **Motions:**
  - objeto entra com pop + giro e flutua;
  - barras crescem uma a uma;
  - moeda gira, relógio anda, pino quica, balão "digita".
  - Número grande (`BigStat`) entra com pop e blur e depois dá lugar ao objeto.
- **Ritmo:** troca de objeto a cada 1,5–3 s, sempre no tempo da palavra.
- **Trilha:** eletrônica suave/lo-fi tensa (notícia), 90–110 bpm.
- **Erros a evitar:**
  - mais de 2 objetos ao mesmo tempo;
  - número sem rótulo ("15,8 bi" sem "faltam em 2028");
  - objeto encostando na legenda: mantenha o objeto entre y = 400 e 1150.

## 2. COLAGEM — `motor/src/estilos/colagem.tsx` · status: parcial
**Visual:** mesa de papel creme/kraft com fibras; fotos P&B coladas com fita e legenda em etiqueta salmão; documentos
datilografados com tarjas pretas e um círculo feito à mão na linha importante; tiras de papel rasgado com a frase-chave;
recortes de cor (verde, preto, jornal) que entram pelas bordas.

- **Paleta padrão:** papel `#EFE6D6`, kraft `#C9A57A`, tinta `#2B2118`, destaque salmão `#E58C6E`, verde `#2F6B4F`, preto `#1B1714`.
  Cena escura ocasional (`PaperBg dark`) para mudar o clima.
- **Tipografia:** EB Garamond (legenda `KCap kind="papel"` com marca-texto salmão na palavra-chave) e JetBrains Mono no texto datilografado.
- **Componentes:** `PaperBg`, `TapedPhoto{src|children, caption}`, `RedactedDoc{title, circle}`, `TornStrip{text}`, `Scraps`, `Silhueta`.
- **Motions:**
  - Ken Burns lento na foto;
  - documento que se datilografa e as linhas aparecem;
  - círculo à mão que se desenha;
  - tira rasgada que desliza;
  - recortes entrando.
- **Fotos de pessoas reais:** só arquivo fornecido pela pessoa (com direito de uso) ou de domínio público baixado por ela.
  Sem foto, use `Silhueta` ou objeto (livro, carta, quadro).
- **Trilha:** piano/cordas contemplativo, 70–90 bpm.
- **Erros a evitar:**
  - foto colorida moderna (quebra o clima: use `bw`);
  - texto demais no documento: ele é textura, a frase vai na legenda ou na tira.

## 3. PARTÍCULAS — `motor/src/estilos/particulas.tsx` · status: parcial
**Visual:** preto profundo com grão; tudo feito de milhares de pontos brancos que se desmancham e se remontam em outra
forma (rosto → cadeira → átomo → galáxia → onda → olho).

- **Paleta:** P&B, brilho branco; destaque só no texto da legenda (`KCap kind="suave"`: cinza → branco na palavra falada).
- **Formas prontas:**
  - `textPts('E=mc²')`, `iconPts('olho'|'cabeca'|…)`;
  - `sphere`, `galaxy`, `atom`, `rings`, `waveGrid` + `animateWave`, `dust`;
  - imagens por luminância: `useImagePts('<projeto>/retrato.png')`, a partir de foto liberada ou de imagem gerada de **objeto**, nunca de rosto real gerado.
- **Motions:** `DotField` com chaves `{at, pts, spin, tilt}`. Morfe a cada 1,2–2,5 s, gire as formas 3D devagar e respire o grão.
- **Trilha:** ambient/drone com pulsos, 60–80 bpm.
- **Erros a evitar:**
  - formas finas demais em poucos pontos (fica ilegível);
  - morfar a cada palavra (cansa).

## 4. LINHA — `motor/src/estilos/linha.tsx` · status: parcial (prévia completa v036 "Por que procrastinamos" aprovada como exemplo pelo titular)
**Visual:** grafite `#141313`, traço fino off-white que se desenha, pontos de acento laranja pulsando, rótulos mono
pequenos em caixa alta ("A MENTE SELECIONA"), diagramas (órbitas, Venn, escada, grade de quadrados).

- **Paleta padrão:** fundo `#141313`, traço `#D9D4CC`, acento `#E8743B`. Variações: acento ciano `#3BC9E8` ou lima da marca.
- **Tipografia:** legenda `KCap kind="suave"` (Inter, cinza com a palavra falada em branco negrito); rótulos JetBrains Mono 22 px.
- **Ícones prontos (`ICONS`):**
  - livro, olho, cabeca, orbita, predio, lupa, vela, carro, lampada, aviao, venn, onda, escada, pessoa;
  - cerebro, relogio, grafico, moeda, globo, sol, documento, coracao, balao, planeta.
  - Para criar um ícone novo: viewBox 0–100, poucos traços, 1 a 3 pontos de acento.
- **Motions:**
  - `LineIcon` se desenha em ~0,9 s;
  - `Trace` (setas e conexões), `OrbitDot` (ponto que orbita), `Tag` (rótulo que se digita);
  - `SquareGrid` (proporção/contagem).
- **Trilha:** ambient minimal/piano + textura, 70–90 bpm.
- **Erros a evitar:**
  - ícone grande demais (fica pesado): de 260 a 520 px;
  - mais de 3 rótulos na tela.

## 5. ILUSTRADO — `motor/src/estilos/ilustrado.tsx` · status: proposto
**Visual:** cenas pintadas à mão (traço suave, cores terrosas) com personagens simpáticos, de cabeça grande, recortados.
A câmera passeia (paralaxe) e os personagens respiram, piscam e gesticulam.

- **Ativos:** gerados por IA de imagem, **sempre no mesmo prompt de estilo**:
  - 1 fundo por cenário, de 2400 px de largura;
  - cada personagem num PNG com fundo transparente, de corpo inteiro e frontal;
  - variações de pose num PNG por pose.
  - Prompt base: *"ilustração digital pintada, traço suave, cores terrosas, personagens de cabeça grande e olhos simples,
    luz suave, sem texto, fundo [cenário]"*.
- **Componentes:** `ParallaxScene{layers, panX, zoom}`, `Boneco{src, talk}`, `ArchCard` (cartão final em arco).
- **Legenda:** serifada branca pequena (`KCap kind="papel"` com `ink="#FFFFFF"`) ou `suave`.
- **Pessoas sagradas e históricas:** representação respeitosa e genérica, sem caricatura.
- **Por que é proposto:** depende de gerar os PNGs (custa créditos de imagem) e de testar a consistência do personagem entre as poses.

---

> Estilos 6–14: componentes renderizados e checados em quadros e na vitrine `motor/src/videos/estilos_teste2`
> (`harness/entry-estilos_teste2.tsx`, 34 s, uma cena por estilo). Status **parcial** até o primeiro vídeo aprovado.
> Todos aceitam `pal` (paleta) — a paleta padrão é só ponto de partida.

## 6. QUADRO — `motor/src/estilos/quadro.tsx` · status: parcial
**Visual:** lousa verde-ardósia com manchas de giz apagado, traço de giz com textura (filtro SVG), escrita à mão letra
por letra, sublinhados/círculos/setas feitos "na hora", apagador em zigue-zague como transição.

- **Paleta padrão (`QUADRO`):** fundo `#22302A`, giz `#EDEBE4`, destaques amarelo `#F2D36B`, rosa `#F29C9C`, azul `#9CC8F2`.
- **Fonte:** Caveat (`XFONT.giz`) em títulos curtos e na legenda.
- **Componentes:** `QuadroBg{moldura}`, `GizDefs` (1 por cena, obrigatório), `GizIcon` (qualquer ícone de `ICONS`),
  `GizText`, `GizMark{sublinha|circulo|seta|xis|check}`, `Apagador` (~0,6 s).
- **Legenda:** `KCap kind="suave" font={XFONT.giz} size={64} ink={QUADRO.giz} dim="rgba(237,235,228,.35)" accent={QUADRO.amarelo}`.
- **Trilha:** acústica leve / lo-fi, 80–95 bpm. SFX: giz riscando, apagador.
- **Erros a evitar:** escrever frases longas na lousa (no máximo 3 palavras); esquecer `GizDefs` (traço fica liso).

## 7. KINETIC — `motor/src/estilos/kinetic.tsx` · status: parcial
**Visual:** fundo preto, a própria fala vira palavras gigantes em Anton caixa alta que batem com tremor; a lâmina anterior
sobe e apaga; palavra-chave em acento; palavras-fantasma em contorno rolando no fundo.

- **Paleta padrão (`KINETIC`):** fundo `#0B0B0B`, tinta branca, acento lima `#C6FF3D`.
- **Componentes:** `KineticStack{big, hl, max}` (lê o words.json), `Slam` (palavra/número que bate com faixa),
  `BgMarquee{words}` (decorativo, marcado `data-qa="decor"`), `KineticBar`, `shake()`.
- **Legenda:** NÃO use KCap — o texto gigante já é a legenda (uma leitura por vez).
- **Trilha:** batida marcada 100–128 bpm; um "hit" por `Slam`.
- **Erros a evitar:** `big` em mais de 1 palavra por bloco; `max` > 3 (vira parede de texto).

## 8. INFOGRÁFICO — `motor/src/estilos/infografico.tsx` · status: parcial
**Visual:** azul-noite com grade de pontos, contadores grandes, barras que crescem uma a uma, linha que se desenha,
rosca de percentual, grade de pessoas ("1 em cada N"), etiqueta de fonte discreta.

- **Paleta padrão (`INFO`):** fundo `#0F1724`, tinta `#E6EDF7`, acento âmbar `#FFB020`, 2º `#3DD6C6`, 3º `#FF5C7A`.
- **Componentes:** `InfoBg`, `Counter{to, prefix, suffix, dec}` (formato pt-BR), `BarChart{data}`, `LineChart{pts 0–1}`,
  `Donut{pct}`, `PictoGrid{n, lit}`, `FonteTag`, `fmt()`.
- **Regra dura:** todo número na tela está no `fatos.md` com fonte; `FonteTag` mostra a fonte quando o dado é central.
- **Legenda:** `KCap kind="escuro" accent={INFO.accent}` (y ≈ 1450 se houver gráfico grande).
- **Erros a evitar:** mais de 5 barras; dois gráficos ao mesmo tempo; número sem unidade.

## 9. INTERFACE — `motor/src/estilos/interface.tsx` · status: parcial
**Visual:** fundo claro, celular genérico (sem marca) com conversa que aparece em tempo real ("digitando…"),
notificação que desce, busca que se digita com resultados-esqueleto, janela de desktop e cursor que clica.

- **Paleta padrão (`UI`):** fundo `#DDE3EA`, tela branca, bolha "eu" violeta `#5B5CF6`, bolha "ele" `#E9ECF1`, alerta `#F04438`.
- **Componentes:** `UiBg`, `Phone{scale, tilt}`, `ChatScreen{title, msgs}`, `Notif{app, text, alerta}`, `SearchScreen{query}`,
  `Janela{title}`, `Cursor{path}`, `Encenacao` (selo).
- **Regras:** nada de cores/layout de apps reais (sem verde de mensageiro, sem logos, sem "Google"); conversa é sempre
  encenação — selo `Encenacao` ou dito na narração.
- **Legenda:** `KCap kind="pilula" accent={UI.accent}`.
- **Erros a evitar:** mensagens longas (máx. ~40 caracteres); mais de 4 bolhas visíveis.

## 10. JORNAL — `motor/src/estilos/jornal.tsx` · status: parcial
**Visual:** papel envelhecido com manchas e vinheta (ou mesa escura), primeira página que gira e para, manchete
serifada pesada, colunas de texto em barras, carimbo vermelho que bate, recortes serrilhados, máquina de escrever.

- **Paleta padrão (`JORNAL`):** papel `#E9DFC8`, tinta `#1E1A14`, vermelho `#A3261B`, marca-texto `#F2C94C`.
- **Fontes:** Playfair Display 900 (`XFONT.jornal`) e Courier Prime (`XFONT.maquina`).
- **Componentes:** `JornalBg{mesa}`, `PrimeiraPagina{nome, data, kicker, title, foto}`, `Datilo`, `Carimbo`, `Recorte`.
- **Regras:** nome do jornal sempre inventado (padrão "O DIÁRIO"); manchete = fato-chave curto, não a frase narrada;
  colunas são barras, nunca texto falso legível; datas e fatos vêm do `fatos.md`.
- **Legenda:** `KCap kind="papel" font={XFONT.maquina} weight={700} accent={JORNAL.marca}` (`ink` claro sobre a mesa escura).
- **Erros a evitar:** girar toda página (1 giro por vídeo basta; depois `spin={false}`).

## 11. BLUEPRINT — `motor/src/estilos/blueprint.tsx` · status: parcial
**Visual:** azul de planta técnica com grade dupla e margem, traço branco que se desenha sobre linhas de construção
tracejadas, cotas com setas e medida, chamadas em cotovelo, engrenagens girando, carimbo de prancha no canto.

- **Paleta padrão (`BP`):** fundo `#0D3B6E`, traço `#DCEBFF`, acento `#FFD166`.
- **Componentes:** `BlueprintBg{carimbo}`, `BpIcon` (qualquer ícone de `ICONS`), `Cota{x1,y1,x2,y2,label,off}`,
  `Chamada{x,y,tx,ty,text}`, `Engrenagem{r, teeth, speed}` (pares com `speed` oposta).
- **Legenda:** `KCap kind="suave" font={XFONT.mono} size={46} ink={BP.line} dim="rgba(220,235,255,.4)" accent={BP.accent}`.
- **Erros a evitar:** cotas com medidas inventadas (use só o que foi dito, ou rótulos sem número).

## 12. RETRÔ — `motor/src/estilos/retro.tsx` · status: parcial
**Visual:** anos 80/synthwave: céu degradê roxo, sol listrado, montanhas em linha ciano, chão de grade rosa em
perspectiva correndo, texto cromado com contorno neon que pisca, camada VHS (scanlines, tracking, OSD "PLAY ▶"), glitch RGB.

- **Paleta padrão (`RETRO`):** rosa `#FF3EA5`, ciano `#2DE2E6`, amarelo `#FFD319`, roxo `#7A2BF5`.
- **Fonte:** Orbitron (`XFONT.retro`).
- **Componentes:** `RetroBg{horizon, sol, speed}`, `ChromeText{text, sub}`, `VHS{osd, forte}` (sempre por último),
  `Glitch{at:[...]}` (envolve a cena; use nas viradas).
- **Legenda:** `KCap kind="suave" font={XFONT.retro} weight={700} size={42} ink="#FFFFFF" glow={RETRO.rosa} accent={RETRO.ciano}`.
- **Trilha:** synthwave 90–110 bpm. **Erros a evitar:** glitch a cada frase (no máximo 1 a cada 6–8 s).

## 13. FLAT — `motor/src/estilos/flat.tsx` · status: parcial
**Visual:** fundo liso creme com formas grandes translúcidas flutuando, formas sólidas que entram com pop, bonequinho
simples (acena, pensa, comemora), ícones em círculos coloridos, lista numerada, transição de círculo que cobre a tela.

- **Paleta padrão (`FLAT`):** fundo `#FFF4E4`, tinta `#1D1D1F`, cores `#FF5A5F`, `#3D5AFE`, `#00B894`, `#FFC145`.
  É o estilo mais fácil de pôr na marca do comprador: troque as 4 cores pelas da marca.
- **Componentes:** `FlatBg{cor}`, `Forma{circulo|quadrado|triangulo|pilula|anel|estrela}`, `Boneco{cor, acao}`,
  `FlatIcon{name, bg}`, `ListaItem{n, text, cor}`, `Cobertura{cor}`.
- **Legenda:** `KCap kind="pilula" accent={FLAT.c4}`.
- **Erros a evitar:** mais de 4 cores na mesma cena; `ListaItem` com frase longa (máx. 3 palavras).

## 14. MAPA — `motor/src/estilos/mapa.tsx` · status: parcial
**Visual:** mapa-múndi vetorial escuro (Natural Earth 1:110m, domínio público; dados em `motor/src/estilos/dados/mundo.json`),
câmera que viaja e dá zoom (afasta no meio de viagens longas), países que acendem, pinos que caem com rótulo e pulso,
rotas em arco com ponto viajando.

- **Paleta padrão (`MAPA`):** fundo `#0A1220`, terra `#22324A`, destaque `#FF6B3D`, rota `#FFD166`.
- **Componentes:** `WorldMap{cams:[{at, foco, zoom}], hl:[{at, pais, cor}], pinos:[{at, onde, label}], rotas:[{at, de, para}], cy}`,
  `pos()` e `PAISES`. `foco`/`onde`/`de`/`para` aceitam nome do país (em inglês, como no JSON: 'Brazil', 'Japan',
  'United States of America') ou `[lon, lat]` para cidades.
- **Zoom:** 1 = mundo; 2–3 = continente/país grande; 5–8 = país pequeno/região (o 1:110m perde detalhe acima de ~8).
- **Legenda:** `KCap kind="escuro" accent={MAPA.hl}`.
- **Erros a evitar:** fronteiras disputadas — mostre o país sem tomar lado; nunca use mapa para "provar" algo que não está no `fatos.md`.

---

## Variações (para não ficar repetitivo)
- **Paleta:** troque o destaque (marca da pessoa) e o tom do fundo.
- **Cenário:** estúdio, cidade, papel claro ou escuro, grafite com grade.
- **Gancho:** número gigante, objeto absurdo, pergunta em título, rosto/retrato, cena.
- **Legenda:** `escuro`, `pilula` (fundo escuro em vídeos claros), `suave`, `papel`; e as variações por estilo com
  `font` (XFONT.giz, maquina, retro, mono, impacto), `ink`, `dim`, `weight` e `glow`.
- **Paleta de qualquer estilo:** todo componente aceita `pal={{...PADRAO, accent: '#…'}}` — troque só o necessário.
- **CTA:** cartão com o @ da pessoa, objeto (balão, celular) com a palavra-chave, cartão em arco (ilustrado), letreiro.
