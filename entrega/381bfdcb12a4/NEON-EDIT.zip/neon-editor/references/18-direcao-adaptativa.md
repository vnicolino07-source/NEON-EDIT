# 18 · Direção criativa adaptativa

O NEON EDITOR não reproduz os vídeos aprovados. Ele **lê o assunto e a narrativa de cada vídeo novo e decide** o que
mostrar, com o mesmo nível de sofisticação. Os aprovados (`exemplos-aprovados/`) mostram o **padrão de qualidade**, não
um roteiro a copiar. Este guia complementa o `14-direcao-criativa.md` (prioridades e repertório).

## O processo (para cada vídeo)

1. **Rascunho automático:** `python pipeline/neon.py mapa --proj projetos/<id>`. Ele gera `mapa_sugerido.md` com:
   - as frases e as intenções de cada uma: gancho, pedido literal, número, lista, comparação, ação, resultado, pergunta, afirmação forte, CTA;
   - o **assunto provável** e o vocabulário visual correspondente (`config/vocabulario_visual.json`);
   - o alvo de eventos visuais.

   É heurístico: as palavras-chave podem errar. Leia a fala inteira e corrija o rascunho.
2. **Entenda o vídeo como roteirista:** qual é a promessa, a virada e a prova? Qual é a frase que a pessoa mais quer que
   fique na cabeça de quem assiste? Ela merece o maior momento visual do vídeo (não necessariamente o gancho).
3. **Escolha uma linguagem visual para o vídeo,** coerente com o assunto e diferente da dos vídeos anteriores, e anote-a
   em uma frase. Exemplos:
   - "rede de dados que se monta" para IA;
   - "painel de negócios que cresce" para empreendedorismo;
   - "feed e métricas" para marketing;
   - "quadro de aula" para um tutorial.

   Ela dá unidade: os efeitos do vídeo parecem pertencer ao mesmo mundo.
4. **Para cada frase, decida:** reutilizar um componente, **adaptar** (parâmetros, texto, composição, combinação) ou
   **criar** um novo. Pergunte sempre: *o que aparece na tela que prova ou demonstra isso, no instante em que é dito?*
5. **Monte o mapa final** (tempo → fala → intenção → efeito → componente → layout → som) e confira:
   - nenhum trecho > 2 s parado;
   - um foco por vez;
   - nenhum efeito sem ligação com a fala;
   - a estrutura é diferente da do vídeo anterior (gancho, sequência de layouts, objeto principal, CTA).
6. **Teste os componentes novos em quadros** antes do vídeo inteiro (`10-renderizacao.md`) e passe no `qa_layout`.

## Vocabulário por assunto (ponto de partida, não limite)

| Assunto | Linguagem visual | Componentes prontos | 3D | Ideias a criar |
|---|---|---|---|---|
| Empreendedorismo / negócios | crescimento, solidez, painel | GrowthChart, MetricTiles, NeonCounter, VersusCard, Stamp | Bars3D, Coins3D | organograma que se monta, funil 3D, loja isométrica |
| Tecnologia / IA | rede, interface futurista, código, varredura | Network3D, TechHUD, CodeWindow, NeonPrompt, StepTrack, LiveExplain | Network3D, ShatterText3D | circuito acendendo, holograma, fluxo de dados entre ícones |
| Marketing / redes | funil, desempenho, notificações, feed | FunnelCard, GrowthChart, MetricTiles, NeonToasts, PostPanel, KineticStack | Bars3D | feed rolando com o próprio vídeo, chuva de comentários |
| Finanças | moedas, recibos, balança, comparação de preço | Coins3D, NeonCounter, NeonBeforeAfter, Stamp | Coins3D, Falling3D | recibo imprimindo, cofre, balança |
| Educação / tutorial | quadro, lista numerada, diagrama, marca-texto | NeonSteps, NeonChecklist, NeonQuote, VersusCard | Text3D | anotações à mão, mapa mental, quadro branco |
| Produtividade | tempo, calendário, checklist | Clock3D, NeonChecklist, NeonProgress | Clock3D | calendário virando, ampulheta |
| Criatividade / edição | a própria edição vira efeito | PresenterStage (tela cortada, celular), SelectionBox, IdentityCard, KineticGiantText | ShatterText3D | linha do tempo multipista, camadas isométricas |

Os assuntos se misturam. Um vídeo sobre "IA para vender mais" é tecnologia **e** marketing. Escolha o que cada frase pede.

## Criar componentes novos (quando nada pronto demonstra a frase)

- Comece de um componente parecido (`13-componentes.md`) e de `components/adaptativo/` (exemplos limpos de 2D e 3D).
- **2D (React/SVG/CSS):** cards, gráficos, interfaces, tipografia, diagramas. Mais rápidos de renderizar.
- **3D (Three.js via `ThreeLayer`):** só quando volume, luz ou física comunicam.
  - Primitivas (caixas, cilindros, esferas, texto extrudado) resolvem muito: moedas são cilindros, barras são caixas, uma rede é esferas e cilindros finos.
  - Linhas WebGL têm 1 px e somem no render por software: use cilindros finos.
  - A câmera fica fixa ou com movimento lento; a cena inteira é função de `t`.
- **Sempre:**
  - só os tokens da marca;
  - textos e números como parâmetros;
  - saída de 0,3 s;
  - texto testado com a palavra mais longa;
  - fundo de card só com a superfície da marca;
  - nada sobre o rosto;
  - recorte validado para o que fica atrás da pessoa.
- **Imagens reais ou geradas** (fotos, produtos, ilustrações) só se a pessoa fornecer ou autorizar a fonte. Nunca baixe
  imagens de terceiros, logotipos ou fotos de pessoas públicas.
- Registre o componente novo como experimental (`13-componentes.md`). Depois da aprovação do vídeo, ele vira acervo.

## Nível de sofisticação (o que separa "template" de direção)

- **Literalidade:** o pedido na fala acontece na tela, no mesmo instante.
- **Continuidade:** um elemento se transforma no próximo em vez de sumir e outro aparecer do nada (card que ganha
  uma etapa, botão que vira resultado, rede que se acende).
- **Profundidade:** camadas (atrás da pessoa com recorte, frente, interface), e não só cards chapados.
- **Ritmo:** evento a cada ~1 s, maior intervalo ≤ 2 s, com respiro nos momentos emocionais.
- **Precisão:** números, nomes e palavras exatamente como ditos; legenda fiel.
- **Coerência:** uma linguagem visual por vídeo, na identidade da marca.

## O que está implementado e o que não está

| Capacidade | Situação |
|---|---|
| Rascunho de intenções e assunto (`neon.py mapa`) | implementado; testado no v002 (detectou os 3 pedidos literais) e na edição de teste; heurístico (palavras-chave) |
| Componentes adaptativos 2D (GrowthChart, FunnelCard, MetricTiles, TechHUD, CodeWindow, KineticStack, Stamp, VersusCard) | implementados e renderizados na vitrine `DirecaoAdaptativa` com `qa_layout` sem falhas; não aprovados por cliente |
| Componentes adaptativos 3D (Network3D, Bars3D, Coins3D) | implementados e renderizados na vitrine; não aprovados por cliente |
| Decidir a linguagem visual e criar componentes novos por vídeo | é trabalho do Claude seguindo este guia, não de um algoritmo; demonstrado na edição de teste (ver `17-pendencias-e-limitacoes.md`) |
| Imagens geradas por IA, troca de roupa/cenário, vídeo gerado | **não implementado** (não há gerador de imagem/vídeo no kit) |
| Cenas 3D complexas (personagens, ambientes modelados) | **não implementado**; só primitivas e texto 3D |
