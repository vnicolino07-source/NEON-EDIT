# 19 · O que as referências do gênero ensinam (destilado, sem os vídeos)

Durante o desenvolvimento foram estudados 8 vídeos de terceiros: Reels/Shorts de 23 a 115 s, em português, sobre IA e
criação de conteúdo. **Os vídeos não fazem parte do kit**: ficam no ambiente privado do titular. Aqui estão só as
medições e as técnicas, convertidas em regras independentes. Nunca copie a marca, a paleta, as fontes, os personagens ou
os textos de outro criador.

## Medições (8 vídeos, medidas automáticas em 29/10/2026)

| Medida | Faixa | Mediana | Regra para o NEON EDITOR |
|---|---|---|---|
| Primeira fala | 0,00–0,05 s | 0,02 s | a fala começa no quadro 1 |
| Fala ativa | 90–100% do tempo | 96% | pausas internas ≤ 0,25 s (o kit reduz as > 0,30 s para 0,14 s) |
| Palavras por segundo | 3,08–4,02 | 3,5 | 3,5–4,4 depois da aceleração (aprovados: 3,7 e 4,4) |
| Eventos visuais medidos por segundo* | 0,97–2,2 | 1,7 | ≥ 1 evento declarado por segundo; nunca > 2 s parado |
| Cortes duros de câmera por minuto | 0–24 | 5,6 | não é obrigatório cortar a câmera: o dinamismo pode vir dos gráficos |
| Loudness integrado | −14,1 LUFS (todos) | −14,1 | master em −14 LUFS / −1 dBTP |

\*A medição automática subestima animações pequenas. Os vídeos mais densos ficaram com o maior intervalo entre 1,2 e
1,7 s. Os menos densos tinham trechos de 3–5 s sem mudança: é o que **não** fazer.

## Técnicas observadas, convertidas em regras

**Abertura**
- Elemento gráfico ligado à primeira frase já no primeiro segundo: título enorme atrás da pessoa, pergunta na tela
  respondida em seguida, demonstração imediata (arquivo entrando, cronômetro) ou prova "este vídeo".
- O gancho mostra a promessa; não usa vinheta nem logo.

**Ritmo e cortes**
- Um elemento novo a cada ~0,5–1 s nos vídeos mais fortes. Cada elemento entra, comunica e **sai ou se transforma** no
  seguinte.
- Troca de layout no corte, para cobrir saltos de imagem.

**Layouts**
- O mais comum é o dividido: interface ou ilustração em cima (~40–45%) e a pessoa num painel embaixo.
- Variações observadas:
  - tela cheia com cards pequenos no topo, sem cobrir o rosto;
  - tela gráfica cheia por 1–2 s;
  - quadro branco em cima;
  - interface clara em tela cheia.

**Motion graphics que funcionam** (a animação acontece **na palavra**)
- Checklist que marca no item falado e contador que para no número falado.
- Carimbo que cai na palavra de juízo ("grátis", "aprovado", "caro").
- Prompt digitado com envio e arquivo arrastado para um chat.
- Forma de onda com as pausas cortadas e a duração caindo.
- Tabela que ganha linhas e gráfico com a última barra no acento.
- Tipografia empilhada em crescendo.
- Fluxo A → B → C com ícones e anotações à mão (círculos, setas, "erro!").

**3D e profundidade**
- Título ou objeto atrás da pessoa com recorte, planta isométrica girando, objetos caindo e camadas isométricas.
- Muito do que parece 3D é 2D com perspectiva: só chame de 3D o que é 3D.
- Trocas de roupa, objeto ou cenário "na palavra" exigem geração de imagem/vídeo por IA, que **o kit não tem**.

**Transições**
- Troca de layout no corte, flash de luz curto, recuo de câmera revelando o mapa inteiro e grade de recapitulação
  (2×2) antes do CTA.

**Legendas**
- Blocos curtos com uma palavra destacada. Estilos vistos:
  - branca com destaque colorido;
  - duas linhas (sans + serif itálico);
  - rótulo mono numa tarja.
- Em vários vídeos, a legenda **muda quando a fala pede** ("deixa a legenda amarela"): é um efeito literal, não um padrão.

**Som**
- Voz sempre à frente.
- Efeitos curtos nas entradas, digitação nos prompts e impacto nos carimbos.
- Loudness padronizado em −14 LUFS.

**CTA**
- Quase sempre: campo de comentário com a palavra falada digitada, botão com cursor ou envio, e às vezes uma
  notificação de DM respondida.
- Se a palavra não estiver clara no áudio, use "comente aqui embaixo" e não invente.

**Variação de tema por segmento**
- Um mesmo criador mudava a paleta a cada "profissão" demonstrada.
- No NEON EDITOR, a marca fica fixa e o que muda por segmento é o **objeto e a metáfora** (`18-direcao-adaptativa.md`).

## Como usar referências novas da pessoa

Siga `01-configuracao-inicial.md` (pergunta 10): ficha por referência com tempos exatos, técnicas a usar e o que não
copiar. Meça com os mesmos critérios acima: primeira fala, palavras/s, eventos/s, maior intervalo e loudness.
