# 03 · Transcrição, correções e sincronia

A legenda e todo efeito "na palavra" dependem dos tempos das palavras. Os problemas abaixo aconteceram de verdade e
estão resolvidos no pipeline; entender a causa evita reintroduzi-los.

## Ferramenta

sherpa-onnx + Parakeet TDT v3 int8 (multilíngue, inclui português), com tempo por token. `neon.py transcrever` corta o
áudio a cada 16–23 s no ponto mais silencioso (o modelo erra mais em trechos longos) e junta os tokens em palavras
(token que começa com espaço = palavra nova). Saída: `data/words_raw.json` com `{w, s, e}` em segundos do bruto.

## Problemas conhecidos e como o pipeline trata

| Problema | Causa | Tratamento |
|---|---|---|
| **Palavra antecipada depois de pausa** | O modelo marca o início de palavras de começo de frase 0,25–0,4 s antes do som real. | `neon.py palavras` procura o ataque real na energia: se os primeiros 80 ms estão abaixo de −50 dB, avança o início até o primeiro ponto acima de −45 dB (até 450 ms). |
| **Palavra de começo de frase "fora" do trecho mantido** | Por causa da antecipação, a palavra cai antes do início do segmento. | Se a sobreposição com algum segmento é ≤ 20 ms, ela é ligada ao segmento que começa até 0,3 s depois do fim dela. |
| **Sobra de tomada descartada** (ex.: v002, "aí." de 90,67–92,35 s cujo fim invadia a janela do CTA) | O modelo estica a duração da última palavra de uma frase até a próxima fala. A ponta esticada entra no trecho mantido e a palavra aparece na legenda sem ter sido dita ali. | `neon.py palavras` avisa quando menos de 30% da palavra está dentro do trecho mantido. Confira e remova em `correcoes.json`. |
| **Palavra não reconhecida** (ex.: "IA" no CTA do v002) | Siglas curtas e palavras coladas somem. | `neon.py rever --proj P a:b` re-transcreve a janela; `neon.py formantes` mostra F1/F2: /i/ ≈ F1 300 Hz e F2 > 2000 Hz; /a/ ≈ F1 > 650 Hz e F2 ≈ 1300 Hz. Um glide /i/→/a/ sustentou "IA". Insira em `correcoes.json` e **peça confirmação** no relatório. |
| **Palavra trocada** (ex.: "Claudio" → Claude, "views" → reels, "o" → um) | Nomes próprios, marcas e estrangeirismos. | `trocar` em `correcoes.json`. Se for dedução (não ouvida com clareza), marque `motivo` e peça confirmação. |
| **Atraso da voz após o tratamento** | A cadeia de voz atrasa o áudio de forma constante: ≈ 25 ms do redutor de ruído `afftdn` + ≈ 3 ms do rubberband (medido com sinal de teste). Os vídeos aprovados compensaram 20 ms (sobra de ~6–8 ms, imperceptível; o limite de percepção fica perto de 40 ms). | `neon.py voz` mede o atraso de cada vídeo por correlação de envoltórias (v002: 26 ms), corta e mede de novo; o residual tem que dar 0 ± 2 ms. `qa/qa_latencia.py` confere a medição contra rajadas de tempo conhecido. |
| **Palavras sobrepostas** | Tokens muito próximos depois do mapeamento. | Início mínimo 50 ms depois da anterior; duração mínima 70 ms; o fim nunca invade a próxima. |

## `correcoes.json` (por tempo do bruto, nunca por índice)

```json
{
  "trocar":  [{"em": 6.16, "de": "Claudio", "para": "Claude"},
              {"em": 43.01, "de": "views", "para": "reels", "motivo": "inferido, confirmar"}],
  "remover": [{"em": 90.67, "de": "aí.", "motivo": "sobra da 1ª tomada"}],
  "inserir": [{"texto": "IA", "inicio": 93.05, "fim": 93.24, "motivo": "formantes i→a, confirmar"}]
}
```

`em` = início aproximado no bruto (tolerância 0,6 s; `tolerancia` muda isso). `de` evita trocar a palavra errada.
Índices mudam a cada transcrição; tempos não.

## Regras

- **Palavra incerta não vira gráfico** sem confirmação, e a dúvida vai no relatório da prévia.
- Corrija nomes de marca para a grafia oficial (Claude, ChatGPT, Instagram, Reels).
- Números: escreva como a pessoa disse ("três dias" → "3 dias" na legenda está ok; "três dias" → "72 horas" não).
- Recalcule tudo (`edl` → `palavras`) depois de qualquer mudança nos cortes ou na velocidade. Os tempos no código da
  composição vêm sempre de `T('palavra', n)` / `TE()` (ocorrência n da palavra na timeline final), nunca de números
  escritos à mão. Assim um corte novo não desalinha os efeitos.

## Como testar a sincronia

1. `buildBlocks` (legendas) lança erro se o texto das legendas não bater, palavra por palavra, com `words.json`.
2. `python qa/qa_legendas.py --proj P`: palavras em silêncio (início abaixo de −50 dB na voz final), palavras com menos
   de 70 ms, buracos > 0,6 s dentro de frase, palavras fora da duração.
3. Na prévia, confira de ouvido 3 pontos: primeira palavra, uma palavra destacada no meio e a palavra do CTA.
