# 06 · Motion graphics, layouts e transições

## Princípio

**Ilustre a fala, não decore.** Cada elemento existe porque demonstra, prova ou organiza uma frase específica e aparece
no momento em que ela é dita. Um efeito bonito sem ligação com a fala é ruído. Escolha consciente para cada momento:
**reutilizar** um componente, **adaptar** (parâmetros, composição) ou **criar** um novo. Não use um efeito só porque
está pronto, e não repita a mesma estrutura de um vídeo anterior.

## Layouts do apresentador (`PresenterStage`)

| Layout | Quando | Detalhe |
|---|---|---|
| Tela cheia | gancho, frases de impacto, CTA, momentos pessoais | zoom em degraus nas palavras de ênfase |
| Dividido (card no topo ≥ 38% da altura, vídeo arredondado embaixo) | explicação com interface, etapas, listas | o card ocupa a área do topo, rosto enquadrado a 30% da altura do painel |
| "Celular" (o próprio vídeo vira a tela de um aparelho à esquerda, painel à direita) | quando a fala é sobre postar, publicar, o vídeo em si | transição de 0,35 s; painel com botão e resultado |
| Tela gráfica cheia | resultado, número grande, comparação | sem o apresentador por ≤ 2 s |
| Composições livres | quando a fala pede ("tela embaixo, explicação em cima") | faça exatamente o que a frase descreve |

As transições entre layouts são **interpolações contínuas** (o retângulo do vídeo se move e muda de tamanho), não cortes.
`layoutWeights(t, {split: [[a,b]], phone: [[c,d]]})` gera os pesos; o resto é tela cheia.

## Transições que demonstram

| Efeito (componente) | Fala que pediu (v002) | Como funciona |
|---|---|---|
| Tela cortada no meio (`PresenterStage cut`) | "se eu quiser que ele corte essa tela no meio" | laser do acento atravessa em "corte"; as metades se afastam e giram 2,2° em "meio"; voltam ao fim da frase |
| Tela desce, explicação sobe (layout dividido + `LiveExplain`) | "minha tela fique pra baixo e a tela dele dá a explicação… fica em cima" | o painel do vídeo desce em "baixo"; a área de cima transcreve a fala ao vivo; seta para cima em "cima" |
| Apresentador vira celular (`PresenterStage` phone + `PostPanel`) | "deixa o vídeo pronto pra eu postar nos meus reels" | o vídeo encolhe para um aparelho; "Postar" vira "✓ postado" em "postar"; curva de visualizações sem números |
| Seleção de editor (`SelectionBox`) | "ele faz tudo o que eu quiser nesse vídeo aqui" | alças de seleção em volta do quadro inteiro |
| Texto gigante atrás da cabeça (`KineticGiantText` + recorte) | "um texto gigante atrás da minha cabeça" | texto em camadas cai atrás da pessoa em "texto", trava em "colocar", sai na frase seguinte |

## Movimento da marca

- Entrada padrão de interface: **sobe 56 px + escala 0,94 → 1 em 0,55 s**, curva `cubic-bezier(.2,.9,.25,1.15)` (`pop`).
- Saída: espelho da entrada em 0,3 s (`popOut`).
- Cascata: 0,3 s entre elementos do mesmo card.
- Digitação: 55 ms/caractere, ou `typedBetween` para casar início e fim com a fala.
- Movimentos novos (cinéticos, físicos, 3D) podem ter a curva que a cena pedir, com acabamento coerente.

## Sincronia

- Todo tempo vem de `T('palavra', n)` / `TE(...)`. Entradas começam **na palavra** (ou até 0,25 s antes, para estar
  inteiro quando a palavra soa). Saídas começam ~0,3 s antes do próximo elemento.
- Um elemento novo por vez. Quando dois precisam coexistir, o segundo transforma o primeiro (card que ganha uma etapa),
  em vez de empilhar.

## Hierarquia e limites

- Nada cobre o rosto/boca. Na tela cheia, gráficos ficam acima da cabeça (y < 450) ou nas laterais; em cima do vídeo
  real, todo texto pequeno vai **dentro de um card** (superfície + borda): rótulos mono soltos sobre a imagem ficam
  ilegíveis (lição do v002: o CTA foi colocado num card).
- Todo elemento cabe em 1080 px com margem de 56 px. Use `boxSizing: 'border-box'` em cards com padding e largura fixa
  (no v002 o card do CTA vazou pela borda até essa correção). Componentes dentro de um card recebem `width` = largura
  interna do card (largura − 2 × padding): no v002 o campo do CTA ficou 96 px mais largo que o card (defeito menor,
  encontrado depois da aprovação pelo `qa_layout.mjs`).
- Texto de tamanho fixo grande (texto gigante, palavra do CTA): verifique a palavra mais longa. "GIGANTE" a 300 px
  saía da tela; 235 px coube. `qa/qa_layout.mjs` mede isso.
- Interfaces que imitam um app real (Instagram, editor) são **ilustrativas**: genéricas, sem logotipo de terceiros.
- Números, percentuais e resultados só se ditos. "Visualizações" sem número é ok; "+212%" inventado não.

## Criar um componente novo

1. Arquivo em `motor/src/components/experimental/`, comentário no topo com `[EXPERIMENTAL <vídeo>]`, o que faz e os
   parâmetros.
2. Recebe `t` (segundos desde a entrada) e tempos relativos (`colorsAt`, `exitAt`...). Nada de relógio do navegador:
   tudo é função do quadro (o render é determinístico).
3. Só tokens da marca (`COLOR`, `FONT`, `TYPE`, `RADIUS`, `SPACE`, `alpha()`); nenhuma cor ou fonte escrita à mão.
4. Raiz com `fontFamily` herdada da composição; tamanhos testados com o texto mais longo possível.
5. Depois da aprovação do vídeo, documente em `13-componentes.md` e mova a seção para "aprovados".
