# 07 · Animações 3D (Three.js)

## Quando o 3D agrega

Use 3D quando **volume, luz, profundidade ou física comunicam algo** que o 2D não comunica:
- a palavra-âncora do gancho com peso físico (v002: "EDITORES DE VÍDEO" riscado e explodindo em letras);
- um objeto concreto citado na fala (dinheiro caindo, relógio desacelerando, arquivos);
- algo que fica "atrás" da pessoa, com profundidade real;
- um impacto (queda, explosão, giro) sincronizado com a palavra.

Não use 3D para decorar, para algo que a fala não menciona, nem em todo vídeo. Não chame de 3D o que é 2D com perspectiva.

## Componentes testados

| Componente | O que faz | Status |
|---|---|---|
| `ShatterText3D` | 1–2 linhas extrudadas letra a letra; risco vermelho atravessa em `strikeAt`; as letras tremem e explodem com velocidade, gravidade e giro em `explodeAt`, somem em ~0,95 s | aprovado (v002) |
| `Text3D` | texto extrudado com sombra numa parede invisível; entrada por linha, crescimento, giro | aprovado (A1, versão antiga da paleta) |
| `Falling3D` | objetos desenhados num canvas (notas, cards) caindo em ondas, atrás ou na frente | aprovado (A1) |
| `Clock3D` | relógio 3D que desacelera em `slowAt` | aprovado (A1) |
| `ThreeLayer` | base: cena determinística, um render por quadro, `preserveDrawingBuffer`, segura o render até carregar fontes | infraestrutura |

## Configuração que funcionou

- **Câmera:** perspectiva 36°, z = 10, olhando para a origem. Coordenadas: y ≈ 1,85–2,15 coloca o texto acima da cabeça
  no enquadramento padrão (rosto em y≈760 px). `size` 0,42 para 2 linhas de ~10 letras.
- **Luz:** ambiente 0,9 + direcional 2,3 de cima-esquerda (−4, 6, 9) + ponto do acento (intensidade 30, alcance 20) de
  baixo-direita: dá borda colorida da marca sem pintar a pessoa.
- **Materiais:** `MeshStandardMaterial`, frente na cor de texto ou acento (rugosidade 0,35), lateral em `borda` ou
  `acento_escuro` (0,5). Sem texturas.
- **Tone mapping:** ACES Filmic, exposição 1,05, sRGB.
- **Fonte:** TTF estático peso 700 da marca (`FONT_FILES.display3d`), carregado com `TTFLoader`. Variáveis não servem
  para o Three.js.
- **Física:** posições calculadas por fórmula a partir de `t` (velocidade inicial pseudoaleatória com semente fixa,
  gravidade 9,8/2). Nunca use `requestAnimationFrame` nem tempo real: cada quadro tem que sair igual em qualquer máquina.

## Integração com a edição

- Atrás da pessoa: renderize o 3D no `behind` do `PresenterStage` e ative `cutout` **só nos quadros com recorte
  gerado e conferido** (`neon.py recortes`). Fora desses quadros, posicione o 3D em área livre (acima da cabeça, laterais).
- O primeiro quadro precisa do 3D já visível se ele for o gancho: use `introFrom` negativo (ex.: −0,4 s).
- Som: impacto na entrada, laser/whoosh no risco, estilhaço na explosão (`08`).
- O render por software (SwiftShader, sem GPU) é lento: ~0,5–1,5 s por quadro com 3D. Planeje.

## Erros conhecidos

| Problema | Causa | Solução |
|---|---|---|
| Quadro com 3D vazio ou piscando | o render saiu antes da fonte carregar | `ThreeLayer` usa `holdRender` até o `init` terminar; sempre crie a cena dentro de `init` assíncrono |
| Resultado diferente em cada render | animação dependente de relógio | estado só função de `t` |
| WebGL indisponível no render | Chromium sem GL | Remotion: `Config.setChromiumOpenGlRenderer('angle')`; harness: `--use-gl=angle --use-angle=swiftshader` |
| Texto 3D na fonte errada | `arquivo_3d` aponta para fonte variável | gere/forneça TTF estático peso 700 |
