# 04 · Cortes, velocidade e ritmo

O ritmo aprovado vem do vídeo A1 e foi mantido no v002. Esses números são o padrão até a pessoa pedir outro.

## Cortes

1. **Escolha as janelas** que ficam, em segundos do bruto, em `projetos/<id>/cortes.json`:

```json
{
  "velocidade": 1.15,
  "respiro_final": 0.35,
  "janelas": [
    {"de": 0.20, "ate": 12.40, "rotulo": "gancho"},
    {"de": 25.84, "ate": 36.00, "rotulo": "2ª tentativa da explicação", "inicio_exato": true},
    {"de": 66.05, "ate": 82.38, "rotulo": "…termina em 'que eu gosto'", "fim_exato": true}
  ]
}
```

   - Sem `inicio_exato`/`fim_exato`, a borda é ajustada à fala: **0,05 s antes do ataque** da primeira palavra e
     **0,08 s depois do fim** da última (limiar −50 dB).
   - Com `inicio_exato`/`fim_exato`, a borda é exatamente a indicada. Use quando a emenda estiver **no meio** de uma fala
     contínua (ex.: cortar o começo de uma frase repetida). Escolha o ponto com `neon.py texto` + a energia: o corte
     precisa cair num vale de energia ou no fim natural de uma palavra.
2. **Dentro de cada janela**, pausas acima de **0,30 s** viram **0,14 s** (respirações longas somem; as curtas ficam,
   para a fala não soar robótica).
3. **O vídeo começa na primeira palavra** (silêncio inicial cortado) e termina com um respiro de 0,35 s.
4. Rode `neon.py edl`. Cada segmento é quantizado num número inteiro de quadros da timeline final (sem deriva de
   áudio/vídeo).

### O que cortar (critérios editoriais)

- Silêncios, hesitações ("é…", "hum"), frases abandonadas e repetidas (fica a versão completa e mais fluente).
- Trechos que repetem uma ideia já dita sem acrescentar nada (ex.: v002 cortou "que é que eu te envio?" depois de
  "Gostou dessa ferramenta?": era redundante e pouco claro).
- Nunca corte uma palavra pela metade; nunca junte duas frases de forma que mude o sentido; nunca crie uma frase que a
  pessoa não disse juntando pedaços.
- Muletas no fim de frase ("tá bom?") ficam se forem parte do jeito da pessoa e não arrastarem o ritmo.
- Se um corte mudar a imagem de forma brusca (pulo de posição), cubra com troca de layout, reenquadramento ou elemento
  gráfico exatamente no corte. Corte seco na imagem, sem fusão.

## Velocidade

- **Padrão 1,15×**, aplicada **depois** dos cortes, no vídeo inteiro, com rubberband (tom e formantes preservados).
- Faixa normal 1,10–1,20×. Até 1,30× só se a fala continuar clara. Nunca acelere um arquivo já acelerado sem medir.
- Referência de densidade: A1 ficou com **3,68 palavras/s** depois da aceleração; v002 com **4,4 palavras/s** (fala mais
  rápida já no bruto). As referências externas ficam entre 3,1 e 4,1. Acima de ~4,5 palavras/s, considere 1,10×.
- A voz é processada em `neon.py voz` (ver `08-audio-e-sfx.md`).

## Ritmo visual (regra dos 2 s)

- **Nunca mais de 2 s sem evolução visual perceptível.** A1: 70 eventos em 59,2 s (1 a cada 0,85 s; maior intervalo
  1,89 s). v002: 50 eventos em 52,3 s (1 a cada 1,05 s; maior intervalo 1,81 s).
- **Conta como evento:** entrada ou saída de elemento, transformação (botão → "postado"), etapa de demonstração,
  reenquadramento com degrau ≥ 5% de zoom, troca de layout, objeto 3D em movimento, corte de tela.
- **Não conta:** a legenda trocando de palavra; um card parado.
- **Um foco por vez:** o elemento entra, comunica e sai (ou se transforma no próximo). Nada cobre o rosto ou a boca.
- **Alterne layouts** (tela cheia, dividido com card no topo, tela gráfica cheia, "celular", composições). Não repita a
  mesma sequência de um vídeo anterior.
- **Reenquadramento:** degraus de ~0,22 s nas palavras de ênfase (zoom 1,00–1,16), punch-in curto em títulos,
  aproximação no fim.
- Declare cada evento em `VISUAL_EVENTS` (tempo, descrição) e rode `python qa/qa_ritmo.py meta.json`: falha com qualquer
  intervalo > 2 s.

## Abertura (primeiros 3 s)

- Impacto **no quadro 1**, ligado à primeira frase. Nada de vinheta, logo ou tela preta.
- Pelo menos 3 transformações nos primeiros ~4 s (ex.: v002 abriu com "EDITORES DE VÍDEO" em 3D já na tela, riscado em
  vermelho em "matar" e explodindo em "editores", com reenquadramento logo depois).
- Varie o tipo de gancho entre vídeos: palavra 3D, transformação do quadro, objeto, pergunta na tela, demonstração.
