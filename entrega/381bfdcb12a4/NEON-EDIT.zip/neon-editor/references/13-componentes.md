# 13 · Biblioteca de componentes

Todos em `motor/src/`. Todos leem cores e fontes da marca ativa. `t` = segundos desde a entrada do componente (a menos
que dito). `exitAt` = segundo (relativo) em que começa a saída de 0,3 s. Situação: **aprovado** = usado em vídeo aprovado
por cliente; **testado** = renderizado e conferido na vitrine/demonstração; **experimental** = criado, não aprovado.

Dependências comuns: `remotion`, `react`; 3D: `three` (+ `three/examples/jsm` TTFLoader, FontLoader, TextGeometry).
Compatibilidade: render no Remotion (CLI/Studio) ou no renderizador local (`motor/harness`). Tudo determinístico por quadro.

## Infraestrutura

| Nome | Arquivo | Função | Parâmetros |
|---|---|---|---|
| Tokens da marca | `brand/neon.ts` (+ `marca.json`) | cores, fontes, tamanhos, raios, espaços, curvas, durações | `COLOR`, `FONT`, `FONT_FILES`, `TYPE`, `RADIUS`, `SPACE`, `EASE`, `MOTION`, `alpha(hex, a)` |
| Movimento da marca | `motion/neonMotion.ts` | entrada/saída, cascata, digitação, contador, risco, barra, varredura, pulso, check | `pop(t, delay)`, `popOut(t, start)`, `phase(t, delay, dur, ease)`, `typedBetween`, `countUp`, `strike`, `grow`, `scan`, `pulse`, `check` |
| Tempo das palavras | `engine/timing.ts` | lê `data/words.json`/`edl.json`; tempo da n-ésima palavra | `T('palavra', n)`, `TE(...)`, `WORDS`, `TOTAL_FRAMES`, `FPS` |
| Legendas | `engine/captions.ts` + `components/neon/NeonLayout.tsx` (`NeonCaption`) + `NeonCaptionTrack.tsx` | blocos verificados contra a transcrição | `buildBlocks(['texto *destaque*', '!oculto'])`, `blockAt(blocks, t)` |
| Apresentador | `engine/Plate.tsx` | quadro + elementos atrás + recorte | `frame, behind, fgRanges` |
| Som | `engine/SoundTrack.tsx` | voz, trilha com ducking, efeitos | `sfx: {at, name, vol}[]`, `total` |
| Segurar render | `engine/render.ts` | `holdRender(label)` até fonte/3D carregar | — |
| Camada 3D | `components/three/ThreeLayer.tsx` | cena Three.js determinística | `t, init(ctx), update(ctx, t), width, height, shadows` |

## Layout

| Nome | Função | Parâmetros | Situação |
|---|---|---|---|
| `NeonFrame` (`NeonLayout.tsx`) | layout da biblioteca: tela cheia (0) ↔ card no topo + vídeo embaixo (1) | `split 0–1, slot, zoom, focusY, caption` | aprovado (A1) |
| `PresenterStage` (`experimental/PresenterStage.tsx`) | palco com 3 layouts que se transformam (cheia/dividido/celular), zoom em degraus, atrás + recorte, tela cortada no meio | `frame, t, weights, zoom, face, behind, cutout, cut{laserAt, splitAt, joinAt}`; helpers `layoutWeights`, `zoomSteps`, `captionY` | aprovado (v002, como `Stage`) → generalizado para o kit e testado na demonstração |

## Cards da biblioteca (`components/neon/NeonCards.tsx`)

Todos aceitam `t, exitAt, width, style`. A largura padrão é a da área do card no topo (968 px): **dentro de outro card,
passe `width` = largura interna do card**. Situação: testados na vitrine; usados em vídeos aprovados quando indicado.

| Nome | Uso | Parâmetros próprios |
|---|---|---|
| `NeonCounter` | número dito | `label, value, prefix, suffix, line1, line2, from, countDelay, countDur` |
| `NeonChecklist` | lista/etapas concluídas | `label, items[], checkTimes[]` (tempos das palavras) |
| `NeonBeforeAfter` | comparação | `label, before, after, beforeLabel, afterLabel, strikeAt, afterAt` |
| `NeonProgress` | processo acontecendo | `label, status, title, steps[], growDelay, growDur` |
| `NeonPrompt` | comando digitado/enviado (aprovado no CTA do v002) | `text, typeStart, typeEnd, sendAt` |
| `NeonToasts` | notificação / DM (aprovado no v002) | `items[{title, sub, icon: check|money|bell, at}]` |
| `NeonSteps` | passo a passo | `label, steps[], stepTimes[]` |
| `NeonBars` | crescimento (só dados reais) | `label, values[], delta` |
| `NeonQuote` | frase central com marca-texto | `before, highlight, after, markAt, fontSize` |
| `NeonImageReveal` | imagem com varredura | `tag, src, placeholder` |
| `NeonPoll` | enquete (só opções ditas) | `question, options[{text, pct, win}]` |
| `NeonCTA` | chamada final | `kicker, word, button, typeStart, buttonAt` |
| `NeonCard`, `Label` | blocos básicos | `children, style` / `children, color, style` |

## Motions criados no v002 (`components/experimental/`) — aprovados com o vídeo

| Nome | Demonstra | Parâmetros | Limitações |
|---|---|---|---|
| `ShatterText3D` | palavra 3D riscada em vermelho que explode em letras | `t` (absoluto), `lines[]`, `accentLine`, `strikeAt`, `explodeAt`, `y`, `size`, `introFrom` | até ~2 linhas de 10 letras com `size` 0,42; precisa de `arquivo_3d` |
| `KineticGiantText` | texto gigante em camadas atrás da cabeça | `lines[], landAt, lockAt, exitAt, top` | 235 px por linha: até ~7 letras largas; usar com recorte |
| `SelectionBox` | "tudo nesse vídeo": alças de seleção no quadro | `exitAt, label` | tela cheia |
| `IdentityCard` | identidade visual: cores, fontes e efeitos entrando nas palavras | `colorsAt, fontsAt, fxAt, exitAt` | mostra as cores e fontes da marca ativa |
| `StepTrack` | grava → pasta → Claude edita, com ilustração da etapa | `steps[{label, at, icon: phone|folder|spark}], frame, doneAt, exitAt, folder, ask, reading, done` | 3 etapas; textos internos parametrizados (padrões do v002, nome do guia genérico) |
| `PostPanel` | postar → postado + curva de visualizações sem números | `postAt, viewsAt, exitAt` | pensado para o layout "celular" |
| `LiveExplain` | a tela transcreve a fala ao vivo, última palavra destacada | `t, abs (tempo absoluto), words[{w, start}], exitAt` | até ~25 palavras visíveis |
| `TemplateCard` | modelo de vídeo (wireframe + itens) | `exitAt` | textos fixos: "card no topo / vídeo embaixo / legenda" |
| `ReferenceScan` | referência escaneada → estilo entendido | `scanAt, styleAt, exitAt` | chips fixos: ritmo, cortes, legendas, cores |
| `OnePrompt` | "1 prompt" com envio (avião de papel) | `sendAt, exitAt, caption` | — |

Ao adaptar um componente com textos fixos, transforme o texto em parâmetro (sem mudar o desenho) e registre aqui.

## Direção adaptativa (`components/adaptativo/`) — criados para o kit, testados na vitrine `DirecaoAdaptativa`, não aprovados por cliente

| Nome | Para quê | Parâmetros |
|---|---|---|
| `GrowthChart` | linha com área que se desenha, pontos, valor final contando (só número dito) | `label, values, labels, valueLabel{value,prefix,suffix}, drawAt, drawDur, exitAt, width, height` |
| `FunnelCard` | funil em cascata | `label, stages[{text, at}], exitAt, width` |
| `MetricTiles` | indicadores com número dito ou só tendência | `items[{label, value?, prefix, suffix, trend: up|down, at}], exitAt, width` |
| `TechHUD` | interface futurista: anéis, grade, varredura, linhas digitando | `title, lines[], lineStart, lineStep, exitAt, width, height` |
| `CodeWindow` | editor de código digitando com destaque de palavras-chave | `file, code[], typeStart, charsPerSec, exitAt, width` |
| `KineticStack` | tipografia em crescendo, palavra a palavra | `words[{text, at, hl, size}], exitAt, align` |
| `Stamp` | carimbo de veredito caindo | `text, tone: acento|alerta, at, exitAt, rotate` |
| `VersusCard` | comparação A × B com vencedor | `label, a{title, items}, b{title, items}, winner, winnerAt, exitAt` |
| `Network3D` (3D) | rede de nós e conexões com pulsos (IA, dados, comunidade) | `t, nodes, seed, buildDur, y, scale, exitAt, width, height` |
| `Bars3D` (3D) | barras 3D crescendo (forma relativa) | `t, values, growAt, stagger, exitAt` |
| `Coins3D` (3D) | moedas caindo e empilhando | `t, count, span, exitAt, seed` |

## Conjunto paralelo `components/criativos/` (Graficos2D.tsx, Cenas3D.tsx) + `library/VitrineCriativa.tsx`

Segundo conjunto de vocabulário adaptativo, com MetricBoard, LineChart, FlowDiagram, TechHUD e KineticWords (2D) e
Bars3D, Network3D e Symbol3D (3D: engrenagem, seta, alvo, balão, cifrão...). Foi conferido em 29/10: compila, renderiza
na `VitrineCriativa` e passa no `qa_layout`. Alguns nomes coincidem com `components/adaptativo/`: importe de um módulo
só por arquivo. `pipeline/direcao.py` é um analisador alternativo ao `neon.py mapa`; os dois geram o rascunho da direção.

## 3D (`components/three/Neon3D.tsx`) — aprovados no A1 (paleta antiga; reaplicados com tokens)

| Nome | Parâmetros |
|---|---|
| `Text3D` | `lines[], lineTimes[], y, size, growAt, spinAt, exitAt, accentLine` |
| `Falling3D` | `draw(ctx, w, h)` (desenho do objeto), `waves[{at, count, span}]`, `layer: behind|front`, `endAt`, `seed` |
| `Clock3D` | `slowAt, exitAt, width, height` |

## Composições de referência

| Arquivo | Para quê |
|---|---|
| `videos/_modelo/Video.tsx` | esqueleto mínimo para começar um vídeo |
| `videos/demonstracao/Video.tsx` | direção completa no padrão do v002 (texto sintético): melhor exemplo de como escrever um vídeo |
| `library/Vitrine.tsx` | todos os cards e 3D em sequência, para conferir a marca |
| `videos/adaptativo/Video.tsx` | vitrine da direção adaptativa (empreendedorismo, tecnologia, marketing) |

## Componentes do A1 ainda não migrados (não incluídos no kit)

PromptField, EditComposition (quadro vira canvas de editor), ThumbCard (o próprio vídeo num card em perspectiva),
ProntoFlow (camadas isométricas), Features (onda real da voz), FolderPrompt, HookTitle/IATitle (título atrás com raios),
HorasPrompt, ClosingStickers, Closing. Existem no projeto privado do A1 com a aparência antiga; precisam ser reescritos
com tokens antes de entrar no kit (ver `references/17-pendencias-e-limitacoes.md`).
