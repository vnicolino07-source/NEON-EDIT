# 10 · Renderização

## Especificação

| | Prévia | Final |
|---|---|---|
| Resolução | 720×1280 | 1080×1920 |
| Proporção / fps | 9:16, 30 fps constantes | 9:16, 30 fps constantes |
| Vídeo | H.264, CRF 20, yuv420p | H.264, CRF 14–16, yuv420p, `+faststart` |
| Áudio | AAC 192 kb/s, 48 kHz | AAC 256 kb/s, 48 kHz |
| Loudness | −14 LUFS / −1 dBTP | −14 LUFS / −1 dBTP |
| Nome | `PREVIA_PARA_APROVACAO_<video>_v<n>.mp4` | `<video>_FINAL_1080x1920.mp4` |

A composição é sempre desenhada em 1080×1920. A prévia é a mesma composição em escala.

## Caminho A — Remotion oficial (máquina com npm)

```bash
cd motor
npm install                                   # uma vez
npx remotion studio src/index.ts              # opcional: ver e ajustar no navegador
npx remotion render src/index.ts <Composicao> out/previa_raw.mp4 --codec=h264 --crf=20 --scale=0.6667 --audio-codec=aac --concurrency=2
npx remotion render src/index.ts <Composicao> out/final_raw.mp4  --codec=h264 --crf=16 --audio-codec=aac --audio-bitrate=256k
python ../pipeline/neon.py finalizar --video out/final_raw.mp4 --audio out/final_raw.mp4 --saida out/<video>_FINAL_1080x1920.mp4
```

O Remotion mistura a voz, a trilha (ducking pela envoltória) e os efeitos com `SoundTrack`; `finalizar` só ajusta o
loudness. `remotion.config.ts` já define JPEG 95, `angle` para WebGL e concorrência 2 (o 3D é pesado: aumente só se
houver memória).

**Situação:** o projeto está configurado para esse caminho, mas ele **ainda não foi executado** (o npm estava bloqueado
no ambiente de desenvolvimento). Os vídeos aprovados saíram pelo caminho B. Execute o teste de portabilidade antes de
confiar nele (`testes-portabilidade/PROCEDIMENTO.md` na raiz do pacote).

## Caminho B — renderizador local (testado; usado nos vídeos aprovados)

Renderiza a composição quadro a quadro num Chromium sem interface (Playwright, WebGL por SwiftShader) e codifica com ffmpeg.
Não precisa da CLI do Remotion: só de `esbuild`, `playwright`, `react`, `react-dom` e do código do Remotion/Three.js
(do `node_modules` ou de uma cópia do código-fonte apontada por `NEON_VENDOR`).

```bash
cd motor
cp harness/entry-modelo.tsx harness/entry-<id>.tsx       # aponte para src/videos/<id>/Video e exporte SFX/VISUAL_EVENTS em __meta
node harness/build.cjs entry-<id>.tsx bundle.js
node harness/render.mjs meta out/meta.json               # SFX + eventos + duração
PREVIEW_W=540 node harness/render.mjs stills out/stills 0 30 60 ...   # quadros de teste
# vídeo em partes paralelas (cada parte = 1 navegador; com 2 CPUs, 2–4 partes)
PREVIEW_W=720  CRF=20 node harness/render.mjs video 0 400 out/p0.mp4
PREVIEW_W=720  CRF=20 node harness/render.mjs video 400 800 out/p1.mp4
...
ffmpeg -f concat -i lista.txt -c copy out/video.mp4      # lista.txt: file 'p0.mp4' (uma por linha)
python ../pipeline/neon.py mixar --motor . --meta out/meta.json --saida out/mix.wav
python ../pipeline/neon.py finalizar --video out/video.mp4 --audio out/mix.wav --saida out/PREVIA_PARA_APROVACAO_<id>_v1.mp4 --audio-kbps 192
```

Final: o mesmo com `PREVIEW_W=1080 CRF=14`. Tempo medido na nuvem (2 CPUs, sem GPU): ~0,5 s/quadro em 720 e
~1 s/quadro em 1080 com 3D. Um vídeo de 50 s (1.500 quadros) leva ~10–15 min em 4 partes.

Sem npm (ambiente na nuvem com GitHub liberado): clone `remotion-dev/remotion` na tag `v4.0.539` (só `packages/core` e
`packages/player`) e `mrdoob/three.js` na tag `r170` (`build/` e `examples/jsm/`), e exporte `NEON_VENDOR=<pasta>`
contendo `remotion/` e `threejs/`.

## Antes do vídeo inteiro

1. Compile e renderize ~30 quadros espalhados (um por cena + todas as transições).
2. Monte uma folha de contato (`ffmpeg -pattern_type glob -i 'out/stills/*.jpg' -vf "scale=270:-1,tile=9x4" folha.jpg`)
   e **olhe**: fonte da marca em todo texto, nada saindo da tela, rosto livre, recortes limpos, contraste.
3. `node ../qa/qa_layout.mjs` sobre os mesmos quadros (fontes, estouro de tela, cores fora da paleta).

## Problemas de render conhecidos

| Sintoma | Causa | Solução |
|---|---|---|
| Quadro com texto em Times | componente sem `fontFamily` herdada | raiz da composição com `fontFamily: FONT.display` |
| Quadros pretos / 3D ausente | render antes de a fonte/cena carregar | `holdRender` (já nos componentes); `setFrame` espera `__pending` e as imagens |
| Processo morto sem erro (OOM) | muitas partes paralelas ou filtro ffmpeg gigante | menos partes; emendar com o concat demuxer em vez de `filter_complex` |
| Final maior que 30 MB não sobe para a pasta do computador pela ponte do app | limite da ponte de arquivos | entregar o master pelo chat e, na pasta, uma cópia em 2 passadas a ~4,1 Mb/s, ou copiar manualmente |
