# 22 · Estilo sob medida (a pessoa descreve, você monta)

Use quando a pessoa pedir um vídeo "no estilo X" e X **não** for um dos 14 estilos do guia 21, ou quando ela descrever
o visual com as próprias palavras ("fundo verde, letras grandes, clima de documentário", "tipo aqueles vídeos de anime",
"bem clean, estilo Apple"). O caminho é sempre o mesmo: **descrição → ficha de estilo → peças do motor → teste → prévia → salvar**.

Quase todo pedido é uma variação de um estilo que já existe ("o Linha, só que verde e com serifa"). Comece procurando
o parente mais próximo na matriz do guia 21; só construa componente novo quando nenhuma peça servir.

---

## 1. Ler a descrição e preencher a FICHA DE ESTILO

Antes de qualquer código, escreva a ficha (no projeto: `projetos/<video>/estilo.md`) com 8 campos:

| Campo | Pergunta que responde | Exemplo |
|---|---|---|
| Base | Qual dos 14 estilos é o parente mais próximo? | Flat |
| Paleta | Fundo, tinta, 1 acento (+ até 2 apoios), em hex | `#0E2A1F`, `#F4F1E8`, `#7CFF6B` |
| Tipografia | Fonte de título e de legenda (só as do kit ou OFL que a pessoa enviar) | Anton / Inter |
| Imagem | O que aparece: ícones em traço, formas, objetos 3D, mapas, telas, fotos da pessoa, ilustração gerada | ícones em círculos |
| Movimento | Como as coisas entram e saem: pop, desenho de traço, deslize, máquina de escrever, glitch, morph | pop + deslize |
| Legenda | `KCap kind` + `font/ink/dim/glow` | pilula, acento verde |
| Ritmo | Troca de imagem (s), palavras/s, cortes secos ou suaves | 2 s, 2,8 p/s |
| Trilha | Gênero e bpm (da pasta de músicas da pessoa) | lo-fi 85 bpm |

### Vocabulário → decisões (tradução das palavras mais comuns)

| A pessoa diz | Traduza para |
|---|---|
| clean, minimalista, "estilo Apple", elegante | Flat ou Linha; fundo claro ou preto puro; 1 acento; Inter 600–800; muito espaço vazio; entradas lentas (0,5 s) sem tremor |
| dark, misterioso, sombrio, documentário | Colagem/Jornal em mesa escura ou Linha; grão; acento vermelho ou âmbar; música grave |
| neon, futurista, tecnológico, cyber | Retrô sem o sol, ou Linha com glow; fundo quase preto; acento ciano/lima/rosa com `glow` |
| divertido, colorido, infantil, leve | Flat com 4 cores vivas; Boneco; formas pulando; Caveat ou Inter 800 |
| sério, jornalístico, notícia | Argila 3D estúdio ou Infográfico; paleta azul/cinza; sem tremor; FonteTag |
| vintage, antigo, nostálgico | Jornal (papel) ou Retrô (VHS); grão alto; Playfair/Courier |
| científico, técnico, "como funciona" | Blueprint ou Partículas |
| energético, motivacional, "tipo TikTok" | Kinetic; cortes a cada 1–1,5 s; batida forte |
| escola, aula, didático | Quadro ou Flat com ListaItem |
| "com a minha cor / da minha marca" | qualquer base + `pal` com as cores da marca ativa (seção 3) |

### Quando a descrição for vaga
Faça **no máximo 3 perguntas**, de preferência com opções:
1. "Fundo claro ou escuro?"
2. "Qual cor de destaque? (ou: posso usar a da sua marca?)"
3. "Mais calmo e elegante, ou mais rápido e energético?"
Se a pessoa não responder ou disser "do jeito que você achar", escolha, escreva na ficha o que escolheu e siga.

## 2. Quando a pessoa manda um vídeo de referência

Use o mesmo método do guia 19 (referências destiladas): meça ritmo (trocas por segundo), paleta (amostre 5–8 quadros),
tipografia (serifa? peso? caixa alta?), tipo de imagem e movimento dominante. Depois:
- **Modele o estilo, nunca copie o criador:** troque cores exatas, personagens, mascotes, vinhetas, bordões e qualquer
  elemento que identifique o canal. Quem fez a referência não pode reconhecer o próprio trabalho no resultado.
- Sem logos de terceiros, sem personagens protegidos (de desenho, games, filmes), sem marcas d'água.
- Registre na ficha: "referência: <arquivo>, medido: <números>; mudado: <o que foi trocado>".

## 3. Paleta: da marca da pessoa para o estilo

Todo componente de estilo aceita `pal`. Monte a partir de `motor/src/brand/marca.json` (marca ativa):

```tsx
import marca from '../../brand/marca.json';
import {FLAT} from '../../estilos/flat';
const PAL = {...FLAT, bg: marca.cores.texto, ink: marca.cores.fundo, c1: marca.cores.acento};
// e passe pal={PAL} em cada componente; na legenda: accent={marca.cores.acento}
```

Regras: contraste de legenda ≥ 4,5:1 com o fundo; acento nunca em texto pequeno sobre fundo claro sem contorno;
no máximo 1 acento + 2 apoios por cena.

## 4. Montar

1. Copie `motor/src/videos/_modelo` (ou o vídeo de tema mais parecido) e importe as peças da base escolhida.
2. Se faltar uma peça, crie em `motor/src/estilos/pessoal_<nome>.tsx`, reaproveitando `base.tsx` (`ph`, `Pop`, `KCap`),
   `ICONS` do `linha.tsx` e o padrão dos componentes (props `t`, `at`, `until`, `pal`; entrada ≤ 0,45 s; saída com blur).
3. Fonte nova só se for licença livre (OFL/Apache) e enviada pela pessoa ou baixada com autorização; registre em
   `public/fonts/` com o arquivo de licença e em `ensureXFonts`, e acrescente à lista do `qa/qa_layout.mjs`.
4. Texto decorativo que sai da tela de propósito → `data-qa="decor"` no contêiner.

## 5. Testar antes da prévia

1. **Stills:** 6–10 quadros (`PREVIEW_W=540 node harness/render.mjs stills ...`). Confira: legenda legível e embaixo
   (y 1400–1500), nada importante no topo (até y ≈ 250), nada cortado, paleta igual à ficha.
2. **Mostre à pessoa um still** só se ela pediu para ver o estilo antes; senão siga direto para a prévia.
3. **Prévia completa com áudio** (regra 1 do SKILL.md) + `qa_tudo.py --tipo previa`.

## 6. Salvar para reusar

Aprovado o estilo, salve a ficha em `config/estilos_pessoais/<nome>.json` (campos da seção 1 + caminho do arquivo de
peças + vídeo onde foi aprovado). Na próxima vez que a pessoa disser "naquele estilo verde", procure aqui primeiro.

```json
{"nome": "verde-documentario", "base": "linha", "paleta": {"bg": "#0E2A1F", "line": "#F4F1E8", "accent": "#7CFF6B"},
 "fontes": {"titulo": "XFONT.impacto", "legenda": "XFONT.sans"}, "legenda": {"kind": "suave", "accent": "#7CFF6B"},
 "movimento": "traço + pop", "ritmo_s": 2.0, "trilha": "ambient 80 bpm", "pecas": "motor/src/estilos/pessoal_verde.tsx",
 "aprovado_em": "projetos/v041"}
```

## 7. O que dizer que NÃO dá (ou custa mais)

- **Pessoas reais, fotos e vídeos de terceiros:** só com material da própria pessoa ou de domínio público que ela forneça.
- **Ilustração pintada, anime, personagens detalhados, cenas realistas:** exigem imagens/vídeos gerados por IA
  (créditos à parte) e teste de consistência — trate como o estilo Ilustrado (guia 21, nº 5, status proposto).
- **Imitar um canal/criador específico ou personagem conhecido:** recuse a cópia e ofereça um estilo com o mesmo
  "clima" e elementos próprios.
- Seja honesto sobre o status: um estilo sob medida é **parcial** até a pessoa aprovar a prévia.
