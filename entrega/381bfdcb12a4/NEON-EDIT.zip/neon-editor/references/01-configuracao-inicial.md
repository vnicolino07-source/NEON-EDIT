# 01 · Configuração inicial da pessoa (primeiro uso)

Rode este roteiro quando `config/perfil.json` não existir, ou quando a pessoa pedir para mudar a marca ou o estilo.
O objetivo é sair com dois arquivos: `config/marcas/<id>.json` (a identidade) e `config/perfil.json` (as preferências).
Nada disso depende da memória do chat: o que não estiver nesses arquivos não existe na próxima sessão.

A pessoa não precisa saber programar. Faça as perguntas em linguagem simples, aceite respostas soltas ("azul e preto",
"uma fonte moderna") e traduza para os arquivos. Use a ferramenta de perguntas com opções quando houver; senão, pergunte em
texto, no máximo 3 perguntas por mensagem.

## Perguntas (nesta ordem)

1. **Nome da marca** (vira o `nome` e o `id` em minúsculas com hífen).
2. **Logo?** Se sim, peça o arquivo (PNG com fundo transparente ou SVG). Copie para `motor/public/marca/logo.<ext>` e
   registre em `"logo"`. Uso: assinatura discreta no CTA e na tela final. Nunca sobre o rosto.
3. **Cores.** Peça a cor principal (acento) e se o visual é escuro ou claro. Se a pessoa mandar uma imagem ou site da marca,
   extraia as cores de lá. Monte a paleta completa (ver "Montar a paleta").
4. **Fontes.** Se tiver fontes próprias, peça os arquivos (.ttf/.otf/.woff2) e confirme que a licença permite uso em vídeo.
   Sem fonte própria: use as incluídas (Space Grotesk para títulos e legendas, JetBrains Mono para rótulos; ambas OFL).
   O 3D precisa de um TTF estático peso 700 (`arquivo_3d`).
5. **Formato:** vertical 9:16 1080×1920 (o único comprovado). Outros formatos ficam registrados como desejo, não prometidos.
6. **Estilo de edição** (mostre as opções de `config/estilos.json` com o status de cada uma, sem prometer o que é "proposto").
7. **Legendas?** (padrão: sim, 2–3 palavras por bloco, palavra-chave destacada).
8. **3D?** (padrão: sim, só quando a fala pedir).
9. **Efeitos sonoros e trilha?** (padrão: sim, discretos).
10. **Vídeos de referência?** Peça os arquivos ou links. Guarde em `referencias/` (fora do kit) e catalogue em
    `config/referencias.md`: para cada um, o que copiar (ritmo, tipo de gancho, transição, tipografia) com tempos
    exatos, e o que NÃO copiar (marca, paleta, fontes de terceiros). Nunca afirme ter assistido a uma referência que não abriu.

Depois de responder, mostre um resumo e peça confirmação. Grave os arquivos, ative a marca
(`python pipeline/neon.py marca usar <id> --motor motor`) e rode `python qa/teste_rapido.py --marca <id>`: a demonstração
com a marca nova é o primeiro "visto" da pessoa. Envie a folha de quadros e pergunte se a identidade está certa.

## Montar a paleta

| Campo | Como derivar se a pessoa não disser |
|---|---|
| `fundo` | tema escuro: quase preto puxado para o tom da marca (L* 4–8). Tema claro: off-white (L* 96–98). |
| `superficie` | fundo + 4–6 pontos de luminosidade (cards) |
| `superficie2` | superfície + 2–3 pontos ("antes", notificação) |
| `borda` | superfície + 8–12 pontos |
| `area_video` | entre fundo e superfície |
| `acento` | a cor principal da marca. **Um** acento só. |
| `acento_escuro` | acento misturado 40% com o fundo |
| `texto_sobre_acento_escuro` | acento misturado 70% com o fundo |
| `texto` | quase branco (tema escuro) ou quase preto (tema claro) |
| `texto_secundario` | cinza com contraste ≥ 4,5:1 sobre a superfície |
| `alerta` | vermelho/coral, só para riscar e negativo |

Confira o contraste: texto sobre superfície ≥ 7:1; `fundo` (usado como texto sobre o acento) contra o acento ≥ 4,5:1.
`python qa/qa_marca.py config/marcas/<id>.json` calcula isso e recusa paletas ilegíveis.

**Tema claro:** os componentes foram aprovados no tema escuro. Um tema claro funciona tecnicamente (as cores são tokens),
mas não foi aprovado por nenhum cliente. Avise e gere a demonstração antes de editar um vídeo real.

## `config/perfil.json`

```json
{
  "marca": "minha-marca",
  "formato": "9:16",
  "estilo": "dinamico",
  "velocidade": 1.15,
  "legendas": {"ativo": true, "palavras_por_bloco": [2, 3], "destaque": "fundo_acento"},
  "tres_d": true,
  "sfx": true,
  "trilha": true,
  "cta_padrao": null,
  "referencias": "config/referencias.md",
  "pasta_trabalho": "C:/Users/<pessoa>/Documents/NEON EDITOR",
  "observacoes": ["preferências específicas ditas pela pessoa, com a data"]
}
```

Toda correção que a pessoa fizer e disser que vale para sempre entra em `observacoes` e, se for regra de edição, no
histórico (`15-entrega-e-correcoes.md`).

## Estilos (resumo de `config/estilos.json`)

| Estilo | O que é | Status |
|---|---|---|
| Dinâmico | cortes secos, 1,15×, legenda palavra a palavra, reenquadramentos, efeitos sincronizados | **comprovado** (A1, v002) |
| Motion graphics | cards, interfaces, tipografia cinética, demonstrações | **comprovado** (v002; componentes testados) |
| Premium 3D | dinâmico + objetos e tipografia 3D com luz e física | **parcial**: Text3D, ShatterText3D, Falling3D, Clock3D testados; cena 3D inteira não |
| Cinematográfico | movimentos suaves, transições discretas, menos elementos | **proposto** (não testado) |
| Personalizado | definido pelas referências da pessoa | **proposto**: depende da análise das referências |

Mostre o status. Nunca apresente um estilo "proposto" como pronto.
