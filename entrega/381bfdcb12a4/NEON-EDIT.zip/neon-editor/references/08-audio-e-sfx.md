# 08 · Áudio: voz, trilha e efeitos sonoros

**A voz é a prioridade.** Trilha e efeitos existem para dar ritmo; se competirem com a fala, estão errados.

## Voz (`neon.py voz`)

1. Corte segmento a segmento com **microfade de 4 ms** em cada emenda (evita estalo; nenhuma dissolvência longa).
2. Aceleração com rubberband: `tempo=1.15, pitch=1, transients=crisp, detector=compound, phase=laminar, window=standard,
   smoothing=off, formant=preserved, pitchq=quality`.
3. Tratamento: passa-alta 75 Hz → redução de ruído leve (`afftdn nr=6`) → EQ −1,5 dB em 220 Hz e +2 dB em 3,5 kHz →
   de-esser → compressor 2,5:1 (limiar −20 dB, ataque 8 ms, release 120 ms) → loudnorm −16 LUFS / −1,5 dBTP.
4. **Compensação de atraso** medida por correlação de envoltórias (1 ms de resolução). A cadeia atrasa ≈ 28 ms
   (`afftdn` ≈ 25 ms + rubberband ≈ 3 ms); os vídeos aprovados usaram 20 ms fixos, a medição automática dá 26–28 ms.
   Residual exigido: 0 ± 2 ms. Acima de ~40 ms a boca e a voz parecem descoladas.
5. Envoltória por quadro (`voice_env.json` = RMS do quadro ÷ máximo) para o ducking da trilha.

## Trilha

- Gerada por síntese (`pipeline/sfx.py`): pad de acordes com filtro + baixo + batida leve. A do v002: Dm9 · Bbmaj7 ·
  Gm9 · Am7, 102 BPM. Troque a progressão/BPM por vídeo para não repetir; mantenha o caráter (discreto, sem melodia).
- Volume com **ducking**: 0,16 linear sem fala → 0,06 com fala (`0,16 − 0,1 × min(1, 4 × envoltória)`, janela de ±6
  quadros); entra em 20 quadros e sai em 30.
- Música de terceiros só com licença explícita para o uso. Nunca baixe música da internet.

## Efeitos sonoros

| Efeito | Quando | Volume (linear) |
|---|---|---|
| whoosh / whoosh_short | troca de layout, elemento voando, envio | 0,18–0,26 |
| pop | entrada de card ou etiqueta | 0,2–0,24 |
| click | botão, seleção, item marcado | 0,2–0,3 |
| type | digitação (1 por palavra digitada, não por letra) | 0,2 |
| impact | título forte, palavra que cai | 0,18–0,3 |
| reverse | antecipação de algo grande (0,4 s antes) | 0,2 |
| riser | crescimento, resultado subindo | 0,14 |
| ding | conclusão, "do meu jeito", "entendeu" | 0,18 |
| laser | risco, corte de tela | 0,22–0,3 |
| shatter | explosão de palavra | 0,34 |
| paper, tick | dinheiro/papéis, relógio | 0,2 |

Regras:
- Sincronize com o **evento visual**, que por sua vez está na palavra. Um som por evento importante, **não em toda
  palavra**. v002: 38 efeitos em 52 s (≈ 1 a cada 1,4 s).
- Nunca dois efeitos fortes no mesmo quadro; espace pelo menos 0,15 s.
- Todos abaixo da voz. Se uma frase importante coincidir com um efeito forte, baixe o efeito.
- Os efeitos são sintetizados pelo kit (sem material de terceiros). Pode criar outros em `sfx.py` com a mesma lógica.

## Mixagem e master

- `neon.py mixar`: voz + trilha com ducking + efeitos (posição arredondada ao quadro), se o pico passar de 0,98 o mix inteiro é reduzido (sem limitador).
- `neon.py finalizar`: loudnorm em **duas passagens** com alvo **−14 LUFS integrado / −1 dBTP** (linear quando possível).
  v002 final: −14,4 LUFS, −1,0 dBTP (o limite de pico segurou 0,4 LU; tolerância aceita: ±1 LU).
- AAC 48 kHz: 192 kb/s na prévia, 256 kb/s no final.

## Verificação (`qa/qa_audio.py`)

Loudness integrado −14 ± 1 LU; pico ≤ −0,9 dBTP; nada de clipping digital; voz sem trechos mudos > 1,2 s dentro do
vídeo; duração do áudio = duração do vídeo ± 1 quadro; nenhum estalo nas emendas (salto de amostra > 0,3 no ponto de
corte).
