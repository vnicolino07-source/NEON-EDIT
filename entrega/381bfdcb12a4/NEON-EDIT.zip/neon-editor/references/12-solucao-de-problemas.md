# 12 · Solução de problemas (lições verificadas)

Formato: **PROBLEMA → CAUSA → SOLUÇÃO → COMO EVITAR → COMO TESTAR.** Todos aconteceram durante os vídeos aprovados.

## Transcrição e sincronia

**Palavra antecipada depois de pausa** → o Parakeet marca o início 0,25–0,4 s antes do som real → `neon.py palavras`
alinha ao ataque de energia (−50/−45 dB) → nunca use `words_raw.json` direto na composição → `qa_legendas.py` + ouvir a
primeira palavra de cada frase.

**Palavra que não foi dita aparece na legenda (v002: "aí")** → a última palavra de uma tomada descartada foi esticada
pelo reconhecimento até a tomada seguinte e invadiu o trecho mantido → `remover` em `correcoes.json` → leia os AVISOS de
`neon.py palavras` → `qa_legendas.py` acusa palavra em silêncio.

**Palavra curta não reconhecida (v002: "IA")** → siglas e palavras coladas somem → `neon.py rever` + `neon.py formantes`;
`inserir` com o tempo medido; pedir confirmação → sempre revisar a palavra do CTA → ouvir o CTA na prévia.

**Nome próprio errado (Claudio, views)** → vocabulário do modelo → `trocar` → lista de nomes de marca da pessoa em
`config/perfil.json` (`nomes_proprios`) → busca no `words.json`.

**Boca e voz descoladas** → atraso constante da cadeia de voz (≈ 25 ms do `afftdn` + ≈ 3 ms do rubberband; nos vídeos
aprovados atribuído só ao rubberband e compensado em 20 ms fixos) → compensação **medida** em `neon.py voz` → nunca usar
um valor fixo → residual 0 ± 2 ms impresso pelo comando; `qa/qa_latencia.py` confere o método.

**Efeitos desalinhados depois de mudar um corte** → tempos escritos à mão na composição → só `T()`/`TE()` → recompilar
depois de qualquer mudança em `cortes.json` → `buildBlocks` quebra se as palavras mudarem.

## Legendas e layout

**Texto em fonte serifada (Times) em cards e no "1 prompt" (v002, 1ª rodada de quadros)** → elementos sem `fontFamily`
herdavam o padrão do navegador → `fontFamily: FONT.display, color: COLOR.text` no `AbsoluteFill` raiz → copie a raiz do
modelo → `qa_layout.mjs` (falha "fonte").

**"GIGANTE" cortado na borda (v002)** → 300 px para 7 letras passa de 1080 px → 235 px → teste com a palavra mais longa →
`qa_layout.mjs` (falha "corte").

**Card do CTA vazando pela direita (v002)** → largura fixa + padding sem `box-sizing` → `boxSizing: 'border-box'` →
use em todo card com largura e padding → `qa_layout.mjs`.

**Rótulo mono ilegível sobre a imagem (CTA do v002)** → texto pequeno cinza direto sobre o vídeo → todo texto pequeno
dentro de card (superfície + borda) → regra em `06` → revisão visual.

**Título 3D cortado pela troca de painel (A1)** → a transição de layout começava antes do título terminar → começar
transições ~0,3 s depois da saída do elemento → revisão dos quadros de transição.

**Faixa clara no topo durante a transição (A1)** → fundo do card semitransparente durante a animação → opacidade do
fundo fixa em 1 → quadros no meio das transições.

## Recortes (elementos atrás da pessoa)

**Recorte borrado ou faltando** → modelo pesado (BiRefNet) estourou a memória → u2net_human_seg + filtro guiado (raio 8,
eps 1e-3) + suavização temporal 0,75/0,25 → gere recortes **só** nos quadros que precisam → folha `qa/recorte_i-j.jpg`
sobre magenta.

**Halo no cabelo/mãos** → máscara binária sem refinamento → filtro guiado (exige `opencv-contrib`, módulo `ximgproc`) →
o comando falha se o módulo não existir → folha magenta.

**Texto atrás aparecendo na frente do rosto em alguns quadros** → elemento atrás ativo fora do intervalo com recorte →
condicione `cutout`/elemento ao intervalo de quadros recortados (`hookOn`, `giantOn` no v002) → quadros nas bordas do
intervalo.

## Render

**Processo encerrado sem mensagem** → falta de memória (ffmpeg `filter_complex` com muitas entradas; muitas partes
paralelas) → emendar com o concat demuxer; menos partes → monitorar `dmesg`/uso de memória.

**`pkill -f` derrubou o próprio terminal** → o padrão casava com o comando do shell → encerre por PID (`ps` + `awk`) →
—.

**Render diferente entre execuções** → animação dependente de relógio → estado só função do quadro → renderizar o mesmo
quadro duas vezes e comparar (deve ser idêntico).

**Arquivo final não chega na pasta do computador** → limite de 30 MB por arquivo da ponte do app → entregar o master
pelo chat + cópia em 2 passadas ~4,1 Mb/s na pasta (v002: 28 MB, SSIM 0,996) → verificar o tamanho antes de enviar.

## Ambiente

**npm / PyPI bloqueados (ambiente na nuvem)** → política de rede → código-fonte do Remotion e do Three.js pelo GitHub
(`NEON_VENDOR`), binário estático do sherpa-onnx e modelos pelas releases do GitHub; numpy/scipy/onnxruntime/opencv
já vinham instalados → `instalador/verificar_ambiente.py` diz o que falta → `qa/teste_rapido.py`.

**ffmpeg sem rubberband** → build mínimo → instalar um build completo (ffmpeg.org / gyan.dev no Windows / Homebrew) →
o verificador testa o filtro → `ffmpeg -filters | grep rubberband`.
