# 15 · Prévia, correções, versão final e histórico

## Prévia

- Sempre o **vídeo inteiro com áudio**, MP4 720×1280, chamado `PREVIA_PARA_APROVACAO_<video>_v<n>.mp4`. Nunca prints ou
  quadros soltos no lugar dela.
- Entregue com o rótulo **"PRÉVIA PARA APROVAÇÃO"** e um relatório curto (sem repetir o que a pessoa vai ver):
  - duração bruta → final e velocidade;
  - **trechos removidos** (falsos começos, repetições, frases cortadas por redundância), para a pessoa conferir;
  - **palavras inferidas** que precisam de confirmação (ex.: "IA", "reels"), com o motivo;
  - efeitos novos criados (vão para a biblioteca como experimentais);
  - números do QA (eventos, maior intervalo, loudness) e limitações.
- Salve na pasta de trabalho da pessoa (ex.: `PREVIAS E REVISÕES/`) e no projeto. Nunca sobrescreva uma prévia anterior:
  a correção vira `v2`, `v3`...
- Espere a resposta. Não exporte o final antes.

## Correções

1. Liste cada pedido da pessoa e o que vai mudar (tabela pedido → alteração).
2. Classifique: **[este vídeo]** (vale só aqui) ou **[padrão]** (a pessoa disse que vale sempre, ou é uma correção de
   regra geral). Na dúvida, trate como "este vídeo" e pergunte no relatório se deve virar padrão.
3. Aplique, rode o QA de novo e envie a nova prévia.
4. Se a correção virou padrão: atualize o guia correspondente em `references/` **ou** `config/perfil.json`
   (`observacoes`) e registre no histórico.

## Versão final (só depois de "aprovado")

1. Renderize 1080×1920 (CRF 14–16), mixe, finalize (−14 LUFS / −1 dBTP), rode `qa_tudo.py --tipo final`.
2. Entregue o arquivo e salve em `VIDEOS APROVADOS/` (ou a pasta que a pessoa usar). Se o arquivo passar do limite de
   transferência do ambiente (ex.: 30 MB na ponte do app desktop), entregue o master pelo chat e salve na pasta uma cópia
   em duas passadas a ~4,1 Mb/s (SSIM ≥ 0,99 em relação ao master), dizendo isso.
3. Zip do projeto da edição (composição, dados, `cortes.json`, `correcoes.json`, relatório de QA; **sem** os quadros
   extraídos e recortes, que são regeneráveis).
4. Componentes experimentais usados no vídeo aprovado passam a "aprovados" em `13-componentes.md`.
5. **Histórico** (`HISTORICO_DE_APROVACOES.md` na pasta de trabalho): acrescente uma entrada nova, sem apagar as
   anteriores, com o modelo abaixo.

## Modelo de entrada no histórico

```markdown
## <id> — "<título/assunto>" (<arquivo bruto>)

**Status:** APROVADO em <data> (prévia v<n>). Final: `<arquivo final>` (<resolução>, <LUFS>, <dBTP>).
- Bruto <x> s → final <y> s a <velocidade>×; <n> palavras (<p> palavras/s); <e> eventos (maior intervalo <g> s); <s> efeitos sonoros.
- Removidos: …
- Confirmações: …
- Direção (estrutura): gancho …; layouts …; objetos/metáforas …; CTA …
- Componentes novos: …
- Correções pedidas: | # | pedido | alteração | [este vídeo]/[padrão] |
- Decisões técnicas que funcionaram: …
- Reutilizável: …
```
