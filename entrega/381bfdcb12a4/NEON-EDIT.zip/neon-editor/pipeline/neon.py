#!/usr/bin/env python3
"""
NEON EDITOR — pipeline de preparação de um vídeo bruto (linha de comando).

Cada subcomando faz UMA etapa e grava o resultado na pasta do projeto do vídeo. As etapas são as mesmas que produziram
os vídeos aprovados (A1 e v002); os parâmetros padrão são os aprovados. Rode `python neon.py <comando> -h` para detalhes.

  preparar   <video> --proj P         copia o bruto, extrai a voz (16k/48k), mede a energia (10 ms) e mostra o ffprobe
  transcrever --proj P                transcrição com tempo por palavra (sherpa-onnx + Parakeet TDT v3)
  rever       --proj P a:b [a:b...]   re-transcreve janelas curtas para conferir palavras duvidosas
  formantes   --proj P a:b [a:b...]   F1/F2 por 10 ms para decidir vogais de palavras incertas (ex.: "IA")
  texto       --proj P                imprime a transcrição com tempos e as pausas, para o plano de cortes
  edl         --proj P [--velocidade 1.15]  aplica cortes.json → edl.json (cortes pela fala + aceleração)
  palavras    --proj P                mapeia as palavras para a timeline final + correcoes.json → words.json
  mapa        --proj P                rascunho da direção: frases, intenções, assunto provável e sugestões (heurístico)
  quadros     --proj P                extrai os quadros 1080×1920 da timeline final
  voz         --proj P                voz cortada + rubberband + tratamento + compensação de atraso medida
  recortes    --proj P i-j [k-l...]   máscaras do apresentador (u2net + filtro guiado + suavização temporal)
  sfx         --motor M               gera os efeitos sonoros e a trilha (síntese própria, sem material de terceiros)
  vincular    --proj P --motor M      liga o projeto ao motor Remotion (dados, quadros, recortes, áudio)
  marca       usar <id> --motor M     ativa config/marcas/<id>.json no motor
  mixar       --proj P --motor M --meta meta.json --saida mix.wav   voz + trilha com ducking + efeitos
  finalizar   --video v.mp4 --audio mix.wav --saida final.mp4 [--crf 16]  junta, normaliza (−14 LUFS / −1 dBTP)

Ferramentas externas: ffmpeg (com librubberband), sherpa-onnx-offline + modelo Parakeet, u2net_human_seg.onnx.
Caminhos em config/ferramentas.json (gerado pelo instalador) ou nas variáveis NEON_ASR_BIN, NEON_ASR_MODEL, NEON_U2NET.
"""
import argparse, json, os, re, shutil, subprocess, sys, unicodedata
from pathlib import Path

import numpy as np
import scipy.io.wavfile as wavfile

KIT = Path(__file__).resolve().parent.parent
FPS = 30
SR_VOZ = 48000


# ---------------------------------------------------------------- utilidades
def die(msg):
    print('ERRO: ' + msg, file=sys.stderr)
    sys.exit(1)


def run(cmd, **kw):
    r = subprocess.run(cmd, **kw)
    if r.returncode != 0:
        die('comando falhou: ' + ' '.join(map(str, cmd))[:400])
    return r


def tools():
    cfg = {}
    p = KIT / 'config' / 'ferramentas.json'
    if p.exists():
        cfg = json.loads(p.read_text(encoding='utf-8'))
    t = {
        'asr_bin': os.environ.get('NEON_ASR_BIN', cfg.get('asr_bin', '')),
        'asr_model': os.environ.get('NEON_ASR_MODEL', cfg.get('asr_model', '')),
        'u2net': os.environ.get('NEON_U2NET', cfg.get('u2net', '')),
        'threads': int(cfg.get('threads', 2)),
    }
    return t


def need(path, what):
    if not path or not Path(path).exists():
        die(f'{what} não encontrado ({path or "caminho vazio"}). Rode o instalador ou ajuste config/ferramentas.json.')


def readwav(p):
    sr, x = wavfile.read(p)
    x = x.astype(np.float32) / 32768
    if x.ndim > 1:
        x = x.mean(1)
    return sr, x


def writewav(p, sr, x):
    wavfile.write(p, sr, (np.clip(x, -1, 1) * 32767).astype(np.int16))


def proj(a):
    p = Path(a.proj).resolve()
    for d in ['data', 'audio', 'public/frames', 'public/fg', 'public/audio']:
        (p / d).mkdir(parents=True, exist_ok=True)
    return p


def norm(s):
    s = unicodedata.normalize('NFD', s.lower())
    return re.sub(r'[^a-z0-9]', '', ''.join(c for c in s if unicodedata.category(c) != 'Mn'))


def sherpa(t, wav):
    """Transcreve um WAV 16 kHz. Usa o binário sherpa-onnx-offline (caminho testado) ou, se não houver binário,
    o pacote Python `sherpa_onnx` (mesmo motor; caminho NÃO testado no ambiente de desenvolvimento)."""
    m = Path(t['asr_model'])
    if t['asr_bin']:
        o = subprocess.run([t['asr_bin'], f'--encoder={m}/encoder.int8.onnx', f'--decoder={m}/decoder.int8.onnx', f'--joiner={m}/joiner.int8.onnx',
                            f'--tokens={m}/tokens.txt', '--model-type=nemo_transducer', f'--num-threads={t["threads"]}', str(wav)], capture_output=True, text=True)
        js = [l for l in (o.stdout + o.stderr).splitlines() if l.startswith('{')]
        if not js:
            die('a transcrição não retornou resultado:\n' + (o.stderr or '')[-800:])
        return json.loads(js[-1])
    try:
        import sherpa_onnx
    except ImportError:
        die('nenhum motor de transcrição: defina asr_bin em config/ferramentas.json ou instale o pacote Python sherpa-onnx')
    rec = sherpa_onnx.OfflineRecognizer.from_transducer(encoder=str(m / 'encoder.int8.onnx'), decoder=str(m / 'decoder.int8.onnx'),
                                                        joiner=str(m / 'joiner.int8.onnx'), tokens=str(m / 'tokens.txt'),
                                                        num_threads=t['threads'], model_type='nemo_transducer')
    sr, x = readwav(wav)
    st = rec.create_stream()
    st.accept_waveform(sr, x)
    rec.decode_stream(st)
    r = st.result
    ts = list(r.timestamps)
    du = list(getattr(r, 'durations', []) or [])
    if len(du) != len(ts):
        du = [max(0.04, b - a) for a, b in zip(ts, ts[1:] + [len(x) / sr])]
    return {'text': r.text, 'tokens': list(r.tokens), 'timestamps': ts, 'durations': du}


def asr_ok(t):
    if t['asr_bin']:
        need(t['asr_bin'], 'binário sherpa-onnx-offline')
    need(t['asr_model'], 'modelo Parakeet')


# ---------------------------------------------------------------- preparar
def cmd_preparar(a):
    P = proj(a)
    src = Path(a.video)
    if not src.exists():
        die(f'vídeo não encontrado: {src}')
    dst = P / ('bruto' + src.suffix.lower())
    if not dst.exists():
        shutil.copy2(src, dst)  # o original nunca é alterado
    info = json.loads(subprocess.run(['ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(dst)], capture_output=True, text=True).stdout)
    v = next((s for s in info['streams'] if s['codec_type'] == 'video'), None)
    au = next((s for s in info['streams'] if s['codec_type'] == 'audio'), None)
    if not v or not au:
        die('o arquivo precisa ter vídeo e áudio')
    rot = 0
    for sd in v.get('side_data_list', []):
        rot = int(sd.get('rotation', rot) or rot)
    rot = int(v.get('tags', {}).get('rotate', rot))
    w, h = int(v['width']), int(v['height'])
    if abs(rot) % 180 == 90:
        w, h = h, w
    fr = v.get('avg_frame_rate', '30/1').split('/')
    meta = {'arquivo': dst.name, 'duracao': float(info['format']['duration']), 'largura_exibida': w, 'altura_exibida': h, 'rotacao': rot,
            'fps': round(float(fr[0]) / max(1.0, float(fr[1])), 3), 'audio_sr': int(au['sample_rate']), 'audio_canais': int(au['channels'])}
    (P / 'data' / 'bruto.json').write_text(json.dumps(meta, indent=1, ensure_ascii=False), encoding='utf-8')
    run(['ffmpeg', '-v', 'error', '-y', '-i', str(dst), '-vn', '-ac', '1', '-ar', '16000', str(P / 'audio' / 'voz16k.wav')])
    run(['ffmpeg', '-v', 'error', '-y', '-i', str(dst), '-vn', '-ac', '1', '-ar', str(SR_VOZ), str(P / 'audio' / 'voz48k.wav')])
    sr, x = readwav(P / 'audio' / 'voz16k.wav')
    hop = sr // 100
    n = len(x) // hop
    db = 20 * np.log10(np.sqrt((x[:n * hop].reshape(n, hop) ** 2).mean(1)) + 1e-9)
    np.save(P / 'data' / 'db10ms.npy', db)
    print(json.dumps(meta, ensure_ascii=False))
    if abs(w / h - 9 / 16) > 0.01:
        print(f'AVISO: proporção {w}×{h} não é 9:16. Os quadros serão ampliados e cortados no centro (confira o enquadramento).')
    print(f'fala ativa (> −50 dB): {(db > -50).mean() * 100:.0f}% do tempo')


# ---------------------------------------------------------------- transcrição
def cmd_transcrever(a):
    P = proj(a)
    t = tools()
    asr_ok(t)
    db = np.load(P / 'data' / 'db10ms.npy')
    wav = P / 'audio' / 'voz16k.wav'
    sr, x = readwav(wav)
    dur = len(x) / sr
    cuts = [0.0]  # cortes nos pontos mais silenciosos a cada ~16–23 s (o modelo funciona melhor em trechos curtos)
    while dur - cuts[-1] > 24:
        i0, i1 = int((cuts[-1] + 16) * 100), int((cuts[-1] + 23) * 100)
        cuts.append((i0 + int(np.argmin(db[i0:i1]))) / 100)
    cuts.append(dur)
    words = []
    tmp = P / 'audio' / '_trecho.wav'
    for c0, c1 in zip(cuts, cuts[1:]):
        run(['ffmpeg', '-v', 'error', '-y', '-ss', str(c0), '-to', str(c1), '-i', str(wav), str(tmp)])
        r = sherpa(t, tmp)
        cur = None
        for tok, ts, du in zip(r['tokens'], r['timestamps'], r.get('durations', [0.08] * len(r['tokens']))):
            if tok.startswith(' ') or cur is None:
                if cur:
                    words.append(cur)
                cur = {'w': tok.strip(), 's': round(c0 + ts, 3), 'e': round(c0 + ts + du, 3)}
            else:
                cur['w'] += tok
                cur['e'] = round(c0 + ts + du, 3)
        if cur:
            words.append(cur)
        print(f'[{c0:6.1f}–{c1:6.1f}] {r["text"]}')
    tmp.unlink(missing_ok=True)
    (P / 'data' / 'words_raw.json').write_text(json.dumps(words, ensure_ascii=False), encoding='utf-8')
    print(f'{len(words)} palavras → data/words_raw.json')


def cmd_rever(a):
    P = proj(a)
    t = tools()
    asr_ok(t)
    tmp = P / 'audio' / '_janela.wav'
    for win in a.janelas:
        s0, s1 = map(float, win.split(':'))
        run(['ffmpeg', '-v', 'error', '-y', '-ss', str(s0), '-to', str(s1), '-i', str(P / 'audio' / 'voz16k.wav'), '-af', 'apad=pad_dur=0.5', str(tmp)])
        r = sherpa(t, tmp)
        print(win, '|', r['text'], '|', ' '.join(f'{tok}@{s0 + s:.2f}' for tok, s in zip(r['tokens'], r['timestamps'])))
    tmp.unlink(missing_ok=True)


def cmd_formantes(a):
    """F1/F2 por LPC. /i/: F1 baixo (~300) e F2 alto (>2000); /a/: F1 alto (>650) e F2 médio (~1300)."""
    import scipy.signal as sg
    P = proj(a)
    sr, x = readwav(P / 'audio' / 'voz48k.wav')
    x = x.astype(np.float64)

    def lpc(fr, order):
        r = np.correlate(fr, fr, 'full')[len(fr) - 1:len(fr) + order]
        A = np.zeros(order + 1)
        A[0] = 1
        e = r[0]
        for i in range(1, order + 1):
            k = -(r[i] + np.dot(A[1:i], r[i - 1:0:-1])) / e
            A[1:i] = A[1:i] + k * A[i - 1:0:-1]
            A[i] = k
            e *= 1 - k * k
        return A

    for seg in a.janelas:
        s0, s1 = map(float, seg.split(':'))
        y = sg.lfilter([1, -0.97], 1, x[int(s0 * sr):int(s1 * sr)])
        L = int(0.025 * sr)
        rows = []
        for i in range(0, len(y) - L, int(0.01 * sr)):
            fr = y[i:i + L] * np.hamming(L)
            if np.sqrt(np.mean(fr ** 2)) < 0.003:
                continue
            roots = [r for r in np.roots(lpc(fr, 12)) if np.imag(r) >= 0]
            f = sorted(np.angle(r) * sr / (2 * np.pi) for r in roots if 90 < np.angle(r) * sr / (2 * np.pi) < 4000 and abs(r) > 0.85)
            if len(f) >= 2:
                rows.append((round(s0 + i / sr, 2), int(f[0]), int(f[1])))
        print(seg, ' '.join(f'{t}s:F1={f1},F2={f2}' for t, f1, f2 in rows))


def cmd_texto(a):
    P = proj(a)
    W = json.loads((P / 'data' / 'words_raw.json').read_text(encoding='utf-8'))
    db = np.load(P / 'data' / 'db10ms.npy')
    line, last = [], None
    for w in W:
        if last is not None and w['s'] - last > 0.6:
            print(' '.join(line))
            print(f'   … pausa {w["s"] - last:.2f}s')
            line = []
        line.append(f'{w["w"]}@{w["s"]:.2f}')
        last = w['e']
    print(' '.join(line))
    act = db > -50
    print(f'\nduração {len(db) / 100:.1f}s · fala ativa {act.mean() * 100:.0f}%')


# ---------------------------------------------------------------- EDL
PRE, POST = 0.05, 0.08  # margem antes do ataque / depois do fim da palavra (aprovado no A1)
MAXGAP, KEEPGAP = 0.30, 0.14  # pausas internas > 0,30 s viram 0,14 s
LIMIAR_DB = -50


def cmd_edl(a):
    P = proj(a)
    C = json.loads((P / 'cortes.json').read_text(encoding='utf-8'))
    speed = float(a.velocidade or C.get('velocidade', 1.15))
    db = np.load(P / 'data' / 'db10ms.npy')
    act = db > LIMIAR_DB
    dur = len(db) / 100
    segs = []
    for j in C['janelas']:
        s_in, e_in, lab = float(j['de']), float(j['ate']), j.get('rotulo', '')
        i0, i1 = int(s_in * 100), int(e_in * 100)
        on = np.where(act[i0:i1])[0]
        if not len(on):
            die(f'janela {s_in}–{e_in} não tem fala')
        s = s_in if j.get('inicio_exato') else max(s_in, (i0 + on[0]) / 100 - PRE)
        e = e_in if j.get('fim_exato') else min(e_in, (i0 + on[-1] + 1) / 100 + POST)
        idx = np.where(act[int(s * 100):int(e * 100)])[0]
        runs = []
        st = pv = idx[0]
        for k in idx[1:]:
            if k - pv > 1:
                runs.append((st, pv + 1))
                st = k
            pv = k
        runs.append((st, pv + 1))
        base, cur = int(s * 100), s
        for (r0, r1), (n0, n1) in zip(runs, runs[1:]):
            if (n0 - r1) / 100 > MAXGAP:
                segs.append([cur, (base + r1) / 100 + KEEPGAP / 2, lab])
                cur = (base + n0) / 100 - KEEPGAP / 2
        segs.append([cur, e, lab])
    segs[-1][1] = min(dur, segs[-1][1] + float(C.get('respiro_final', 0.35)))
    step = speed / FPS
    out, F, cut_t = [], 0, 0.0
    for s, e, l in segs:
        n = max(1, round((e - s) / step))
        out.append({'src_start': round(float(s), 4), 'src_end': round(float(s + n * step), 4), 'cut_start': round(cut_t, 4),
                    'dst_start': round(F / FPS, 4), 'frames': n, 'dst_frame': F, 'speed': speed, 'label': l})
        F += n
        cut_t += n * step
    E = {'segments': out, 'duration': round(F / FPS, 4), 'speed': speed, 'cut_duration': round(cut_t, 4)}
    (P / 'data' / 'edl.json').write_text(json.dumps(E, indent=1, ensure_ascii=False), encoding='utf-8')
    for o in out:
        print(f"{o['src_start']:7.2f}-{o['src_end']:7.2f}  final {o['dst_start']:6.2f}  {o['frames']:4d}q  {o['label']}")
    print(f'bruto {dur:.2f}s → cortado {cut_t:.2f}s → final {F / FPS:.2f}s ({F} quadros) a {speed:.2f}×')


# ---------------------------------------------------------------- palavras
def aplicar_correcoes(W, C):
    """correcoes.json: trocar/remover/inserir por TEMPO do bruto (nunca por índice, que muda a cada transcrição)."""
    def achar(item):
        cands = [i for i, w in enumerate(W) if abs(w['s'] - float(item['em'])) <= float(item.get('tolerancia', 0.6))
                 and ('de' not in item or norm(w['w']) == norm(item['de']))]
        if not cands:
            die(f'correção sem palavra correspondente: {item}')
        return min(cands, key=lambda i: abs(W[i]['s'] - float(item['em'])))
    for it in C.get('trocar', []):
        W[achar(it)]['w'] = it['para']
    for it in C.get('remover', []):
        del W[achar(it)]
    for it in C.get('inserir', []):
        W.append({'w': it['texto'], 's': float(it['inicio']), 'e': float(it['fim'])})
    W.sort(key=lambda w: w['s'])
    return W


def cmd_palavras(a):
    P = proj(a)
    W = json.loads((P / 'data' / 'words_raw.json').read_text(encoding='utf-8'))
    cp = P / 'correcoes.json'
    if cp.exists():
        W = aplicar_correcoes(W, json.loads(cp.read_text(encoding='utf-8')))
    E = json.loads((P / 'data' / 'edl.json').read_text(encoding='utf-8'))['segments']
    db = np.load(P / 'data' / 'db10ms.npy')
    out, avisos = [], []
    for w in W:
        ov = [(min(w['e'], s['src_end']) - max(w['s'], s['src_start']), s) for s in E]
        best = max(ov, key=lambda x: x[0])
        seg, s0 = best[1], w['s']
        if best[0] <= 0.02:
            # o ASR adianta palavras de início de frase para antes do início do segmento (depois de silêncio)
            nxt = [x for x in E if 0 <= x['src_start'] - w['e'] < 0.3 or (w['s'] < x['src_start'] <= w['e'] + 0.3)]
            if not nxt or w['e'] < nxt[0]['src_start'] - 0.3:
                continue  # palavra de trecho cortado
            seg = nxt[0]
            s0 = seg['src_start']
        # palavra-fantasma: o reconhecimento esticou a última palavra de uma tomada descartada (> 0,9 s) até o trecho
        # mantido; quase nada dela cai no trecho e o que cai é silêncio (v002: "aí." 90,67–92,35 s)
        dur = w['e'] - w['s']
        k0, k1 = max(w['s'], seg['src_start']), min(w['e'], seg['src_end'])
        dentro = max(0.0, k1 - k0)
        fala_dentro = dentro > 0.01 and db[int(k0 * 100):max(int(k0 * 100) + 1, int(k1 * 100))].max() >= -45
        if dur > 0.9 and dentro / dur < 0.3 and not fala_dentro:
            avisos.append(f"'{w['w']}' (bruto {w['s']:.2f}–{w['e']:.2f}s, {dur:.2f}s) quase não cai no trecho mantido e ali não há fala: "
                          'provável sobra de tomada descartada → confira e remova em correcoes.json')
        # alinha o início ao ataque real (energia): o ASR adianta 0,25–0,4 s depois de pausas
        i0 = int(s0 * 100)
        if db[i0:i0 + 8].max() < -50:
            j = np.where(db[i0:i0 + 45] > -45)[0]
            if len(j):
                s0 = (i0 + j[0]) / 100
        m = lambda t: seg['dst_start'] + (min(max(t, seg['src_start']), seg['src_end']) - seg['src_start']) / seg['speed']
        out.append({'w': re.sub(r'[.,]$', '', w['w']), 'start': round(m(s0), 3), 'end': round(m(w['e']), 3), 'src': round(s0, 2)})
    if out and out[0]['end'] < out[0]['start'] + 0.07:
        out[0]['end'] = round(out[0]['start'] + 0.07, 3)
    for x, y in zip(out, out[1:]):
        if y['start'] < x['start'] + 0.05:
            y['start'] = round(x['start'] + 0.05, 3)
        if x['end'] > y['start']:
            x['end'] = y['start']
        if y['end'] < y['start'] + 0.07:
            y['end'] = round(y['start'] + 0.07, 3)
    (P / 'data' / 'words.json').write_text(json.dumps(out, ensure_ascii=False, indent=0), encoding='utf-8')
    L = [f"{i}:{o['w']}@{o['start']:.2f}" for i, o in enumerate(out)]
    for k in range(0, len(L), 12):
        print(' '.join(L[k:k + 12]))
    print(f'{len(out)} palavras na timeline final → data/words.json')
    for av in avisos:
        print('AVISO:', av)


# ---------------------------------------------------------------- quadros
def cmd_quadros(a):
    P = proj(a)
    meta = json.loads((P / 'data' / 'bruto.json').read_text(encoding='utf-8'))
    E = json.loads((P / 'data' / 'edl.json').read_text(encoding='utf-8'))['segments']
    out = P / 'public' / 'frames'
    shutil.rmtree(out, ignore_errors=True)
    out.mkdir(parents=True)
    vf_scale = 'scale=1080:1920:flags=lanczos'
    if abs(meta['largura_exibida'] / meta['altura_exibida'] - 9 / 16) > 0.01:
        vf_scale = 'scale=1080:1920:force_original_aspect_ratio=increase:flags=lanczos,crop=1080:1920'
    for s in E:
        run(['ffmpeg', '-v', 'error', '-y', '-ss', f"{s['src_start']:.4f}", '-i', str(P / meta['arquivo']),
             '-vf', f"setpts=(PTS-STARTPTS)/{s['speed']},fps={FPS},{vf_scale},unsharp=5:5:0.35:5:5:0",
             '-frames:v', str(s['frames']), '-q:v', '2', '-start_number', str(s['dst_frame']), str(out / 'f_%05d.jpg')])
    n, tot = len(list(out.glob('f_*.jpg'))), sum(s['frames'] for s in E)
    print(n, 'quadros de', tot)
    if n != tot:
        die('número de quadros diferente do EDL')


# ---------------------------------------------------------------- voz
VOZ_CADEIA = ('highpass=f=75,afftdn=nr=6:nf=-60,equalizer=f=220:t=q:w=1.2:g=-1.5,equalizer=f=3500:t=q:w=1.0:g=2,deesser=i=0.3,'
              'acompressor=threshold=-20dB:ratio=2.5:attack=8:release=120:makeup=2,loudnorm=I=-16:TP=-1.5:LRA=9')


def envelope(x, sr, hop_s=0.001):
    h = int(sr * hop_s)
    n = len(x) // h
    return np.sqrt((x[:n * h].reshape(n, h) ** 2).mean(1))


def medir_atraso(ref, out, sr, speed, max_ms=120):
    """atraso (ms) da saída do rubberband em relação ao corte original reescalado no tempo (correlação de envoltórias)."""
    e1 = envelope(ref, sr)
    e1 = np.interp(np.arange(0, len(e1), speed), np.arange(len(e1)), e1)  # mesmo eixo de tempo da saída
    e2 = envelope(out, sr)
    n = min(len(e1), len(e2))
    e1, e2 = e1[:n] - e1[:n].mean(), e2[:n] - e2[:n].mean()
    best, lag = -1e9, 0
    for L in range(-max_ms, max_ms + 1):
        a_, b_ = (e1[:n - L], e2[L:]) if L >= 0 else (e1[-L:], e2[:n + L])
        c = float(np.dot(a_, b_))
        if c > best:
            best, lag = c, L
    return lag


def cmd_voz(a):
    P = proj(a)
    D = json.loads((P / 'data' / 'edl.json').read_text(encoding='utf-8'))
    E, sp = D['segments'], D['speed']
    sr, x = readwav(P / 'audio' / 'voz48k.wav')
    fade = int(0.004 * sr)  # microfade de 4 ms em cada emenda (evita clique)
    parts = []
    for s in E:
        i0, n = int(round(s['src_start'] * sr)), int(round((s['src_end'] - s['src_start']) * sr))
        seg = x[i0:i0 + n].copy()
        seg = np.pad(seg, (0, n - len(seg)))
        r = np.linspace(0, 1, fade)
        seg[:fade] *= r
        seg[-fade:] *= r[::-1]
        parts.append(seg)
    y = np.concatenate(parts)
    tmp_cut, tmp_out = P / 'audio' / '_voz_cortada.wav', P / 'audio' / '_voz_rb.wav'
    writewav(tmp_cut, sr, y)
    N = int(round(D['duration'] * sr))
    rb = (f'rubberband=tempo={sp}:pitch=1:transients=crisp:detector=compound:phase=laminar:window=standard:smoothing=off:'
          'formant=preserved:pitchq=quality:channels=together')
    run(['ffmpeg', '-v', 'error', '-y', '-i', str(tmp_cut), '-af', rb + ',' + VOZ_CADEIA, '-ar', str(SR_VOZ), '-ac', '1', str(tmp_out)])
    sr2, z = readwav(tmp_out)
    lag = medir_atraso(y, z, sr, sp)
    print(f'atraso medido da cadeia de voz: {lag} ms (esperado ≈ 26–28 ms: afftdn + rubberband)')
    if lag > 0:
        z = z[int(lag / 1000 * sr2):]
    z = np.pad(z[:N], (0, max(0, N - len(z))))
    resid = medir_atraso(y, z, sr, sp)
    print(f'atraso residual após compensação: {resid} ms (precisa ser 0 ± 2)')
    if abs(resid) > 2:
        print('AVISO: atraso residual acima de 2 ms — confira a sincronia labial na prévia.')
    writewav(P / 'public' / 'audio' / 'voice.wav', sr, z)
    n = sr // FPS
    F = int(round(D['duration'] * FPS))
    r = np.array([np.sqrt(np.mean(z[i * n:(i + 1) * n] ** 2)) if i * n < len(z) else 0.0 for i in range(F)])
    env = [round(float(v), 3) for v in r / (r.max() + 1e-9)]
    (P / 'data' / 'voice_env.json').write_text(json.dumps(env), encoding='utf-8')
    tmp_cut.unlink(missing_ok=True)
    tmp_out.unlink(missing_ok=True)
    print(f'voz {len(z) / sr:.2f}s → public/audio/voice.wav · envoltória ({F} quadros) → data/voice_env.json')


# ---------------------------------------------------------------- recortes
def cmd_recortes(a):
    import cv2
    import onnxruntime as ort
    P = proj(a)
    t = tools()
    need(t['u2net'], 'modelo u2net_human_seg.onnx')
    if not hasattr(cv2, 'ximgproc'):
        die('o OpenCV instalado não tem ximgproc (filtro guiado). Instale opencv-contrib-python-headless.')
    so = ort.SessionOptions()
    so.intra_op_num_threads = t['threads']
    sess = ort.InferenceSession(t['u2net'], so, providers=['CPUExecutionProvider'])
    inp = sess.get_inputs()[0]
    mean, std = np.array([0.485, 0.456, 0.406]), np.array([0.229, 0.224, 0.225])

    def seg(img):
        h, w = img.shape[:2]
        x = cv2.resize(img, (320, 320), interpolation=cv2.INTER_AREA)[:, :, ::-1] / 255.0
        x = x / np.max(x)
        x = ((x - mean) / std).transpose(2, 0, 1)[None].astype(np.float32)
        y = sess.run(None, {inp.name: x})[0][0, 0]
        y = (y - y.min()) / (y.max() - y.min() + 1e-8)
        m = cv2.resize(y.astype(np.float32), (w, h), interpolation=cv2.INTER_CUBIC).clip(0, 1)
        g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255
        return cv2.ximgproc.guidedFilter(g, m.astype(np.float32), 8, 1e-3).clip(0, 1)

    for r in a.intervalos:
        i, j = map(int, r.split('-'))
        prev = None
        for f in range(i, j + 1):
            img = cv2.imread(str(P / 'public' / 'frames' / f'f_{f:05d}.jpg'))
            if img is None:
                die(f'quadro {f} não existe')
            m = seg(img)
            if prev is not None:
                m = 0.75 * m + 0.25 * prev  # suavização temporal (evita borda tremendo)
            prev = m
            cv2.imwrite(str(P / 'public' / 'fg' / f'fg_{f:05d}.webp'), np.dstack([img, (m * 255).astype(np.uint8)]), [cv2.IMWRITE_WEBP_QUALITY, 92])
        # folha de conferência: recorte sobre magenta (borda de cabelo, mãos e microfone)
        k = (i + j) // 2
        img = cv2.imread(str(P / 'public' / 'fg' / f'fg_{k:05d}.webp'), cv2.IMREAD_UNCHANGED)
        al = img[:, :, 3:4] / 255.0
        bg = np.zeros_like(img[:, :, :3])
        bg[:] = (200, 40, 220)
        (P / 'qa').mkdir(exist_ok=True)
        cv2.imwrite(str(P / 'qa' / f'recorte_{i}-{j}.jpg'), cv2.resize((img[:, :, :3] * al + bg * (1 - al)).astype(np.uint8), (540, 960)))
        print(f'recortes {i}–{j} prontos · confira qa/recorte_{i}-{j}.jpg', flush=True)



# ---------------------------------------------------------------- mapa (direção adaptativa)
INTENCOES = [
    ('cta', r'\b(comenta|comente|segue|siga|salva|salve|compartilha|link|direct|bio|inscreve)\b'),
    ('pedido_literal', r'\b(se eu (quiser|pedir)|quero que|eu peço|pedi (para|pra))\b.*\b(coloc\w*|cort\w*|text\w*|tela|explod\w*|atrás|gir\w*|apare\w*|troc\w*|mud\w*|fique|fica)\b'),
    ('pergunta', r'(\?|^(como|por que|porque|qual|quanto|quantos|quantas|você sabia|sabia que|o que|será que)\b)'),
    ('numero', r'(\d|\b(dois|duas|três|quatro|cinco|seis|sete|oito|nove|dez|vinte|trinta|cem|cento|mil|milhão|milhões|bilhão|dobro|metade|por cento|reais)\b)'),
    ('lista', r'\b(primeiro|primeira|segundo|segunda|terceiro|terceira|passo|passos|dica|dicas|etapa|etapas|item)\b'),
    ('comparacao', r'\b(antes|depois|melhor|pior|mais do que|menos do que|versus|em vez|ao invés|diferença|igual)\b'),
    ('acao', r'\b(gravo|pego|jogo|mando|abro|clico|coloco|escrevo|faço|uso|envio|subo|baixo|crio|monto|edito|posto|conecto|instalo)\b'),
    ('resultado', r'\b(pronto|pronta|resultado|consegui|ficou|funciona|funcionou|feito|deu certo)\b'),
    ('afirmacao_forte', r'\b(nunca|sempre|ninguém|todo mundo|acabou|morreu|matar|segredo|absurdo|inacreditável|o maior|o melhor|simples)\b'),
]
SUGESTAO_INTENCAO = {
    'gancho': 'impacto no quadro 1: palavra-âncora com ação (ShatterText3D/Text3D), transformação do quadro ou objeto ligado à frase',
    'cta': 'NeonPrompt digitando a palavra falada + envio + NeonToasts (dentro de card)',
    'pedido_literal': 'EXECUTE exatamente o que a frase descreve, no instante da fala (ex.: PresenterStage cut, KineticGiantText atrás, layout que desce)',
    'pergunta': 'pergunta na tela respondida em seguida, ou NeonPoll só com opções ditas',
    'numero': 'NeonCounter / GrowthChart / MetricTiles com o valor EXATO dito (confira a palavra)',
    'lista': 'NeonChecklist / NeonSteps / StepTrack marcando na palavra de cada item',
    'comparacao': 'NeonBeforeAfter / VersusCard / risco no antigo',
    'acao': 'demonstração em etapas sincronizada com cada verbo (StepTrack, interface ilustrativa)',
    'resultado': 'transformação de estado: botão vira "feito", barra completa, Stamp',
    'afirmacao_forte': 'tipografia cinética (KineticStack), 3D ou reenquadramento forte na palavra',
}


def cmd_mapa(a):
    """Rascunho da direção: frases, intenções, assunto e sugestões. É um PONTO DE PARTIDA heurístico para o Claude
    decidir criativamente (references/18-direcao-adaptativa.md), não a direção final."""
    P = proj(a)
    src = P / 'data' / 'words.json'
    W = json.loads(src.read_text(encoding='utf-8'))
    voc = json.loads((KIT / 'config' / 'vocabulario_visual.json').read_text(encoding='utf-8'))
    # pontuação vem da transcrição bruta (words.json perde '.' e ','): casa cada palavra pelo tempo de origem
    raw_p = P / 'data' / 'words_raw.json'
    fim_frase = set()
    if raw_p.exists():
        R = json.loads(raw_p.read_text(encoding='utf-8'))
        for i, w in enumerate(W):
            c = [r for r in R if abs(r['s'] - w.get('src', -9)) < 0.6 and norm(r['w']) == norm(w['w'])]
            if c and min(c, key=lambda r: abs(r['s'] - w['src']))['w'].endswith(('.', '?', '!')):
                fim_frase.add(i)
    frases, cur = [], []
    for i, w in enumerate(W):
        cur.append(w)
        nxt = W[i + 1] if i + 1 < len(W) else None
        if nxt is None or i in fim_frase or w['w'].endswith(('?', '!', '.')) or nxt['start'] - w['end'] >= 0.45 or len(cur) >= 24:
            frases.append(cur)
            cur = []
    dur = W[-1]['end'] if W else 0
    total = {k: 0 for k in voc['dominios']}
    linhas = []
    for n, fr in enumerate(frases):
        txt = ' '.join(w['w'] for w in fr)
        low = txt.lower()
        low = re.sub(r'\b(tá bom|ta bom|né|certo|beleza|ok)\?', '', low).strip()  # pergunta retórica de fim de frase não conta
        ints = [k for k, rx in INTENCOES if re.search(rx, low)]
        if n == 0:
            ints = ['gancho'] + ints
        dom = {}
        toks = [norm(w['w']) for w in fr]
        for d, info in voc['dominios'].items():
            kws = {norm(x) for x in info['palavras']}
            c = sum(1 for t in toks if t in kws)
            if c:
                dom[d] = c
                total[d] += c
        linhas.append({'inicio': round(fr[0]['start'], 2), 'fim': round(fr[-1]['end'], 2), 'frase': txt, 'intencoes': ints, 'dominios': dom})
    rank = sorted([(v, k) for k, v in total.items() if v], reverse=True)
    principais = [k for _, k in rank[:2]] or ['criatividade_design']
    out = {'duracao': dur, 'dominios': dict((k, v) for v, k in rank), 'principais': principais, 'frases': linhas,
           'eventos_minimos': int(np.ceil(dur / 2.0)), 'eventos_alvo': int(round(dur / 1.0))}
    (P / 'data' / 'mapa_sugerido.json').write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding='utf-8')
    md = [f'# Mapa sugerido (rascunho heurístico) — {P.name}', '',
          f'Duração {dur:.1f}s · assunto provável: **{", ".join(principais)}** ({", ".join(f"{k} {v}" for v, k in rank) or "sem palavras-chave"})',
          f'Eventos visuais: mínimo {out["eventos_minimos"]} (regra dos 2 s), alvo ~{out["eventos_alvo"]} (1 por segundo, como os aprovados).', '',
          'Vocabulário do assunto (ideias, não obrigação):']
    for d in principais:
        info = voc['dominios'][d]
        md += [f'- **{d}**: metáforas — {"; ".join(info["metaforas"])}', f'  componentes — {", ".join(info["componentes"])}; 3D — {", ".join(info["tres_d"])}',
               f'  movimento — {info["movimento"]}; sons — {", ".join(info["sons"])}; criar — {"; ".join(info["criar"])}; evitar — {"; ".join(info["evitar"])}']
    md += ['', '| tempo | frase | intenções | sugestão |', '|---|---|---|---|']
    for l in linhas:
        sug = ' · '.join(SUGESTAO_INTENCAO[i] for i in l['intencoes'] if i in SUGESTAO_INTENCAO) or 'sem gatilho: reenquadramento, transformação do elemento atual ou tipografia na palavra-chave'
        md.append(f"| {l['inicio']:.2f}–{l['fim']:.2f} | {l['frase']} | {', '.join(l['intencoes']) or '—'} | {sug} |")
    md += ['', 'Próximo passo: decidir, frase a frase, entre REUTILIZAR, ADAPTAR ou CRIAR (references/18), variar a estrutura em',
           'relação aos vídeos anteriores e declarar os VISUAL_EVENTS.']
    (P / 'mapa_sugerido.md').write_text('\n'.join(md), encoding='utf-8')
    print('\n'.join(md[:8]))
    print(f'{len(linhas)} frases → mapa_sugerido.md / data/mapa_sugerido.json')

# ---------------------------------------------------------------- motor
def cmd_sfx(a):
    M = Path(a.motor).resolve()
    (M / 'public' / 'sfx').mkdir(parents=True, exist_ok=True)
    (M / 'public' / 'audio').mkdir(parents=True, exist_ok=True)
    run([sys.executable, str(Path(__file__).parent / 'sfx.py')], cwd=M)


def link(src, dst):
    if dst.is_symlink() or dst.is_file():
        dst.unlink()
    elif dst.is_dir():
        shutil.rmtree(dst)
    try:
        os.symlink(src, dst, target_is_directory=src.is_dir())
    except OSError:  # Windows sem permissão de link simbólico: copia
        (shutil.copytree if src.is_dir() else shutil.copy2)(src, dst)


def cmd_vincular(a):
    P, M = Path(a.proj).resolve(), Path(a.motor).resolve()
    for f in ['words.json', 'edl.json', 'voice_env.json']:
        if not (P / 'data' / f).exists():
            die(f'falta data/{f} no projeto (rode as etapas anteriores)')
        shutil.copy2(P / 'data' / f, M / 'src' / 'data' / f)
    link(P / 'public' / 'frames', M / 'public' / 'frames')
    link(P / 'public' / 'fg', M / 'public' / 'fg')
    (M / 'public' / 'audio').mkdir(parents=True, exist_ok=True)
    shutil.copy2(P / 'public' / 'audio' / 'voice.wav', M / 'public' / 'audio' / 'voice.wav')
    if not (M / 'public' / 'audio' / 'music.wav').exists():
        print('AVISO: falta public/audio/music.wav — rode `neon.py sfx --motor ...`')
    print(f'motor ligado ao projeto {P.name}')


def cmd_marca(a):
    M = Path(a.motor).resolve()
    src = KIT / 'config' / 'marcas' / f'{a.id}.json'
    if not src.exists():
        die(f'marca {a.id} não existe em config/marcas/')
    m = json.loads(src.read_text(encoding='utf-8'))
    for k in ['fundo', 'superficie', 'borda', 'acento', 'texto', 'texto_secundario', 'alerta']:
        if not re.match(r'^#[0-9A-Fa-f]{6}$', m['cores'].get(k, '')):
            die(f'cor "{k}" ausente ou fora do formato #RRGGBB')
    for k in ['titulo', 'mono']:
        f = m['fontes'][k]
        for key in ['variavel', 'arquivo_3d']:
            if key in f and not (M / 'public' / f[key]).exists():
                die(f'fonte {f[key]} não está em motor/public/')
    if m.get('logo') and not (M / 'public' / m['logo']).exists():
        die(f'logo {m["logo"]} não está em motor/public/')
    shutil.copy2(src, M / 'src' / 'brand' / 'marca.json')
    print(f'marca ativa: {m["nome"]} (recompile o motor para aplicar)')


def cmd_mixar(a):
    M = Path(a.motor).resolve()
    meta = json.loads(Path(a.meta).read_text(encoding='utf-8'))
    run([sys.executable, str(M / 'harness' / 'mix.py'), str(M / 'public'), a.meta, a.saida, str(M / 'src' / 'data' / 'voice_env.json')])
    print(f'{len(meta.get("SFX", []))} efeitos mixados → {a.saida}')


def cmd_finalizar(a):
    """Junta vídeo + mix com loudnorm em DUAS passagens (alvo −14 LUFS / −1 dBTP, linear quando possível)."""
    o = subprocess.run(['ffmpeg', '-hide_banner', '-i', a.audio, '-af', 'loudnorm=I=-14:TP=-1:LRA=11:print_format=json', '-f', 'null', '-'],
                       capture_output=True, text=True).stderr
    j = json.loads(o[o.rindex('{'):o.rindex('}') + 1])
    ln = (f"loudnorm=I=-14:TP=-1:LRA=11:measured_I={j['input_i']}:measured_TP={j['input_tp']}:measured_LRA={j['input_lra']}:"
          f"measured_thresh={j['input_thresh']}:offset={j['target_offset']}:linear=true")
    run(['ffmpeg', '-v', 'error', '-y', '-i', a.video, '-i', a.audio, '-af', ln,
         '-c:v', 'copy', '-c:a', 'aac', '-b:a', a.audio_kbps + 'k', '-ar', '48000', '-shortest', '-movflags', '+faststart', a.saida])
    print(f"mix medido {j['input_i']} LUFS / {j['input_tp']} dBTP → {a.saida} (confira com qa/qa_audio.py)")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest='cmd', required=True)
    p = sub.add_parser('preparar'); p.add_argument('video'); p.add_argument('--proj', required=True); p.set_defaults(f=cmd_preparar)
    p = sub.add_parser('transcrever'); p.add_argument('--proj', required=True); p.set_defaults(f=cmd_transcrever)
    p = sub.add_parser('rever'); p.add_argument('--proj', required=True); p.add_argument('janelas', nargs='+'); p.set_defaults(f=cmd_rever)
    p = sub.add_parser('formantes'); p.add_argument('--proj', required=True); p.add_argument('janelas', nargs='+'); p.set_defaults(f=cmd_formantes)
    p = sub.add_parser('texto'); p.add_argument('--proj', required=True); p.set_defaults(f=cmd_texto)
    p = sub.add_parser('edl'); p.add_argument('--proj', required=True); p.add_argument('--velocidade', type=float); p.set_defaults(f=cmd_edl)
    p = sub.add_parser('palavras'); p.add_argument('--proj', required=True); p.set_defaults(f=cmd_palavras)
    p = sub.add_parser('mapa'); p.add_argument('--proj', required=True); p.set_defaults(f=cmd_mapa)
    p = sub.add_parser('quadros'); p.add_argument('--proj', required=True); p.set_defaults(f=cmd_quadros)
    p = sub.add_parser('voz'); p.add_argument('--proj', required=True); p.set_defaults(f=cmd_voz)
    p = sub.add_parser('recortes'); p.add_argument('--proj', required=True); p.add_argument('intervalos', nargs='+'); p.set_defaults(f=cmd_recortes)
    p = sub.add_parser('sfx'); p.add_argument('--motor', required=True); p.set_defaults(f=cmd_sfx)
    p = sub.add_parser('vincular'); p.add_argument('--proj', required=True); p.add_argument('--motor', required=True); p.set_defaults(f=cmd_vincular)
    p = sub.add_parser('marca'); p.add_argument('acao', choices=['usar']); p.add_argument('id'); p.add_argument('--motor', required=True); p.set_defaults(f=cmd_marca)
    p = sub.add_parser('mixar'); p.add_argument('--motor', required=True); p.add_argument('--meta', required=True); p.add_argument('--saida', required=True); p.set_defaults(f=cmd_mixar)
    p = sub.add_parser('finalizar'); p.add_argument('--video', required=True); p.add_argument('--audio', required=True); p.add_argument('--saida', required=True)
    p.add_argument('--audio-kbps', default='256'); p.set_defaults(f=cmd_finalizar)
    a = ap.parse_args()
    a.f(a)


if __name__ == '__main__':
    main()
