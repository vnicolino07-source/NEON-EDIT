#!/usr/bin/env python3
"""
Rascunho de DIREÇÃO CRIATIVA ADAPTATIVA a partir da fala (data/words.json da timeline final).

Não decide sozinho: entrega ao Claude um mapa com (1) o assunto/nicho provável e o vocabulário visual sugerido,
(2) os momentos da fala que pedem efeito (números, listas, perguntas, comparações, ações, pedidos literais, nomes, CTA),
(3) os buracos de mais de 2 s sem candidato. O Claude escolhe, adapta ou cria (references/18-direcao-adaptativa.md).

Uso: python pipeline/direcao.py --proj projetos/<id> [--saida projetos/<id>/mapa_sugerido.md]
"""
import argparse, json, re, unicodedata
from collections import Counter
from pathlib import Path


def norm(s):
    s = unicodedata.normalize('NFD', s.lower())
    return re.sub(r'[^a-z0-9%$]', '', ''.join(c for c in s if unicodedata.category(c) != 'Mn'))


# ---- nichos: palavras-chave (normalizadas) → vocabulário visual ----------------------------------------------------
NICHOS = {
    'negócios / empreendedorismo': {
        'chaves': 'empresa negocio negocios cliente clientes venda vendas vender faturamento lucro margem empreender empreendedor socio produto servico mercado escala escalar contratar equipe ceo startup investimento investidor receita custo preco'.split(),
        'vocabulario': ['MetricBoard (indicadores que sobem na palavra)', 'Bars3D (crescimento em 3D)', 'LineChart (evolução)', 'FlowDiagram (processo do negócio)', 'Symbol3D arrow/coin/target', 'NeonBeforeAfter (antes × depois)'],
    },
    'marketing / redes sociais': {
        'chaves': 'marketing seguidores seguidor engajamento alcance views visualizacoes reels stories post postar conteudo viralizar viral algoritmo instagram tiktok youtube campanha anuncio trafego leads conversao funil marca audiencia'.split(),
        'vocabulario': ['LineChart (alcance/engajamento — só com números ditos)', 'MetricBoard (KPIs falados)', 'PostPanel / interface de post ilustrativa', 'KineticWords (frases de impacto)', 'Symbol3D heart/play/bubble', 'NeonPoll (enquete com opções faladas)'],
    },
    'tecnologia / IA': {
        'chaves': 'ia inteligencia artificial claude chatgpt gpt modelo prompt codigo programar software app aplicativo automacao automatizar robo dados api tecnologia ferramenta sistema computador algoritmo agente skill'.split(),
        'vocabulario': ['TechHUD (interface futurista com log digitado)', 'Network3D (rede/IA com pulsos)', 'NeonPrompt / OnePrompt (comando digitado)', 'StepTrack / FlowDiagram (o que a ferramenta faz)', 'LiveExplain (a tela explicando)', 'Symbol3D gear/bubble'],
    },
    'finanças': {
        'chaves': 'dinheiro reais real r$ investir investimento juros renda poupanca acoes bolsa cripto bitcoin divida salario economia economizar orcamento patrimonio dividendos'.split(),
        'vocabulario': ['MetricBoard (valores ditos)', 'LineChart / Bars3D (evolução)', 'Falling3D com notas (dinheiro)', 'Symbol3D coin/glyph "$"', 'NeonBeforeAfter'],
    },
    'educação / explicação': {
        'chaves': 'aprender aprenda ensinar aula curso estudo estudar explicar entender dica dicas passo erro erros metodo tecnica regra exemplo'.split(),
        'vocabulario': ['NeonSteps / FlowDiagram (passo a passo)', 'NeonChecklist (lista que marca na palavra)', 'KineticWords (conceito-chave)', 'NeonQuote (frase central)', 'Symbol3D glyph "?" / "!"'],
    },
    'saúde / bem-estar': {
        'chaves': 'saude treino treinar academia dieta alimentacao sono dormir corpo musculo peso energia ansiedade mente respirar habito habitos'.split(),
        'vocabulario': ['NeonChecklist (hábitos)', 'MetricBoard (números ditos: horas, repetições)', 'Clock3D (tempo/sono)', 'Symbol3D heart', 'KineticWords'],
    },
}
# ---- gatilhos de momento ---------------------------------------------------------------------------------------------
NUM_PALAVRAS = set('um uma dois duas tres quatro cinco seis sete oito nove dez onze doze quinze vinte trinta quarenta cinquenta cem cento cem mil milhao milhoes bilhao bilhoes metade dobro triplo'.split())
UNIDADES = set('%  porcento reais real dolares mil milhoes horas hora minutos minuto segundos dias dia semanas meses anos vezes x'.split())
LISTA = set('primeiro primeira segundo segunda terceiro terceira quarto passo etapa dica erro motivo maneira forma jeito'.split())
CONTRASTE = set('antes depois mas porem enquanto versus contra diferenca melhor pior'.split())
ACAO = set('gravo gravar pego jogo mando enviar envio mandar clico abro abrir coloco colocar escrevo digito crio criar posto postar edito editar corto cortar arrasto salvo baixo baixar'.split())
LITERAL = set('explodir explodindo explode atras gigante corta cortar tela meio cima baixo aparece aparecer surge some sumir gira girar cai cair voando zoom texto palavra'.split())
COMUNS = set('esse essa isso este esta isto ele ela eles elas voce eu nos tudo todo toda aqui agora entao depois quando porque como mas'.split())
CTA = set('comenta comente comentarios segue siga seguir salva salve compartilha compartilhe link bio direct dm inscreva'.split())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--proj', required=True)
    ap.add_argument('--saida')
    a = ap.parse_args()
    P = Path(a.proj)
    W = json.loads((P / 'data' / 'words.json').read_text(encoding='utf-8'))
    dur = json.loads((P / 'data' / 'edl.json').read_text(encoding='utf-8'))['duration']
    N = [norm(w['w']) for w in W]
    # pontuação original (o words.json final perde '.' e ','): recupera do words_raw.json pelo tempo do bruto
    fim_frase = set()
    rawp = P / 'data' / 'words_raw.json'
    if rawp.exists():
        R = json.loads(rawp.read_text(encoding='utf-8'))
        for i, w in enumerate(W):
            r = min(R, key=lambda x: abs(x['s'] - w.get('src', -9)))
            if r['w'].endswith(('.', '?', '!')) and abs(r['s'] - w.get('src', -9)) < 0.6:
                fim_frase.add(i)
    cont = Counter(N)
    pont = {k: sum(cont[c] for c in v['chaves']) for k, v in NICHOS.items()}
    nichos = sorted(pont.items(), key=lambda x: -x[1])
    momentos = []

    def add(i, tipo, sugestao):
        momentos.append((W[i]['start'], tipo, W[i]['w'], ' '.join(w['w'] for w in W[max(0, i - 3):i + 4]), sugestao))

    for i, n in enumerate(N):
        raw = W[i]['w']
        nx = N[i + 1] if i + 1 < len(N) else ''
        if re.search(r'\d', raw) or n in NUM_PALAVRAS and (nx in UNIDADES or re.search(r'\d', W[i + 1]['w'] if i + 1 < len(W) else '')):
            add(i, 'número', 'contador/indicador ou gráfico — só com o valor exato dito')
        if n in LISTA:
            add(i, 'lista/etapa', 'passo a passo, checklist ou fluxo; uma etapa por palavra')
        if raw.endswith('?'):
            add(i, 'pergunta', 'pergunta na tela, enquete ou pausa visual; resposta revela')
        if n in CONTRASTE:
            add(i, 'comparação', 'antes × depois, divisão de tela, risco no antigo')
        if n in ACAO:
            add(i, 'ação', 'demonstração da ação (interface ilustrativa, objeto em movimento)')
        if n in LITERAL:
            add(i, 'pedido literal', 'EXECUTE exatamente o que a frase descreve, no momento da fala')
        if n in CTA:
            add(i, 'CTA', 'campo de comentário/botão com a palavra falada; notificação')
        inicio_frase = i == 0 or (i - 1) in fim_frase or W[i - 1]['w'].endswith(('.', '?', '!')) or W[i]['start'] - W[i - 1]['end'] > 0.25
        if raw[:1].isupper() and not inicio_frase and len(n) > 2 and n not in COMUNS:
            add(i, 'nome próprio', 'conferir grafia; logo NUNCA (marca de terceiros): use o nome em texto ou ícone genérico')
    momentos.sort()
    # buracos: trechos > 2 s sem momento candidato (precisam de reenquadramento/evento próprio)
    ts = [0.0] + [m[0] for m in momentos] + [dur]
    buracos = [(x, y) for x, y in zip(ts, ts[1:]) if y - x > 2.0]
    gancho = ' '.join(w['w'] for w in W if w['start'] < 3.0)
    L = [f'# Mapa sugerido de direção — {P.name}', '',
         '> Rascunho automático. O Claude decide: reutilizar, adaptar ou CRIAR. Nada aqui autoriza inventar números ou falas.', '',
         f'**Duração:** {dur:.1f} s · **palavras:** {len(W)} ({len(W) / max(dur, 0.1):.2f}/s)', '',
         '## Assunto provável', '']
    for k, v in nichos[:3]:
        if v:
            L.append(f'- **{k}** (pontuação {v}): ' + '; '.join(NICHOS[k]['vocabulario']))
    if not any(v for _, v in nichos):
        L.append('- nenhum nicho dominante: decida pelo conteúdo (references/18)')
    L += ['', '## Gancho (primeiros 3 s)', '', f'"{gancho}" → impacto no quadro 1 ligado a esta frase; ≥ 3 transformações até ~4 s.', '',
          '## Momentos candidatos', '', '| Tempo | Tipo | Palavra | Contexto | Sugestão |', '|---|---|---|---|---|']
    L += [f'| {t:.2f} | {tp} | {w} | {ctx} | {sg} |' for t, tp, w, ctx, sg in momentos]
    L += ['', '## Buracos de mais de 2 s sem candidato', '']
    L += [f'- {x:.2f}–{y:.2f} s ({y - x:.2f} s): reenquadramento, transformação do elemento anterior ou efeito novo ligado à frase' for x, y in buracos] or ['- nenhum']
    txt = '\n'.join(L) + '\n'
    out = Path(a.saida) if a.saida else P / 'mapa_sugerido.md'
    out.write_text(txt, encoding='utf-8')
    print(f'nichos: {", ".join(f"{k}={v}" for k, v in nichos[:3])} | {len(momentos)} momentos | {len(buracos)} buracos > 2 s → {out}')


if __name__ == '__main__':
    main()
