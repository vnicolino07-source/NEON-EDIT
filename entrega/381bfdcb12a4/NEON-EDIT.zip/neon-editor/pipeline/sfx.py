# Efeitos sonoros e trilha gerados proceduralmente (sem material de terceiros)
import os
import numpy as np, scipy.io.wavfile as w, scipy.signal as sg
SR=48000; rng=np.random.default_rng(7)
def save(n,x,peak=0.9):
    x=x/ (np.max(np.abs(x))+1e-9)*peak; w.write(f'public/sfx/{n}.wav',SR,(x*32767).astype(np.int16))
def t(d): return np.arange(int(d*SR))/SR
def env(d,a,r,shape=2):
    tt=t(d); e=np.minimum(1,tt/a)*np.clip(1-(tt-a)/max(r,1e-3),0,1)**shape; return e
def bp(x,lo,hi,o=2): return sg.sosfilt(sg.butter(o,[lo,hi],'band',fs=SR,output='sos'),x)
def lp(x,f,o=2): return sg.sosfilt(sg.butter(o,f,'low',fs=SR,output='sos'),x)
def hp(x,f,o=2): return sg.sosfilt(sg.butter(o,f,'high',fs=SR,output='sos'),x)
def sweep_noise(d,f0,f1,q=0.35):
    n=rng.standard_normal(int(d*SR)); out=np.zeros_like(n); B=512
    for i in range(0,len(n),B):
        f=f0*(f1/f0)**(i/len(n)); out[i:i+B]=bp(n[max(0,i-2048):i+B],f*(1-q),f*(1+q))[-len(n[i:i+B]):]
    return out
# whoosh
d=0.5; tt=t(d); e=np.sin(np.pi*np.clip(tt/d,0,1))**2.2
save('whoosh',sweep_noise(d,500,3200)*e,0.8)
d=0.28; tt=t(d); e=np.sin(np.pi*np.clip(tt/d,0,1))**2
save('whoosh_short',sweep_noise(d,900,4500)*e,0.75)
# pop
d=0.14; tt=t(d); f=380+700*np.exp(-tt*40); ph=2*np.pi*np.cumsum(f)/SR
save('pop',np.sin(ph)*np.exp(-tt*32)+0.25*hp(rng.standard_normal(len(tt)),3000)*np.exp(-tt*300),0.85)
# click (UI)
d=0.05; tt=t(d); save('click',bp(rng.standard_normal(len(tt)),1800,6000)*np.exp(-tt*180)+0.5*np.sin(2*np.pi*2400*tt)*np.exp(-tt*120),0.7)
# type tick
d=0.035; tt=t(d); save('type',bp(rng.standard_normal(len(tt)),2500,7000)*np.exp(-tt*260),0.5)
# impact
d=0.9; tt=t(d); f=95*np.exp(-tt*3)+38; ph=2*np.pi*np.cumsum(f)/SR
x=np.sin(ph)*np.exp(-tt*5.5)+0.35*lp(rng.standard_normal(len(tt)),900)*np.exp(-tt*14)
save('impact',np.tanh(1.6*x),0.9)
# riser
d=1.1; tt=t(d); e=(tt/d)**2.4
x=sweep_noise(d,300,6000,0.25)*e+0.25*np.sin(2*np.pi*np.cumsum(200+700*(tt/d)**2)/SR)*e
x[-int(0.02*SR):]*=np.linspace(1,0,int(0.02*SR)); save('riser',x,0.7)
# ding (sucesso)
d=0.9; tt=t(d); x=sum(a*np.sin(2*np.pi*f*tt)*np.exp(-tt*k) for f,a,k in [(1318.5,1,5),(1975.5,.5,6),(2637,.25,8)])
x[:int(.003*SR)]*=np.linspace(0,1,int(.003*SR)); save('ding',x,0.6)
# papel / notas (farfalhar)
d=1.6; tt=t(d); g=np.zeros(len(tt))
for k in range(40):
    p=int(rng.uniform(0,d-0.08)*SR); L=int(rng.uniform(0.02,0.07)*SR); g[p:p+L]+=rng.uniform(.3,1)*np.hanning(L)*rng.standard_normal(L)
save('paper',bp(g,1500,8000)*np.sin(np.pi*tt/d)**0.6,0.55)
# tic-tac
d=0.9; x=np.zeros(int(d*SR))
for i,s in enumerate(np.arange(0,d-0.05,0.15)):
    L=int(0.03*SR); tt=np.arange(L)/SR; x[int(s*SR):int(s*SR)+L]+=bp(rng.standard_normal(L),2500 if i%2 else 3500,8000)*np.exp(-tt*220)
save('tick',x,0.5)
# swoosh reverso (tipografia)
d=0.6; tt=t(d); e=(tt/d)**3; e[-int(.03*SR):]*=np.linspace(1,0,int(.03*SR))
save('reverse',sweep_noise(d,800,5000)*e,0.7)
# estilhaço (palavra explodindo)
d=1.0; tt=t(d); x=0.9*np.tanh(2*np.sin(2*np.pi*np.cumsum(70*np.exp(-tt*4)+35)/SR)*np.exp(-tt*6))+0.6*bp(rng.standard_normal(len(tt)),400,9000)*np.exp(-tt*9)
g=np.zeros(len(tt))
for k in range(30):
    p=int(rng.uniform(0.05,0.7)*SR);L=int(0.012*SR);g[p:p+L]+=rng.uniform(.2,.6)*hp(rng.standard_normal(L),3000)*np.hanning(L)
save('shatter',x+g,0.9)
# laser (corte da tela)
d=0.45; tt=t(d); f=3200*np.exp(-tt*7)+300; x=np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-tt*5)+0.3*bp(rng.standard_normal(len(tt)),2000,8000)*np.exp(-tt*12)
save('laser',x,0.6)

# ---------- trilha (pad suave + batida leve, 96 BPM) ----------
D=float(os.environ.get("NEON_MUSIC_DUR", "56")); BPM=102; beat=60/BPM; tt=t(D); mus=np.zeros(len(tt))
chords=[[50,57,60,64,69],[46,53,57,62,65],[43,50,53,57,62],[45,52,55,59,64]]  # Dm9 Bbmaj7 Gm9 Am7 (v002)
bar=4*beat
def mtof(m): return 440*2**((m-69)/12)
for i,s in enumerate(np.arange(0,D,2*bar)):
    ch=chords[i%4]; L=int(min(2*bar+1.5,D-s)*SR); tl=np.arange(L)/SR
    e=np.minimum(1,tl/1.2)*np.clip(1-(tl-(2*bar))/1.5,0,1)
    x=sum(np.sin(2*np.pi*mtof(m)*tl+np.sin(2*np.pi*0.3*tl)*0.6)+0.4*np.sin(2*np.pi*mtof(m)*1.003*tl) for m in ch)
    a=int(s*SR); mus[a:a+L]+=lp(x,1800)*e*0.12
    # baixo
    bass=np.sin(2*np.pi*mtof(ch[0]-12)*tl)*np.minimum(1,tl/0.05)*np.exp(-tl*0.5)
    mus[a:a+L]+=bass*0.10
for s in np.arange(0,D-1,beat):
    k=int(round(s/beat))
    if k%2==0:
        L=int(0.35*SR); tl=np.arange(L)/SR; f=48+90*np.exp(-tl*30)
        mus[int(s*SR):int(s*SR)+L]+=np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-tl*9)*0.35
    L=int(0.05*SR); tl=np.arange(L)/SR; o=int((s+beat/2)*SR)
    if o+L<len(mus): mus[o:o+L]+=hp(rng.standard_normal(L),7000)*np.exp(-tl*90)*0.06
mus=lp(mus,9000)
w.write('public/audio/music.wav',SR,(mus/np.max(np.abs(mus))*0.8*32767).astype(np.int16))
print('ok')
