#!/usr/bin/env python3
"""
Gera um PROJETO DE DEMONSTRAÇÃO sintético (sem vídeo de ninguém) para testar o motor:
quadros 1080×1920 de um "apresentador" ilustrado, máscara exata dele, palavras com tempo, EDL, voz muda e envoltória.

Uso: python pipeline/demo.py --proj projetos/_demo [--motor motor]
Com --motor, já liga o projeto ao motor (equivale a `neon.py vincular`).
"""
import argparse, json, math, shutil, subprocess, sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

FPS = 30
TEXTO = ('Este vídeo de demonstração mostra o motor do editor funcionando. '
         'Primeiro uma palavra em três dimensões explode na tela. '
         'Depois o vídeo vira um celular e fica pronto para postar. '
         'Agora um texto gigante aparece atrás da minha cabeça. '
         'Se eu pedir ele corta essa tela no meio. '
         'A minha tela desce e a explicação fica em cima. '
         'Tudo com um só prompt. Comenta aí demo nos comentários.')
# densidade alvo ≈ 3,7–4,4 palavras/s (vídeos aprovados)


def palavras():
    ws, t = [], 0.08
    for frase in TEXTO.split('. '):
        tokens = frase.strip(' .').split(' ')
        for k, w in enumerate(tokens):
            d = max(0.12, 0.032 * len(w) + 0.07)
            ws.append({'w': w, 'start': round(t, 3), 'end': round(t + d, 3), 'src': round(t, 2)})
            t += d + 0.03
        t += 0.14  # pausa entre frases já reduzida para 0,14 s, como no corte real
    return ws, t + 0.3


_BASE = None


def desenhar(f, total, W=1080, H=1920):
    """Sala com luz quente/fria (cores "naturais", fora da paleta da marca) e um apresentador em silhueta estilizada."""
    global _BASE
    if _BASE is None:
        y = np.linspace(0, 1, H)[:, None]
        x = np.linspace(0, 1, W)[None, :]
        _BASE = Image.fromarray(np.clip(np.stack([150 + 50 * x - 30 * y, 140 + 20 * y + 0 * x, 175 - 40 * x + 10 * y], -1), 0, 255).astype(np.uint8))
    img = _BASE.copy()
    d = ImageDraw.Draw(img)
    for i in range(3):  # prateleiras ao fundo
        yy = 520 + i * 260
        d.rectangle([700, yy, 1030, yy + 14], fill=(70, 60, 80))
        d.rectangle([760 + 60 * i, yy - 70, 820 + 60 * i, yy], fill=(200 - 40 * i, 120 + 30 * i, 90))
    sway = 14 * math.sin(f / FPS * 1.7)
    nod = 6 * math.sin(f / FPS * 3.1)
    mask = Image.new('L', (W, H), 0)
    m = ImageDraw.Draw(mask)
    cx, cy = 540 + sway, 760 + nod
    m.ellipse([cx - 175, cy - 230, cx + 175, cy + 220], fill=255)  # cabeça
    m.rectangle([cx - 70, cy + 180, cx + 70, cy + 330], fill=255)  # pescoço
    m.rounded_rectangle([cx - 430, cy + 300, cx + 430, H + 200], radius=260, fill=255)  # ombros/tronco
    mask = mask.filter(ImageFilter.GaussianBlur(2))
    pessoa = Image.new('RGB', (W, H), (52, 46, 58))
    pd = ImageDraw.Draw(pessoa)
    pd.ellipse([cx - 175, cy - 230, cx + 175, cy + 220], fill=(214, 170, 140))  # rosto
    pd.ellipse([cx - 185, cy - 250, cx + 185, cy - 60], fill=(60, 44, 36))  # cabelo
    pd.ellipse([cx - 80, cy - 20, cx - 40, cy + 15], fill=(50, 40, 40))
    pd.ellipse([cx + 40, cy - 20, cx + 80, cy + 15], fill=(50, 40, 40))
    boca = 10 + 18 * abs(math.sin(f / FPS * 9))  # "fala"
    pd.ellipse([cx - 55, cy + 95, cx + 55, cy + 95 + boca], fill=(120, 50, 55))
    img.paste(pessoa, (0, 0), mask)
    return img, mask


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--proj', required=True)
    ap.add_argument('--motor')
    a = ap.parse_args()
    P = Path(a.proj).resolve()
    for s in ['data', 'public/frames', 'public/fg', 'public/audio']:
        (P / s).mkdir(parents=True, exist_ok=True)
    W_, dur = palavras()
    F = int(math.ceil(dur * FPS))
    edl = {'segments': [{'src_start': 0, 'src_end': round(F / FPS, 4), 'cut_start': 0, 'dst_start': 0, 'frames': F, 'dst_frame': 0, 'speed': 1.0,
                         'label': 'demonstração'}], 'duration': round(F / FPS, 4), 'speed': 1.0, 'cut_duration': round(F / FPS, 4)}
    (P / 'data' / 'words.json').write_text(json.dumps(W_, ensure_ascii=False, indent=0), encoding='utf-8')
    (P / 'data' / 'edl.json').write_text(json.dumps(edl, indent=1), encoding='utf-8')
    env = np.zeros(F)
    for w in W_:
        env[int(w['start'] * FPS):int(w['end'] * FPS) + 1] = 0.7
    (P / 'data' / 'voice_env.json').write_text(json.dumps([round(float(v), 3) for v in env]), encoding='utf-8')
    import scipy.io.wavfile as wf
    wf.write(P / 'public' / 'audio' / 'voice.wav', 48000, np.zeros(int(F / FPS * 48000), np.int16))
    for f in range(F):
        img, mask = desenhar(f, F)
        img.save(P / 'public' / 'frames' / f'f_{f:05d}.jpg', quality=88)
        rgba = img.copy()
        rgba.putalpha(mask)
        rgba.save(P / 'public' / 'fg' / f'fg_{f:05d}.webp', quality=85, method=0)
    print(f'demonstração: {len(W_)} palavras, {F} quadros ({F / FPS:.1f}s) em {P}')
    if a.motor:
        subprocess.run([sys.executable, str(Path(__file__).parent / 'neon.py'), 'vincular', '--proj', str(P), '--motor', a.motor], check=True)


if __name__ == '__main__':
    main()
