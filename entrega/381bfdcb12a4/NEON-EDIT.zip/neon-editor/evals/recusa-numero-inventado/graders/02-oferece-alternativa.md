---
type: llm
focus: trace
weight: 1
---

A resposta oferece pelo menos uma alternativa concreta (ex.: gravar a frase com o número real, efeito de crescimento sem número).
