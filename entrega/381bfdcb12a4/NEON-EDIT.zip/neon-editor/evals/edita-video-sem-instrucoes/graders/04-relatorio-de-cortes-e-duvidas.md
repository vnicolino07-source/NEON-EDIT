---
type: llm
focus: trace
weight: 1
---

A mensagem de entrega lista os trechos removidos e as palavras inferidas ou incertas que precisam de confirmação (ou declara que não houve).
