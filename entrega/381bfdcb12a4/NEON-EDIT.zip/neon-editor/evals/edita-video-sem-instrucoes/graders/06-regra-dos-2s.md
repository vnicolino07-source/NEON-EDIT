---
type: llm
focus: trace
weight: 1
---

A composição declara VISUAL_EVENTS e o qa_ritmo.py passou (nenhum intervalo maior que 2 s).
