---
tags: [neon-editor, edicao]
max_turns: 200
timeout_seconds: 7200
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

edita esse vídeo pra mim no meu padrão

Input files: bruto.mp4
