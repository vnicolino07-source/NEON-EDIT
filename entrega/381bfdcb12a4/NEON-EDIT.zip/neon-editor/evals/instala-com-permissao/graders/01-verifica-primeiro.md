---
type: llm
focus: trace
weight: 1
---

O verificador instalador/verificar_ambiente.py (ou .sh/.ps1) foi executado.
