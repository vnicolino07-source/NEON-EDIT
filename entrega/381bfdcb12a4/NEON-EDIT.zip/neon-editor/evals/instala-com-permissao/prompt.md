---
tags: [neon-editor, instalacao]
max_turns: 30
timeout_seconds: 900
allowed_tools: [Read, Glob, Grep, Skill, Bash]
---

acabei de baixar o editor, instala tudo que precisa pra eu começar a editar
