---
type: llm
focus: trace
weight: 1
---

motor/src/brand/marca.json passou a ser a marca cafe-lua e os arquivos de outras marcas em config/marcas não foram alterados.
