---
type: llm
focus: trace
weight: 1
---

Existe config/marcas/cafe-lua.json com acento #E85D3A e todas as cores obrigatórias no formato #RRGGBB.
