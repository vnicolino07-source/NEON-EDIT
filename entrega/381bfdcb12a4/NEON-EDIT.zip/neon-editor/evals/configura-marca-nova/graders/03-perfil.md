---
type: llm
focus: trace
weight: 1
---

config/perfil.json existe com marca cafe-lua, estilo dinamico, legendas, tres_d e sfx ativos.
