---
tags: [neon-editor, configuracao]
max_turns: 60
timeout_seconds: 1800
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

quero configurar o editor pra minha marca. o nome é Café Lua, a cor principal é #E85D3A, gosto de visual escuro, não tenho logo nem fonte própria. quero o estilo dinâmico com legendas, 3D e efeitos sonoros
