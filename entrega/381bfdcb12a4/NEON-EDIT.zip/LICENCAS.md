# Licenças

> **Pendente de decisão do titular:** a licença comercial do código do kit (o que o comprador pode fazer: uso próprio,
> uso em clientes, revenda). Este arquivo lista as obrigações de terceiros, que valem em qualquer caso.

## Código do kit

`neon-editor/` (componentes, composições, pipeline, QA, instalador, guias): © titular do NEON EDITOR. Licença comercial
a definir (ver pendência acima).

## Incluídos no pacote

| Item | Licença | Obrigação |
|---|---|---|
| Space Grotesk (`motor/public/fonts/SpaceGrotesk-*`) | SIL Open Font License 1.1 | manter `OFL-SpaceGrotesk.txt` junto; não vender a fonte isoladamente |
| JetBrains Mono (`motor/public/fonts/JetBrainsMono-*`) | SIL Open Font License 1.1 | manter `OFL-JetBrainsMono.txt` junto |
| Inter, EB Garamond, Instrument Serif, Poppins (`motor/public/fonts/`) | SIL Open Font License 1.1 | manter os `OFL-*.txt` junto |
| Caveat, Anton, Courier Prime, Orbitron, Playfair Display (estilos quadro, kinetic, jornal, retrô) | SIL Open Font License 1.1 (via @fontsource 5) | manter `OFL-caveat.txt`, `OFL-anton.txt`, `OFL-courier-prime.txt`, `OFL-orbitron.txt`, `OFL-playfair-display.txt` |
| Mapa-múndi (`motor/src/estilos/dados/mundo.json`) | Natural Earth 1:110m (domínio público), convertido do pacote `world-atlas` 2 (ISC) | — |
| Efeitos sonoros e trilha | gerados por `pipeline/sfx.py` (síntese própria, sem amostras de terceiros) | — |

As versões estáticas 400/500/700 das fontes foram geradas a partir das fontes variáveis (permitido pela OFL; o nome
reservado não é usado para uma fonte modificada distribuída separadamente).

## Instalados pelo comprador (não incluídos no pacote)

| Item | Licença (verificar na fonte antes de distribuir comercialmente) |
|---|---|
| Remotion 4.x | **Licença própria do Remotion**: gratuita para pessoas físicas e empresas pequenas; empresas maiores precisam de licença paga (ver remotion.dev/license). Cada comprador é responsável pela própria licença. |
| Three.js | MIT |
| React | MIT |
| ffmpeg | LGPL/GPL conforme o build (builds com rubberband geralmente são GPL) |
| Rubber Band Library | GPL (ou comercial) — usado via ffmpeg instalado pelo comprador |
| sherpa-onnx | Apache 2.0 |
| Modelo Parakeet TDT 0.6B v3 (NVIDIA) | CC-BY-4.0 (atribuição exigida) |
| u2net_human_seg (U²-Net) | Apache 2.0 (modelo do projeto U²-Net, distribuído pelo rembg) |
| numpy, scipy, Pillow, onnxruntime, OpenCV | BSD/MIT/Apache, conforme cada pacote |
| Playwright, esbuild | Apache 2.0 / MIT |

Os nomes Claude, Instagram, Reels e TikTok são marcas dos respectivos titulares; o kit não usa logotipos de terceiros.
As licenças acima foram listadas com o conhecimento disponível no desenvolvimento e **precisam ser conferidas** nas
fontes oficiais antes da venda (ver `neon-editor/references/17-pendencias-e-limitacoes.md`).
