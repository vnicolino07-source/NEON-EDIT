# Manifesto do pacote (versão 1.1.0-rc1 — candidata, NÃO validada para venda)

Gerado por `ferramentas/gerar_manifesto.py` em 23/11/2026 13:14. Hashes em `manifesto.json`.

**218 arquivos, 16.6 MB.**

## Incluídos

| Grupo | Arquivos | Tamanho |
|---|---|---|
| `LEIA-ME-PRIMEIRO.md` | 1 | 4 kB |
| `LICENCAS.md` | 1 | 3 kB |
| `RELATORIO_DE_EXPORTACAO.md` | 1 | 10 kB |
| `docs` | 3 | 8 kB |
| `exemplos-aprovados` | 12 | 12536 kB |
| `ferramentas` | 1 | 3 kB |
| `neon-editor/SKILL.md` | 1 | 11 kB |
| `neon-editor/config` | 9 | 22 kB |
| `neon-editor/evals` | 26 | 5 kB |
| `neon-editor/instalador` | 6 | 21 kB |
| `neon-editor/motor` | 118 | 3797 kB |
| `neon-editor/pipeline` | 4 | 57 kB |
| `neon-editor/qa` | 10 | 29 kB |
| `neon-editor/references` | 23 | 130 kB |
| `testes-portabilidade` | 2 | 5 kB |

## Gerados na máquina do comprador (não vão no pacote)

- `motor/node_modules/` (npm install), modelos de transcrição e recorte (`instalador/baixar_modelos.py`)
- `config/ferramentas.json`, `config/perfil.json`, marcas do comprador
- `motor/public/{frames,fg,audio,bundle.js}`, `projetos/` (dados de cada vídeo). `motor/src/data/*` vai com os dados sintéticos da demonstração, para o motor compilar antes do primeiro vídeo

## Deixados de fora de propósito (privados do titular)

- Vídeos brutos e masters do titular e os projetos completos das edições (do v002 entra só a prévia aprovada 720p, como referência).
- Biblioteca Neon original, guia pessoal e catálogo de referências com nomes de criadores (a marca Neon entra só como parte do exemplo v002, autorizado).
- Vídeos de referência de terceiros.
- Pacote de testes privado (regressão do v002) — fica em `PACOTE DE TESTES PRIVADO/` na pasta do titular.

## Itens que dependem de decisão do titular antes da venda

- `neon-editor/references/14-direcao-criativa.md` e `16-casos-aprovados.md` citam trechos da fala dos vídeos aprovados como exemplo. Autorize ou peça para anonimizar.
- `LICENCAS.md`: definir a licença comercial do kit e conferir as licenças de terceiros (em especial a do Remotion para clientes empresas).
- Nome comercial: o kit usa "NEON EDITOR" e prefixos `Neon*` no código (técnicos). Confirme o nome.
